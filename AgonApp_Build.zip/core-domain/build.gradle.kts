plugins {
    id("gaith.jvm.library")
}

// core-domain لا يعتمد على أي وحدة أخرى (§2.2). تبعيات الاختبار فقط.
dependencies {
    testImplementation(libs.junit)
    testImplementation(libs.archunit)
}

/*
 * ArchitectureRulesTest يفحص البايت كود المترجم لكل الوحدات (§2.3):
 * نمرر مسارات أصناف main و test لكل وحدة، ونجعل مهمة الاختبار تعتمد على ترجمتها،
 * ونعلنها مدخلات حتى لا تُعتبر المهمة UP-TO-DATE عند تغيّر وحدة أخرى.
 */
val archRoot: File = rootDir
val archMainClassDirs = mapOf(
    "core-domain" to listOf("core-domain/build/classes/kotlin/main"),
    "core-data" to listOf("core-data/build/classes/kotlin/main"),
    "core-store" to listOf("core-store/build/tmp/kotlin-classes/debug"),
    "app" to listOf(
        "app/build/tmp/kotlin-classes/debug",
        "app/build/intermediates/javac/debug/compileDebugJavaWithJavac/classes",
    ),
)
val archTestClassDirs = mapOf(
    "core-domain" to listOf("core-domain/build/classes/kotlin/test", "core-domain/build/classes/kotlin/testFixtures"),
    "core-data" to listOf("core-data/build/classes/kotlin/test", "core-data/build/classes/kotlin/testFixtures"),
    "core-store" to listOf("core-store/build/tmp/kotlin-classes/debugUnitTest", "core-store/build/tmp/kotlin-classes/debugAndroidTest"),
    "app" to listOf("app/build/tmp/kotlin-classes/debugUnitTest", "app/build/tmp/kotlin-classes/debugAndroidTest"),
)
val archMainSourceDirs = mapOf(
    "build-logic" to "build-logic/src/main",
    "core-domain" to "core-domain/src/main",
    "core-data" to "core-data/src/main",
    "core-store" to "core-store/src/main",
    "app" to "app/src/main",
)

fun encode(m: Map<String, List<String>>): String =
    m.entries.joinToString(";") { (k, v) -> k + "=" + v.joinToString(",") }

tasks.named<Test>("test") {
    dependsOn(
        ":core-data:classes",
        ":core-data:testClasses",
        ":core-store:compileDebugKotlin",
        ":core-store:compileDebugUnitTestKotlin",
        ":app:compileDebugKotlin",
        ":app:compileDebugJavaWithJavac",
        ":app:compileDebugUnitTestKotlin",
    )
    systemProperty("gaith.arch.root", archRoot.absolutePath)
    systemProperty("gaith.arch.mainClassDirs", encode(archMainClassDirs))
    systemProperty("gaith.arch.testClassDirs", encode(archTestClassDirs))
    systemProperty("gaith.arch.mainSourceDirs", archMainSourceDirs.entries.joinToString(";") { (k, v) -> "$k=$v" })
    val scanned = (archMainClassDirs.values.flatten() + archTestClassDirs.values.flatten() + archMainSourceDirs.values)
        .filterNot { it.startsWith("core-domain/") }
        .map { File(archRoot, it) }
    inputs.files(scanned).withPropertyName("archScannedTrees").optional()
}
