package com.ghaith.trading.domain.evaluation

/*
 * العقد المشترك §0: DataState و NetError.
 * يحتوي هذا الملف في M0 على أنواع الحالة والخطأ فقط (تُستعمل في PriceTriple داخل Money.kt).
 * نتيجة التقييم TradeEvaluation (Accepted|AdjustedAccept|Rejected|InsufficientData)
 * و EvaluationFacade تُبنيان في M2 حسب §4 من 01_architecture.
 */

/** حالة البيانات (§0). CACHED يحمل عمره بالمللي ثانية. */
sealed interface DataState {
    data object LIVE : DataState

    data class CACHED(val ageMs: Long) : DataState {
        init {
            require(ageMs >= 0) { "CACHED.ageMs must be >= 0, was $ageMs" }
        }
    }

    data object STALE : DataState

    data object ESTIMATED : DataState

    data object PAPER : DataState

    data object RECONSTRUCTED : DataState
}

/** أخطاء الشبكة السبعة (§0). */
enum class NetError {
    NETWORK,
    RATE_LIMIT,
    GEO_BLOCK,
    SCHEMA_DRIFT,
    STALE,
    GAP,
    CLOCK_SKEW,
}

/**
 * قيمة موسومة بحالتها وعمرها (§0: "كل رقم موسوم DataState").
 * [ageMs] عمر القيمة المقيس بالساعة المحقونة؛ [source] مصدرها (النقطة أو المخزن أو fixture).
 */
data class Observed<out T>(
    val value: T,
    val state: DataState,
    val ageMs: Long,
    val source: String,
) {
    init {
        require(ageMs >= 0) { "Observed.ageMs must be >= 0, was $ageMs" }
        require(source.isNotBlank()) { "Observed.source must not be blank" }
    }
}
