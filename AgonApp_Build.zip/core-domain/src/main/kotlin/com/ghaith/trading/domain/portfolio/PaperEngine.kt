package com.ghaith.trading.domain.portfolio

import com.ghaith.trading.domain.risk.PositionInput
import com.ghaith.trading.domain.risk.PositionOutput
import com.ghaith.trading.domain.risk.Side
import java.math.BigDecimal

/** سبب إغلاق الصفقة التجريبية. */
enum class CloseReason { MANUAL, STOP, TAKE_PROFIT, LIQUIDATION }

data class PaperPosition(
    val id: Long,
    val symbol: String,
    val side: Side,
    val entry: BigDecimal,
    val qty: BigDecimal,
    val leverage: Int,
    val margin: BigDecimal,
    val entryFee: BigDecimal,
    val liquidation: BigDecimal,
    val stop: BigDecimal?,
    val takeProfit: BigDecimal?,
    val openedAtMs: Long,
)

data class ClosedTrade(
    val id: Long,
    val symbol: String,
    val side: Side,
    val entry: BigDecimal,
    val exit: BigDecimal,
    val qty: BigDecimal,
    /** الربح/الخسارة الصافي بعد كل العمولات. */
    val pnl: BigDecimal,
    val reason: CloseReason,
    val openedAtMs: Long,
    val closedAtMs: Long,
)

data class Account(
    val balance: BigDecimal,
    val positions: List<PaperPosition>,
    val history: List<ClosedTrade>,
    val nextId: Long,
)

sealed interface OpenResult {
    data class Opened(val account: Account) : OpenResult

    data class Rejected(val reason: String) : OpenResult
}

/**
 * محرك التداول الورقي. دوال نقية بلا حالة؛ كل المبالغ BigDecimal.
 * الرصيد = النقد (يشمل الأرباح المحققة والعمولات). المتاح = الرصيد − الهامش المحجوز.
 * عند التصفية تُخسر قيمة الهامش كاملة (تبسيط).
 */
object PaperEngine {
    val START_BALANCE: BigDecimal = BigDecimal("10000")
    val TAKER_FEE: BigDecimal = BigDecimal("0.0005")

    private const val MAX_HISTORY = 200

    fun newAccount(): Account = Account(START_BALANCE, emptyList(), emptyList(), 1L)

    fun usedMargin(account: Account): BigDecimal =
        account.positions.fold(BigDecimal.ZERO) { sum, p -> sum.add(p.margin) }

    fun available(account: Account): BigDecimal = account.balance.subtract(usedMargin(account))

    fun unrealized(position: PaperPosition, price: BigDecimal): BigDecimal =
        when (position.side) {
            Side.LONG -> price.subtract(position.entry).multiply(position.qty)
            Side.SHORT -> position.entry.subtract(price).multiply(position.qty)
        }

    fun open(
        account: Account,
        symbol: String,
        input: PositionInput,
        output: PositionOutput,
        nowMs: Long,
    ): OpenResult {
        val needed = output.margin.add(output.entryFee)
        if (needed > available(account)) {
            return OpenResult.Rejected("الهامش المطلوب أكبر من الرصيد المتاح؛ خفّض المخاطرة أو ارفع الرافعة")
        }
        val position = PaperPosition(
            id = account.nextId,
            symbol = symbol,
            side = input.side,
            entry = input.entry,
            qty = output.qty,
            leverage = input.leverage,
            margin = output.margin,
            entryFee = output.entryFee,
            liquidation = output.liquidation,
            stop = input.stop,
            takeProfit = input.takeProfit,
            openedAtMs = nowMs,
        )
        return OpenResult.Opened(
            account.copy(
                balance = account.balance.subtract(output.entryFee),
                positions = account.positions + position,
                nextId = account.nextId + 1L,
            ),
        )
    }

    fun close(
        account: Account,
        id: Long,
        price: BigDecimal,
        reason: CloseReason,
        nowMs: Long,
    ): Account {
        val p = account.positions.firstOrNull { it.id == id } ?: return account
        val liquidated = reason == CloseReason.LIQUIDATION
        val gross = if (liquidated) p.margin.negate() else unrealized(p, price)
        val exitFee = if (liquidated) BigDecimal.ZERO else price.multiply(p.qty).multiply(TAKER_FEE)
        val net = gross.subtract(exitFee).subtract(p.entryFee)
        val trade = ClosedTrade(
            id = p.id,
            symbol = p.symbol,
            side = p.side,
            entry = p.entry,
            exit = price,
            qty = p.qty,
            pnl = net,
            reason = reason,
            openedAtMs = p.openedAtMs,
            closedAtMs = nowMs,
        )
        return account.copy(
            balance = account.balance.add(gross).subtract(exitFee),
            positions = account.positions.filter { it.id != id },
            history = (listOf(trade) + account.history).take(MAX_HISTORY),
        )
    }

    /** يطبّق الأسعار الحية: يغلق أي مركز لامس التصفية أو الوقف أو الهدف. */
    fun applyPrices(account: Account, prices: Map<String, BigDecimal>, nowMs: Long): Account {
        var current = account
        for (p in account.positions) {
            val price = prices[p.symbol] ?: continue
            val reason = trigger(p, price) ?: continue
            val fill = if (reason == CloseReason.LIQUIDATION) p.liquidation else price
            current = close(current, p.id, fill, reason, nowMs)
        }
        return current
    }

    private fun trigger(p: PaperPosition, price: BigDecimal): CloseReason? {
        val stop = p.stop
        val tp = p.takeProfit
        return when (p.side) {
            Side.LONG -> when {
                price <= p.liquidation -> CloseReason.LIQUIDATION
                stop != null && price <= stop -> CloseReason.STOP
                tp != null && price >= tp -> CloseReason.TAKE_PROFIT
                else -> null
            }
            Side.SHORT -> when {
                price >= p.liquidation -> CloseReason.LIQUIDATION
                stop != null && price >= stop -> CloseReason.STOP
                tp != null && price <= tp -> CloseReason.TAKE_PROFIT
                else -> null
            }
        }
    }
}
