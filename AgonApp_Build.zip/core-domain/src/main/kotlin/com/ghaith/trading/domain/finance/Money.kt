package com.ghaith.trading.domain.finance

import com.ghaith.trading.domain.evaluation.Observed
import java.math.BigDecimal
import java.math.BigInteger
import java.math.MathContext
import java.math.RoundingMode

/*
 * Money.kt — §1 من 02_financial_engine و§6.1 من 01_architecture.
 * أغلفة قيمية صارمة فوق BigDecimal: Money / Price / Qty، و PriceTriple.
 * لا Double ولا Float (تفرضه ArchitectureRulesTest على البايت كود).
 * لا تحويل ضمني بين الأنواع، وكل قسمة بمقياس ووضع تقريب صريحين.
 */

/** الدقة الوسيطة المعلنة (§1.2): 34 رقماً معنوياً، HALF_EVEN. */
object DecimalPolicy {
    val INTERMEDIATE: MathContext = MathContext(34, RoundingMode.HALF_EVEN)

    /** حد المقياس المقبول لأي قسمة صريحة. */
    const val MAX_SCALE: Int = 64
}

/** أخطاء إدخال/قيمة مصنفة. لا تتحول إلى صفر بديل ولا تُخفى. */
enum class ValueError {
    INVALID_PRICE_NON_POSITIVE,
    INVALID_QTY_NON_POSITIVE,
    INVALID_QTY_NEGATIVE,
    INVALID_STEP_NON_POSITIVE,
    INVALID_STEP_ORIGIN_NEGATIVE,
    BELOW_STEP_ORIGIN,
    NOT_ON_STEP,
    DIVISION_BY_ZERO,
    NON_POSITIVE_DENOMINATOR,
    INVALID_SCALE,
    INVALID_ROUNDING_MODE,
    INVALID_TICK_COUNT,
    INVALID_CURRENCY_CODE,
    INVALID_SYMBOL,
    INSTRUMENT_MISMATCH,
    CURRENCY_MISMATCH,
}

/** نتيجة مكتوبة: إما قيمة صالحة أو خطأ مصنف مع تفصيل. */
sealed interface Checked<out T> {
    data class Ok<out T>(val value: T) : Checked<T>

    data class Err(val error: ValueError, val detail: String) : Checked<Nothing>
}

/** عمليات عشرية صريحة المقياس والتقريب (§1.2). */
object Decimals {
    fun divide(
        numerator: BigDecimal,
        denominator: BigDecimal,
        scale: Int,
        mode: RoundingMode,
    ): Checked<BigDecimal> {
        if (denominator.signum() == 0) {
            return Checked.Err(ValueError.DIVISION_BY_ZERO, "$numerator / 0")
        }
        if (scale < 0 || scale > DecimalPolicy.MAX_SCALE) {
            return Checked.Err(ValueError.INVALID_SCALE, "scale=$scale")
        }
        if (mode == RoundingMode.UNNECESSARY) {
            return Checked.Err(ValueError.INVALID_ROUNDING_MODE, "UNNECESSARY is not an explicit rounding")
        }
        return Checked.Ok(numerator.divide(denominator, scale, mode))
    }

    /** تمثيل قانوني مستقل عن اللغة والمنطقة: بلا أس، بلا أصفار لاحقة، والصفر "0". */
    fun canonical(value: BigDecimal): String =
        if (value.signum() == 0) "0" else value.stripTrailingZeros().toPlainString()
}

/** عملة معلومة (مثل USDT). */
class Currency private constructor(val code: String) {
    override fun equals(other: Any?): Boolean = other is Currency && other.code == code

    override fun hashCode(): Int = code.hashCode()

    override fun toString(): String = code

    companion object {
        private val CODE = Regex("[A-Z0-9]{2,16}")

        fun of(code: String): Checked<Currency> =
            if (CODE.matches(code)) {
                Checked.Ok(Currency(code))
            } else {
                Checked.Err(ValueError.INVALID_CURRENCY_CODE, "code='$code'")
            }
    }
}

/** النطاق الوحيد المدعوم (§1.2 من 01_architecture): عقود USDT-M الدائمة. */
enum class Market {
    USDT_M_PERPETUAL,
}

/**
 * أداة تداول: الرمز كاملاً كما في exchangeInfo + السوق.
 * الهوية بمطابقة الرمز الكامل حرفياً؛ لا مطابقة جزئية.
 */
class Instrument private constructor(val symbol: String, val market: Market) {
    override fun equals(other: Any?): Boolean =
        other is Instrument && other.symbol == symbol && other.market == market

    override fun hashCode(): Int = 31 * symbol.hashCode() + market.hashCode()

    override fun toString(): String = "$symbol@$market"

    companion object {
        fun of(symbol: String, market: Market): Checked<Instrument> =
            if (symbol.isEmpty() || symbol.any { it.isWhitespace() }) {
                Checked.Err(ValueError.INVALID_SYMBOL, "symbol='$symbol'")
            } else {
                Checked.Ok(Instrument(symbol, market))
            }
    }
}

/**
 * خطوة قانونية (tickSize أو stepSize) مع أصلها الذي تحدده مرشحات المنصة
 * (minPrice لـ PRICE_FILTER، minQty لـ LOT_SIZE). القيمة القانونية = origin + n×size، n≥0 صحيح.
 * المطابقة تامة: لا تُقبل قيمة "قريبة" من الخطوة (§1.2).
 */
class Step private constructor(val size: BigDecimal, val origin: BigDecimal) {
    fun isOnStep(value: BigDecimal): Boolean =
        value >= origin && value.subtract(origin).remainder(size).signum() == 0

    /** عدد الوحدات الصحيح n لقيمة قانونية؛ خطأ إن لم تكن على الخطوة تماماً. */
    fun units(value: BigDecimal): Checked<BigInteger> {
        if (value < origin) {
            return Checked.Err(ValueError.BELOW_STEP_ORIGIN, "value=$value origin=$origin")
        }
        val offset = value.subtract(origin)
        if (offset.remainder(size).signum() != 0) {
            return Checked.Err(ValueError.NOT_ON_STEP, "value=$value step=$size origin=$origin")
        }
        return Checked.Ok(offset.divide(size, 0, RoundingMode.UNNECESSARY).toBigIntegerExact())
    }

    fun fromUnits(units: BigInteger): BigDecimal {
        require(units.signum() >= 0) { "units must be >= 0, was $units" }
        return origin.add(size.multiply(BigDecimal(units)))
    }

    /** أكبر قيمة قانونية ≤ value. */
    fun floor(value: BigDecimal): Checked<BigDecimal> {
        if (value < origin) {
            return Checked.Err(ValueError.BELOW_STEP_ORIGIN, "value=$value origin=$origin")
        }
        val units = value.subtract(origin).divide(size, 0, RoundingMode.FLOOR)
        return Checked.Ok(origin.add(size.multiply(units)))
    }

    /** أصغر قيمة قانونية ≥ value (للمقارنة، مثل حد MIN_NOTIONAL). */
    fun ceil(value: BigDecimal): Checked<BigDecimal> {
        if (value <= origin) {
            return Checked.Ok(origin)
        }
        val units = value.subtract(origin).divide(size, 0, RoundingMode.CEILING)
        return Checked.Ok(origin.add(size.multiply(units)))
    }

    /**
     * floor على الخطوة لحاصل القسمة numerator/denominator بدقة تامة (بلا تقريب وسيط):
     * n = ⌊(numerator − origin×denominator) / (denominator×size)⌋.
     * يُستعمل لـ Q_wallet=floorToStep(R/lossPerUnit) دون خطر تقريب مزدوج.
     */
    fun floorOfQuotient(numerator: BigDecimal, denominator: BigDecimal): Checked<BigDecimal> {
        val check = checkDenominator(numerator, denominator)
        if (check != null) return check
        val shifted = numerator.subtract(origin.multiply(denominator))
        if (shifted.signum() < 0) {
            return Checked.Err(ValueError.BELOW_STEP_ORIGIN, "$numerator/$denominator < origin=$origin")
        }
        val units = shifted.divide(denominator.multiply(size), 0, RoundingMode.FLOOR)
        return Checked.Ok(origin.add(size.multiply(units)))
    }

    /** ceil على الخطوة لحاصل القسمة بدقة تامة (مثل أقل كمية تحقق حداً اسمياً). */
    fun ceilOfQuotient(numerator: BigDecimal, denominator: BigDecimal): Checked<BigDecimal> {
        val check = checkDenominator(numerator, denominator)
        if (check != null) return check
        val shifted = numerator.subtract(origin.multiply(denominator))
        if (shifted.signum() <= 0) {
            return Checked.Ok(origin)
        }
        val units = shifted.divide(denominator.multiply(size), 0, RoundingMode.CEILING)
        return Checked.Ok(origin.add(size.multiply(units)))
    }

    private fun checkDenominator(numerator: BigDecimal, denominator: BigDecimal): Checked.Err? =
        when {
            denominator.signum() == 0 ->
                Checked.Err(ValueError.DIVISION_BY_ZERO, "$numerator / 0")
            denominator.signum() < 0 ->
                Checked.Err(ValueError.NON_POSITIVE_DENOMINATOR, "$numerator / $denominator")
            else -> null
        }

    override fun equals(other: Any?): Boolean =
        other is Step && other.size.compareTo(size) == 0 && other.origin.compareTo(origin) == 0

    override fun hashCode(): Int =
        31 * Decimals.canonical(size).hashCode() + Decimals.canonical(origin).hashCode()

    override fun toString(): String = "Step(size=${Decimals.canonical(size)}, origin=${Decimals.canonical(origin)})"

    companion object {
        fun of(size: BigDecimal, origin: BigDecimal): Checked<Step> =
            when {
                size.signum() <= 0 -> Checked.Err(ValueError.INVALID_STEP_NON_POSITIVE, "size=$size")
                origin.signum() < 0 -> Checked.Err(ValueError.INVALID_STEP_ORIGIN_NEGATIVE, "origin=$origin")
                else -> Checked.Ok(Step(size, origin))
            }
    }
}

/** وحدة التسوية النقدية: أصغر وحدة قانونية لعملة (مقياسها العشري). */
class SettlementUnit private constructor(val currency: Currency, val scale: Int) {
    override fun equals(other: Any?): Boolean =
        other is SettlementUnit && other.currency == currency && other.scale == scale

    override fun hashCode(): Int = 31 * currency.hashCode() + scale

    override fun toString(): String = "SettlementUnit($currency, scale=$scale)"

    companion object {
        fun of(currency: Currency, scale: Int): Checked<SettlementUnit> =
            if (scale < 0 || scale > DecimalPolicy.MAX_SCALE) {
                Checked.Err(ValueError.INVALID_SCALE, "scale=$scale")
            } else {
                Checked.Ok(SettlementUnit(currency, scale))
            }
    }
}

/**
 * مبلغ بعملة معلومة. موقّع: الأرباح والخسائر والتدفقات قد تكون سالبة (§1.1).
 * المساواة عددية (1.0 == 1.00) ضمن العملة نفسها.
 */
class Money private constructor(val amount: BigDecimal, val currency: Currency) : Comparable<Money> {
    operator fun plus(other: Money): Money {
        requireSameCurrency(other)
        return Money(amount.add(other.amount), currency)
    }

    operator fun minus(other: Money): Money {
        requireSameCurrency(other)
        return Money(amount.subtract(other.amount), currency)
    }

    operator fun unaryMinus(): Money = Money(amount.negate(), currency)

    /** ضرب تام بلا تقريب. */
    fun times(factor: BigDecimal): Money = Money(amount.multiply(factor), currency)

    fun divide(divisor: BigDecimal, scale: Int, mode: RoundingMode): Checked<Money> =
        when (val q = Decimals.divide(amount, divisor, scale, mode)) {
            is Checked.Ok -> Checked.Ok(Money(q.value, currency))
            is Checked.Err -> q
        }

    /** تقريب نحو +∞ إلى وحدة التسوية (اتجاه محافظ للتكاليف والمخصصات، §1.2). */
    fun ceilTo(unit: SettlementUnit): Money {
        require(unit.currency == currency) { "settlement currency ${unit.currency} != $currency" }
        return Money(amount.setScale(unit.scale, RoundingMode.CEILING), currency)
    }

    /** تقريب نحو −∞ إلى وحدة التسوية. */
    fun floorTo(unit: SettlementUnit): Money {
        require(unit.currency == currency) { "settlement currency ${unit.currency} != $currency" }
        return Money(amount.setScale(unit.scale, RoundingMode.FLOOR), currency)
    }

    val signum: Int get() = amount.signum()

    override fun compareTo(other: Money): Int {
        requireSameCurrency(other)
        return amount.compareTo(other.amount)
    }

    override fun equals(other: Any?): Boolean =
        other is Money && other.currency == currency && other.amount.compareTo(amount) == 0

    override fun hashCode(): Int = 31 * currency.hashCode() + Decimals.canonical(amount).hashCode()

    override fun toString(): String = "${Decimals.canonical(amount)} $currency"

    private fun requireSameCurrency(other: Money) {
        require(other.currency == currency) { "currency mismatch: $currency vs ${other.currency}" }
    }

    companion object {
        fun of(amount: BigDecimal, currency: Currency): Money = Money(amount, currency)

        fun zero(currency: Currency): Money = Money(BigDecimal.ZERO, currency)
    }
}

/**
 * سعر موجب فقط (§1.1) لأداة محددة، مقوَّم بعملة التسعير، ومرتبط بخطوة السعر (tickSize وأصلها).
 * السعر قد لا يكون على الخطوة (مثل وقف مطلوب 99.495)؛ [isOnTick] يقرر ذلك والتقريب صريح الاتجاه.
 */
class Price private constructor(
    val value: BigDecimal,
    val instrument: Instrument,
    val quote: Currency,
    val tick: Step,
) : Comparable<Price> {
    val isOnTick: Boolean get() = tick.isOnStep(value)

    fun tickUnits(): Checked<BigInteger> = tick.units(value)

    fun floorToTick(): Checked<Price> = wrap(tick.floor(value))

    fun ceilToTick(): Checked<Price> = wrap(tick.ceil(value))

    /** السعر + n×tick (n ≥ 0). */
    fun plusTicks(n: Long): Checked<Price> {
        if (n < 0) return Checked.Err(ValueError.INVALID_TICK_COUNT, "n=$n")
        return of(value.add(tick.size.multiply(BigDecimal.valueOf(n))), instrument, quote, tick)
    }

    /** السعر − n×tick (n ≥ 0)؛ ناتج غير موجب ⇒ خطأ مصنف. */
    fun minusTicks(n: Long): Checked<Price> {
        if (n < 0) return Checked.Err(ValueError.INVALID_TICK_COUNT, "n=$n")
        return of(value.subtract(tick.size.multiply(BigDecimal.valueOf(n))), instrument, quote, tick)
    }

    override fun compareTo(other: Price): Int {
        require(other.instrument == instrument) { "instrument mismatch: $instrument vs ${other.instrument}" }
        return value.compareTo(other.value)
    }

    override fun equals(other: Any?): Boolean =
        other is Price && other.instrument == instrument && other.quote == quote &&
            other.tick == tick && other.value.compareTo(value) == 0

    override fun hashCode(): Int =
        ((31 * instrument.hashCode() + quote.hashCode()) * 31 + tick.hashCode()) * 31 +
            Decimals.canonical(value).hashCode()

    override fun toString(): String = "${Decimals.canonical(value)} $quote ($instrument)"

    private fun wrap(result: Checked<BigDecimal>): Checked<Price> =
        when (result) {
            is Checked.Ok -> of(result.value, instrument, quote, tick)
            is Checked.Err -> result
        }

    companion object {
        fun of(value: BigDecimal, instrument: Instrument, quote: Currency, tick: Step): Checked<Price> =
            if (value.signum() <= 0) {
                Checked.Err(ValueError.INVALID_PRICE_NON_POSITIVE, "price=$value")
            } else {
                Checked.Ok(Price(value, instrument, quote, tick))
            }
    }
}

/**
 * كمية موجبة (§1.1). الاتجاه حقل مستقل (LONG/SHORT) ولا يُرمَّز بالإشارة.
 * الصفر ⇒ INVALID_QTY_NON_POSITIVE، السالب ⇒ INVALID_QTY_NEGATIVE.
 */
class Qty private constructor(
    val value: BigDecimal,
    val instrument: Instrument,
    val step: Step,
) : Comparable<Qty> {
    val isOnStep: Boolean get() = step.isOnStep(value)

    fun stepUnits(): Checked<BigInteger> = step.units(value)

    override fun compareTo(other: Qty): Int {
        require(other.instrument == instrument) { "instrument mismatch: $instrument vs ${other.instrument}" }
        return value.compareTo(other.value)
    }

    override fun equals(other: Any?): Boolean =
        other is Qty && other.instrument == instrument && other.step == step &&
            other.value.compareTo(value) == 0

    override fun hashCode(): Int =
        (31 * instrument.hashCode() + step.hashCode()) * 31 + Decimals.canonical(value).hashCode()

    override fun toString(): String = "${Decimals.canonical(value)} ($instrument)"

    companion object {
        fun of(value: BigDecimal, instrument: Instrument, step: Step): Checked<Qty> =
            when {
                value.signum() == 0 -> Checked.Err(ValueError.INVALID_QTY_NON_POSITIVE, "qty=$value")
                value.signum() < 0 -> Checked.Err(ValueError.INVALID_QTY_NEGATIVE, "qty=$value")
                else -> Checked.Ok(Qty(value, instrument, step))
            }

        /** floorToStep(numerator/denominator) بدقة تامة؛ لا ترفع الكمية أبداً. */
        fun floorToStep(
            numerator: BigDecimal,
            denominator: BigDecimal,
            instrument: Instrument,
            step: Step,
        ): Checked<Qty> =
            when (val floored = step.floorOfQuotient(numerator, denominator)) {
                is Checked.Ok -> of(floored.value, instrument, step)
                is Checked.Err -> floored
            }
    }
}

/** القيمة الاسمية N = السعر × الكمية بعملة التسعير، بضرب تام. */
fun notional(price: Price, qty: Qty): Checked<Money> =
    if (price.instrument != qty.instrument) {
        Checked.Err(ValueError.INSTRUMENT_MISMATCH, "${price.instrument} vs ${qty.instrument}")
    } else {
        Checked.Ok(Money.of(price.value.multiply(qty.value), price.quote))
    }

/** خانة سعر في الثلاثي: موجود موسوم، أو مفقود بسبب. لا يُستبدل المفقود بسعر آخر (§1.4). */
sealed interface PriceSlot {
    data class Present(val observed: Observed<Price>) : PriceSlot

    data class Missing(val reason: String) : PriceSlot {
        init {
            require(reason.isNotBlank()) { "Missing.reason must not be blank" }
        }
    }
}

/**
 * PriceTriple(contractPrice, markPrice, executionPrice) — ثلاث قيم مستقلة (§1.4)،
 * كل منها بحالته وعمره. يُرفض خلط أدوات مختلفة داخل الثلاثي.
 */
class PriceTriple private constructor(
    val instrument: Instrument,
    val contractPrice: PriceSlot,
    val markPrice: PriceSlot,
    val executionPrice: PriceSlot,
) {
    override fun equals(other: Any?): Boolean =
        other is PriceTriple && other.instrument == instrument &&
            other.contractPrice == contractPrice && other.markPrice == markPrice &&
            other.executionPrice == executionPrice

    override fun hashCode(): Int =
        ((31 * instrument.hashCode() + contractPrice.hashCode()) * 31 + markPrice.hashCode()) * 31 +
            executionPrice.hashCode()

    override fun toString(): String =
        "PriceTriple($instrument, contract=$contractPrice, mark=$markPrice, execution=$executionPrice)"

    companion object {
        fun of(
            instrument: Instrument,
            contractPrice: PriceSlot,
            markPrice: PriceSlot,
            executionPrice: PriceSlot,
        ): Checked<PriceTriple> {
            val slots = listOf(
                "contractPrice" to contractPrice,
                "markPrice" to markPrice,
                "executionPrice" to executionPrice,
            )
            for ((name, slot) in slots) {
                if (slot is PriceSlot.Present && slot.observed.value.instrument != instrument) {
                    return Checked.Err(
                        ValueError.INSTRUMENT_MISMATCH,
                        "$name instrument ${slot.observed.value.instrument} != $instrument",
                    )
                }
            }
            return Checked.Ok(PriceTriple(instrument, contractPrice, markPrice, executionPrice))
        }
    }
}
