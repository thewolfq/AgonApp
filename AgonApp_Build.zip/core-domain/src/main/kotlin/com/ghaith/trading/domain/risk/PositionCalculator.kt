package com.ghaith.trading.domain.risk

import java.math.BigDecimal
import java.math.RoundingMode

/** اتجاه الصفقة: شراء (LONG) أو بيع (SHORT). */
enum class Side { LONG, SHORT }

/**
 * مدخلات حاسبة المركز (عقود USDT-M دائمة، هامش معزول).
 * feeRate: عمولة Taker لكل جهة. maintenanceRate: نسبة هامش الصيانة التقريبية.
 */
data class PositionInput(
    val side: Side,
    val entry: BigDecimal,
    val stop: BigDecimal,
    val takeProfit: BigDecimal?,
    val leverage: Int,
    val riskAmount: BigDecimal,
    val feeRate: BigDecimal = PositionCalculator.DEFAULT_TAKER_FEE,
    val maintenanceRate: BigDecimal = PositionCalculator.DEFAULT_MAINTENANCE,
)

data class PositionOutput(
    val qty: BigDecimal,
    val notional: BigDecimal,
    val margin: BigDecimal,
    val entryFee: BigDecimal,
    val liquidation: BigDecimal,
    /** الخسارة الصافية عند الوقف (تشمل عمولتي الدخول والخروج). */
    val lossAtStop: BigDecimal,
    /** الربح الصافي عند الهدف، أو null إن لم يُحدَّد هدف. */
    val profitAtTp: BigDecimal?,
    /** نسبة العائد إلى المخاطرة الصافية (ربح الهدف بعد الرسوم ÷ خسارة الوقف بعد الرسوم)، أو null. */
    val rewardRisk: BigDecimal?,
)

sealed interface CalcResult {
    data class Ok(val value: PositionOutput) : CalcResult

    data class Invalid(val reason: String) : CalcResult
}

object PositionCalculator {
    val DEFAULT_TAKER_FEE: BigDecimal = BigDecimal("0.0005")
    val DEFAULT_MAINTENANCE: BigDecimal = BigDecimal("0.005")
    const val MAX_LEVERAGE: Int = 125

    private const val SCALE = 12

    fun calculate(input: PositionInput): CalcResult {
        val isLong = input.side == Side.LONG
        val entry = input.entry
        val stop = input.stop
        val tp = input.takeProfit
        val lev = input.leverage

        if (entry.signum() <= 0 || stop.signum() <= 0) {
            return CalcResult.Invalid("سعر الدخول والوقف يجب أن يكونا أكبر من صفر")
        }
        if (lev < 1 || lev > MAX_LEVERAGE) {
            return CalcResult.Invalid("الرافعة يجب أن تكون بين 1 و $MAX_LEVERAGE")
        }
        if (input.riskAmount.signum() <= 0) {
            return CalcResult.Invalid("مبلغ المخاطرة يجب أن يكون أكبر من صفر")
        }
        if (input.feeRate.signum() < 0 || input.feeRate >= BigDecimal.ONE) {
            return CalcResult.Invalid("نسبة العمولة يجب أن تكون من صفر إلى أقل من 100%")
        }
        if (input.maintenanceRate.signum() < 0 || input.maintenanceRate >= BigDecimal.ONE) {
            return CalcResult.Invalid("نسبة هامش الصيانة يجب أن تكون من صفر إلى أقل من 100%")
        }
        if (isLong && stop >= entry) {
            return CalcResult.Invalid("في الشراء يجب أن يكون الوقف أقل من سعر الدخول")
        }
        if (!isLong && stop <= entry) {
            return CalcResult.Invalid("في البيع يجب أن يكون الوقف أعلى من سعر الدخول")
        }
        if (tp != null) {
            if (tp.signum() <= 0) return CalcResult.Invalid("الهدف يجب أن يكون أكبر من صفر")
            if (isLong && tp <= entry) return CalcResult.Invalid("في الشراء يجب أن يكون الهدف أعلى من الدخول")
            if (!isLong && tp >= entry) return CalcResult.Invalid("في البيع يجب أن يكون الهدف أقل من الدخول")
        }

        val levDec = BigDecimal(lev)
        val distance = entry.subtract(stop).abs()
        val riskPerUnit = distance.add(entry.add(stop).multiply(input.feeRate))
        val qty = input.riskAmount.divide(riskPerUnit, SCALE, RoundingMode.DOWN)
        if (qty.signum() <= 0) {
            return CalcResult.Invalid("الكمية الناتجة صفر؛ ارفع مبلغ المخاطرة أو قرّب الوقف")
        }

        val notional = qty.multiply(entry)
        val margin = notional.divide(levDec, SCALE, RoundingMode.UP)
        val entryFee = notional.multiply(input.feeRate)
        val inverseLeverage = BigDecimal.ONE.divide(levDec, SCALE, RoundingMode.HALF_EVEN)
        val liquidation = if (isLong) {
            entry.multiply(BigDecimal.ONE.subtract(inverseLeverage).add(input.maintenanceRate))
        } else {
            entry.multiply(BigDecimal.ONE.add(inverseLeverage).subtract(input.maintenanceRate))
        }

        if (isLong && stop <= liquidation) {
            return CalcResult.Invalid("الوقف خلف سعر التصفية؛ خفّض الرافعة أو قرّب الوقف")
        }
        if (!isLong && stop >= liquidation) {
            return CalcResult.Invalid("الوقف خلف سعر التصفية؛ خفّض الرافعة أو قرّب الوقف")
        }

        val exitFeeAtStop = qty.multiply(stop).multiply(input.feeRate)
        val lossAtStop = qty.multiply(distance).add(entryFee).add(exitFeeAtStop)

        var profitAtTp: BigDecimal? = null
        var rewardRisk: BigDecimal? = null
        if (tp != null) {
            val tpDistance = tp.subtract(entry).abs()
            val exitFeeAtTp = qty.multiply(tp).multiply(input.feeRate)
            profitAtTp = qty.multiply(tpDistance).subtract(entryFee).subtract(exitFeeAtTp)
            if (profitAtTp.signum() <= 0) {
                return CalcResult.Invalid("الهدف لا يحقق ربحًا صافيًا بعد احتساب عمولتي الدخول والخروج")
            }
            // نسبة R:R تحسب على صافي الربح والخسارة، لا على المسافة السعرية وحدها.
            rewardRisk = profitAtTp.divide(lossAtStop, 2, RoundingMode.HALF_UP)
        }

        return CalcResult.Ok(
            PositionOutput(
                qty = qty,
                notional = notional,
                margin = margin,
                entryFee = entryFee,
                liquidation = liquidation,
                lossAtStop = lossAtStop,
                profitAtTp = profitAtTp,
                rewardRisk = rewardRisk,
            ),
        )
    }
}
