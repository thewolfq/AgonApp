package com.ghaith.trading.domain.archprobe

import android.archprobe.AndroidApiProbe
import java.math.BigDecimal

/*
 * مجسّات اختبار فقط (src/test): مخالفات متعمدة لإثبات أن قواعد ArchUnit ليست فارغة الأثر.
 * لا تدخل أي حزمة إنتاج؛ وقاعدة R4 نفسها تمنع أي main من الاعتماد عليها.
 */

/** يخالف R1: يعتمد على android.*. */
class DependsOnAndroidProbe {
    fun read(): Int = AndroidApiProbe.value()
}

/** يخالف R3: TODO(). */
class TodoProbe {
    fun pending(): Int = TODO("probe")
}

/** صنف "اختباري فقط" لاختبار R4. */
class TestOnlyHelperProbe {
    fun help(): Int = 2
}

/** يخالف R4 عند معاملته كـ main: يعتمد على صنف اختباري. */
class LeakyMainProbe {
    fun use(): Int = TestOnlyHelperProbe().help()
}

/** نظيف تجاه القواعد كلها. */
class CleanProbe {
    fun sum(a: BigDecimal, b: BigDecimal): BigDecimal = a.add(b)
}
