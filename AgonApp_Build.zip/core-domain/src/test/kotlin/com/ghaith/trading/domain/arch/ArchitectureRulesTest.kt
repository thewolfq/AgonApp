package com.ghaith.trading.domain.arch

import android.archprobe.AndroidApiProbe
import com.ghaith.trading.domain.archprobe.CleanProbe
import com.ghaith.trading.domain.archprobe.DependsOnAndroidProbe
import com.ghaith.trading.domain.archprobe.LeakyMainProbe
import com.ghaith.trading.domain.archprobe.TestOnlyHelperProbe
import com.ghaith.trading.domain.archprobe.TodoProbe
import com.ghaith.trading.domain.archprobe.finance.BoxedDoubleListProbe
import com.ghaith.trading.domain.archprobe.finance.CleanBigDecimalProbe
import com.ghaith.trading.domain.archprobe.finance.FieldDoubleProbe
import com.ghaith.trading.domain.archprobe.finance.LocalDoubleProbe
import com.ghaith.trading.domain.archprobe.finance.ParamFloatProbe
import com.tngtech.archunit.core.domain.JavaClass
import com.tngtech.archunit.core.domain.JavaClasses
import com.tngtech.archunit.core.importer.ClassFileImporter
import com.tngtech.archunit.lang.ArchCondition
import com.tngtech.archunit.lang.ArchRule
import com.tngtech.archunit.lang.ConditionEvents
import com.tngtech.archunit.lang.SimpleConditionEvent
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer

/*
 * ArchitectureRulesTest — §2.3 من 01_architecture: القواعد الأربع على البايت كود المترجم لكل الوحدات.
 *   R1: لا android.* داخل core-domain (+ استقلالية النواة عن بقية الوحدات، §2.2).
 *   R2: لا Double/Float (خصائص، معاملات، أنواع إرجاع، متغيرات محلية، عمليات) في finance/portfolio/evaluation.
 *   R3: لا TODO()/NotImplementedError في أي مسار main.
 *   R4: لا تسرب من test/testFixtures إلى main.
 * لكل قاعدة اختبار ذاتي على مجسّات (probes) مخالفة عمداً في مسار test يثبت أن القاعدة ليست فارغة الأثر.
 */
class ArchitectureRulesTest {

    // ===================================================================== المدخلات

    private fun parseDirs(property: String): Map<String, List<File>> {
        val raw = System.getProperty(property)
            ?: throw IllegalStateException("system property '$property' not set (run via Gradle :core-domain:test)")
        return raw.split(';').filter { it.isNotBlank() }.associate { entry ->
            val (module, paths) = entry.split('=', limit = 2)
            module to paths.split(',').filter { it.isNotBlank() }.map { File(root, it) }
        }
    }

    private val root: File = File(
        System.getProperty("gaith.arch.root")
            ?: throw IllegalStateException("system property 'gaith.arch.root' not set"),
    )
    private val mainClassDirs = parseDirs("gaith.arch.mainClassDirs")
    private val testClassDirs = parseDirs("gaith.arch.testClassDirs")
    private val mainSourceDirs: Map<String, File> = parseDirs("gaith.arch.mainSourceDirs").mapValues { it.value.single() }

    private fun existing(dirs: Collection<File>): List<File> = dirs.filter { it.isDirectory }

    private fun classFiles(dirs: Collection<File>): List<File> =
        existing(dirs).flatMap { d -> d.walkTopDown().filter { it.isFile && it.name.endsWith(".class") }.toList() }

    private fun sourceFiles(dir: File): List<File> =
        if (!dir.isDirectory) emptyList()
        else dir.walkTopDown().filter { it.isFile && (it.extension == "kt" || it.extension == "java" || it.extension == "kts") }.toList()

    private fun importMain(modules: Collection<String> = mainClassDirs.keys): JavaClasses {
        val paths = existing(modules.flatMap { mainClassDirs.getValue(it) }).map { it.toPath() }
        return ClassFileImporter().importPaths(paths)
    }

    private fun importProbes(vararg types: Class<*>): JavaClasses = ClassFileImporter().importClasses(*types)

    private fun assertRuleFails(rule: ArchRule, classes: JavaClasses) {
        try {
            rule.check(classes)
        } catch (expected: AssertionError) {
            return
        }
        fail("rule unexpectedly passed on probe classes: ${rule.description}")
    }

    // ===================================================================== عدم الفراغ

    @Test
    fun scannedTreesAreNotVacuous() {
        for ((module, srcDir) in mainSourceDirs) {
            if (module == "build-logic") continue
            val hasSources = sourceFiles(srcDir).any { it.extension == "kt" || it.extension == "java" }
            if (hasSources) {
                val classes = classFiles(mainClassDirs.getValue(module))
                assertTrue("module '$module' has main sources but no compiled classes were found in ${mainClassDirs[module]}", classes.isNotEmpty())
            }
        }
        val financeClasses = importMain(listOf("core-domain")).filter { it.packageName.endsWith(".finance") }
        assertTrue("core-domain finance package must contain compiled classes (Money.kt)", financeClasses.isNotEmpty())
        val appClasses = importMain(listOf("app"))
        assertTrue("app must contain MainActivity", appClasses.any { it.simpleName == "MainActivity" })
    }

    // ===================================================================== R1

    private val r1AndroidRule: ArchRule = noClasses()
        .that().resideInAPackage("com.ghaith.trading.domain..")
        .should().dependOnClassesThat().resideInAPackage("android..")
        .because("§2.3 R1: core-domain is pure Kotlin/JVM")

    private val r1IndependenceRule: ArchRule = noClasses()
        .that().resideInAPackage("com.ghaith.trading.domain..")
        .should().dependOnClassesThat().resideInAnyPackage(
            "com.ghaith.trading.data..",
            "com.ghaith.trading.store..",
            "com.ghaith.trading.ui..",
            "com.ghaith.trading",
        )
        .because("§2.2: core-domain depends on no other module")

    @Test
    fun rule1_coreDomainHasNoAndroidDependency() {
        val domain = importMain(listOf("core-domain"))
        r1AndroidRule.check(domain)
        r1IndependenceRule.check(domain)
        val androidImport = Regex("""^\s*import\s+android\.""")
        val offenders = sourceFiles(mainSourceDirs.getValue("core-domain")).flatMap { f ->
            f.readLines().withIndex().filter { androidImport.containsMatchIn(it.value) }.map { "${f.relativeTo(root)}:${it.index + 1}" }
        }
        assertEquals("android.* imports in core-domain/src/main", emptyList<String>(), offenders)
    }

    @Test
    fun rule1_selfTest_detectsAndroidDependency() {
        assertRuleFails(r1AndroidRule, importProbes(DependsOnAndroidProbe::class.java, AndroidApiProbe::class.java))
        r1AndroidRule.check(importProbes(CleanProbe::class.java))
    }

    // ===================================================================== R2

    private val forbiddenTypeNames = setOf("double", "float", "java.lang.Double", "java.lang.Float")

    private val noFloatingPointInSignaturesOrCalls = object : ArchCondition<JavaClass>(
        "not use Double/Float in fields, parameters, return types, dependencies or member calls",
    ) {
        override fun check(item: JavaClass, events: ConditionEvents) {
            fun violated(owner: Any, message: String) = events.add(SimpleConditionEvent.violated(owner, message))
            item.fields.filter { it.rawType.name in forbiddenTypeNames }
                .forEach { violated(it, "field ${it.fullName} : ${it.rawType.name}") }
            item.codeUnits.forEach { cu ->
                if (cu.rawReturnType.name in forbiddenTypeNames) violated(cu, "return ${cu.fullName} : ${cu.rawReturnType.name}")
                cu.rawParameterTypes.filter { it.name in forbiddenTypeNames }
                    .forEach { violated(cu, "parameter of ${cu.fullName} : ${it.name}") }
            }
            item.directDependenciesFromSelf.filter { it.targetClass.name in forbiddenTypeNames }
                .forEach { violated(it, it.description) }
            item.codeUnitAccessesFromSelf.forEach { call ->
                val t = call.target
                if (t.rawReturnType.name in forbiddenTypeNames || t.rawParameterTypes.any { it.name in forbiddenTypeNames }) {
                    violated(call, "call ${call.description}")
                }
            }
        }
    }

    private val r2Rule: ArchRule = classes()
        .that().resideInAnyPackage("..finance..", "..portfolio..", "..evaluation..")
        .should(noFloatingPointInSignaturesOrCalls)
        .allowEmptyShould(true)
        .because("§2.3 R2: no Double/Float in money/risk code")

    private val r2Segments = setOf("finance", "portfolio", "evaluation")

    private fun inR2Package(className: String): Boolean =
        className.substringBeforeLast('.', "").split('.').any { it in r2Segments }

    @Test
    fun rule2_noDoubleOrFloatInFinancePortfolioEvaluation() {
        r2Rule.check(importMain())
        val scanned = classFiles(mainClassDirs.values.flatten())
            .map { ClassFileScan.scan(it.readBytes()) }
            .filter { inR2Package(it.className) }
        assertTrue("bytecode scan found no finance/evaluation classes — scan would be vacuous", scanned.isNotEmpty())
        val violations = scanned.flatMap { r -> r.violations.map { "${r.className}: $it" } }
        assertEquals("Double/Float in bytecode (locals/opcodes/constants/descriptors)", emptyList<String>(), violations)
        println("R2 bytecode scan: ${scanned.size} classes in ${r2Segments.joinToString("/")} packages, 0 violations")
    }

    private fun scanProbe(type: Class<*>): ClassFileScan.Result {
        val resource = type.name.replace('.', '/') + ".class"
        val bytes = type.classLoader.getResourceAsStream(resource)?.use { it.readBytes() }
            ?: throw IllegalStateException("cannot read $resource")
        return ClassFileScan.scan(bytes)
    }

    @Test
    fun rule2_selfTest_detectsFieldsParamsLocalsAndBoxedGenerics() {
        assertRuleFails(r2Rule, importProbes(FieldDoubleProbe::class.java))
        assertRuleFails(r2Rule, importProbes(ParamFloatProbe::class.java))
        // متغير محلي double فقط: لا يظهر في التواقيع، ويلتقطه فاحص البايت كود.
        val local = scanProbe(LocalDoubleProbe::class.java)
        assertTrue("local double must be detected: $local", local.violations.isNotEmpty())
        val boxed = scanProbe(BoxedDoubleListProbe::class.java)
        assertTrue("List<Double> signature must be detected: $boxed", boxed.violations.isNotEmpty())
        assertTrue(scanProbe(FieldDoubleProbe::class.java).violations.isNotEmpty())
        assertTrue(scanProbe(ParamFloatProbe::class.java).violations.isNotEmpty())
        val clean = scanProbe(CleanBigDecimalProbe::class.java)
        assertEquals("clean BigDecimal probe must have no violations", emptyList<String>(), clean.violations)
        r2Rule.check(importProbes(CleanBigDecimalProbe::class.java))
    }

    // ===================================================================== R3

    private val r3Rule: ArchRule = noClasses()
        .should().dependOnClassesThat().haveFullyQualifiedName("kotlin.NotImplementedError")
        .because("§2.3 R3: no TODO()/NotImplementedError in main")

    @Test
    fun rule3_noTodoOrNotImplementedInMain() {
        r3Rule.check(importMain())
        val pattern = Regex("""\bTODO\b|NotImplementedError""")
        val offenders = mainSourceDirs.values.flatMap { sourceFiles(it) }.flatMap { f ->
            f.readLines().withIndex().filter { pattern.containsMatchIn(it.value) }.map { "${f.relativeTo(root)}:${it.index + 1}" }
        }
        assertEquals("TODO/NotImplementedError in main sources", emptyList<String>(), offenders)
    }

    @Test
    fun rule3_selfTest_detectsTodo() {
        assertRuleFails(r3Rule, importProbes(TodoProbe::class.java))
        r3Rule.check(importProbes(CleanProbe::class.java))
    }

    // ===================================================================== R4

    private fun testLeakViolations(main: JavaClasses, testOnlyNames: Set<String>): List<String> =
        main.flatMap { c ->
            c.directDependenciesFromSelf
                .filter { it.targetClass.name in testOnlyNames }
                .map { "${c.name} -> ${it.targetClass.name} (${it.description})" }
        }

    @Test
    fun rule4_noTestOrFixtureLeakIntoMain() {
        val main = importMain()
        val mainNames = main.map { it.name }.toSet()
        val testNames = classFiles(testClassDirs.values.flatten())
            .map { ClassFileScan.scan(it.readBytes()).className }
            .toSet() - mainNames
        assertTrue("no compiled test classes found — R4 would be vacuous", testNames.isNotEmpty())
        assertEquals(emptyList<String>(), testLeakViolations(main, testNames))
        println("R4: ${main.size} main classes checked against ${testNames.size} test classes, 0 leaks")
    }

    @Test
    fun rule4_selfTest_detectsLeak() {
        val probeMain = importProbes(LeakyMainProbe::class.java, TestOnlyHelperProbe::class.java)
            .filter { it.name == LeakyMainProbe::class.java.name }
        val leaks = probeMain.flatMap { c ->
            c.directDependenciesFromSelf.filter { it.targetClass.name == TestOnlyHelperProbe::class.java.name }
        }
        assertFalse("leak probe must be detected", leaks.isEmpty())
        val clean = testLeakViolations(importProbes(CleanProbe::class.java), setOf(TestOnlyHelperProbe::class.java.name))
        assertEquals(emptyList<String>(), clean)
    }
}

/**
 * فاحص ملفات .class مستقل (لا يعتمد على ArchUnit) لالتقاط Double/Float في:
 * ثوابت المجمع، واصفات الحقول والدوال، NameAndType/MethodType، Signature،
 * LocalVariableTable/TypeTable (المتغيرات المحلية)، وأكواد التشغيل العائمة.
 */
internal object ClassFileScan {
    data class Result(val className: String, val violations: List<String>)

    private val floatingOpcodes: Map<Int, String> = mapOf(
        0x0b to "fconst_0", 0x0c to "fconst_1", 0x0d to "fconst_2", 0x0e to "dconst_0", 0x0f to "dconst_1",
        0x17 to "fload", 0x18 to "dload", 0x22 to "fload_0", 0x23 to "fload_1", 0x24 to "fload_2", 0x25 to "fload_3",
        0x26 to "dload_0", 0x27 to "dload_1", 0x28 to "dload_2", 0x29 to "dload_3", 0x30 to "faload", 0x31 to "daload",
        0x38 to "fstore", 0x39 to "dstore", 0x43 to "fstore_0", 0x44 to "fstore_1", 0x45 to "fstore_2", 0x46 to "fstore_3",
        0x47 to "dstore_0", 0x48 to "dstore_1", 0x49 to "dstore_2", 0x4a to "dstore_3", 0x51 to "fastore", 0x52 to "dastore",
        0x62 to "fadd", 0x63 to "dadd", 0x66 to "fsub", 0x67 to "dsub", 0x6a to "fmul", 0x6b to "dmul",
        0x6e to "fdiv", 0x6f to "ddiv", 0x72 to "frem", 0x73 to "drem", 0x76 to "fneg", 0x77 to "dneg",
        0x86 to "i2f", 0x87 to "i2d", 0x89 to "l2f", 0x8a to "l2d", 0x8b to "f2i", 0x8c to "f2l", 0x8d to "f2d",
        0x8e to "d2i", 0x8f to "d2l", 0x90 to "d2f", 0x95 to "fcmpl", 0x96 to "fcmpg", 0x97 to "dcmpl", 0x98 to "dcmpg",
        0xae to "freturn", 0xaf to "dreturn",
    )

    fun scan(bytes: ByteArray): Result {
        val b = ByteBuffer.wrap(bytes)
        check(b.int == 0xCAFEBABE.toInt()) { "not a class file" }
        u2(b); u2(b)
        val cpCount = u2(b)
        val utf8 = arrayOfNulls<String>(cpCount)
        val tags = IntArray(cpCount)
        val ref = IntArray(cpCount)
        val violations = mutableListOf<String>()
        var i = 1
        while (i < cpCount) {
            val tag = u1(b)
            tags[i] = tag
            when (tag) {
                1 -> { val n = u2(b); val raw = ByteArray(n); b.get(raw); utf8[i] = String(raw, Charsets.UTF_8) }
                3 -> skip(b, 4)
                4 -> { skip(b, 4); violations += "constant pool: CONSTANT_Float" }
                5 -> { skip(b, 8); i++ }
                6 -> { skip(b, 8); violations += "constant pool: CONSTANT_Double"; i++ }
                7, 16 -> ref[i] = u2(b)
                8, 19, 20 -> u2(b)
                9, 10, 11 -> { u2(b); u2(b) }
                12 -> { u2(b); ref[i] = u2(b) }
                15 -> { u1(b); u2(b) }
                17, 18 -> { u2(b); u2(b) }
                else -> error("unknown constant pool tag $tag at $i")
            }
            i++
        }
        for (k in 1 until cpCount) {
            when (tags[k]) {
                7 -> {
                    val name = utf8[ref[k]] ?: continue
                    val bad = if (name.startsWith("[")) Sig.hasFloating(name) else name == "java/lang/Double" || name == "java/lang/Float"
                    if (bad) violations += "class constant: $name"
                }
                12, 16 -> {
                    val desc = utf8[ref[k]] ?: continue
                    if (Sig.hasFloating(desc)) violations += "member descriptor: $desc"
                }
            }
        }
        u2(b)
        val thisClass = u2(b)
        val className = (utf8[ref[thisClass]] ?: error("bad this_class")).replace('/', '.')
        u2(b)
        repeat(u2(b)) { u2(b) }
        repeat(u2(b)) {
            u2(b); val name = utf8[u2(b)]; val desc = utf8[u2(b)] ?: ""
            if (Sig.hasFloating(desc)) violations += "field $name : $desc"
            readAttributes(b, utf8, "field $name", violations)
        }
        repeat(u2(b)) {
            u2(b); val name = utf8[u2(b)]; val desc = utf8[u2(b)] ?: ""
            if (Sig.hasFloating(desc)) violations += "method $name$desc"
            readAttributes(b, utf8, "method $name", violations)
        }
        readAttributes(b, utf8, "class", violations)
        return Result(className, violations.distinct())
    }

    private fun readAttributes(b: ByteBuffer, utf8: Array<String?>, owner: String, out: MutableList<String>) {
        repeat(u2(b)) {
            val name = utf8[u2(b)]
            val len = b.int
            val end = b.position() + len
            when (name) {
                "Code" -> {
                    u2(b); u2(b)
                    val codeLen = b.int
                    val code = ByteArray(codeLen); b.get(code)
                    scanCode(code, owner, out)
                    repeat(u2(b)) { skip(b, 8) }
                    readAttributes(b, utf8, owner, out)
                }
                "LocalVariableTable", "LocalVariableTypeTable" -> repeat(u2(b)) {
                    u2(b); u2(b); val local = utf8[u2(b)]; val desc = utf8[u2(b)] ?: ""; u2(b)
                    if (Sig.hasFloating(desc)) out += "$owner local '$local' : $desc"
                }
                "Signature" -> {
                    val sig = utf8[u2(b)] ?: ""
                    if (Sig.hasFloating(sig)) out += "$owner signature: $sig"
                }
                else -> b.position(end)
            }
            b.position(end)
        }
    }

    private fun scanCode(code: ByteArray, owner: String, out: MutableList<String>) {
        var pc = 0
        fun at(p: Int) = code[p].toInt() and 0xff
        fun s4(p: Int) = ByteBuffer.wrap(code, p, 4).int
        while (pc < code.size) {
            val op = at(pc)
            floatingOpcodes[op]?.let { out += "$owner opcode $it @pc=$pc" }
            pc += when (op) {
                0x10, 0x12, 0x15, 0x16, 0x17, 0x18, 0x19, 0x36, 0x37, 0x38, 0x39, 0x3a, 0xa9 -> 2
                0xbc -> { val t = at(pc + 1); if (t == 6 || t == 7) out += "$owner newarray ${if (t == 6) "float" else "double"} @pc=$pc"; 2 }
                0x11, 0x13, 0x14, 0x84, in 0x99..0xa8, in 0xb2..0xb8, 0xbb, 0xbd, 0xc0, 0xc1, 0xc6, 0xc7 -> 3
                0xc5 -> 4
                0xb9, 0xba, 0xc8, 0xc9 -> 5
                0xc4 -> {
                    val inner = at(pc + 1)
                    floatingOpcodes[inner]?.let { out += "$owner wide $it @pc=$pc" }
                    if (inner == 0x84) 6 else 4
                }
                0xaa -> {
                    val base = pc + 1 + ((4 - (pc + 1) % 4) % 4)
                    val low = s4(base + 4); val high = s4(base + 8)
                    (base + 12 + (high - low + 1) * 4) - pc
                }
                0xab -> {
                    val base = pc + 1 + ((4 - (pc + 1) % 4) % 4)
                    val pairs = s4(base + 4)
                    (base + 8 + pairs * 8) - pc
                }
                else -> 1
            }
        }
    }

    private fun skip(b: ByteBuffer, n: Int) {
        b.position(b.position() + n)
    }

    private fun u1(b: ByteBuffer) = b.get().toInt() and 0xff
    private fun u2(b: ByteBuffer) = b.short.toInt() and 0xffff

    /** محلل تواقيع/واصفات JVM يكشف الأنواع D/F و java/lang/Double|Float دون الخلط بأسماء الأصناف. */
    private class Sig(private val s: String) {
        var found = false

        fun top() {
            var i = 0
            if (s.startsWith("<")) i = formal(i)
            if (i < s.length && s[i] == '(') {
                i++
                while (s[i] != ')') i = type(i)
                i = type(i + 1)
                while (i < s.length && s[i] == '^') i = type(i + 1)
            } else {
                while (i < s.length) i = type(i)
            }
        }

        private fun formal(start: Int): Int {
            var i = start + 1
            while (s[i] != '>') {
                while (s[i] != ':') i++
                while (s[i] == ':') {
                    i++
                    if (s[i] == 'L' || s[i] == '[' || s[i] == 'T') i = type(i)
                }
            }
            return i + 1
        }

        private fun type(start: Int): Int =
            when (s[start]) {
                'D', 'F' -> { found = true; start + 1 }
                'B', 'C', 'I', 'J', 'S', 'Z', 'V' -> start + 1
                '[' -> type(start + 1)
                'T' -> s.indexOf(';', start) + 1
                'L' -> classType(start)
                else -> error("bad signature '$s' at $start")
            }

        private fun classType(start: Int): Int {
            var i = start + 1
            var first = true
            var done = false
            while (!done) {
                val nameStart = i
                while (s[i] != ';' && s[i] != '<' && s[i] != '.') i++
                val name = s.substring(nameStart, i)
                if (first && (name == "java/lang/Double" || name == "java/lang/Float")) found = true
                first = false
                if (s[i] == '<') i = args(i)
                if (s[i] == '.') i++ else done = true
            }
            return i + 1
        }

        private fun args(start: Int): Int {
            var i = start + 1
            while (s[i] != '>') {
                when (s[i]) {
                    '*' -> i++
                    '+', '-' -> i = type(i + 1)
                    else -> i = type(i)
                }
            }
            return i + 1
        }

        companion object {
            fun hasFloating(signature: String): Boolean {
                if (signature.isEmpty()) return false
                val p = Sig(signature)
                p.top()
                return p.found
            }
        }
    }
}
