package com.ghaith.trading.domain.risk

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class PositionCalculatorTest {
    private fun d(s: String) = BigDecimal(s)

    private fun assertNum(expected: String, actual: BigDecimal?) {
        assertTrue("expected $expected but was $actual", actual != null && d(expected).compareTo(actual) == 0)
    }

    private fun input(
        side: Side = Side.LONG,
        entry: String = "100",
        stop: String = "90",
        tp: String? = "120",
        lev: Int = 5,
        risk: String = "100",
        fee: String = "0",
    ) = PositionInput(side, d(entry), d(stop), tp?.let { d(it) }, lev, d(risk), d(fee), d("0.005"))

    private fun ok(i: PositionInput): PositionOutput {
        val r = PositionCalculator.calculate(i)
        assertTrue("expected Ok but was $r", r is CalcResult.Ok)
        return (r as CalcResult.Ok).value
    }

    @Test
    fun longWithoutFeesMatchesHandCalculation() {
        val o = ok(input())
        assertNum("10", o.qty)
        assertNum("1000", o.notional)
        assertNum("200", o.margin)
        assertNum("0", o.entryFee)
        assertNum("80.5", o.liquidation)
        assertNum("100", o.lossAtStop)
        assertNum("200", o.profitAtTp)
        assertNum("2", o.rewardRisk)
    }

    @Test
    fun shortWithoutFeesMatchesHandCalculation() {
        val o = ok(input(side = Side.SHORT, stop = "110", tp = "80"))
        assertNum("10", o.qty)
        assertNum("119.5", o.liquidation)
        assertNum("200", o.profitAtTp)
        assertNum("100", o.lossAtStop)
    }

    @Test
    fun feesShrinkQuantityAndLossNeverExceedsRisk() {
        val o = ok(input(fee = "0.001"))
        assertTrue(o.qty < d("10"))
        assertTrue(o.lossAtStop <= d("100"))
    }

    @Test
    fun rewardRiskUsesNetProfitAndNetLossAfterFees() {
        val o = ok(input(fee = "0.001"))
        val expected = o.profitAtTp!!.divide(o.lossAtStop, 2, java.math.RoundingMode.HALF_UP)
        assertNum(expected.toPlainString(), o.rewardRisk)
        assertTrue(o.rewardRisk!! < d("2")) // الرسوم تجعل النسبة أقل من نسبة المسافات السعرية 2:1.
    }

    @Test
    fun rejectsTargetThatCannotCoverRoundTripFees() {
        val expensiveFees = input(entry = "100", stop = "99", tp = "100.1", fee = "0.01")
        assertTrue(PositionCalculator.calculate(expensiveFees) is CalcResult.Invalid)
    }

    @Test
    fun noTakeProfitGivesNoProfitOrRatio() {
        val o = ok(input(tp = null))
        assertEquals(null, o.profitAtTp)
        assertEquals(null, o.rewardRisk)
    }

    @Test
    fun rejectsStopOnWrongSide() {
        assertTrue(PositionCalculator.calculate(input(stop = "110")) is CalcResult.Invalid)
        assertTrue(PositionCalculator.calculate(input(side = Side.SHORT, stop = "90", tp = "80")) is CalcResult.Invalid)
    }

    @Test
    fun rejectsTakeProfitOnWrongSide() {
        assertTrue(PositionCalculator.calculate(input(tp = "95")) is CalcResult.Invalid)
    }

    @Test
    fun rejectsStopBeyondLiquidation() {
        assertTrue(PositionCalculator.calculate(input(stop = "85", lev = 20)) is CalcResult.Invalid)
    }

    @Test
    fun rejectsBadLeverageAndRisk() {
        assertTrue(PositionCalculator.calculate(input(lev = 0)) is CalcResult.Invalid)
        assertTrue(PositionCalculator.calculate(input(lev = 126)) is CalcResult.Invalid)
        assertTrue(PositionCalculator.calculate(input(risk = "0")) is CalcResult.Invalid)
    }

    @Test
    fun feeRateMustBeNonNegativeAndLessThanOne() {
        val negative = input().copy(feeRate = BigDecimal("-0.1"))
        val tooHigh = input().copy(feeRate = BigDecimal("1"))
        assertTrue(PositionCalculator.calculate(negative) is CalcResult.Invalid)
        assertTrue(PositionCalculator.calculate(tooHigh) is CalcResult.Invalid)
    }

    @Test
    fun maintenanceRateMustBeNonNegativeAndLessThanOne() {
        val negative = input().copy(maintenanceRate = BigDecimal("-0.1"))
        val tooHigh = input().copy(maintenanceRate = BigDecimal("1"))
        assertTrue(PositionCalculator.calculate(negative) is CalcResult.Invalid)
        assertTrue(PositionCalculator.calculate(tooHigh) is CalcResult.Invalid)
    }
}
