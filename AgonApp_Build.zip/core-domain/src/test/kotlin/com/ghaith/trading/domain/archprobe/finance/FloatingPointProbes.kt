package com.ghaith.trading.domain.archprobe.finance

import java.math.BigDecimal

/*
 * مجسّات اختبار فقط في حزمة "finance" لإثبات أن R2 تلتقط Double/Float
 * في الخصائص والمعاملات والمتغيرات المحلية والأنواع العامة المغلّفة.
 */

class FieldDoubleProbe(val amount: Double)

class ParamFloatProbe {
    fun accept(v: Float): Int = if (v > 0f) 1 else 0
}

class LocalDoubleProbe {
    fun scaled(x: Int): Int {
        val d = x * 1.5
        return d.toInt()
    }
}

class BoxedDoubleListProbe {
    fun values(n: Int): List<Double> = List(n) { it * 0.5 }
}

class CleanBigDecimalProbe {
    fun fee(notional: BigDecimal, rate: BigDecimal): BigDecimal = notional.multiply(rate)
}
