package com.ghaith.trading.domain.finance

import com.ghaith.trading.domain.evaluation.DataState
import com.ghaith.trading.domain.evaluation.Observed
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import java.util.Locale

/*
 * اختبارات Money.kt (بوابة M0 بند 3): التقريب، الخطوات، منع القيم السالبة غير المنطقية.
 * القيم المتوقعة مكتوبة يدوياً من §11 في 02_financial_engine (لا تُستخرج من دالة الإنتاج).
 */
class MoneyTest {

    private fun <T> ok(c: Checked<T>): T = when (c) {
        is Checked.Ok -> c.value
        is Checked.Err -> {
            fail("expected Ok but got ${c.error}: ${c.detail}")
            throw AssertionError("unreachable")
        }
    }

    private fun err(c: Checked<*>): ValueError = when (c) {
        is Checked.Ok -> {
            fail("expected Err but got Ok(${c.value})")
            throw AssertionError("unreachable")
        }
        is Checked.Err -> c.error
    }

    private fun d(s: String) = BigDecimal(s)

    private val usdt = ok(Currency.of("USDT"))
    private val sym = ok(Instrument.of("TESTSYM", Market.USDT_M_PERPETUAL))
    private val alt = ok(Instrument.of("ALTTEST", Market.USDT_M_PERPETUAL))
    private val tick = ok(Step.of(d("0.01"), d("0.01")))      // PRICE_FILTER: tickSize=0.01, minPrice=0.01
    private val lot = ok(Step.of(d("0.001"), d("0.001")))     // LOT_SIZE: stepSize=0.001, minQty=0.001
    private val settle8 = ok(SettlementUnit.of(usdt, 8))

    // ---------- الدقة المعلنة ----------

    @Test
    fun intermediatePrecisionIs34DigitsHalfEven() {
        assertEquals(34, DecimalPolicy.INTERMEDIATE.precision)
        assertEquals(RoundingMode.HALF_EVEN, DecimalPolicy.INTERMEDIATE.roundingMode)
    }

    @Test
    fun divisionRequiresNonZeroDenominatorAndExplicitRounding() {
        assertEquals(ValueError.DIVISION_BY_ZERO, err(Decimals.divide(d("1"), d("0"), 8, RoundingMode.HALF_EVEN)))
        assertEquals(ValueError.DIVISION_BY_ZERO, err(Decimals.divide(d("1"), d("0.000"), 8, RoundingMode.HALF_EVEN)))
        assertEquals(ValueError.INVALID_ROUNDING_MODE, err(Decimals.divide(d("1"), d("3"), 8, RoundingMode.UNNECESSARY)))
        assertEquals(ValueError.INVALID_SCALE, err(Decimals.divide(d("1"), d("3"), -1, RoundingMode.HALF_EVEN)))
        assertEquals(d("0.33333333"), ok(Decimals.divide(d("1"), d("3"), 8, RoundingMode.HALF_EVEN)))
        assertEquals(d("0.33333334"), ok(Decimals.divide(d("1"), d("3"), 8, RoundingMode.CEILING)))
    }

    @Test
    fun canonicalFormIsLocaleIndependent() {
        val saved = Locale.getDefault()
        try {
            Locale.setDefault(Locale.forLanguageTag("ar-YE"))
            assertEquals("100.01", Decimals.canonical(d("100.0100")))
            assertEquals("1000", Decimals.canonical(d("1E+3")))
            assertEquals("0", Decimals.canonical(d("0.000")))
            assertEquals("-0.5", Decimals.canonical(d("-0.50")))
            Locale.setDefault(Locale.GERMANY)
            assertEquals("4719.67192", Decimals.canonical(d("4719.67192")))
        } finally {
            Locale.setDefault(saved)
        }
    }

    // ---------- Price ----------

    @Test
    fun priceRejectsZeroAndNegative() {
        assertEquals(ValueError.INVALID_PRICE_NON_POSITIVE, err(Price.of(d("0"), sym, usdt, tick)))      // V6a
        assertEquals(ValueError.INVALID_PRICE_NON_POSITIVE, err(Price.of(d("0.00"), sym, usdt, tick)))
        assertEquals(ValueError.INVALID_PRICE_NON_POSITIVE, err(Price.of(d("-100"), sym, usdt, tick)))
    }

    @Test
    fun priceSlippageTicksMatchGoldenEffEntryEffExit() {
        val entry = ok(Price.of(d("100.00"), sym, usdt, tick))
        assertEquals(d("100.01"), ok(entry.plusTicks(1)).value)                // effEntry (§11.1)
        val stop = ok(Price.of(d("98.00"), sym, usdt, tick))
        assertEquals(d("97.99"), ok(stop.minusTicks(1)).value)                  // effExit V1
        assertEquals(ValueError.INVALID_TICK_COUNT, err(entry.plusTicks(-1)))
        val tiny = ok(Price.of(d("0.01"), sym, usdt, tick))
        assertEquals(ValueError.INVALID_PRICE_NON_POSITIVE, err(tiny.minusTicks(1)))
    }

    @Test
    fun stopRoundingToTickIsExplicitAndExact() {
        val requested = ok(Price.of(d("99.495"), sym, usdt, tick))             // V4
        assertFalse(requested.isOnTick)
        assertEquals(ValueError.NOT_ON_STEP, err(requested.tickUnits()))
        assertEquals(d("99.50"), ok(requested.ceilToTick()).value)              // طويل: نحو الدخول
        assertEquals(d("99.49"), ok(requested.floorToTick()).value)             // قصير: نحو الدخول
        val legal = ok(Price.of(d("99.50"), sym, usdt, tick))
        assertTrue(legal.isOnTick)
        assertEquals(BigInteger.valueOf(9949), ok(legal.tickUnits()))          // (99.50-0.01)/0.01
    }

    @Test
    fun liquidationCheckRoundsUpToTick() {
        // §11.4: LP_long≈99.18593467 ⇒ فحص محافظ لأعلى tick = 99.19
        val lp = ok(Price.of(d("99.18593467"), sym, usdt, tick))
        assertEquals(d("99.19"), ok(lp.ceilToTick()).value)
        val lp74 = ok(Price.of(d("99.20454122"), sym, usdt, tick))
        assertEquals(d("99.21"), ok(lp74.ceilToTick()).value)
    }

    // ---------- Qty ----------

    @Test
    fun qtyRejectsZeroAndNegativeWithDistinctCodes() {
        assertEquals(ValueError.INVALID_QTY_NON_POSITIVE, err(Qty.of(d("0"), sym, lot)))                 // V6b
        assertEquals(ValueError.INVALID_QTY_NEGATIVE, err(Qty.of(d("-0.001"), sym, lot)))                // V6c
    }

    @Test
    fun qtyFloorToStepMatchesGoldenValues() {
        // V1: floorToStep(100/2.119)=47.192
        assertEquals(d("47.192"), ok(Qty.floorToStep(d("100"), d("2.119"), sym, lot)).value)
        // V2: floorToStep(0.10/2.119)=0.047
        assertEquals(d("0.047"), ok(Qty.floorToStep(d("0.10"), d("2.119"), sym, lot)).value)
        // V5: floorToStep(0.04/2.119)=0.018
        assertEquals(d("0.018"), ok(Qty.floorToStep(d("0.04"), d("2.119"), sym, lot)).value)
        // V2-ALT: 0.161 لأن 0.162×0.61975>0.10
        assertEquals(d("0.161"), ok(Qty.floorToStep(d("0.10"), d("0.61975"), sym, lot)).value)
        // V3/V4
        assertEquals(d("161.355"), ok(Qty.floorToStep(d("100"), d("0.61975"), sym, lot)).value)
        assertEquals(d("16.135"), ok(Qty.floorToStep(d("10"), d("0.61975"), sym, lot)).value)
    }

    @Test
    fun floorOfQuotientNeverRoundsUpAtExactBoundary() {
        // حاصل يساوي خطوة تماماً يبقى كما هو، وأقل منه بقليل يهبط خطوة كاملة.
        assertEquals(d("47.192"), ok(lot.floorOfQuotient(d("99.999848"), d("2.119"))))   // 47.192×2.119
        assertEquals(d("47.191"), ok(lot.floorOfQuotient(d("99.999847"), d("2.119"))))
        assertEquals(ValueError.BELOW_STEP_ORIGIN, err(lot.floorOfQuotient(d("0.0001"), d("2.119"))))
        assertEquals(ValueError.DIVISION_BY_ZERO, err(lot.floorOfQuotient(d("1"), d("0"))))
        assertEquals(ValueError.NON_POSITIVE_DENOMINATOR, err(lot.floorOfQuotient(d("1"), d("-2"))))
    }

    @Test
    fun minimumLegalQtyForNotionalRoundsUpForComparison() {
        // §11.1: 5.025/100.01 ⇒ Q_min=0.051، واسميها 5.10051
        val qMin = ok(lot.ceilOfQuotient(d("5.025"), d("100.01")))
        assertEquals(d("0.051"), qMin)
        val price = ok(Price.of(d("100.01"), sym, usdt, tick))
        val q = ok(Qty.of(qMin, sym, lot))
        assertEquals(Money.of(d("5.10051"), usdt), ok(notional(price, q)))
    }

    @Test
    fun nearStepValueIsNotAcceptedAsOnStep() {
        assertFalse(lot.isOnStep(d("0.0010000001")))
        assertEquals(ValueError.NOT_ON_STEP, err(lot.units(d("47.1925"))))
        assertTrue(lot.isOnStep(d("47.192")))
        assertEquals(BigInteger.valueOf(47191), ok(lot.units(d("47.192"))))
        assertEquals(d("47.192"), lot.fromUnits(BigInteger.valueOf(47191)))
        assertEquals(ValueError.BELOW_STEP_ORIGIN, err(lot.units(d("0.0005"))))
    }

    @Test
    fun stepOriginIsRespected() {
        val shifted = ok(Step.of(d("0.5"), d("0.2")))       // قيم قانونية: 0.2، 0.7، 1.2 ...
        assertTrue(shifted.isOnStep(d("1.2")))
        assertFalse(shifted.isOnStep(d("1.0")))
        assertEquals(d("0.7"), ok(shifted.floor(d("1.1"))))
        assertEquals(d("1.2"), ok(shifted.ceil(d("0.9"))))
    }

    @Test
    fun stepRejectsInvalidDefinitions() {
        assertEquals(ValueError.INVALID_STEP_NON_POSITIVE, err(Step.of(d("0"), d("0"))))
        assertEquals(ValueError.INVALID_STEP_NON_POSITIVE, err(Step.of(d("-0.01"), d("0"))))
        assertEquals(ValueError.INVALID_STEP_ORIGIN_NEGATIVE, err(Step.of(d("0.01"), d("-1"))))
    }

    // ---------- Money ----------

    @Test
    fun moneyIsSignedAndNumericallyEqual() {
        val loss = Money.of(d("-99.999848"), usdt)
        assertEquals(-1, loss.signum)
        assertEquals(Money.of(d("1.0"), usdt), Money.of(d("1.00"), usdt))
        assertEquals(Money.of(d("1.0"), usdt).hashCode(), Money.of(d("1.00"), usdt).hashCode())
        assertEquals(Money.of(d("0"), usdt), Money.of(d("10"), usdt) - Money.of(d("10.000"), usdt))
        assertEquals(Money.of(d("-5"), usdt), -Money.of(d("5"), usdt))
    }

    @Test
    fun moneyRejectsCurrencyMixing() {
        val btc = ok(Currency.of("BTC"))
        assertThrows(IllegalArgumentException::class.java) { Money.of(d("1"), usdt) + Money.of(d("1"), btc) }
        assertThrows(IllegalArgumentException::class.java) { Money.of(d("1"), usdt).compareTo(Money.of(d("1"), btc)) }
        assertNotEquals(Money.of(d("1"), usdt), Money.of(d("1"), btc))
    }

    @Test
    fun feesAreExactAndMarginRoundsUpToSettlementUnit() {
        // رسم الفتح لكل وحدة: 100.01×0.0005 = 0.050005 (تام)
        assertEquals(Money.of(d("0.050005"), usdt), Money.of(d("100.01"), usdt).times(d("0.0005")))
        // V1: PostedMargin = 4,719.67192/23 ⇒ 205.20312696 بعد التقريب المحافظ لأعلى (مقياس 8)
        val posted = ok(Money.of(d("4719.67192"), usdt).divide(d("23"), 8, RoundingMode.CEILING))
        assertEquals(Money.of(d("205.20312696"), usdt), posted)
        // V2-advisor: 5.10051/23 ⇒ ≈0.22176131
        val posted2 = ok(Money.of(d("5.10051"), usdt).divide(d("23"), 8, RoundingMode.CEILING))
        assertEquals(Money.of(d("0.22176131"), usdt), posted2)
        // ceilTo/floorTo إلى وحدة التسوية
        assertEquals(Money.of(d("205.20312696"), usdt), Money.of(d("205.203126956"), usdt).ceilTo(settle8))
        assertEquals(Money.of(d("205.20312695"), usdt), Money.of(d("205.203126956"), usdt).floorTo(settle8))
        assertEquals(ValueError.DIVISION_BY_ZERO, err(Money.of(d("1"), usdt).divide(d("0"), 8, RoundingMode.CEILING)))
    }

    @Test
    fun notionalRequiresSameInstrument() {
        val price = ok(Price.of(d("100.01"), sym, usdt, tick))
        val q = ok(Qty.of(d("47.192"), sym, lot))
        assertEquals(Money.of(d("4719.67192"), usdt), ok(notional(price, q)))   // V1
        val qAlt = ok(Qty.of(d("1"), alt, lot))
        assertEquals(ValueError.INSTRUMENT_MISMATCH, err(notional(price, qAlt)))
    }

    @Test
    fun currencyAndSymbolValidation() {
        assertEquals(ValueError.INVALID_CURRENCY_CODE, err(Currency.of("usdt")))
        assertEquals(ValueError.INVALID_CURRENCY_CODE, err(Currency.of("")))
        assertEquals(ValueError.INVALID_SYMBOL, err(Instrument.of("", Market.USDT_M_PERPETUAL)))
        assertEquals(ValueError.INVALID_SYMBOL, err(Instrument.of("BTC USDT", Market.USDT_M_PERPETUAL)))
        // الهوية بمطابقة كاملة: رمزان متشابهان ليسا الأداة نفسها.
        assertNotEquals(
            ok(Instrument.of("UPUSDT", Market.USDT_M_PERPETUAL)),
            ok(Instrument.of("JUPUSDT", Market.USDT_M_PERPETUAL)),
        )
    }

    // ---------- PriceTriple ----------

    private fun live(p: Price) = PriceSlot.Present(Observed(p, DataState.LIVE, 1_000L, "fixture"))

    @Test
    fun priceTripleKeepsThreeIndependentSlots() {
        val p100 = ok(Price.of(d("100.00"), sym, usdt, tick))
        val triple = ok(PriceTriple.of(sym, live(p100), PriceSlot.Missing("markPrice not received"), live(p100)))
        assertTrue(triple.markPrice is PriceSlot.Missing)              // لا يُستبدل المفقود بسعر آخر
        assertTrue(triple.contractPrice is PriceSlot.Present)
        assertEquals(DataState.LIVE, (triple.executionPrice as PriceSlot.Present).observed.state)
    }

    @Test
    fun priceTripleRejectsMixedInstruments() {
        val p = ok(Price.of(d("100.00"), sym, usdt, tick))
        val q = ok(Price.of(d("100.00"), alt, usdt, tick))
        assertEquals(ValueError.INSTRUMENT_MISMATCH, err(PriceTriple.of(sym, live(p), live(q), live(p))))
    }

    @Test
    fun observedRejectsNegativeAgeAndCachedCarriesAge() {
        assertThrows(IllegalArgumentException::class.java) { Observed(1, DataState.LIVE, -1L, "x") }
        assertThrows(IllegalArgumentException::class.java) { DataState.CACHED(-5L) }
        assertEquals(12_000L, DataState.CACHED(12_000L).ageMs)
    }
}
