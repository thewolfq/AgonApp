package com.ghaith.trading.domain.portfolio

import com.ghaith.trading.domain.risk.CalcResult
import com.ghaith.trading.domain.risk.PositionCalculator
import com.ghaith.trading.domain.risk.PositionInput
import com.ghaith.trading.domain.risk.Side
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class PaperEngineTest {
    private fun d(s: String) = BigDecimal(s)

    private fun longInput(risk: String = "100", stop: String = "90", lev: Int = 5) =
        PositionInput(Side.LONG, d("100"), d(stop), d("120"), lev, d(risk), PaperEngine.TAKER_FEE, d("0.005"))

    private fun opened(input: PositionInput = longInput()): Account {
        val out = (PositionCalculator.calculate(input) as CalcResult.Ok).value
        val r = PaperEngine.open(PaperEngine.newAccount(), "BTCUSDT", input, out, 1L)
        return (r as OpenResult.Opened).account
    }

    private fun prices(v: String) = mapOf("BTCUSDT" to d(v))

    @Test
    fun openReservesMarginAndChargesEntryFee() {
        val a = opened()
        assertEquals(1, a.positions.size)
        assertTrue(a.balance < PaperEngine.START_BALANCE)
        assertTrue(PaperEngine.available(a) < a.balance)
        assertEquals(2L, a.nextId)
    }

    @Test
    fun unrealizedPnlMatchesDirection() {
        val p = opened().positions.single()
        val expectedGross = d("5").multiply(p.qty)
        assertEquals(0, expectedGross.compareTo(PaperEngine.unrealized(p, d("105"))))
    }

    @Test
    fun customFeeRateIsStoredAndUsedForExitFee() {
        val input = longInput().copy(feeRate = d("0.001"))
        val account = opened(input)
        val position = account.positions.single()
        assertEquals(0, d("0.001").compareTo(position.feeRate))
        val closed = PaperEngine.close(account, position.id, d("110"), CloseReason.MANUAL, 3L)
        val expectedExitFee = d("110").multiply(position.qty).multiply(d("0.001"))
        val expectedNet = PaperEngine.unrealized(position, d("110"))
            .subtract(position.entryFee)
            .subtract(expectedExitFee)
        assertEquals(0, expectedNet.compareTo(closed.history.single().pnl))
    }

    @Test
    fun netUnrealizedIncludesBothFeesWhileEquityAvoidsDoubleCountingEntryFee() {
        val account = opened()
        val position = account.positions.single()
        val price = d("105")
        val gross = PaperEngine.unrealized(position, price)
        val exitFee = PaperEngine.estimatedExitFee(position, price)
        val net = gross.subtract(position.entryFee).subtract(exitFee)
        assertEquals(0, net.compareTo(PaperEngine.unrealizedNet(position, price)))
        assertEquals(0, gross.subtract(exitFee)
            .compareTo(PaperEngine.equityContribution(position, price)))
        val equity = account.balance.add(PaperEngine.equityContribution(position, price))
        assertEquals(0, net.compareTo(equity.subtract(PaperEngine.START_BALANCE)))
    }

    @Test
    fun closeAllAtPricesClosesPositionsWithSavedPrices() {
        val account = opened()
        val closed = PaperEngine.closeAllAtPrices(
            account,
            prices("105"),
            CloseReason.APP_CLOSED,
            4L,
        )
        assertTrue(closed.positions.isEmpty())
        assertEquals(CloseReason.APP_CLOSED, closed.history.single().reason)
    }

    @Test
    fun closeAllAtPricesKeepsStopReasonWhenSavedPriceAlreadyCrossedStop() {
        val account = opened()
        val closed = PaperEngine.closeAllAtPrices(
            account,
            prices("89"),
            CloseReason.APP_CLOSED,
            4L,
        )
        assertEquals(CloseReason.STOP, closed.history.single().reason)
        assertTrue(closed.history.single().pnl.signum() < 0)
    }

    @Test
    fun closeAllAtPricesLeavesPositionsWithoutSavedPriceOpen() {
        val account = opened()
        val closed = PaperEngine.closeAllAtPrices(
            account,
            emptyMap(),
            CloseReason.CONNECTION_LOST,
            4L,
        )
        assertEquals(1, closed.positions.size)
        assertTrue(closed.history.isEmpty())
    }

    @Test
    fun stopClosesWithLoss() {
        val a = PaperEngine.applyPrices(opened(), prices("89"), 2L)
        assertTrue(a.positions.isEmpty())
        assertEquals(CloseReason.STOP, a.history.single().reason)
        assertTrue(a.history.single().pnl.signum() < 0)
    }

    @Test
    fun takeProfitClosesWithGain() {
        val a = PaperEngine.applyPrices(opened(), prices("121"), 2L)
        assertEquals(CloseReason.TAKE_PROFIT, a.history.single().reason)
        assertTrue(a.history.single().pnl.signum() > 0)
        assertTrue(a.balance > PaperEngine.START_BALANCE)
    }

    @Test
    fun liquidationWinsOverStop() {
        val a = PaperEngine.applyPrices(opened(), prices("80"), 2L)
        assertEquals(CloseReason.LIQUIDATION, a.history.single().reason)
        assertTrue(a.history.single().pnl.signum() < 0)
        assertTrue(a.balance < PaperEngine.START_BALANCE)
    }

    @Test
    fun noTriggerKeepsPosition() {
        val a = PaperEngine.applyPrices(opened(), prices("105"), 2L)
        assertEquals(1, a.positions.size)
        assertTrue(a.history.isEmpty())
    }

    @Test
    fun manualCloseRealizesProfit() {
        val a = opened()
        val closed = PaperEngine.close(a, a.positions.single().id, d("110"), CloseReason.MANUAL, 3L)
        assertTrue(closed.positions.isEmpty())
        assertEquals(CloseReason.MANUAL, closed.history.single().reason)
        assertTrue(closed.history.single().pnl.signum() > 0)
    }

    @Test
    fun rejectsPositionLargerThanAvailableBalance() {
        val input = longInput(risk = "100000", stop = "99", lev = 1)
        val out = (PositionCalculator.calculate(input) as CalcResult.Ok).value
        val r = PaperEngine.open(PaperEngine.newAccount(), "BTCUSDT", input, out, 1L)
        assertTrue(r is OpenResult.Rejected)
    }
}
