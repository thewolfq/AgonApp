package com.ghaith.trading.domain.portfolio

import com.ghaith.trading.domain.risk.CalcResult
import com.ghaith.trading.domain.risk.PositionCalculator
import com.ghaith.trading.domain.risk.PositionInput
import com.ghaith.trading.domain.risk.Side
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class PaperEngineTest {
    private fun d(s: String) = BigDecimal(s)

    private fun longInput(risk: String = "100", stop: String = "90", lev: Int = 5) =
        PositionInput(Side.LONG, d("100"), d(stop), d("120"), lev, d(risk), PaperEngine.TAKER_FEE, d("0.005"))

    private fun opened(input: PositionInput = longInput()): Account {
        val out = (PositionCalculator.calculate(input) as CalcResult.Ok).value
        val r = PaperEngine.open(PaperEngine.newAccount(), "BTCUSDT", input, out, 1L)
        return (r as OpenResult.Opened).account
    }

    private fun prices(v: String) = mapOf("BTCUSDT" to d(v))

    @Test
    fun openReservesMarginAndChargesEntryFee() {
        val a = opened()
        assertEquals(1, a.positions.size)
        assertTrue(a.balance < PaperEngine.START_BALANCE)
        assertTrue(PaperEngine.available(a) < a.balance)
        assertEquals(2L, a.nextId)
    }

    @Test
    fun unrealizedPnlMatchesDirection() {
        val p = opened().positions.single()
        assertEquals(0, d("50").compareTo(PaperEngine.unrealized(p, d("105")).setScale(6, java.math.RoundingMode.HALF_UP)))
    }

    @Test
    fun stopClosesWithLoss() {
        val a = PaperEngine.applyPrices(opened(), prices("89"), 2L)
        assertTrue(a.positions.isEmpty())
        assertEquals(CloseReason.STOP, a.history.single().reason)
        assertTrue(a.history.single().pnl.signum() < 0)
    }

    @Test
    fun takeProfitClosesWithGain() {
        val a = PaperEngine.applyPrices(opened(), prices("121"), 2L)
        assertEquals(CloseReason.TAKE_PROFIT, a.history.single().reason)
        assertTrue(a.history.single().pnl.signum() > 0)
        assertTrue(a.balance > PaperEngine.START_BALANCE)
    }

    @Test
    fun liquidationWinsOverStop() {
        val a = PaperEngine.applyPrices(opened(), prices("80"), 2L)
        assertEquals(CloseReason.LIQUIDATION, a.history.single().reason)
        assertTrue(a.history.single().pnl.signum() < 0)
        assertTrue(a.balance < PaperEngine.START_BALANCE)
    }

    @Test
    fun noTriggerKeepsPosition() {
        val a = PaperEngine.applyPrices(opened(), prices("105"), 2L)
        assertEquals(1, a.positions.size)
        assertTrue(a.history.isEmpty())
    }

    @Test
    fun manualCloseRealizesProfit() {
        val a = opened()
        val closed = PaperEngine.close(a, a.positions.single().id, d("110"), CloseReason.MANUAL, 3L)
        assertTrue(closed.positions.isEmpty())
        assertEquals(CloseReason.MANUAL, closed.history.single().reason)
        assertTrue(closed.history.single().pnl.signum() > 0)
    }

    @Test
    fun rejectsPositionLargerThanAvailableBalance() {
        val input = longInput(risk = "100000", stop = "99", lev = 1)
        val out = (PositionCalculator.calculate(input) as CalcResult.Ok).value
        val r = PaperEngine.open(PaperEngine.newAccount(), "BTCUSDT", input, out, 1L)
        assertTrue(r is OpenResult.Rejected)
    }
}
