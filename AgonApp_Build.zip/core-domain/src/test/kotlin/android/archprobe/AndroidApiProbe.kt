package android.archprobe

/** مجسّ اختبار فقط: صنف في حزمة android.* لإثبات أن R1 تلتقط الاعتماد عليها. */
object AndroidApiProbe {
    fun value(): Int = 1
}
