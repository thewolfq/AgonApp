#!/usr/bin/env python3
"""
§9.5 من 03_implementation: فحص الحزمة لحجم صفحة 16KB.
- كل lib/**/*.so داخل الـAPK يجب أن تكون كل مقاطع PT_LOAD فيه بمحاذاة p_align >= 16384،
  وبقوة للعدد 2، وأن تتطابق p_offset و p_vaddr بباقي القسمة على p_align.
- يفشل (exit 1) عند أي مخالفة، ويطبع تقريراً لكل مكتبة. محاذاة الـzip نفسها يفحصها `zipalign -c -P 16`.
الاستعمال: check_16kb.py <apk> [<apk> ...]
"""
import struct
import sys
import zipfile

PAGE_16K = 16384
PT_LOAD = 1


def load_segments(data: bytes):
    if data[:4] != b"\x7fELF":
        raise ValueError("not an ELF file")
    ei_class, ei_data = data[4], data[5]
    endian = "<" if ei_data == 1 else ">"
    if ei_class == 2:  # ELF64
        e_phoff = struct.unpack_from(endian + "Q", data, 0x20)[0]
        e_phentsize, e_phnum = struct.unpack_from(endian + "HH", data, 0x36)
        for i in range(e_phnum):
            off = e_phoff + i * e_phentsize
            p_type, _flags, p_offset, p_vaddr, _paddr, _filesz, _memsz, p_align = struct.unpack_from(
                endian + "IIQQQQQQ", data, off)
            if p_type == PT_LOAD:
                yield p_offset, p_vaddr, p_align
    elif ei_class == 1:  # ELF32
        e_phoff = struct.unpack_from(endian + "I", data, 0x1C)[0]
        e_phentsize, e_phnum = struct.unpack_from(endian + "HH", data, 0x2A)
        for i in range(e_phnum):
            off = e_phoff + i * e_phentsize
            p_type, p_offset, p_vaddr, _paddr, _filesz, _memsz, _flags, p_align = struct.unpack_from(
                endian + "IIIIIIII", data, off)
            if p_type == PT_LOAD:
                yield p_offset, p_vaddr, p_align
    else:
        raise ValueError(f"unknown ELF class {ei_class}")


def check_apk(path: str) -> int:
    failures = 0
    with zipfile.ZipFile(path) as z:
        libs = [n for n in z.namelist() if n.startswith("lib/") and n.endswith(".so")]
        if not libs:
            print(f"{path}: no lib/**/*.so")
            return 0
        for name in sorted(libs):
            segs = list(load_segments(z.read(name)))
            bad = [
                (o, v, a) for (o, v, a) in segs
                if a < PAGE_16K or (a & (a - 1)) != 0 or (o % a) != (v % a)
            ]
            aligns = sorted({a for (_o, _v, a) in segs})
            status = "OK" if (segs and not bad) else "FAIL"
            if status == "FAIL":
                failures += 1
            print(f"{path}: {name}: PT_LOAD={len(segs)} p_align={[hex(a) for a in aligns]} -> {status}")
    return failures


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    total = sum(check_apk(p) for p in argv[1:])
    if total:
        print(f"16KB LOAD alignment: {total} library(ies) FAILED")
        return 1
    print("16KB LOAD alignment: all native libraries OK")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
