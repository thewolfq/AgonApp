# بيئة البناء المحلية في صندوق التطوير (ليست جزءاً من CI).
export GAITH_TOOLS=/usr/local/gaith-tools
export JAVA_HOME=$GAITH_TOOLS/jdk-17.0.21.1+2
export ANDROID_HOME=$GAITH_TOOLS/sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export GRADLE_USER_HOME=$GAITH_TOOLS/gradle-home
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$PATH
