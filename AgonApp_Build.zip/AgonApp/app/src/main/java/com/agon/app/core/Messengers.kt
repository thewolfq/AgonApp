package com.agon.app.core

import com.agon.app.data.providers.arr
import com.agon.app.data.providers.bool
import com.agon.app.data.providers.obj
import com.agon.app.data.providers.str
import com.agon.app.data.store.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/** وجهة الإشعارات (يفصل المنطق عن Android). يعيد true إن سُلّم الإشعار للنظام. */
interface AlertSink {
    fun alert(key: String, title: String, body: String, critical: Boolean): Boolean
}

/**
 * Telegram قناة احتياطية اختيارية عبر Bot API الرسمي. الرمز والمعرّف من التخزين الآمن فقط؛
 * لا يُسجّل الرابط (يحوي الرمز) ولا يظهر في رسائل الخطأ.
 */
class TelegramNotifier(private val http: OkHttpClient, private val secure: SecureStore) {
    fun configured(): Boolean = secure.has(SecureStore.TELEGRAM_TOKEN) && secure.has(SecureStore.TELEGRAM_CHAT)

    suspend fun send(text: String): Result<Unit> = withContext(Dispatchers.IO) {
        val token = secure.get(SecureStore.TELEGRAM_TOKEN)
        val chat = secure.get(SecureStore.TELEGRAM_CHAT)
        if (token.isNullOrBlank() || chat.isNullOrBlank()) return@withContext Result.failure(IllegalStateException("Telegram غير مُعدّ"))
        try {
            val body = FormBody.Builder().add("chat_id", chat).add("text", text.take(3900)).add("disable_web_page_preview", "true").build()
            http.newCall(Request.Builder().url("https://api.telegram.org/bot$token/sendMessage").post(body).build()).execute().use { resp ->
                if (resp.isSuccessful) Result.success(Unit) else Result.failure(IllegalStateException("Telegram HTTP ${resp.code}"))
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("تعذر الاتصال بـTelegram (${e.javaClass.simpleName})"))
        }
    }
}

@Serializable
data class LlmEvent(val type: String = "other", val title: String = "", val date: String = "", val source: String = "")

/** مخرج منظم لطبقة النموذج اللغوي. دورها فيتو مخاطر فقط: لا ترفع الدرجة ولا تنشئ إشارة. */
@Serializable
data class LlmVerdict(
    val veto: Boolean = false,
    val reason: String = "",
    val source: String = "",
    val date: String = "",
    /** official | reported | rumor | none */
    @SerialName("evidence_level") val evidenceLevel: String = "none",
    val events: List<LlmEvent> = emptyList(),
    val model: String = "",
    val reviewedAt: Long = 0,
    val error: String? = null,
)

/**
 * طبقة نموذج لغوي اختيارية للمرشحين فقط، عبر API متوافق مع صيغة chat/completions يحدده المستخدم
 * (الرابط واسم النموذج والمفتاح من المستخدم؛ لا مفاتيح في المصدر ولا في السجلات). ليست شرطًا لتشغيل التطبيق.
 */
class LlmVeto(private val http: OkHttpClient, private val secure: SecureStore) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true; encodeDefaults = true }

    fun configured(endpoint: String, model: String): Boolean = endpoint.startsWith("https://") && model.isNotBlank() && secure.has(SecureStore.LLM_KEY)

    fun encode(v: LlmVerdict): String = json.encodeToString(LlmVerdict.serializer(), v)
    fun decode(text: String): LlmVerdict? = runCatching { json.decodeFromString(LlmVerdict.serializer(), text) }.getOrNull()

    /** يفسّر نص النموذج إلى حكم منظم؛ أي نص غير صالح يعطي حكمًا بلا فيتو مع خطأ واضح. */
    fun parseContent(content: String, model: String, now: Long): LlmVerdict {
        val cleaned = content.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) return LlmVerdict(error = "رد النموذج ليس JSON", model = model, reviewedAt = now)
        val v = runCatching { json.decodeFromString(LlmVerdict.serializer(), cleaned.substring(start, end + 1)) }.getOrNull()
            ?: return LlmVerdict(error = "JSON لا يطابق المخطط المطلوب", model = model, reviewedAt = now)
        val level = v.evidenceLevel.lowercase().takeIf { it in setOf("official", "reported", "rumor", "none") } ?: "none"
        return v.copy(evidenceLevel = level, model = model, reviewedAt = now, error = null, reason = v.reason.take(600), source = v.source.take(300), events = v.events.take(8))
    }

    suspend fun review(endpoint: String, model: String, symbol: String, marketLabel: String, facts: String, now: Long): LlmVerdict = withContext(Dispatchers.IO) {
        val key = secure.get(SecureStore.LLM_KEY)
        if (key.isNullOrBlank()) return@withContext LlmVerdict(error = "لا يوجد مفتاح", model = model, reviewedAt = now)
        if (!endpoint.startsWith("https://")) return@withContext LlmVerdict(error = "الرابط يجب أن يبدأ بـhttps://", model = model, reviewedAt = now)
        val system = "You are a risk reviewer for a personal crypto market monitor. You do NOT produce trade signals. " +
            "Decide only whether there is a known risk event that should veto studying this pair. " +
            "Reply with a single JSON object: {\"veto\": boolean, \"reason\": string, \"source\": string, \"date\": \"YYYY-MM-DD or empty\", " +
            "\"evidence_level\": \"official|reported|rumor|none\", \"events\": [{\"type\": \"listing|delisting|hack|unlock|suspicious|other\", \"title\": string, \"date\": string, \"source\": string}]}. " +
            "If you have no verifiable information, set veto=false, evidence_level=\"none\", empty events, and say so in reason. Never invent sources or dates. Answer in Arabic."
        val user = "Pair: $symbol ($marketLabel). Deterministic facts from the app (not predictions): $facts"
        val body = buildJsonObject {
            put("model", model)
            put("temperature", 0)
            put("response_format", buildJsonObject { put("type", "json_object") })
            put("messages", buildJsonArray {
                add(buildJsonObject { put("role", "system"); put("content", system) })
                add(buildJsonObject { put("role", "user"); put("content", user) })
            })
        }.toString()
        try {
            val req = Request.Builder().url(endpoint).header("Authorization", "Bearer $key")
                .post(body.toRequestBody("application/json".toMediaType())).build()
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return@withContext LlmVerdict(error = "HTTP ${resp.code}", model = model, reviewedAt = now)
                val root = json.parseToJsonElement(text) as? JsonObject
                val content = root?.arr("choices")?.firstOrNull()?.let { it as? JsonObject }?.obj("message")?.str("content")
                    ?: return@withContext LlmVerdict(error = "صيغة رد غير متوقعة", model = model, reviewedAt = now)
                parseContent(content, model, now)
            }
        } catch (e: Exception) {
            LlmVerdict(error = "تعذر الاتصال (${e.javaClass.simpleName})", model = model, reviewedAt = now)
        }
    }
}

@Suppress("unused")
private fun JsonObject.flag(key: String): Boolean = bool(key) ?: false
