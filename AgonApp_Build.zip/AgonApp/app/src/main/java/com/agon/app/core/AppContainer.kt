package com.agon.app.core

import android.app.Application
import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BinanceEndpoints
import com.agon.app.data.providers.BinanceRest
import com.agon.app.data.providers.EndpointConfig
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.StreamCategory
import com.agon.app.data.providers.StreamConnection
import com.agon.app.data.providers.SymbolSession
import com.agon.app.data.providers.TickerHub
import com.agon.app.data.store.BackupManager
import com.agon.app.data.store.SecureStore
import com.agon.app.data.store.SettingsRepo
import com.agon.app.data.store.Store
import com.agon.app.platform.background.MonitorController
import com.agon.app.platform.background.NetworkWatcher
import com.agon.app.platform.background.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.Collections
import java.util.WeakHashMap
import java.util.concurrent.TimeUnit

/** تركيب يدوي للتبعيات (بلا إطار DI). نسخة واحدة لكل عملية. */
class AppContainer(val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** بلا معترضات تسجيل: لا تُكتب روابط أو ترويسات (قد تحوي أسرارًا) في السجلات. */
    val http: OkHttpClient = OkHttpClient.Builder()
        .pingInterval(AppConfig.Ws.CLIENT_PING_INTERVAL_MS, TimeUnit.MILLISECONDS)
        .connectTimeout(AppConfig.Rest.CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .readTimeout(AppConfig.Rest.READ_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .build()

    val store = Store(app)
    val secure = SecureStore(app)
    val settingsRepo = SettingsRepo(store)
    val endpoints: () -> EndpointConfig = { BinanceEndpoints.config(settingsRepo.settings.value.spotDataOnly) }
    val rest = BinanceRest(http, endpoints)

    /** مركز أسعار مستقل لكل سوق؛ لا cache مشترك بين Spot وFutures. */
    val hubs: Map<Market, TickerHub> = Market.entries.associateWith { m ->
        TickerHub(m, rest, StreamConnection(http, "hub-${m.id}", scope, { BinanceEndpoints.wsBase(endpoints(), m, StreamCategory.MARKET) }), scope)
    }
    val directory = SymbolDirectory(rest)
    val notifier = Notifier(app)
    val telegram = TelegramNotifier(http, secure)
    val llm = LlmVeto(http, secure)
    val backup = BackupManager(app, store)
    val monitor = MonitorController(app)
    val tradeMonitor = TradeMonitor(store, hubs, rest, directory, notifier, telegram, settingsRepo.settings, scope)
    val studies = StudyRunner(store, rest, directory, hubs, notifier, llm, settingsRepo.settings, scope)
    val outcomes = OutcomeTracker(store, rest)

    private val sessions: MutableSet<SymbolSession> = Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap()))
    val network = NetworkWatcher(app) { reason -> onNetworkChanged(reason) }

    init {
        notifier.ensureChannels()
        network.start()
        scope.launch {
            settingsRepo.load()
            monitor.prefs.restartAfterBoot = settingsRepo.settings.value.restartAfterBoot
            backup.refreshStatus()
            studies.loadPersisted()
            // نسخ يومي اختياري وقياس النتائج المستحقة عند فتح التطبيق (فرصة إضافية إن لم تكن الخدمة تعمل).
            runCatching { backup.maybeDaily(settingsRepo.settings.value.backupDaily) }
            runCatching { outcomes.runOnce() }
        }
    }

    fun hub(market: Market): TickerHub = hubs.getValue(market)

    fun newSession(market: Market, symbol: String): SymbolSession =
        SymbolSession(market, symbol, rest, http, endpoints, scope).also { sessions.add(it) }

    /** تبديل Wi‑Fi/بيانات: أعد فتح كل الاتصالات فورًا؛ الدفاتر تُعاد من snapshot والأسعار تُعاد بذرتها. */
    fun onNetworkChanged(reason: String) {
        hubs.values.forEach { it.forceReconnect(reason) }
        synchronized(sessions) { sessions.toList() }.forEach { it.forceReconnect(reason) }
    }

    /** تغيير مصدر Spot من الإعدادات يُطبّق بإعادة الاتصال وإعادة البذر. */
    fun onSourcesChanged() {
        hub(Market.SPOT).forceReconnect("source-changed")
        scope.launch { hub(Market.SPOT).seed(force = true) }
        synchronized(sessions) { sessions.toList() }.filter { it.market == Market.SPOT }.forEach { it.forceReconnect("source-changed") }
    }
}
