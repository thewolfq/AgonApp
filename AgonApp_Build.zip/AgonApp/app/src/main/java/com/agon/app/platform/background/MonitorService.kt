package com.agon.app.platform.background

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.agon.app.GhaithApp
import com.agon.app.config.AppConfig
import com.agon.app.core.AppContainer
import com.agon.app.data.providers.Market
import com.agon.app.data.store.BackupResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * خدمة المراقبة الخلفية الاختيارية.
 *
 * النوع specialUse: مراقبة أسعار لحظية مستمرة عبر WebSocket يبدؤها المستخدم لإطلاق تنبيهات
 * الصفقات. لا ينطبق نوع آخر: dataSync محدود بـ6 ساعات/24 ساعة عند استهداف API 35+ وليس للمراقبة
 * المستمرة؛ remoteMessaging/connectedDevice/mediaPlayback لا تصف الاستخدام. الوصف في Manifest
 * (PROPERTY_SPECIAL_USE_FGS_SUBTYPE). الإشعار الدائم ظاهر دائمًا وفيه زر إيقاف.
 *
 * لا وعود: Force Stop أو قتل النظام أو قيود الشركة المصنعة أو Doze قد توقف الخدمة أو تؤخر الشبكة؛
 * عندها تظهر حالة «متوقفة» في التطبيق ويُطلب التشغيل يدويًا.
 */
class MonitorService : Service() {
    private var scope: CoroutineScope? = null
    private lateinit var container: AppContainer
    private var started = false
    private var stoppedByUser = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        container = (application as GhaithApp).container
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stoppedByUser = true
            shutdown()
            return START_NOT_STICKY
        }
        // intent == null ⇒ النظام أعاد إنشاء الخدمة (START_STICKY). قد يُمنع startForeground من الخلفية في Android 12+.
        try {
            val n = container.notifier.monitorNotification("جارٍ بدء المراقبة…")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(Notifier.MONITOR_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(Notifier.MONITOR_ID, n)
            }
        } catch (e: Exception) {
            // ForegroundServiceStartNotAllowedException / SecurityException: لا تحايل — نعرض التوقف ونطلب تشغيلًا يدويًا.
            val reason = "منع النظام تشغيل المراقبة من الخلفية (${e.javaClass.simpleName})"
            container.monitor.onBlocked(reason)
            container.notifier.status(Notifier.STOPPED_ID, "المراقبة متوقفة", "$reason. افتح التطبيق وشغّل المراقبة يدويًا.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started) {
            started = true
            container.notifier.cancel(Notifier.STOPPED_ID)
            container.monitor.onStarted(System.currentTimeMillis())
            container.tradeMonitor.start(OWNER)
            val sc = CoroutineScope(SupervisorJob() + Dispatchers.Default)
            scope = sc
            sc.launch { heartbeatLoop() }
            sc.launch { maintenanceLoop() }
        }
        return START_STICKY
    }

    private suspend fun heartbeatLoop() {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        while (scope?.isActive == true) {
            val now = System.currentTimeMillis()
            container.monitor.onHeartbeat(now)
            val s = container.tradeMonitor.stats.value
            val conn = Market.entries.joinToString(" · ") { m -> "${m.label}: ${container.hubs.getValue(m).status.value.let { st -> if (st.mode.name == "IDLE") "—" else st.ws.state.label }}" }
            val last = if (s.lastTickAt > 0) fmt.format(Date(s.lastTickAt)) else "—"
            container.notifier.updateMonitor("${s.openTrades} صفقة مفتوحة · ${s.symbols} رمزًا · آخر سعر $last\n$conn")
            delay(30_000L)
        }
    }

    /** مهام دورية خفيفة داخل الخدمة نفسها (بلا JobScheduler/WorkManager ⇒ لا تعتمد على حصص مهام Android 16). */
    private suspend fun maintenanceLoop() {
        var lastScan = System.currentTimeMillis()
        var lastBackupCheck = 0L
        while (scope?.isActive == true) {
            runCatching { container.outcomes.runOnce() }
            val now = System.currentTimeMillis()
            val settings = container.settingsRepo.settings.value
            if (now - lastBackupCheck >= AppConfig.Backup.CHECK_INTERVAL_MS) {
                lastBackupCheck = now
                when (runCatching { container.backup.maybeDaily(settings.backupDaily) }.getOrNull()) {
                    is BackupResult.FolderLost -> container.notifier.status(Notifier.BACKUP_ID, "تعذر النسخ الاحتياطي", "فُقد إذن مجلد النسخ. افتح الإعدادات واختر المجلد مجددًا.")
                    is BackupResult.Failed -> container.notifier.status(Notifier.BACKUP_ID, "فشل النسخ الاحتياطي", "راجع الإعدادات > النسخ.")
                    else -> Unit
                }
            }
            if (settings.autoScan && now - lastScan >= AppConfig.Scan.AUTO_SCAN_INTERVAL_MS) {
                lastScan = now
                runCatching { container.studies.runScan(settings.defaultMarket) }
            }
            delay(AppConfig.Outcome.CHECK_INTERVAL_MS)
        }
    }

    private fun shutdown() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Android 15+: إن فرض النظام مهلة على الخدمة نتوقف بنظافة ونعلن ذلك. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        container.notifier.status(Notifier.STOPPED_ID, "المراقبة متوقفة", "أوقف النظام الخدمة (مهلة). افتح التطبيق وشغّلها يدويًا.")
        shutdown()
    }

    override fun onDestroy() {
        if (started) {
            container.tradeMonitor.stop(OWNER)
            container.monitor.onStopped(stoppedByUser, if (stoppedByUser) null else "أوقف النظام خدمة المراقبة")
            if (!stoppedByUser) container.notifier.status(Notifier.STOPPED_ID, "المراقبة متوقفة", "توقفت خدمة المراقبة دون طلبك. افتح التطبيق لتشغيلها.")
        } else if (stoppedByUser) {
            container.monitor.onStopped(true, null)
        }
        scope?.cancel()
        scope = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.agon.app.action.MONITOR_START"
        const val ACTION_STOP = "com.agon.app.action.MONITOR_STOP"
        const val OWNER = "service"
    }
}

/**
 * بعد إعادة تشغيل الجهاز. ملاحظات صادقة:
 * - بعد Force Stop لا يسلّم النظام BOOT_COMPLETED للتطبيق إطلاقًا حتى يفتحه المستخدم؛ لا إعادة تشغيل تلقائية.
 * - Android 15 يمنع بدء أنواع معينة من الخدمات من BOOT_COMPLETED (منها dataSync)؛ specialUse غير مشمول،
 *   لكن البدء قد يُمنع لأسباب أخرى، فنلتقط الخطأ ونعرض إشعار «متوقفة» بدل الادعاء.
 * - الافتراضي: لا تشغيل تلقائي؛ فقط إشعار يطلب التشغيل اليدوي. التشغيل بعد الإقلاع خيار يفعّله المستخدم.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = MonitorPrefs(context)
        if (!prefs.wanted) return
        val notifier = Notifier(context).also { it.ensureChannels() }
        if (prefs.restartAfterBoot) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, MonitorService::class.java).setAction(MonitorService.ACTION_START))
                return
            } catch (e: Exception) {
                prefs.stoppedReason = "منع النظام تشغيل المراقبة بعد الإقلاع (${e.javaClass.simpleName})"
            }
        } else {
            prefs.stoppedReason = "أُعيد تشغيل الجهاز"
        }
        notifier.status(Notifier.STOPPED_ID, "المراقبة متوقفة", "توقفت المراقبة بعد إعادة تشغيل الجهاز. افتح «غيث التداول» لتشغيلها.")
    }
}
