package com.agon.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.agon.app.config.AppConfig
import com.agon.app.data.providers.FeedStatus
import com.agon.app.data.providers.HubMode
import com.agon.app.data.providers.SeedState
import com.agon.app.data.providers.WsState
import com.agon.app.domain.engine.fmt
import com.agon.app.domain.engine.fmtPrice
import com.agon.app.ui.theme.LocalMarketColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

// ---------- تنسيق ----------

fun priceText(p: Double?): String = if (p == null || p.isNaN()) "—" else fmtPrice(p)

fun pctText(p: Double?, decimals: Int = 2): String = if (p == null || p.isNaN()) "—" else (if (p >= 0) "+" else "") + fmt(p, decimals) + "%"

fun volText(v: Double?): String {
    if (v == null || v.isNaN()) return "—"
    val a = abs(v)
    return when {
        a >= 1e9 -> fmt(v / 1e9, 2) + "B"
        a >= 1e6 -> fmt(v / 1e6, 2) + "M"
        a >= 1e3 -> fmt(v / 1e3, 1) + "K"
        else -> fmt(v, 0)
    }
}

fun timeText(ms: Long): String = if (ms <= 0) "—" else SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(ms))
fun dateTimeText(ms: Long): String = if (ms <= 0) "—" else SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ms))

fun agoText(now: Long, ts: Long): String {
    if (ts <= 0) return "—"
    val s = (now - ts) / 1000
    return when {
        s < 0 -> "بعد ${durationText(-s)}"
        s < 2 -> "الآن"
        else -> "قبل ${durationText(s)}"
    }
}

fun durationText(seconds: Long): String = when {
    seconds < 60 -> "${seconds}ث"
    seconds < 3600 -> "${seconds / 60}د"
    seconds < 86_400 -> "${seconds / 3600}س ${(seconds % 3600) / 60}د"
    else -> "${seconds / 86_400}ي ${(seconds % 86_400) / 3600}س"
}

// ---------- مكونات ----------

/** نص رقمي باتجاه LTR داخل واجهة RTL (أسعار، نسب، رموز). */
@Composable
fun Num(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    weight: FontWeight? = null,
    mono: Boolean = false,
    align: TextAlign? = null,
) {
    Text(
        text = text, modifier = modifier, color = color, fontWeight = weight, textAlign = align, maxLines = 1, overflow = TextOverflow.Ellipsis,
        style = style.copy(textDirection = TextDirection.Ltr, fontFamily = if (mono) FontFamily.Monospace else style.fontFamily),
    )
}

@Composable
fun signColor(value: Double?): Color {
    val m = LocalMarketColors.current
    return when {
        value == null || value == 0.0 || value.isNaN() -> MaterialTheme.colorScheme.onSurfaceVariant
        value > 0 -> m.up
        else -> m.down
    }
}

@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    container: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = container),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                trailing?.invoke()
            }
            content()
        }
    }
}

@Composable
fun Pill(text: String, color: Color = MaterialTheme.colorScheme.primary, modifier: Modifier = Modifier, filled: Boolean = false) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (filled) color else color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 3.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = if (filled) MaterialTheme.colorScheme.surface else color, maxLines = 1)
    }
}

/** كل ما لم يُثبت بقياس خارج العينة يُوسم بهذه الشارة. */
@Composable
fun UnprovenBadge(modifier: Modifier = Modifier) = Pill(AppConfig.UNPROVEN, LocalMarketColors.current.warn, modifier)

@Composable
fun StatRow(label: String, value: String, valueColor: Color = Color.Unspecified, hint: String? = null) {
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Num(value, style = MaterialTheme.typography.bodyMedium, color = valueColor, weight = FontWeight.Medium)
        }
        if (hint != null) Text(hint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun <T> SegmentRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, subtitle: String, modifier: Modifier = Modifier, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(34.dp))
        }
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (actionLabel != null && onAction != null) Button(onClick = onAction) { Text(actionLabel) }
    }
}

@Composable
fun ErrorState(message: String, modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(40.dp))
        Text("تعذر التحميل", style = MaterialTheme.typography.titleMedium)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (onRetry != null) Button(onClick = onRetry) { Text("إعادة المحاولة") }
    }
}

@Composable
fun LoadingState(text: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        CircularProgressIndicator()
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Dot(color: Color) {
    Box(Modifier.size(8.dp).clip(CircleShape).background(color))
}

/** حالة البث: تميّز «متصل بلا تغيير» عن «منقطع». */
@Composable
fun FeedStatusRow(status: FeedStatus, now: Long, modifier: Modifier = Modifier) {
    val m = LocalMarketColors.current
    val (color, text) = when {
        status.mode == HubMode.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant to "البث متوقف"
        status.ws.state == WsState.OPEN && status.staleMarked -> m.warn to "متصل — جارٍ تحديث القيم القديمة"
        status.ws.state == WsState.OPEN -> m.up to "متصل · آخر إطار ${agoText(now, status.lastFrameAt)}"
        status.ws.state == WsState.CONNECTING -> m.warn to "جارٍ الاتصال…"
        else -> m.down to "منقطع — إعادة اتصال${status.ws.lastError?.let { " ($it)" } ?: ""}"
    }
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Dot(color)
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        if (status.seed is SeedState.Loading) {
            Spacer(Modifier.width(4.dp))
            CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 2.dp)
        }
    }
}

@Composable
fun Disclaimer(modifier: Modifier = Modifier) {
    Text(
        AppConfig.DISCLAIMER, modifier = modifier.fillMaxWidth().padding(vertical = 8.dp),
        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center,
    )
}

/** شريط مساهمة متمركز حول الصفر في [-1, +1]. */
@Composable
fun ContributionBar(value: Double, modifier: Modifier = Modifier, scale: Double = 0.3) {
    val m = LocalMarketColors.current
    val frac = (abs(value) / scale).coerceIn(0.0, 1.0).toFloat()
    Row(modifier.height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        // النصف الأول (يمين في RTL) للموجب، الثاني للسالب
        Box(Modifier.weight(1f).height(8.dp), contentAlignment = Alignment.CenterEnd) {
            if (value > 0) Box(Modifier.fillMaxWidth(frac).height(8.dp).background(m.up))
        }
        Box(Modifier.width(1.dp).height(8.dp).background(MaterialTheme.colorScheme.outline))
        Box(Modifier.weight(1f).height(8.dp), contentAlignment = Alignment.CenterStart) {
            if (value < 0) Box(Modifier.fillMaxWidth(frac).height(8.dp).background(m.down))
        }
    }
}
