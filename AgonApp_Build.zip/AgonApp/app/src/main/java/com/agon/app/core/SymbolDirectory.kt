package com.agon.app.core

import com.agon.app.data.providers.BinanceRest
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.SymbolInfo
import com.agon.app.data.providers.TickerHub
import com.agon.app.domain.engine.Scanner
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

/** دليل الرموز الرسمي (exchangeInfo) لكل سوق، يُحمّل عند الحاجة ويُحتفظ به في الذاكرة. */
class SymbolDirectory(private val rest: BinanceRest, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val infos = ConcurrentHashMap<Market, Map<String, SymbolInfo>>()
    private val loadedAt = ConcurrentHashMap<Market, Long>()
    private val mutex = Mutex()

    fun cached(market: Market): Map<String, SymbolInfo>? = infos[market]
    fun info(market: Market, symbol: String): SymbolInfo? = infos[market]?.get(symbol)
    fun loadedAt(market: Market): Long = loadedAt[market] ?: 0L

    suspend fun ensure(market: Market, force: Boolean = false): Map<String, SymbolInfo> = mutex.withLock {
        val cur = infos[market]
        val age = clock() - (loadedAt[market] ?: 0L)
        if (cur != null && !force && age < REFRESH_MS) return cur
        try {
            val map = rest.exchangeInfo(market).associateBy { it.symbol }
            infos[market] = map
            loadedAt[market] = clock()
            map
        } catch (t: Throwable) {
            cur ?: throw t
        }
    }

    /** عملة التسعير: من exchangeInfo إن توفر، وإلا تخمين من اللاحقة (موسوم كتخمين في الواجهة). */
    fun quoteOf(market: Market, symbol: String): String? =
        info(market, symbol)?.quote ?: KNOWN_QUOTES.firstOrNull { symbol.endsWith(it) && symbol.length > it.length }

    fun baseOf(market: Market, symbol: String): String =
        info(market, symbol)?.base ?: quoteOf(market, symbol)?.let { symbol.removeSuffix(it) } ?: symbol

    /** معامل تحويل حجم التسعير إلى USDT من أسعار السوق نفسه؛ null ⇒ غير قابل للتحويل. */
    fun usdtFactor(market: Market, symbol: String, hub: TickerHub): Double? {
        val quote = quoteOf(market, symbol) ?: return null
        return Scanner.usdtFactor(quote) { hub.get(it)?.close }
    }

    companion object {
        const val REFRESH_MS = 6 * 3_600_000L
        val KNOWN_QUOTES = listOf("FDUSD", "USDT", "USDC", "TUSD", "BUSD", "USD1", "BTC", "ETH", "BNB", "TRY", "EUR", "BRL", "JPY", "DAI", "XRP", "SOL")
    }
}
