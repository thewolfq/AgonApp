package com.agon.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.sp
import com.agon.app.data.providers.KlineSeries
import com.agon.app.domain.engine.Level
import com.agon.app.domain.engine.LevelKind
import com.agon.app.domain.engine.fmtPrice
import com.agon.app.ui.theme.LocalMarketColors
import kotlin.math.max

/**
 * شارت شموع: الشموع المغلقة ممتلئة، والشمعة الجارية (غير المغلقة) مفرّغة بإطار فقط لأنها لا تدخل التحليل.
 * المحور الزمني من اليسار إلى اليمين دائمًا (لا يُعكس في RTL).
 */
@Composable
fun CandleChart(series: KlineSeries, levels: List<Level>, modifier: Modifier = Modifier, maxCandles: Int = 72) {
    val colors = LocalMarketColors.current
    val grid = MaterialTheme.colorScheme.outlineVariant
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    val primary = MaterialTheme.colorScheme.primary
    val measurer = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 10.sp, color = labelColor, textDirection = TextDirection.Ltr)

    Canvas(modifier.fillMaxWidth()) {
        val closed = series.closed.takeLast(maxCandles)
        val all = series.live?.let { closed + it } ?: closed
        if (all.isEmpty()) return@Canvas
        val axisW = 64f * density / 2.2f
        val w = size.width - axisW
        val h = size.height
        var hi = all.maxOf { it.high }
        var lo = all.minOf { it.low }
        if (hi <= lo) { hi = lo * 1.001 + 1e-9; lo *= 0.999 }
        val pad = (hi - lo) * 0.06
        hi += pad; lo -= pad
        fun y(p: Double): Float = (h * (1 - (p - lo) / (hi - lo))).toFloat()

        // شبكة أفقية + تسميات السعر
        for (i in 0..4) {
            val p = lo + (hi - lo) * i / 4
            val yy = y(p)
            drawLine(grid, Offset(0f, yy), Offset(w, yy), strokeWidth = 1f)
            val layout = measurer.measure(fmtPrice(p), labelStyle)
            drawText(layout, topLeft = Offset(w + 6f, (yy - layout.size.height / 2f).coerceIn(0f, h - layout.size.height)))
        }

        // الدعوم والمقاومات الواقعة داخل النطاق
        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
        levels.filter { it.price in lo..hi }.forEach { l ->
            val c = if (l.kind == LevelKind.SUPPORT) colors.up else colors.down
            drawLine(c.copy(alpha = 0.7f), Offset(0f, y(l.price)), Offset(w, y(l.price)), strokeWidth = 2f, pathEffect = dash)
        }

        val slot = w / max(all.size, 24)
        val bodyW = (slot * 0.68f).coerceAtLeast(1.5f)
        val offsetX = w - slot * all.size
        all.forEachIndexed { i, k ->
            val cx = offsetX + slot * i + slot / 2
            val up = k.close >= k.open
            val c = if (up) colors.up else colors.down
            drawLine(c, Offset(cx, y(k.high)), Offset(cx, y(k.low)), strokeWidth = 2f)
            val top = y(max(k.open, k.close))
            val bottom = y(minOf(k.open, k.close))
            val bodyH = (bottom - top).coerceAtLeast(2f)
            if (k.closed) {
                drawRect(c, topLeft = Offset(cx - bodyW / 2, top), size = Size(bodyW, bodyH))
            } else {
                drawRect(c.copy(alpha = 0.18f), topLeft = Offset(cx - bodyW / 2, top), size = Size(bodyW, bodyH))
                drawRect(c, topLeft = Offset(cx - bodyW / 2, top), size = Size(bodyW, bodyH), style = Stroke(width = 2f))
            }
        }

        // خط آخر سعر
        val last = all.last().close
        val ly = y(last)
        drawLine(primary, Offset(0f, ly), Offset(w, ly), strokeWidth = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 6f)))
        val lastLayout = measurer.measure(fmtPrice(last), labelStyle.copy(color = primary))
        drawText(lastLayout, topLeft = Offset(w + 6f, (ly - lastLayout.size.height / 2f).coerceIn(0f, h - lastLayout.size.height)))
    }
}
