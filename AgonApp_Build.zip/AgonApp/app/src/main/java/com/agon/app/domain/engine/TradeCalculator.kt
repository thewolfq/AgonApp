package com.agon.app.domain.engine

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.Market
import com.agon.app.domain.model.Direction
import com.agon.app.domain.model.Trade
import kotlin.math.abs

data class TradeInput(
    val market: Market,
    val direction: Direction,
    val entry: Double?,
    val leverage: Double?,
    val target: Double?,
    val stop: Double?,
    val size: Double?,
    val liqManual: Double?,
)

enum class LiqSource(val label: String) { MANUAL("يدوي من المنصة (المرجع)"), ESTIMATE("تقدير تقريبي"), NONE("لا تصفية (بلا رافعة)") }

data class TradeMetrics(
    val valid: Boolean,
    val errors: List<String>,
    val warnings: List<String>,
    val rewardRisk: Double?,
    val targetMovePct: Double?,
    val stopMovePct: Double?,
    /** الربح/الخسارة كنسبة من الهامش بعد الرافعة. */
    val profitPctOnMargin: Double?,
    val lossPctOnMargin: Double?,
    val margin: Double?,
    val profitQuote: Double?,
    val lossQuote: Double?,
    val liqEstimate: Double?,
    val liqReference: Double?,
    val liqSource: LiqSource,
    /** التصفية أقرب من الوقف ⇒ تحذير أحمر. */
    val liqBeforeStop: Boolean,
)

object TradeCalculator {
    const val LIQ_NOTE = "سعر التصفية المقدّر تقريبي (هامش معزول، معدل صيانة افتراضي) ويتأثر بالمنصة ونوع الهامش وشريحة الصيانة والرسوم والتمويل. السعر الذي تدخله يدويًا من منصتك هو المرجع."

    /** تقدير مبسط للهامش المعزول: Long: entry×(1 − 1/L + mmr)، Short: entry×(1 + 1/L − mmr). */
    fun estimateLiquidation(direction: Direction, entry: Double, leverage: Double, mmr: Double = AppConfig.Trade.DEFAULT_MAINTENANCE_MARGIN_RATE): Double? {
        if (leverage <= 1.0 || entry <= 0) return null
        val p = if (direction == Direction.LONG) entry * (1 - 1 / leverage + mmr) else entry * (1 + 1 / leverage - mmr)
        return p.takeIf { it > 0 }
    }

    fun compute(i: TradeInput): TradeMetrics {
        val errors = ArrayList<String>()
        val warnings = ArrayList<String>()
        val entry = i.entry
        val target = i.target
        val stop = i.stop
        val lev = if (i.market == Market.SPOT) 1.0 else (i.leverage ?: 1.0)

        if (entry == null || entry <= 0) errors += "أدخل سعر دخول صحيحًا"
        if (target == null || target <= 0) errors += "أدخل هدفًا صحيحًا"
        if (stop == null || stop <= 0) errors += "أدخل وقفًا صحيحًا"
        if (i.market == Market.SPOT && i.direction == Direction.SHORT) errors += "البيع المكشوف غير متاح في الفوري؛ اختر عقود"
        if (lev < 1.0 || lev > AppConfig.Trade.MAX_LEVERAGE) errors += "الرافعة بين 1 و${AppConfig.Trade.MAX_LEVERAGE.toInt()}"
        if (i.size != null && i.size < 0) errors += "الحجم لا يكون سالبًا"
        if (i.liqManual != null && i.liqManual <= 0) errors += "سعر التصفية غير صحيح"

        if (entry != null && entry > 0 && target != null && target > 0 && stop != null && stop > 0) {
            if (i.direction == Direction.LONG) {
                if (target <= entry) errors += "في الشراء يجب أن يكون الهدف أعلى من الدخول"
                if (stop >= entry) errors += "في الشراء يجب أن يكون الوقف أدنى من الدخول"
            } else {
                if (target >= entry) errors += "في البيع يجب أن يكون الهدف أدنى من الدخول"
                if (stop <= entry) errors += "في البيع يجب أن يكون الوقف أعلى من الدخول"
            }
        }
        if (errors.isNotEmpty() || entry == null || target == null || stop == null) {
            return TradeMetrics(false, errors, warnings, null, null, null, null, null, null, null, null, null, i.liqManual, if (i.liqManual != null) LiqSource.MANUAL else LiqSource.NONE, false)
        }

        val targetMove = abs(target - entry) / entry * 100
        val stopMove = abs(entry - stop) / entry * 100
        val rr = if (stopMove > 0) targetMove / stopMove else null
        val size = i.size?.takeIf { it > 0 }
        val margin = size?.let { it / lev }
        val estimate = if (i.market == Market.FUTURES) estimateLiquidation(i.direction, entry, lev) else null
        val reference = i.liqManual ?: estimate
        val source = when {
            i.liqManual != null -> LiqSource.MANUAL
            estimate != null -> LiqSource.ESTIMATE
            else -> LiqSource.NONE
        }
        val liqBeforeStop = reference != null && (if (i.direction == Direction.LONG) reference >= stop else reference <= stop)
        if (i.liqManual != null) {
            val wrongSide = if (i.direction == Direction.LONG) i.liqManual >= entry else i.liqManual <= entry
            if (wrongSide) warnings += "سعر التصفية المدخل على الجانب الخطأ من سعر الدخول — راجعه في منصتك"
        }
        if (liqBeforeStop) warnings += "التصفية أقرب من الوقف: ستُصفى الصفقة قبل أن يعمل الوقف"
        if (rr != null && rr < 1.0) warnings += "العائد/المخاطرة أقل من 1"
        if (stopMove * lev >= 100) warnings += "الخسارة عند الوقف تتجاوز كامل الهامش"

        return TradeMetrics(
            valid = true, errors = errors, warnings = warnings, rewardRisk = rr,
            targetMovePct = targetMove, stopMovePct = stopMove,
            profitPctOnMargin = targetMove * lev, lossPctOnMargin = stopMove * lev,
            margin = margin, profitQuote = size?.let { it * targetMove / 100 }, lossQuote = size?.let { it * stopMove / 100 },
            liqEstimate = estimate, liqReference = reference, liqSource = source, liqBeforeStop = liqBeforeStop,
        )
    }

    fun inputOf(t: Trade) = TradeInput(t.market, t.direction, t.entry, t.leverage, t.target, t.stop, t.size, t.liqManual)

    /** الربح/الخسارة الحالية كنسبة من الهامش بعد الرافعة. */
    fun pnlPctOnMargin(t: Trade, price: Double): Double =
        (price - t.entry) / t.entry * 100 * t.direction.sign * (if (t.market == Market.SPOT) 1.0 else t.leverage)
}
