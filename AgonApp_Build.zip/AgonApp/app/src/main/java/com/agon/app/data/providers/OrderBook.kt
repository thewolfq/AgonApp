package com.agon.app.data.providers

import com.agon.app.config.AppConfig
import java.util.TreeMap

data class BookWall(val price: Double, val notional: Double, val share: Double)

/** مقاييس الدفتر داخل نطاق ±[bandPct]% حول السعر الأوسط. القيم الاسمية بعملة التسعير. */
data class BookMetrics(
    val bestBid: Double,
    val bestAsk: Double,
    val mid: Double,
    val spreadBps: Double,
    val bidNotional: Double,
    val askNotional: Double,
    val imbalance: Double,
    val bidWall: BookWall?,
    val askWall: BookWall?,
    val bandPct: Double,
    val topBids: List<PriceLevel>,
    val topAsks: List<PriceLevel>,
    val lastUpdateId: Long,
    val bidLevels: Int,
    val askLevels: Int,
)

class LocalOrderBook {
    val bids = TreeMap<Double, Double>(Comparator.reverseOrder())
    val asks = TreeMap<Double, Double>()
    var lastUpdateId: Long = 0L

    fun load(s: DepthSnapshot) {
        bids.clear(); asks.clear()
        s.bids.forEach { if (it.qty > 0) bids[it.price] = it.qty }
        s.asks.forEach { if (it.qty > 0) asks[it.price] = it.qty }
        lastUpdateId = s.lastUpdateId
    }

    /** الكمية مطلقة لكل مستوى؛ الصفر يحذف المستوى. */
    fun apply(e: DepthEvent) {
        e.bids.forEach { if (it.qty == 0.0) bids.remove(it.price) else bids[it.price] = it.qty }
        e.asks.forEach { if (it.qty == 0.0) asks.remove(it.price) else asks[it.price] = it.qty }
        lastUpdateId = e.finalId
    }

    fun metrics(bandPct: Double = AppConfig.Book.DEPTH_BAND_PCT, viewLevels: Int = AppConfig.Book.VIEW_LEVELS): BookMetrics? {
        val bestBid = bids.firstEntry()?.key ?: return null
        val bestAsk = asks.firstEntry()?.key ?: return null
        val mid = (bestBid + bestAsk) / 2
        if (mid <= 0) return null
        val lowBound = mid * (1 - bandPct / 100)
        val highBound = mid * (1 + bandPct / 100)
        var bidN = 0.0
        var askN = 0.0
        var bidWall: PriceLevel? = null
        var askWall: PriceLevel? = null
        for ((p, q) in bids) {
            if (p < lowBound) break
            val n = p * q
            bidN += n
            if (bidWall == null || n > bidWall.price * bidWall.qty) bidWall = PriceLevel(p, q)
        }
        for ((p, q) in asks) {
            if (p > highBound) break
            val n = p * q
            askN += n
            if (askWall == null || n > askWall.price * askWall.qty) askWall = PriceLevel(p, q)
        }
        val total = bidN + askN
        return BookMetrics(
            bestBid = bestBid, bestAsk = bestAsk, mid = mid,
            spreadBps = (bestAsk - bestBid) / mid * 10_000,
            bidNotional = bidN, askNotional = askN,
            imbalance = if (total > 0) (bidN - askN) / total else 0.0,
            bidWall = bidWall?.let { BookWall(it.price, it.price * it.qty, if (bidN > 0) it.price * it.qty / bidN else 0.0) },
            askWall = askWall?.let { BookWall(it.price, it.price * it.qty, if (askN > 0) it.price * it.qty / askN else 0.0) },
            bandPct = bandPct,
            topBids = bids.entries.take(viewLevels).map { PriceLevel(it.key, it.value) },
            topAsks = asks.entries.take(viewLevels).map { PriceLevel(it.key, it.value) },
            lastUpdateId = lastUpdateId, bidLevels = bids.size, askLevels = asks.size,
        )
    }
}

enum class BookSyncState(val label: String) {
    IDLE("بانتظار البث"), BUFFERING("جارٍ البناء من snapshot"), SYNCED("مُزامَن"),
}

sealed class EventResult {
    /** خُزّن مؤقتًا؛ [needSnapshot] يعني اطلب snapshot عبر REST الآن. */
    data class Buffered(val needSnapshot: Boolean) : EventResult()
    object Applied : EventResult()
    object Ignored : EventResult()
    /** فجوة في التسلسل: أُسقط الدفتر ويجب إعادة البناء من snapshot جديد. */
    data class Gap(val reason: String) : EventResult()
}

sealed class SnapshotResult {
    data class Synced(val appliedBuffered: Int, val droppedBuffered: Int) : SnapshotResult()
    /** اللقطة غير قابلة للمطابقة مع الأحداث المخزنة؛ اجلب لقطة أحدث. */
    data class Retry(val reason: String) : SnapshotResult()
}

/**
 * آلة حالة خالصة لمزامنة الدفتر المحلي وفق خوارزمية Binance الرسمية لكل سوق.
 *
 * Spot: خزّن الأحداث → snapshot → إن كان lastUpdateId+1 < U لأول حدث فاللقطة أقدم من البث (أعد الجلب)
 *   → أسقط u <= lastUpdateId → طبّق: u < id تجاهل، U > id+1 فجوة، وإلا طبّق واجعل id = u.
 * Futures: أسقط u < lastUpdateId → أول حدث يجب U <= lastUpdateId <= u → بعدها pu يجب أن يساوي u السابق.
 *
 * لا يُبنى الدفتر أبدًا من تحديثات WebSocket وحدها.
 */
class OrderBookSynchronizer(
    private val market: Market,
    private val maxBuffer: Int = AppConfig.Book.MAX_BUFFERED_EVENTS,
) {
    val book = LocalOrderBook()
    var state: BookSyncState = BookSyncState.IDLE
        private set
    var resyncCount = 0
        private set
    var lastGapReason: String? = null
        private set

    private val buffer = ArrayDeque<DepthEvent>()
    private var lastFinalId = 0L
    private var awaitingFirstFuturesEvent = false

    fun reset(reason: String) {
        buffer.clear()
        state = BookSyncState.IDLE
        lastGapReason = reason
        awaitingFirstFuturesEvent = false
    }

    fun onEvent(e: DepthEvent): EventResult {
        return when (state) {
            BookSyncState.IDLE -> {
                buffer.clear()
                buffer.addLast(e)
                state = BookSyncState.BUFFERING
                EventResult.Buffered(needSnapshot = true)
            }
            BookSyncState.BUFFERING -> {
                buffer.addLast(e)
                if (buffer.size > maxBuffer) {
                    // الطابور امتلأ دون لقطة: ابدأ من جديد لتفادي مطابقة ناقصة.
                    buffer.clear()
                    buffer.addLast(e)
                    EventResult.Buffered(needSnapshot = true)
                } else EventResult.Buffered(needSnapshot = false)
            }
            BookSyncState.SYNCED -> applyLive(e)
        }
    }

    private fun gap(e: DepthEvent, reason: String): EventResult {
        resyncCount++
        lastGapReason = reason
        buffer.clear()
        buffer.addLast(e)
        state = BookSyncState.BUFFERING
        awaitingFirstFuturesEvent = false
        return EventResult.Gap(reason)
    }

    private fun applyLive(e: DepthEvent): EventResult {
        if (market == Market.SPOT) {
            if (e.finalId < book.lastUpdateId) return EventResult.Ignored
            if (e.firstId > book.lastUpdateId + 1) {
                return gap(e, "Spot: U=${e.firstId} > id+1=${book.lastUpdateId + 1}")
            }
            book.apply(e)
            lastFinalId = e.finalId
            return EventResult.Applied
        }
        // Futures
        if (awaitingFirstFuturesEvent) {
            if (e.finalId < book.lastUpdateId) return EventResult.Ignored
            if (e.firstId <= book.lastUpdateId && e.finalId >= book.lastUpdateId) {
                book.apply(e)
                lastFinalId = e.finalId
                awaitingFirstFuturesEvent = false
                return EventResult.Applied
            }
            return gap(e, "Futures: أول حدث U=${e.firstId} لا يغطي lastUpdateId=${book.lastUpdateId}")
        }
        if (e.prevFinalId == null || e.prevFinalId != lastFinalId) {
            return gap(e, "Futures: pu=${e.prevFinalId} ≠ u السابق=$lastFinalId")
        }
        book.apply(e)
        lastFinalId = e.finalId
        return EventResult.Applied
    }

    fun onSnapshot(s: DepthSnapshot): SnapshotResult {
        if (state != BookSyncState.BUFFERING) return SnapshotResult.Retry("لا توجد أحداث مخزنة بعد")
        val first = buffer.firstOrNull() ?: return SnapshotResult.Retry("الطابور فارغ")
        return if (market == Market.SPOT) syncSpot(s, first) else syncFutures(s)
    }

    private fun syncSpot(s: DepthSnapshot, first: DepthEvent): SnapshotResult {
        if (s.lastUpdateId + 1 < first.firstId) {
            return SnapshotResult.Retry("اللقطة (${s.lastUpdateId}) أقدم من أول حدث مخزن (U=${first.firstId})")
        }
        val before = buffer.size
        while (buffer.isNotEmpty() && buffer.first().finalId <= s.lastUpdateId) buffer.removeFirst()
        val dropped = before - buffer.size
        book.load(s)
        var applied = 0
        for (e in buffer) {
            if (e.finalId < book.lastUpdateId) continue
            if (e.firstId > book.lastUpdateId + 1) {
                buffer.clear()
                state = BookSyncState.IDLE
                resyncCount++
                lastGapReason = "Spot: فجوة داخل الأحداث المخزنة"
                return SnapshotResult.Retry(lastGapReason!!)
            }
            book.apply(e)
            applied++
        }
        lastFinalId = book.lastUpdateId
        buffer.clear()
        state = BookSyncState.SYNCED
        return SnapshotResult.Synced(applied, dropped)
    }

    private fun syncFutures(s: DepthSnapshot): SnapshotResult {
        val before = buffer.size
        while (buffer.isNotEmpty() && buffer.first().finalId < s.lastUpdateId) buffer.removeFirst()
        val dropped = before - buffer.size
        val first = buffer.firstOrNull()
        if (first != null && !(first.firstId <= s.lastUpdateId && first.finalId >= s.lastUpdateId)) {
            return SnapshotResult.Retry("Futures: اللقطة (${s.lastUpdateId}) لا تقع ضمن أول حدث [${first.firstId};${first.finalId}]")
        }
        book.load(s)
        var applied = 0
        var prev = 0L
        for ((i, e) in buffer.withIndex()) {
            if (i > 0 && e.prevFinalId != prev) {
                buffer.clear()
                state = BookSyncState.IDLE
                resyncCount++
                lastGapReason = "Futures: فجوة pu داخل الأحداث المخزنة"
                return SnapshotResult.Retry(lastGapReason!!)
            }
            book.apply(e)
            prev = e.finalId
            applied++
        }
        if (applied > 0) {
            lastFinalId = prev
            awaitingFirstFuturesEvent = false
        } else {
            awaitingFirstFuturesEvent = true
        }
        buffer.clear()
        state = BookSyncState.SYNCED
        return SnapshotResult.Synced(applied, dropped)
    }
}
