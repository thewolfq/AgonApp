package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.agon.app.data.providers.Market
import com.agon.app.ui.MainViewModel
import com.agon.app.ui.components.Pill
import com.agon.app.ui.screens.AboutScreen
import com.agon.app.ui.screens.CoinScreen
import com.agon.app.ui.screens.EvidenceScreen
import com.agon.app.ui.screens.MarketScreen
import com.agon.app.ui.screens.MoreScreen
import com.agon.app.ui.screens.SettingsScreen
import com.agon.app.ui.screens.StudiesScreen
import com.agon.app.ui.screens.TradeEditorScreen
import com.agon.app.ui.screens.TradesScreen
import com.agon.app.ui.screens.WatchlistScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.ui.theme.LocalMarketColors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AgonAppTheme {
                // واجهة عربية RTL دائمًا بغض النظر عن لغة الجهاز.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainApp()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // التنبيهات تعمل والتطبيق مفتوح حتى بلا خدمة خلفية.
        (application as GhaithApp).container.tradeMonitor.start("ui")
    }

    override fun onStop() {
        (application as GhaithApp).container.tradeMonitor.stop("ui")
        super.onStop()
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("market", "السوق", Icons.Default.BarChart),
    Tab("watch", "المراقبة", Icons.Default.Visibility),
    Tab("trades", "صفقاتي", Icons.Default.AccountBalanceWallet),
    Tab("studies", "الدراسات", Icons.Default.Science),
    Tab("evidence", "الدليل", Icons.Default.Verified),
    Tab("more", "المزيد", Icons.Default.MoreHoriz),
)

fun NavHostController.openCoin(market: Market, symbol: String) = navigate("coin/${market.id}/$symbol")

fun NavHostController.openTradeEditor(id: Long = 0, market: Market? = null, symbol: String? = null) =
    navigate("trade?id=$id&market=${market?.id ?: ""}&symbol=${symbol ?: ""}")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp() {
    val vm: MainViewModel = viewModel()
    val nav = rememberNavController()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val current = tabs.firstOrNull { it.route == route }
    val monitor by vm.monitor.collectAsStateWithLifecycle()
    val online by vm.online.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (current != null) {
                TopAppBar(
                    title = {
                        Column {
                            Text("غيث التداول", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(current.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    actions = {
                        val m = LocalMarketColors.current
                        Pill(
                            if (monitor.running) "المراقبة تعمل" else "المراقبة متوقفة",
                            if (monitor.running) m.up else if (monitor.stoppedUnexpectedly) m.down else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        IconButton(onClick = { nav.navigate("settings") }) { Icon(Icons.Default.Settings, contentDescription = "الإعدادات") }
                    },
                )
            }
        },
        bottomBar = {
            if (current != null) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, maxLines = 1) },
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo("market") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        Column(Modifier.padding(innerPadding).fillMaxSize()) {
            if (current != null) {
                if (!online) Banner(Icons.Default.WifiOff, "لا يوجد اتصال بالشبكة — الأسعار المعروضة قد تكون قديمة", null, null)
                if (monitor.stoppedUnexpectedly) {
                    Banner(
                        Icons.Default.Warning,
                        "المراقبة الخلفية متوقفة" + (monitor.stoppedReason?.let { ": $it" } ?: "") + ". لا تُستأنف تلقائيًا بعد إيقاف النظام أو Force Stop.",
                        "تشغيل",
                    ) { nav.navigate("settings") }
                }
            }
            NavHost(navController = nav, startDestination = "market", modifier = Modifier.weight(1f)) {
                composable("market") { MarketScreen(vm, onOpen = { m, s -> nav.openCoin(m, s) }) }
                composable("watch") { WatchlistScreen(vm, onOpen = { m, s -> nav.openCoin(m, s) }) }
                composable("trades") { TradesScreen(vm, onEdit = { id -> nav.openTradeEditor(id) }, onNew = { nav.openTradeEditor() }, onOpen = { m, s -> nav.openCoin(m, s) }) }
                composable("studies") { StudiesScreen(vm, onOpen = { m, s -> nav.openCoin(m, s) }) }
                composable("evidence") { EvidenceScreen(vm) }
                composable("more") { MoreScreen(onOpenAbout = { nav.navigate("about") }) }
                composable("about") { AboutScreen(onBack = { nav.popBackStack() }) }
                composable("settings") { SettingsScreen(vm, onBack = { nav.popBackStack() }) }
                composable(
                    "coin/{market}/{symbol}",
                    arguments = listOf(navArgument("market") { type = NavType.StringType }, navArgument("symbol") { type = NavType.StringType }),
                ) { entry ->
                    val market = Market.fromId(entry.arguments?.getString("market"))
                    val symbol = entry.arguments?.getString("symbol").orEmpty()
                    CoinScreen(
                        vm, market, symbol, onBack = { nav.popBackStack() },
                        onNewTrade = { nav.openTradeEditor(0, market, symbol) },
                        onOpenOther = { m -> nav.openCoin(m, symbol) },
                    )
                }
                composable(
                    "trade?id={id}&market={market}&symbol={symbol}",
                    arguments = listOf(
                        navArgument("id") { type = NavType.LongType; defaultValue = 0L },
                        navArgument("market") { type = NavType.StringType; defaultValue = "" },
                        navArgument("symbol") { type = NavType.StringType; defaultValue = "" },
                    ),
                ) { entry ->
                    TradeEditorScreen(
                        vm, tradeId = entry.arguments?.getLong("id") ?: 0L,
                        presetMarket = entry.arguments?.getString("market")?.takeIf { it.isNotEmpty() }?.let { Market.fromId(it) },
                        presetSymbol = entry.arguments?.getString("symbol").orEmpty(),
                        onDone = { nav.popBackStack() },
                    )
                }
            }
        }
    }
}

@Composable
private fun Banner(icon: ImageVector, text: String, action: String?, onAction: (() -> Unit)?) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onErrorContainer)
            Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
            if (action != null && onAction != null) TextButton(onClick = onAction) { Text(action) }
        }
    }
}
