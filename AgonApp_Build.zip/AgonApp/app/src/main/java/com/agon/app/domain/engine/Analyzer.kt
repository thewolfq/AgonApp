package com.agon.app.domain.engine

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BookMetrics
import com.agon.app.data.providers.Kline
import com.agon.app.data.providers.Market
import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.sign

data class TakerFlow(val buyNotional: Double, val sellNotional: Double, val trades: Int, val source: String) {
    val ratio: Double? get() = (buyNotional + sellNotional).let { if (it > 0) buyNotional / it else null }
}

data class DerivativesInput(
    val fundingRate: Double?,
    val fundingStale: Boolean,
    val fundingAt: Long,
    val nextFundingTime: Long?,
    val openInterest: Double?,
    val oiChangePct1h: Double?,
    val oiStale: Boolean,
    val oiAt: Long,
)

data class AnalysisInput(
    val symbol: String,
    val market: Market,
    val now: Long,
    val price: Double,
    /** شموع مغلقة فقط (x=true). */
    val k1m: List<Kline>,
    val k5m: List<Kline>,
    val k1h: List<Kline>,
    /** حجم التسعير 24س محوّلًا إلى USDT؛ null = تعذر التحويل. */
    val quoteVolume24hUsdt: Double?,
    val book: BookMetrics?,
    val bookSynced: Boolean,
    val bookSource: String,
    val liveFlow: TakerFlow?,
    val derivatives: DerivativesInput?,
    val feedHealthy: Boolean,
)

@Serializable
data class Factor(
    val key: String,
    val title: String,
    val available: Boolean,
    /** درجة العامل في [-1, +1]. */
    val score: Double,
    val baseWeight: Double,
    /** الوزن الفعّال بعد حذف غير المتاح وإعادة التطبيع (مجموع المتاح = 1). */
    val weight: Double,
    /** المساهمة = score × weight. */
    val contribution: Double,
    val value: String,
    val reason: String,
)

@Serializable
enum class Severity { BLOCK, WARN }

@Serializable
data class Blocker(val key: String, val severity: Severity, val title: String, val detail: String)

@Serializable
data class TfTrend(val tf: String, val available: Boolean, val score: Double, val label: String)

@Serializable
enum class Bias(val label: String, val sign: Int) {
    UP("ميل صاعد", 1), DOWN("ميل هابط", -1), NEUTRAL("محايد", 0)
}

@Serializable
data class Analysis(
    val symbol: String,
    val market: Market,
    val computedAt: Long,
    /** وقت إغلاق آخر شمعة مغلقة استُخدمت. */
    val basedOnCloseTime: Long,
    val price: Double,
    val factors: List<Factor>,
    /** مجموع المساهمات في [-1, +1]. ليست نسبة ثقة ولا احتمالًا. */
    val score: Double,
    val bias: Bias,
    val trends: List<TfTrend>,
    val structure1h: String,
    val structure5m: String,
    val levels: List<Level>,
    val blockers: List<Blocker>,
    val counterScenario: String,
    val relVolume: Double?,
    val rsi5m: Double?,
    val takerBuyRatio: Double?,
    val takerSource: String,
    val unproven: Boolean = true,
)

object Weights {
    data class Raw(val key: String, val title: String, val baseWeight: Double, val available: Boolean, val score: Double, val value: String, val reason: String)

    /**
     * إصلاح (1): العامل غير المتاح (مثل الدفتر) يُحذف من المجموع وتُعاد قسمة أوزان المتاح على مجموعها،
     * بدل إدخاله بدرجة صفر ووزن ثابت يسحب النتيجة نحو الحياد.
     */
    fun normalize(raw: List<Raw>): List<Factor> {
        val total = raw.filter { it.available }.sumOf { it.baseWeight }
        return raw.map {
            val w = if (it.available && total > 0) it.baseWeight / total else 0.0
            val s = if (it.available) it.score.clampUnit() else 0.0
            Factor(it.key, it.title, it.available, s, it.baseWeight, w, s * w, it.value, it.reason)
        }
    }
}

/** محرك تحليل حتمي: نفس المدخلات ⇒ نفس المخرجات. يعمل على الشموع المغلقة فقط. */
object Analyzer {
    private val E = AppConfig.Engine

    fun tfTrend(tf: String, k: List<Kline>): TfTrend {
        if (k.size < E.EMA_SLOW + 5) return TfTrend(tf, false, 0.0, "بيانات غير كافية")
        val closes = DoubleArray(k.size) { k[it].close }
        val fast = Indicators.ema(closes, E.EMA_FAST).last()
        val slow = Indicators.ema(closes, E.EMA_SLOW).last()
        val s = (if (fast > slow) 0.6 else -0.6) + (if (closes.last() > fast) 0.4 else -0.4)
        val label = when {
            s > 0.5 -> "صاعد"
            s < -0.5 -> "هابط"
            else -> "مختلط"
        }
        return TfTrend(tf, true, s, label)
    }

    fun analyze(i: AnalysisInput): Analysis {
        val raw = ArrayList<Weights.Raw>()

        // 1) الاتجاه متعدد الأطر
        val trends = listOf(tfTrend("1m", i.k1m), tfTrend("5m", i.k5m), tfTrend("1h", i.k1h))
        val tfW = mapOf("1m" to E.TF_WEIGHT_1M, "5m" to E.TF_WEIGHT_5M, "1h" to E.TF_WEIGHT_1H)
        val availTrends = trends.filter { it.available }
        val tfTotal = availTrends.sumOf { tfW.getValue(it.tf) }
        val trendScore = if (tfTotal > 0) availTrends.sumOf { it.score * tfW.getValue(it.tf) } / tfTotal else 0.0
        raw += Weights.Raw(
            "trend", "الاتجاه متعدد الأطر", E.W_TREND, availTrends.isNotEmpty(), trendScore,
            trends.joinToString(" · ") { "${it.tf}: ${it.label}" },
            "EMA${E.EMA_FAST}/EMA${E.EMA_SLOW} وموقع الإغلاق من EMA${E.EMA_FAST} على شموع مغلقة",
        )

        // 2) هيكل السوق
        val s1h = Structure.read(i.k1h)
        val s5m = Structure.read(i.k5m)
        val structAvail = s1h.kind != StructureKind.UNKNOWN || s5m.kind != StructureKind.UNKNOWN
        val w1 = if (s1h.kind != StructureKind.UNKNOWN) 0.6 else 0.0
        val w5 = if (s5m.kind != StructureKind.UNKNOWN) 0.4 else 0.0
        val structScore = if (w1 + w5 > 0) (s1h.kind.score * w1 + s5m.kind.score * w5) / (w1 + w5) else 0.0
        raw += Weights.Raw(
            "structure", "هيكل السوق", E.W_STRUCTURE, structAvail, structScore,
            "1h: ${s1h.kind.label} · 5m: ${s5m.kind.label}", "تسلسل آخر قمتين وقاعين متأرجحين مؤكدين",
        )

        // 3) الزخم
        val closes5 = DoubleArray(i.k5m.size) { i.k5m[it].close }
        val rsiArr = Indicators.rsi(closes5, E.RSI_PERIOD)
        val rsi = rsiArr.lastOrNull()?.takeIf { !it.isNaN() }
        val roc = if (closes5.size > E.ROC_BARS) (closes5.last() / closes5[closes5.size - 1 - E.ROC_BARS] - 1) * 100 else null
        val momAvail = rsi != null && roc != null
        val momScore = if (momAvail) 0.6 * ((rsi!! - 50) / 25).clampUnit() + 0.4 * (roc!! / E.ROC_NORM_PCT).clampUnit() else 0.0
        raw += Weights.Raw(
            "momentum", "الزخم", E.W_MOMENTUM, momAvail, momScore,
            if (momAvail) "RSI ${fmt(rsi!!, 1)} · تغير ساعة ${fmtSigned(roc!!)}%" else "غير متاح",
            "RSI${E.RSI_PERIOD} وتغير ${E.ROC_BARS} شمعة على 5m",
        )

        // 4) الحجم النسبي (موقّع باتجاه جسم آخر شمعة مغلقة)
        val rv = Indicators.relativeVolume(i.k5m, E.REL_VOLUME_PERIOD)
        val lastBar = i.k5m.lastOrNull()
        val rvAvail = rv != null && lastBar != null
        val rvScore = if (rvAvail) sign(lastBar!!.close - lastBar.open) * ((rv!! - 1) / (E.REL_VOLUME_STRONG - 1)).coerceIn(0.0, 1.0) else 0.0
        raw += Weights.Raw(
            "relVolume", "الحجم النسبي", E.W_REL_VOLUME, rvAvail, rvScore,
            if (rvAvail) "×${fmt(rv!!)} من متوسط ${E.REL_VOLUME_PERIOD} شمعة" else "غير متاح",
            "حجم آخر شمعة 5m مغلقة مقابل متوسطها، بإشارة جسم الشمعة",
        )

        // 5) شراء المبادرين: aggTrade الحي إن كفى، وإلا حقول kline الرسمية
        val liveRatio = i.liveFlow?.takeIf { it.trades >= AppConfig.Symbol.TAKER_MIN_TRADES }?.ratio
        val klineRatio = Indicators.takerBuyRatio(i.k5m, E.TAKER_KLINE_BARS)
        val takerRatio = liveRatio ?: klineRatio
        val takerSource = if (liveRatio != null) (i.liveFlow?.source ?: "aggTrade") else if (klineRatio != null) "kline takerBuyQuote (${E.TAKER_KLINE_BARS}×5m)" else "غير متاح"
        raw += Weights.Raw(
            "taker", "شراء المبادرين", E.W_TAKER, takerRatio != null,
            if (takerRatio != null) ((takerRatio - 0.5) / E.TAKER_NORM).clampUnit() else 0.0,
            if (takerRatio != null) "${fmt(takerRatio * 100, 1)}% شراء مبادر" else "غير متاح",
            "المصدر: $takerSource. m=true يعني المبادر بائع",
        )

        // 6) الدفتر — يُحذف إن لم يكن مُزامَنًا
        val bookAvail = i.book != null && i.bookSynced
        raw += Weights.Raw(
            "book", "دفتر الطلبات", E.W_BOOK, bookAvail,
            if (bookAvail) (i.book!!.imbalance / E.BOOK_IMBALANCE_NORM).clampUnit() else 0.0,
            if (bookAvail) "اختلال ${fmtSigned(i.book!!.imbalance * 100, 0)}% ضمن ±${fmt(i.book.bandPct, 1)}%" else "غير متاح — حُذف وأعيد التطبيع",
            "المصدر: ${i.bookSource}. عمق الدفتر ليس حجم 24س",
        )

        // 7) المشتقات (Futures فقط): تمويل متطرف معاكس + OI مع اتجاه السعر
        val d = i.derivatives
        val fundingOk = d?.fundingRate != null && !d.fundingStale
        val oiOk = d?.oiChangePct1h != null && !d.oiStale
        val derivAvail = i.market == Market.FUTURES && (fundingOk || oiOk)
        var derivScore = 0.0
        if (derivAvail) {
            var parts = 0
            if (fundingOk) { derivScore += -(d!!.fundingRate!! / E.EXTREME_FUNDING).clampUnit(); parts++ }
            if (oiOk && roc != null) { derivScore += sign(roc) * (d!!.oiChangePct1h!! / E.OI_CHANGE_NORM_PCT).clampUnit(); parts++ }
            if (parts > 0) derivScore /= parts
        }
        raw += Weights.Raw(
            "derivatives", "التمويل وOI", E.W_DERIVATIVES, derivAvail, derivScore,
            when {
                i.market != Market.FUTURES -> "خاص بسوق العقود — حُذف"
                !derivAvail -> "قديم/غير متاح — حُذف"
                else -> listOfNotNull(
                    if (fundingOk) "تمويل ${fmtSigned(d!!.fundingRate!! * 100, 4)}%" else null,
                    if (oiOk) "OI ساعة ${fmtSigned(d!!.oiChangePct1h!!)}%" else null,
                ).joinToString(" · ")
            },
            "تمويل متطرف يُقرأ عكسيًا؛ ارتفاع OI يُقرأ مع اتجاه السعر",
        )

        val factors = Weights.normalize(raw)
        val score = factors.sumOf { it.contribution }.clampUnit()
        val bias = when {
            score >= E.BIAS_THRESHOLD -> Bias.UP
            score <= -E.BIAS_THRESHOLD -> Bias.DOWN
            else -> Bias.NEUTRAL
        }
        val levels = Levels.compute(i.price, i.k1h, i.k5m, if (i.bookSynced) i.book else null)
        val blockers = blockers(i)
        val lastClose = listOfNotNull(i.k1m.lastOrNull(), i.k5m.lastOrNull(), i.k1h.lastOrNull()).maxOfOrNull { it.closeTime } ?: 0L

        return Analysis(
            symbol = i.symbol, market = i.market, computedAt = i.now, basedOnCloseTime = lastClose, price = i.price,
            factors = factors, score = score, bias = bias, trends = trends,
            structure1h = s1h.kind.label, structure5m = s5m.kind.label,
            levels = levels, blockers = blockers, counterScenario = counterScenario(bias, i.price, levels),
            relVolume = rv, rsi5m = rsi, takerBuyRatio = takerRatio, takerSource = takerSource,
        )
    }

    fun blockers(i: AnalysisInput): List<Blocker> {
        val out = ArrayList<Blocker>()
        val L = AppConfig.Liquidity
        val vol = i.quoteVolume24hUsdt
        when {
            vol == null -> out += Blocker("liquidity", Severity.BLOCK, "تعذر تقويم الحجم بـUSDT", "لا يوجد سعر تحويل لعملة التسعير؛ الزوج مستبعد من المسح والتنبيه.")
            vol < L.SCAN_MIN_QUOTE_VOLUME_24H_USDT -> out += Blocker("liquidity", Severity.BLOCK, "حجم 24س تحت حد المسح", "حجم التسعير 24س ≈ ${fmt(vol / 1e6)}M USDT < 3M. (حجم تداول لا عمق دفتر.)")
            vol < L.ALERT_MIN_QUOTE_VOLUME_24H_USDT -> out += Blocker("liquidity", Severity.WARN, "حجم 24س تحت حد التنبيه", "≈ ${fmt(vol / 1e6)}M USDT بين 3M و4.5M: يُمسح ولا تُرسل له تنبيهات دراسة/قوة.")
        }
        val b = i.book
        if (b != null && i.bookSynced) {
            when {
                b.spreadBps >= E.SPREAD_BLOCK_BPS -> out += Blocker("spread", Severity.BLOCK, "فارق سعري واسع", "${fmt(b.spreadBps, 1)} نقطة أساس ≥ ${fmt(E.SPREAD_BLOCK_BPS, 0)}")
                b.spreadBps >= E.SPREAD_WARN_BPS -> out += Blocker("spread", Severity.WARN, "فارق سعري مرتفع", "${fmt(b.spreadBps, 1)} نقطة أساس")
            }
            listOfNotNull(b.bidWall?.let { "طلبات" to it }, b.askWall?.let { "عروض" to it }).forEach { (side, w) ->
                if (w.share >= AppConfig.Book.WALL_SHARE) out += Blocker("wall-$side", Severity.WARN, "جدار $side مهيمن", "مستوى واحد يمثل ${fmt(w.share * 100, 0)}% من عمق الجانب ضمن ±${fmt(b.bandPct, 1)}% — قد يُسحب (تلاعب محتمل).")
            }
        } else {
            out += Blocker("book", Severity.WARN, "الدفتر غير مُزامَن", "عامل الدفتر والفارق غير متاحين الآن.")
        }
        // تلاعب: فتائل طويلة متكررة أو طفرة حجم انعكست
        val recent = i.k5m.takeLast(20)
        if (recent.size >= 10) {
            val wick = recent.map { k -> val r = k.high - k.low; if (r > 0) 1 - abs(k.close - k.open) / r else 0.0 }.average()
            if (wick >= E.WICK_RATIO_WARN) out += Blocker("wicks", Severity.WARN, "فتائل طويلة متكررة", "متوسط نسبة الفتيل ${fmt(wick * 100, 0)}% في آخر ${recent.size} شمعة 5m.")
            val avgVol = recent.dropLast(1).map { it.quoteVolume }.average()
            for (k in recent.takeLast(3)) {
                val range = k.high - k.low
                if (avgVol > 0 && range > 0 && k.quoteVolume >= avgVol * E.SPIKE_VOLUME_MULT) {
                    val retrace = if (k.close >= k.open) (k.high - k.close) / range else (k.close - k.low) / range
                    if (retrace >= E.SPIKE_REVERSAL_FRACTION) {
                        out += Blocker("spike", Severity.WARN, "طفرة حجم انعكست", "شمعة بحجم ×${fmt(k.quoteVolume / avgVol, 1)} ارتدت ${fmt(retrace * 100, 0)}% من مداها.")
                        break
                    }
                }
            }
        }
        // بيانات متأخرة
        val last1m = i.k1m.lastOrNull()
        if (!i.feedHealthy) out += Blocker("stale", Severity.BLOCK, "الاتصال منقطع", "البث الحي غير متصل؛ القيم المعروضة قد تكون قديمة.")
        else if (last1m != null && i.now - last1m.closeTime > AppConfig.Symbol.KLINE_STALE_MS) {
            out += Blocker("stale", Severity.BLOCK, "شموع متأخرة", "آخر شمعة 1m مغلقة قبل ${(i.now - last1m.closeTime) / 1000}ث.")
        }
        return out
    }

    fun counterScenario(bias: Bias, price: Double, levels: List<Level>): String {
        val support = levels.filter { it.kind == LevelKind.SUPPORT }.maxByOrNull { it.price }
        val resistance = levels.filter { it.kind == LevelKind.RESISTANCE }.minByOrNull { it.price }
        fun p(l: Level?) = l?.let { fmtPrice(it.price) } ?: "غير محدد"
        return when (bias) {
            Bias.UP -> "القراءة الصاعدة تسقط إذا أغلقت شمعة 5m تحت أقرب دعم (${p(support)})؛ عندها يصبح المسار المرجح اختبار الدعم التالي. الفشل عند المقاومة (${p(resistance)}) بحجم بيع مبادر يُضعفها أيضًا."
            Bias.DOWN -> "القراءة الهابطة تسقط إذا أغلقت شمعة 5m فوق أقرب مقاومة (${p(resistance)})؛ عندها يصبح المسار المرجح اختبار المقاومة التالية. ارتداد قوي من الدعم (${p(support)}) بحجم شراء مبادر يُضعفها أيضًا."
            Bias.NEUTRAL -> "لا ميل واضح. اختراق المقاومة (${p(resistance)}) بإغلاق وحجم يرجّح الصعود، وكسر الدعم (${p(support)}) يرجّح الهبوط؛ وكلاهما غير مثبت."
        }
    }
}

fun fmtPrice(p: Double): String {
    val a = abs(p)
    val d = when {
        a == 0.0 -> 2
        a >= 1000 -> 2
        a >= 1 -> 4
        a >= 0.01 -> 5
        a >= 0.0001 -> 7
        else -> 10
    }
    return fmt(p, d)
}
