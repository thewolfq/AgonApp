package com.agon.app.domain.engine

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.Kline
import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.random.Random

data class BacktestConfig(
    val minChange1hPct: Double = AppConfig.Backtest.MIN_CHANGE_1H_PCT,
    val minRelVolume: Double = AppConfig.Backtest.MIN_REL_VOLUME,
    val cooldownBars: Int = AppConfig.Backtest.COOLDOWN_BARS,
    val horizonBars: Int = AppConfig.Backtest.HORIZON_BARS,
    val minVolume24hUsdt: Double = AppConfig.Liquidity.SCAN_MIN_QUOTE_VOLUME_24H_USDT,
    val feeRoundTripPct: Double = AppConfig.Backtest.FEE_ROUND_TRIP_PCT,
)

data class SignalOutcome(
    val symbol: String,
    val index: Int,
    val time: Long,
    val direction: Int,
    val change1hPct: Double,
    val relVolume: Double,
    val volume24hUsdt: Double,
    /** العائد الموقّع باتجاه الإشارة بعد الأفق، ناقص الرسوم (%). */
    val forwardReturnPct: Double,
)

@Serializable
data class SampleStats(
    val n: Int,
    val meanPct: Double,
    val medianPct: Double,
    val hitRate: Double,
    /** فترة 95% لمتوسط العائد من block bootstrap. */
    val ciLowPct: Double,
    val ciHighPct: Double,
)

@Serializable
data class RadarReport(
    val generatedAt: Long,
    val market: String,
    val universeSize: Int,
    val symbolsWithData: Int,
    val totalSignals: Int,
    val inSample: SampleStats,
    val outOfSample: SampleStats,
    val proven: Boolean,
    val verdict: String,
    val definition: String,
    val blockLength: Int,
    val iterations: Int,
)

data class BootstrapResult(val mean: Double, val low: Double, val high: Double)

object Backtest {
    const val DEFINITION = "التعريف المسبق: «مثبت» = n خارج العينة ≥ 100 والحد الأدنى لفترة 95% (block bootstrap) لمتوسط العائد الموقّع بعد الرسوم > 0. غير ذلك = «غير مثبت»."

    /**
     * إصلاح (2) و(3): إشارة واحدة لكل زوج خلال فترة التهدئة، على نفس مجتمع العملات المفحوصة حيًا،
     * وبحجم 24س الحقيقي عند لحظة الإشارة (مجموع آخر 288 شمعة 5m × معامل USDT) لا حجم اليوم الحالي.
     */
    fun scanSignals(series: Map<String, List<Kline>>, usdtFactor: Map<String, Double>, cfg: BacktestConfig = BacktestConfig()): List<SignalOutcome> {
        val h = AppConfig.Scan.BARS_PER_HOUR
        val day = AppConfig.Scan.BARS_PER_DAY
        val out = ArrayList<SignalOutcome>()
        for ((symbol, k) in series) {
            val factor = usdtFactor[symbol] ?: continue
            val n = k.size
            if (n < day + h + cfg.horizonBars + 1) continue
            val prefix = DoubleArray(n + 1)
            for (i in 0 until n) prefix[i + 1] = prefix[i] + k[i].quoteVolume
            var nextAllowed = 0
            var i = day + h - 1
            while (i < n - cfg.horizonBars) {
                if (i >= nextAllowed) {
                    val vol24 = (prefix[i + 1] - prefix[i + 1 - day]) * factor
                    val ref = k[i - h].close
                    if (vol24 >= cfg.minVolume24hUsdt && ref > 0 && k[i].close > 0) {
                        val ch = (k[i].close / ref - 1) * 100
                        val hourVol = prefix[i + 1] - prefix[i + 1 - h]
                        val priorAvgHourly = (prefix[i + 1 - h] - prefix[i + 1 - h - day]) / day * h
                        val rv = if (priorAvgHourly > 0) hourVol / priorAvgHourly else 0.0
                        if (abs(ch) >= cfg.minChange1hPct && rv >= cfg.minRelVolume) {
                            val dir = if (ch > 0) 1 else -1
                            val fwd = (k[i + cfg.horizonBars].close / k[i].close - 1) * 100 * dir - cfg.feeRoundTripPct
                            out += SignalOutcome(symbol, i, k[i].closeTime, dir, ch, rv, vol24, fwd)
                            nextAllowed = i + cfg.cooldownBars
                        }
                    }
                }
                i++
            }
        }
        out.sortBy { it.time }
        return out
    }

    /**
     * Moving block bootstrap لمتوسط سلسلة مرتبة زمنيًا: يحافظ على الارتباط الزمني بين الإشارات المتجاورة
     * (إشارات نفس الساعة على عملات مختلفة ليست مستقلة).
     */
    fun blockBootstrap(values: DoubleArray, blockLength: Int, iterations: Int, seed: Long): BootstrapResult {
        val n = values.size
        if (n == 0) return BootstrapResult(0.0, 0.0, 0.0)
        val mean = values.average()
        if (n < 2) return BootstrapResult(mean, mean, mean)
        val len = blockLength.coerceIn(1, n)
        val blocks = ceil(n.toDouble() / len).toInt()
        val rnd = Random(seed)
        val means = DoubleArray(iterations)
        for (it in 0 until iterations) {
            var sum = 0.0
            var count = 0
            for (b in 0 until blocks) {
                val start = rnd.nextInt(0, n - len + 1)
                var j = 0
                while (j < len && count < n) {
                    sum += values[start + j]
                    count++
                    j++
                }
            }
            means[it] = sum / count
        }
        means.sort()
        return BootstrapResult(mean, means[(iterations * 0.025).toInt()], means[(iterations * 0.975).toInt().coerceAtMost(iterations - 1)])
    }

    fun stats(values: List<Double>): SampleStats {
        if (values.isEmpty()) return SampleStats(0, 0.0, 0.0, 0.0, 0.0, 0.0)
        val arr = values.toDoubleArray()
        val sorted = arr.sortedArray()
        val b = blockBootstrap(arr, AppConfig.Backtest.BLOCK_LENGTH, AppConfig.Backtest.BOOTSTRAP_ITERATIONS, AppConfig.Backtest.BOOTSTRAP_SEED)
        return SampleStats(arr.size, b.mean, sorted[sorted.size / 2], arr.count { it > 0 }.toDouble() / arr.size, b.low, b.high)
    }

    /** تقسيم زمني: أول 60% داخل العينة، الباقي خارجها. الحكم على خارج العينة فقط. */
    fun evaluate(outcomes: List<SignalOutcome>, market: String, universeSize: Int, symbolsWithData: Int, now: Long): RadarReport {
        val sorted = outcomes.sortedBy { it.time }
        val split = (sorted.size * AppConfig.Backtest.SPLIT_IN_SAMPLE).toInt()
        val ins = stats(sorted.take(split).map { it.forwardReturnPct })
        val oos = stats(sorted.drop(split).map { it.forwardReturnPct })
        val proven = oos.n >= AppConfig.Backtest.MIN_OOS_CASES && oos.ciLowPct > 0
        val verdict = when {
            oos.n < AppConfig.Backtest.MIN_OOS_CASES -> "${AppConfig.UNPROVEN}: حالات خارج العينة ${oos.n} < ${AppConfig.Backtest.MIN_OOS_CASES}."
            !proven -> "${AppConfig.UNPROVEN}: فترة الثقة خارج العينة [${fmtSigned(oos.ciLowPct)}%، ${fmtSigned(oos.ciHighPct)}%] تشمل الصفر أو تحته."
            else -> "اجتاز التعريف المسبق على هذه النافذة فقط (${oos.n} حالة)؛ نافذة قصيرة ولا تضمن الاستمرار."
        }
        return RadarReport(now, market, universeSize, symbolsWithData, sorted.size, ins, oos, proven, verdict, DEFINITION, AppConfig.Backtest.BLOCK_LENGTH, AppConfig.Backtest.BOOTSTRAP_ITERATIONS)
    }
}
