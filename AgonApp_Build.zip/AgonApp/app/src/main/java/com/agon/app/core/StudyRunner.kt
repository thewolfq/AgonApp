package com.agon.app.core

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BinanceRest
import com.agon.app.data.providers.Kline
import com.agon.app.data.providers.LocalOrderBook
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.TickerHub
import com.agon.app.data.store.AppSettings
import com.agon.app.data.store.Store
import com.agon.app.domain.engine.Analysis
import com.agon.app.domain.engine.AnalysisInput
import com.agon.app.domain.engine.Analyzer
import com.agon.app.domain.engine.Backtest
import com.agon.app.domain.engine.Calibration
import com.agon.app.domain.engine.Candidate
import com.agon.app.domain.engine.DerivativesInput
import com.agon.app.domain.engine.Excluded
import com.agon.app.domain.engine.RadarReport
import com.agon.app.domain.engine.RelStrength
import com.agon.app.domain.engine.RelativeStrength
import com.agon.app.domain.engine.Scanner
import com.agon.app.domain.engine.ThresholdCalibration
import com.agon.app.domain.engine.fmt
import com.agon.app.domain.engine.fmtSigned
import com.agon.app.domain.model.DecisionRecord
import com.agon.app.domain.model.MarketEvent
import com.agon.app.domain.model.StudyCard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlin.math.abs

data class ScanState(
    val running: Boolean = false,
    val market: Market? = null,
    val stage: String = "",
    val progress: Float = 0f,
    val error: String? = null,
    val lastScanAt: Long = 0L,
    val seen: Int = 0,
    val universe: Int = 0,
    val excluded: List<Excluded> = emptyList(),
    val hasSeries: Boolean = false,
    val llmNote: String? = null,
)

/** محتوى بطاقة الدراسة المحفوظ (لقطة صغيرة، لا شموع). */
@Serializable
data class StudyPayload(
    val analysis: Analysis,
    val candidate: Candidate,
    val relStrength: RelStrength? = null,
    val volume24hUsdt: Double,
    val quote: String,
    val funding: Double? = null,
    val fundingAt: Long = 0,
    val nextFundingTime: Long = 0,
    val openInterest: Double? = null,
    val oiChange1hPct: Double? = null,
    val oiAt: Long = 0,
    val bookSource: String = "",
    val bookImbalance: Double? = null,
    val spreadBps: Double? = null,
    /** ≥ 4.5M USDT حجم 24س ⇒ مؤهل لإشعار الدراسة. */
    val alertEligible: Boolean = false,
    val universeSize: Int = 0,
)

/**
 * خط الدراسات الحتمي: أعلى 100 زوج مؤهل → ترتيب بتغير آخر ساعة والحجم النسبي → دراسة معمقة لأفضل 5،
 * مع لقطة قرار لكل دراسة. الرادار يُقيّم على نفس سلاسل المجتمع المفحوص حيًا.
 */
class StudyRunner(
    private val store: Store,
    private val rest: BinanceRest,
    private val directory: SymbolDirectory,
    private val hubs: Map<Market, TickerHub>,
    private val sink: AlertSink,
    private val llm: LlmVeto,
    private val settings: StateFlow<AppSettings>,
    private val scope: CoroutineScope,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val _state = MutableStateFlow(ScanState())
    val state: StateFlow<ScanState> = _state
    private val _radar = MutableStateFlow<RadarReport?>(null)
    val radar: StateFlow<RadarReport?> = _radar
    private val _calibration = MutableStateFlow(ThresholdCalibration(AppConfig.Scan.RS_THRESHOLD_DEFAULT, false, 0, "غير معاير: لا حالات مقاسة بعد."))
    val calibration: StateFlow<ThresholdCalibration> = _calibration

    private val mutex = Mutex()
    private var lastSeries: Map<String, List<Kline>> = emptyMap()
    private var lastFactors: Map<String, Double> = emptyMap()
    private var lastMarket: Market? = null
    private var lastUniverse = 0

    fun decodePayload(text: String): StudyPayload? = runCatching { json.decodeFromString(StudyPayload.serializer(), text) }.getOrNull()

    suspend fun loadPersisted() {
        store.kvGet(RADAR_KEY)?.let { raw -> runCatching { json.decodeFromString(RadarReport.serializer(), raw) }.getOrNull()?.let { _radar.value = it } }
        refreshCalibration()
    }

    /** معايرة حد 45% من سجل القرارات (القوة النسبية عند الدراسة مقابل العائد الموقّع بعد 24س). */
    suspend fun refreshCalibration() {
        val samples = store.decisions(5000).asReversed().mapNotNull { d ->
            if (d.kind != "study" || d.ret24h == null || d.direction == 0) return@mapNotNull null
            val rs = runCatching { (json.parseToJsonElement(d.snapshot) as? JsonObject)?.get("rsShare")?.jsonPrimitive?.doubleOrNull }.getOrNull() ?: return@mapNotNull null
            rs to d.ret24h
        }
        _calibration.value = Calibration.calibrateThreshold(samples)
    }

    fun launchScan(market: Market) {
        scope.launch { runScan(market) }
    }

    suspend fun runScan(market: Market): Boolean {
        if (!mutex.tryLock()) return false
        try {
            val hub = hubs.getValue(market)
            _state.value = ScanState(running = true, market = market, stage = "تحميل القائمة الرسمية والرموز", lastScanAt = _state.value.lastScanAt, hasSeries = lastSeries.isNotEmpty())
            val infos = directory.ensure(market)
            val tickers = rest.tickers24h(market)
            val universe = Scanner.selectUniverse(tickers, infos)
            if (universe.entries.isEmpty()) error("لا أزواج مؤهلة (حجم 24س ≥ 3M USDT)")
            _state.update { it.copy(stage = "جلب شموع 5m لأعلى ${universe.entries.size} زوج", seen = universe.seen, universe = universe.entries.size, excluded = universe.excluded) }

            // سلاسل 5m للمجتمع كله (طلب واحد لكل زوج، تزامن محدود، احترام الأوزان)
            val series = HashMap<String, List<Kline>>()
            var done = 0
            coroutineScope {
                universe.entries.chunked(AppConfig.Scan.FETCH_CONCURRENCY).forEach { chunk ->
                    chunk.map { e ->
                        async {
                            val k = runCatching { rest.klines(market, e.symbol, AppConfig.Scan.KLINE_INTERVAL, AppConfig.Scan.KLINE_LIMIT).filter { it.closed } }
                            e.symbol to k.getOrNull()
                        }
                    }.awaitAll().forEach { (sym, k) -> if (k != null && k.isNotEmpty()) series[sym] = k }
                    done += chunk.size
                    _state.update { it.copy(progress = 0.7f * done / universe.entries.size) }
                }
            }
            if (series.isEmpty()) error("تعذر جلب الشموع لأي زوج")
            val factors = universe.entries.associate { it.symbol to it.usdtFactor }
            lastSeries = series; lastFactors = factors; lastMarket = market; lastUniverse = universe.entries.size

            // المرشحون: تغير آخر ساعة + الحجم النسبي
            val metrics = universe.entries.mapNotNull { e -> series[e.symbol]?.let { Scanner.candidateMetrics(e.symbol, it, e.usdtFactor) } }
            val top = Scanner.rankCandidates(metrics)
            val btc = series["BTCUSDT"] ?: runCatching { rest.klines(market, "BTCUSDT", AppConfig.Scan.KLINE_INTERVAL, AppConfig.Scan.KLINE_LIMIT).filter { it.closed } }.getOrNull()
            refreshCalibration()
            val cal = _calibration.value

            val scanId = clock()
            val cards = ArrayList<Pair<Long, StudyPayload>>()
            top.forEachIndexed { index, cand ->
                val sym = cand.metrics.symbol
                _state.update { it.copy(stage = "دراسة معمقة ${index + 1}/${top.size}: $sym", progress = 0.7f + 0.3f * index / top.size) }
                val entry = universe.entries.first { it.symbol == sym }
                val k5m = series.getValue(sym)
                val k1h = rest.klines(market, sym, "1h", 200).filter { it.closed }
                val k1m = rest.klines(market, sym, "1m", 120).filter { it.closed }
                val book = runCatching {
                    LocalOrderBook().apply { load(rest.depthSnapshot(market, sym, AppConfig.Book.STUDY_SNAPSHOT_LIMIT)) }.metrics()
                }.getOrNull()
                var deriv: DerivativesInput? = null
                var nextFunding = 0L
                if (market == Market.FUTURES) {
                    val now = clock()
                    val mark = runCatching { rest.premiumIndex(sym) }.getOrNull()
                    val oi = runCatching { rest.openInterest(sym) }.getOrNull()
                    val hist = runCatching { rest.openInterestHist(sym, "5m", 13) }.getOrNull()
                    val change = hist?.takeIf { it.size >= 2 && it.first().openInterest > 0 }?.let { (it.last().openInterest - it.first().openInterest) / it.first().openInterest * 100 }
                    nextFunding = mark?.nextFundingTime ?: 0L
                    deriv = DerivativesInput(mark?.fundingRate, mark == null, now, mark?.nextFundingTime, oi?.openInterest, change, oi == null || change == null, now)
                }
                val now = clock()
                val price = k1m.lastOrNull()?.close ?: cand.metrics.price
                val bookSource = "لقطة REST واحدة (${AppConfig.Book.STUDY_SNAPSHOT_LIMIT} مستوى) — ليست دفترًا حيًا"
                val analysis = Analyzer.analyze(
                    AnalysisInput(sym, market, now, price, k1m, k5m, k1h, entry.quoteVolumeUsdt, book, book != null, bookSource, null, deriv, true),
                )
                val rs = btc?.let { RelativeStrength.compute(k5m, it, threshold = cal.threshold, calibrated = cal.calibrated) }
                val eligible = entry.quoteVolumeUsdt >= AppConfig.Liquidity.ALERT_MIN_QUOTE_VOLUME_24H_USDT
                val payload = StudyPayload(
                    analysis, cand, rs, entry.quoteVolumeUsdt, entry.quote, deriv?.fundingRate, deriv?.fundingAt ?: 0, nextFunding,
                    deriv?.openInterest, deriv?.oiChangePct1h, deriv?.oiAt ?: 0, bookSource, book?.imbalance, book?.spreadBps, eligible, universe.entries.size,
                )
                val id = store.insertStudy(StudyCard(0, now, scanId, sym, market, index + 1, analysis.score, analysis.bias.name, price, json.encodeToString(StudyPayload.serializer(), payload)))
                cards += id to payload
                store.insertDecision(
                    DecisionRecord(
                        ts = now, kind = "study", refId = id, symbol = sym, market = market, direction = analysis.bias.sign, score = analysis.score,
                        price = price, funding = deriv?.fundingRate, openInterest = deriv?.openInterest,
                        snapshot = buildJsonObject {
                            put("factors", buildJsonArray { analysis.factors.forEach { f -> add(buildJsonObject { put("k", f.key); put("a", f.available); put("s", f.score); put("w", f.weight); put("c", f.contribution) }) } })
                            put("change1h", cand.metrics.change1hPct); put("relVol", cand.metrics.relVolume); put("vol24hUsdt", entry.quoteVolumeUsdt)
                            book?.let { put("bookImb", it.imbalance); put("spreadBps", it.spreadBps) }
                            rs?.let { put("rsShare", it.outperformShare); put("rsExcess", it.excessPct); put("rsThreshold", it.threshold) }
                            put("blockers", analysis.blockers.size)
                        }.toString(),
                    ),
                )
                val blocked = analysis.blockers.any { it.severity == com.agon.app.domain.engine.Severity.BLOCK }
                if (settings.value.notifyStudies && eligible && !blocked && abs(analysis.score) >= AppConfig.Scan.STUDY_NOTIFY_MIN_ABS_SCORE) {
                    sink.alert(
                        "study:$scanId:$sym", "دراسة جديدة — $sym",
                        "${analysis.bias.label} (${AppConfig.UNPROVEN}) · الدرجة ${fmtSigned(analysis.score)} · ساعة ${fmtSigned(cand.metrics.change1hPct)}% · حجم نسبي ×${fmt(cand.metrics.relVolume, 1)}", false,
                    )
                }
            }
            _state.update { it.copy(running = false, stage = "اكتمل: ${top.size} دراسات من ${universe.entries.size} زوجًا", progress = 1f, lastScanAt = clock(), hasSeries = true, error = null) }
            runLlm(market, cards)
            return true
        } catch (e: CancellationException) {
            _state.update { it.copy(running = false) }
            throw e
        } catch (e: Throwable) {
            _state.update { it.copy(running = false, error = e.message ?: e.javaClass.simpleName, stage = "فشل المسح") }
            return false
        } finally {
            mutex.unlock()
        }
    }

    /** طبقة النموذج اللغوي الاختيارية: للمرشحين فقط، فيتو مخاطر لا مصدر إشارة، ولا تؤثر في الدرجة. */
    private suspend fun runLlm(market: Market, cards: List<Pair<Long, StudyPayload>>) {
        val s = settings.value
        if (!s.llmEnabled) return
        if (!llm.configured(s.llmEndpoint, s.llmModel)) {
            _state.update { it.copy(llmNote = "النموذج اللغوي مفعّل لكنه غير مكتمل الإعداد (رابط https ونموذج ومفتاح).") }
            return
        }
        var ok = 0
        for ((id, p) in cards) {
            val a = p.analysis
            val facts = "price=${a.price}; 1h change=${fmtSigned(p.candidate.metrics.change1hPct)}%; relative volume x${fmt(p.candidate.metrics.relVolume, 1)}; 24h quote volume ~${fmt(p.volume24hUsdt / 1e6, 1)}M USDT; funding=${p.funding ?: "n/a"}; blockers=${a.blockers.joinToString { it.key }}"
            val verdict = llm.review(s.llmEndpoint, s.llmModel, a.symbol, market.label, facts, clock())
            store.setStudyLlm(id, llm.encode(verdict))
            if (verdict.error == null) {
                ok++
                verdict.events.filter { it.title.isNotBlank() }.forEach { ev ->
                    store.insertEvent(
                        MarketEvent(
                            ts = parseDate(ev.date) ?: clock(), symbol = a.symbol, title = ev.title.take(160), kind = ev.type.take(24),
                            source = ev.source.ifBlank { "بلا مصدر" }.take(200), evidence = "llm-unverified", note = "مستوى الدليل: ${verdict.evidenceLevel}", createdAt = clock(),
                        ),
                    )
                }
            }
        }
        _state.update { it.copy(llmNote = "مراجعة النموذج اللغوي: $ok/${cards.size} نجحت (فيتو مخاطر فقط).") }
    }

    private fun parseDate(text: String): Long? = runCatching {
        java.time.LocalDate.parse(text.trim().take(10)).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
    }.getOrNull()

    /** إعادة قياس الرادار على نفس مجتمع آخر مسح حي، بحجم 24س الحقيقي وblock bootstrap. */
    suspend fun runRadar(): Result<RadarReport> {
        val series = lastSeries
        val market = lastMarket
        if (series.isEmpty() || market == null) return Result.failure(IllegalStateException("شغّل المسح أولًا: القياس يستخدم نفس سلاسل المجتمع المفحوص حيًا (لا تُحفظ شموع)."))
        return runCatching {
            val outcomes = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { Backtest.scanSignals(series, lastFactors) }
            val report = Backtest.evaluate(outcomes, market.id, lastUniverse, series.size, clock())
            store.kvPut(RADAR_KEY, json.encodeToString(RadarReport.serializer(), report))
            _radar.value = report
            report
        }
    }

    companion object {
        const val RADAR_KEY = "radar_report"
    }
}

/** يقيس نتيجة كل لقطة قرار بعد 4 و24 ساعة من شمعة 1m الرسمية عند ذلك الوقت. */
class OutcomeTracker(private val store: Store, private val rest: BinanceRest, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val mutex = Mutex()

    suspend fun runOnce(): Int {
        if (!mutex.tryLock()) return 0
        var measured = 0
        try {
            val now = clock()
            for (d in store.pendingOutcomes(now)) {
                for ((is24, horizon) in listOf(false to AppConfig.Outcome.H4_MS, true to AppConfig.Outcome.H24_MS)) {
                    val already = if (is24) d.price24h != null else d.price4h != null
                    if (already || d.ts + horizon > now || d.price <= 0) continue
                    val k = runCatching { rest.klines(d.market, d.symbol, "1m", 1, startTime = d.ts + horizon) }.getOrNull()?.firstOrNull() ?: continue
                    // العائد موقّع باتجاه القرار؛ القرار المحايد يُسجّل عائده الخام ولا يدخل في معدل الإصابة.
                    val ret = (k.close / d.price - 1) * 100 * (if (d.direction == 0) 1 else d.direction)
                    store.setOutcome(d.id, is24, k.close, ret)
                    measured++
                }
            }
        } finally {
            mutex.unlock()
        }
        return measured
    }
}
