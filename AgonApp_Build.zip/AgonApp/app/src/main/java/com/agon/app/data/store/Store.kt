package com.agon.app.data.store

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabaseLockedException
import android.database.sqlite.SQLiteOpenHelper
import com.agon.app.config.AppConfig
import com.agon.app.data.providers.Market
import com.agon.app.domain.model.AlertRecord
import com.agon.app.domain.model.AlertStateRow
import com.agon.app.domain.model.DecisionRecord
import com.agon.app.domain.model.Direction
import com.agon.app.domain.model.MarketEvent
import com.agon.app.domain.model.SavedLevel
import com.agon.app.domain.model.StudyCard
import com.agon.app.domain.model.Trade
import com.agon.app.domain.model.TradeFrame
import com.agon.app.domain.model.TradeStatus
import com.agon.app.domain.model.WatchItem
import com.agon.app.domain.model.WatchTag
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

/** SQLite مع WAL وmigrations مرقمة. كل migration تُطبّق داخل معاملة SQLiteOpenHelper. */
class GhaithDb(context: Context, name: String) : SQLiteOpenHelper(context, name, null, Migrations.LATEST) {
    init {
        setWriteAheadLoggingEnabled(true)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        // انتظار الأقفال بدل الفشل الفوري.
        db.rawQuery("PRAGMA busy_timeout=5000", null).use { it.moveToFirst() }
    }

    override fun onCreate(db: SQLiteDatabase) {
        Migrations.between(0, Migrations.LATEST).forEach { m -> m.statements.forEach { db.execSQL(it) } }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Migrations.between(oldVersion, newVersion).forEach { m -> m.statements.forEach { db.execSQL(it) } }
    }
}

private fun Cursor.s(n: String): String = getString(getColumnIndexOrThrow(n))
private fun Cursor.sn(n: String): String? = getColumnIndexOrThrow(n).let { if (isNull(it)) null else getString(it) }
private fun Cursor.l(n: String): Long = getLong(getColumnIndexOrThrow(n))
private fun Cursor.ln(n: String): Long? = getColumnIndexOrThrow(n).let { if (isNull(it)) null else getLong(it) }
private fun Cursor.i(n: String): Int = getInt(getColumnIndexOrThrow(n))
private fun Cursor.d(n: String): Double = getDouble(getColumnIndexOrThrow(n))
private fun Cursor.dn(n: String): Double? = getColumnIndexOrThrow(n).let { if (isNull(it)) null else getDouble(it) }

private inline fun <T> SQLiteDatabase.list(sql: String, args: Array<String> = emptyArray(), map: (Cursor) -> T): List<T> =
    rawQuery(sql, args).use { c ->
        val out = ArrayList<T>(c.count)
        while (c.moveToNext()) out += map(c)
        out
    }

/**
 * طبقة التخزين. كاتب واحد واضح: كل الكتابات تمر عبر خيط واحد (ghaith-db-writer) داخل معاملة ذرية،
 * والقراءات متزامنة عبر WAL. لا تُحفظ أسعار أو شموع.
 */
class Store(context: Context, dbName: String = DB_NAME) {
    val helper = GhaithDb(context.applicationContext, dbName)
    private val writerExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "ghaith-db-writer") }
    private val writer = writerExecutor.asCoroutineDispatcher()
    private val _changes = MutableStateFlow(0L)

    /** يزداد بعد كل معاملة كتابة ناجحة؛ الواجهة تعيد الاستعلام عنده. */
    val changes: StateFlow<Long> = _changes

    suspend fun <T> write(block: (SQLiteDatabase) -> T): T = withContext(writer) { writeOnWriterThread(block) }

    private fun <T> writeOnWriterThread(block: (SQLiteDatabase) -> T): T {
        var attempt = 0
        while (true) {
            try {
                val db = helper.writableDatabase
                db.beginTransactionNonExclusive()
                val result = try {
                    val r = block(db)
                    db.setTransactionSuccessful()
                    r
                } finally {
                    db.endTransaction()
                }
                _changes.update { it + 1 }
                return result
            } catch (e: SQLiteDatabaseLockedException) {
                // معالجة الأقفال: إعادة محاولة محدودة بتراجع أسّي.
                if (++attempt > 5) throw e
                Thread.sleep(40L shl attempt)
            }
        }
    }

    suspend fun <T> read(block: (SQLiteDatabase) -> T): T = withContext(Dispatchers.IO) { block(helper.readableDatabase) }

    fun journalMode(): String = helper.readableDatabase.rawQuery("PRAGMA journal_mode", null).use { if (it.moveToFirst()) it.getString(0) else "" }

    fun close() {
        helper.close()
        writerExecutor.shutdown()
    }

    // ---------------- المراقبة ----------------

    private fun watchOf(c: Cursor) = WatchItem(c.l("id"), c.s("symbol"), Market.fromId(c.s("market")), runCatching { WatchTag.valueOf(c.s("tag")) }.getOrDefault(WatchTag.WATCH), c.i("position"), c.l("added_at"))

    suspend fun watchlist(): List<WatchItem> = read { it.list("SELECT * FROM watchlist ORDER BY position, id") { c -> watchOf(c) } }

    /** يضيف إن لم يكن موجودًا. يعيد false إن كان موجودًا (لا تكرار). */
    suspend fun addWatch(symbol: String, market: Market, tag: WatchTag, now: Long): Boolean = write { db ->
        val pos = db.rawQuery("SELECT COALESCE(MAX(position), -1) + 1 FROM watchlist", null).use { it.moveToFirst(); it.getInt(0) }
        val cv = ContentValues().apply { put("symbol", symbol); put("market", market.id); put("tag", tag.name); put("position", pos); put("added_at", now) }
        db.insertWithOnConflict("watchlist", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    suspend fun removeWatch(ids: Collection<Long>) = write { db -> ids.forEach { db.delete("watchlist", "id=?", arrayOf(it.toString())) } }

    suspend fun setWatchTag(id: Long, tag: WatchTag) = write { db ->
        db.update("watchlist", ContentValues().apply { put("tag", tag.name) }, "id=?", arrayOf(id.toString()))
    }

    suspend fun reorderWatch(idsInOrder: List<Long>) = write { db ->
        idsInOrder.forEachIndexed { index, id -> db.update("watchlist", ContentValues().apply { put("position", index) }, "id=?", arrayOf(id.toString())) }
    }

    // ---------------- الصفقات ----------------

    private fun tradeOf(c: Cursor) = Trade(
        id = c.l("id"), symbol = c.s("symbol"), market = Market.fromId(c.s("market")),
        direction = runCatching { Direction.valueOf(c.s("direction")) }.getOrDefault(Direction.LONG),
        frame = runCatching { TradeFrame.valueOf(c.s("frame")) }.getOrDefault(TradeFrame.FAST),
        entry = c.d("entry"), leverage = c.d("leverage"), target = c.d("target"), stop = c.d("stop"), size = c.d("size"),
        note = c.s("note"), liqManual = c.dn("liq_manual"),
        status = runCatching { TradeStatus.valueOf(c.s("status")) }.getOrDefault(TradeStatus.OPEN),
        openedAt = c.l("opened_at"), closedAt = c.ln("closed_at"), closePrice = c.dn("close_price"), closeReason = c.sn("close_reason"),
    )

    private fun tradeValues(t: Trade) = ContentValues().apply {
        put("symbol", t.symbol); put("market", t.market.id); put("direction", t.direction.name); put("frame", t.frame.name)
        put("entry", t.entry); put("leverage", t.leverage); put("target", t.target); put("stop", t.stop); put("size", t.size)
        put("note", t.note); if (t.liqManual != null) put("liq_manual", t.liqManual) else putNull("liq_manual")
        put("status", t.status.name); put("opened_at", t.openedAt)
        if (t.closedAt != null) put("closed_at", t.closedAt) else putNull("closed_at")
        if (t.closePrice != null) put("close_price", t.closePrice) else putNull("close_price")
        if (t.closeReason != null) put("close_reason", t.closeReason) else putNull("close_reason")
    }

    suspend fun trades(): List<Trade> = read { it.list("SELECT * FROM trades ORDER BY status DESC, opened_at DESC") { c -> tradeOf(c) } }

    suspend fun openTrades(): List<Trade> = read { it.list("SELECT * FROM trades WHERE status='OPEN' ORDER BY opened_at DESC") { c -> tradeOf(c) } }

    /** إدراج أو تحديث. تعديل المستويات يمسح حالات التنبيه السابقة للصفقة (العتبات تغيرت). */
    suspend fun saveTrade(t: Trade): Long = write { db ->
        if (t.id == 0L) db.insertOrThrow("trades", null, tradeValues(t))
        else {
            db.update("trades", tradeValues(t), "id=?", arrayOf(t.id.toString()))
            db.delete("alert_state", "trade_id=? AND type != 'STRENGTH_CHANGED'", arrayOf(t.id.toString()))
            t.id
        }
    }

    suspend fun closeTrade(id: Long, price: Double?, reason: String, now: Long) = write { db ->
        val cv = ContentValues().apply {
            put("status", TradeStatus.CLOSED.name); put("closed_at", now); put("close_reason", reason)
            if (price != null) put("close_price", price) else putNull("close_price")
        }
        db.update("trades", cv, "id=?", arrayOf(id.toString()))
    }

    suspend fun deleteTrade(id: Long) = write { db ->
        db.delete("alert_state", "trade_id=?", arrayOf(id.toString()))
        db.delete("trades", "id=?", arrayOf(id.toString()))
    }

    // ---------------- حالة التنبيهات (منع التكرار) ----------------

    private fun stateOf(c: Cursor) = AlertStateRow(c.s("key"), c.l("trade_id"), c.s("type"), c.s("detail"), c.l("fired_at"), c.d("value"))

    private fun stateValues(r: AlertStateRow) = ContentValues().apply {
        put("key", r.key); put("trade_id", r.tradeId); put("type", r.type); put("detail", r.detail); put("fired_at", r.firedAt); put("value", r.value)
    }

    suspend fun alertStates(): List<AlertStateRow> = read { it.list("SELECT * FROM alert_state") { c -> stateOf(c) } }

    suspend fun alertState(key: String): AlertStateRow? = read { it.list("SELECT * FROM alert_state WHERE key=?", arrayOf(key)) { c -> stateOf(c) }.firstOrNull() }

    /**
     * إطلاق ذري: INSERT OR IGNORE على المفتاح الأساسي. true فقط لأول من يُدرج المفتاح؛
     * أي محاولة لاحقة للحالة نفسها (حتى بعد إعادة تشغيل العملية) تعيد false.
     */
    suspend fun tryFireAlert(r: AlertStateRow): Boolean = write { db ->
        db.insertWithOnConflict("alert_state", null, stateValues(r), SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    suspend fun upsertAlertState(r: AlertStateRow) = write { db ->
        db.insertWithOnConflict("alert_state", null, stateValues(r), SQLiteDatabase.CONFLICT_REPLACE)
    }

    suspend fun rearmAlert(key: String) = write { db -> db.delete("alert_state", "key=?", arrayOf(key)) }

    private fun alertOf(c: Cursor) = AlertRecord(c.l("id"), c.l("ts"), c.l("trade_id"), c.s("symbol"), Market.fromId(c.s("market")), c.s("type"), c.s("title"), c.s("body"), c.d("price"), c.i("critical") != 0, c.i("delivered") != 0)

    private fun alertValues(a: AlertRecord, withId: Boolean) = ContentValues().apply {
        if (withId) put("id", a.id)
        put("ts", a.ts); put("trade_id", a.tradeId); put("symbol", a.symbol); put("market", a.market.id); put("type", a.type)
        put("title", a.title); put("body", a.body); put("price", a.price); put("critical", if (a.critical) 1 else 0); put("delivered", if (a.delivered) 1 else 0)
    }

    suspend fun logAlert(a: AlertRecord): Long = write { db -> db.insertOrThrow("alert_log", null, alertValues(a, false)) }

    suspend fun alertLog(limit: Int = 200): List<AlertRecord> = read { it.list("SELECT * FROM alert_log ORDER BY ts DESC LIMIT $limit") { c -> alertOf(c) } }

    suspend fun clearAlertLog() = write { db -> db.delete("alert_log", null, null) }

    // ---------------- الدراسات ----------------

    private fun studyOf(c: Cursor) = StudyCard(c.l("id"), c.l("ts"), c.l("scan_id"), c.s("symbol"), Market.fromId(c.s("market")), c.i("rank"), c.d("score"), c.s("bias"), c.d("price"), c.s("payload"), c.sn("llm"))

    private fun studyValues(s: StudyCard, withId: Boolean) = ContentValues().apply {
        if (withId) put("id", s.id)
        put("ts", s.ts); put("scan_id", s.scanId); put("symbol", s.symbol); put("market", s.market.id); put("rank", s.rank)
        put("score", s.score); put("bias", s.bias); put("price", s.price); put("payload", s.payload)
        if (s.llm != null) put("llm", s.llm) else putNull("llm")
    }

    suspend fun insertStudy(s: StudyCard): Long = write { db -> db.insertOrThrow("studies", null, studyValues(s, false)) }

    suspend fun studies(limit: Int = 60): List<StudyCard> = read { it.list("SELECT * FROM studies ORDER BY ts DESC, rank LIMIT $limit") { c -> studyOf(c) } }

    suspend fun setStudyLlm(id: Long, json: String) = write { db ->
        db.update("studies", ContentValues().apply { put("llm", json) }, "id=?", arrayOf(id.toString()))
    }

    suspend fun deleteStudy(id: Long) = write { db -> db.delete("studies", "id=?", arrayOf(id.toString())) }

    // ---------------- سجل القرارات ----------------

    private fun decisionOf(c: Cursor) = DecisionRecord(
        c.l("id"), c.l("ts"), c.s("kind"), c.l("ref_id"), c.s("symbol"), Market.fromId(c.s("market")), c.i("direction"), c.dn("score"),
        c.d("price"), c.dn("funding"), c.dn("open_interest"), c.s("snapshot"), c.dn("price_4h"), c.dn("ret_4h"), c.dn("price_24h"), c.dn("ret_24h"), c.s("note"),
    )

    private fun decisionValues(d: DecisionRecord, withId: Boolean) = ContentValues().apply {
        if (withId) put("id", d.id)
        put("ts", d.ts); put("kind", d.kind); put("ref_id", d.refId); put("symbol", d.symbol); put("market", d.market.id); put("direction", d.direction)
        if (d.score != null) put("score", d.score) else putNull("score")
        put("price", d.price)
        if (d.funding != null) put("funding", d.funding) else putNull("funding")
        if (d.openInterest != null) put("open_interest", d.openInterest) else putNull("open_interest")
        put("snapshot", d.snapshot)
        if (d.price4h != null) put("price_4h", d.price4h) else putNull("price_4h")
        if (d.ret4h != null) put("ret_4h", d.ret4h) else putNull("ret_4h")
        if (d.price24h != null) put("price_24h", d.price24h) else putNull("price_24h")
        if (d.ret24h != null) put("ret_24h", d.ret24h) else putNull("ret_24h")
        put("note", d.note)
    }

    suspend fun insertDecision(d: DecisionRecord): Long = write { db -> db.insertOrThrow("decision_log", null, decisionValues(d, false)) }

    suspend fun decisions(limit: Int = 500): List<DecisionRecord> = read { it.list("SELECT * FROM decision_log ORDER BY ts DESC LIMIT $limit") { c -> decisionOf(c) } }

    /** السجلات التي حان قياس نتيجتها بعد 4 أو 24 ساعة. */
    suspend fun pendingOutcomes(now: Long, limit: Int = 30): List<DecisionRecord> = read {
        it.list(
            "SELECT * FROM decision_log WHERE (price_4h IS NULL AND ts <= ?) OR (price_24h IS NULL AND ts <= ?) ORDER BY ts LIMIT $limit",
            arrayOf((now - AppConfig.Outcome.H4_MS).toString(), (now - AppConfig.Outcome.H24_MS).toString()),
        ) { c -> decisionOf(c) }
    }

    suspend fun setOutcome(id: Long, is24h: Boolean, price: Double, ret: Double) = write { db ->
        val cv = ContentValues().apply {
            if (is24h) { put("price_24h", price); put("ret_24h", ret) } else { put("price_4h", price); put("ret_4h", ret) }
        }
        db.update("decision_log", cv, "id=?", arrayOf(id.toString()))
    }

    // ---------------- الأحداث والمستويات ----------------

    private fun eventOf(c: Cursor) = MarketEvent(c.l("id"), c.l("ts"), c.s("symbol"), c.s("title"), c.s("kind"), c.s("source"), c.s("evidence"), c.s("note"), c.l("created_at"))

    private fun eventValues(e: MarketEvent, withId: Boolean) = ContentValues().apply {
        if (withId) put("id", e.id)
        put("ts", e.ts); put("symbol", e.symbol); put("title", e.title); put("kind", e.kind); put("source", e.source); put("evidence", e.evidence); put("note", e.note); put("created_at", e.createdAt)
    }

    suspend fun insertEvent(e: MarketEvent): Long = write { db -> db.insertOrThrow("events", null, eventValues(e, false)) }
    suspend fun events(): List<MarketEvent> = read { it.list("SELECT * FROM events ORDER BY ts DESC LIMIT 300") { c -> eventOf(c) } }
    suspend fun deleteEvent(id: Long) = write { db -> db.delete("events", "id=?", arrayOf(id.toString())) }

    private fun levelOf(c: Cursor) = SavedLevel(c.l("id"), c.s("symbol"), Market.fromId(c.s("market")), c.d("price"), c.s("kind"), c.s("reason"), c.l("created_at"))

    private fun levelValues(l: SavedLevel, withId: Boolean) = ContentValues().apply {
        if (withId) put("id", l.id)
        put("symbol", l.symbol); put("market", l.market.id); put("price", l.price); put("kind", l.kind); put("reason", l.reason); put("created_at", l.createdAt)
    }

    suspend fun insertLevel(l: SavedLevel): Long = write { db -> db.insertOrThrow("levels", null, levelValues(l, false)) }
    suspend fun levels(): List<SavedLevel> = read { it.list("SELECT * FROM levels ORDER BY created_at DESC") { c -> levelOf(c) } }
    suspend fun deleteLevel(id: Long) = write { db -> db.delete("levels", "id=?", arrayOf(id.toString())) }

    // ---------------- مفتاح/قيمة ----------------

    suspend fun kvGet(key: String): String? = read { db -> db.rawQuery("SELECT value FROM kv WHERE key=?", arrayOf(key)).use { if (it.moveToFirst()) it.getString(0) else null } }

    suspend fun kvPut(key: String, value: String?) = write { db ->
        if (value == null) db.delete("kv", "key=?", arrayOf(key))
        else db.insertWithOnConflict("kv", null, ContentValues().apply { put("key", key); put("value", value) }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ---------------- النسخ والتصدير والاستيراد ----------------

    /** لقطة متسقة: تُؤخذ على خيط الكاتب الوحيد داخل معاملة، فلا كتابة تتخللها. */
    suspend fun exportData(now: Long): BackupData = write { db ->
        BackupData(
            dbVersion = db.version, exportedAt = now,
            watchlist = db.list("SELECT * FROM watchlist ORDER BY position, id") { c -> watchOf(c) },
            trades = db.list("SELECT * FROM trades ORDER BY id") { c -> tradeOf(c) },
            alertStates = db.list("SELECT * FROM alert_state") { c -> stateOf(c) },
            alertLog = db.list("SELECT * FROM alert_log ORDER BY id") { c -> alertOf(c) },
            studies = db.list("SELECT * FROM studies ORDER BY id") { c -> studyOf(c) },
            decisions = db.list("SELECT * FROM decision_log ORDER BY id") { c -> decisionOf(c) },
            events = db.list("SELECT * FROM events ORDER BY id") { c -> eventOf(c) },
            levels = db.list("SELECT * FROM levels ORDER BY id") { c -> levelOf(c) },
            settings = db.list("SELECT key, value FROM kv") { c -> c.getString(0) to c.getString(1) }.filter { it.first !in LOCAL_KEYS }.toMap(),
        )
    }

    /** استيراد ذري (استبدال كامل): إما أن ينجح كله أو لا يتغير شيء. مفاتيح الجهاز المحلية لا تُمس. */
    suspend fun importData(d: BackupData) = write { db ->
        listOf("watchlist", "trades", "alert_state", "alert_log", "studies", "decision_log", "events", "levels").forEach { db.delete(it, null, null) }
        val local = LOCAL_KEYS.joinToString(",") { "'$it'" }
        db.delete("kv", "key NOT IN ($local)", null)
        d.watchlist.forEach { w ->
            db.insertOrThrow("watchlist", null, ContentValues().apply { put("id", w.id); put("symbol", w.symbol); put("market", w.market.id); put("tag", w.tag.name); put("position", w.position); put("added_at", w.addedAt) })
        }
        d.trades.forEach { t -> db.insertOrThrow("trades", null, tradeValues(t).apply { put("id", t.id) }) }
        d.alertStates.forEach { db.insertOrThrow("alert_state", null, stateValues(it)) }
        d.alertLog.forEach { db.insertOrThrow("alert_log", null, alertValues(it, true)) }
        d.studies.forEach { db.insertOrThrow("studies", null, studyValues(it, true)) }
        d.decisions.forEach { db.insertOrThrow("decision_log", null, decisionValues(it, true)) }
        d.events.forEach { db.insertOrThrow("events", null, eventValues(it, true)) }
        d.levels.forEach { db.insertOrThrow("levels", null, levelValues(it, true)) }
        d.settings.filter { it.key !in LOCAL_KEYS }.forEach { (k, v) ->
            db.insertWithOnConflict("kv", null, ContentValues().apply { put("key", k); put("value", v) }, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    /**
     * نسخ آمن لقاعدة WAL: على خيط الكاتب الوحيد → wal_checkpoint(TRUNCATE) ينقل كل الـWAL إلى الملف الرئيسي،
     * ثم نمسك قفل الكتابة (BEGIN IMMEDIATE) أثناء نسخ الملف، ثم نتحقق من النسخة بـintegrity_check.
     * يعيد false (دون ملف) إن تعذر الـcheckpoint الكامل — لا تُنسخ قاعدة نشطة بطريقة قد تفسدها.
     */
    suspend fun safeCopyTo(dest: File): Boolean = withContext(writer) {
        val db = helper.writableDatabase
        var busy = 1
        repeat(3) {
            if (busy != 0) {
                db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { c -> if (c.moveToFirst()) busy = c.getInt(0) }
                if (busy != 0) Thread.sleep(150)
            }
        }
        if (busy != 0) return@withContext false
        db.beginTransactionNonExclusive()
        try {
            File(db.path).copyTo(dest, overwrite = true)
        } finally {
            db.endTransaction()
        }
        val ok = try {
            SQLiteDatabase.openDatabase(dest.path, null, SQLiteDatabase.OPEN_READONLY).use { copy ->
                copy.rawQuery("PRAGMA integrity_check", null).use { c -> c.moveToFirst() && c.getString(0).equals("ok", ignoreCase = true) }
            }
        } catch (e: Exception) {
            false
        }
        if (!ok) dest.delete()
        ok
    }

    companion object {
        const val DB_NAME = "ghaith.db"

        /** مفاتيح خاصة بالجهاز لا تُصدّر ولا تُستورد (إذن مجلد SAF وحالة النسخ). */
        val LOCAL_KEYS = setOf("backup_tree_uri", "backup_last_at", "backup_last_result", "backup_folder_lost")
    }
}
