package com.agon.app.domain.engine

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.Kline
import com.agon.app.domain.model.Direction
import kotlinx.serialization.Serializable

@Serializable
enum class StrengthState(val label: String) {
    STRONG("قوية"), HOLDING("متماسكة"), WEAK("ضعف ظاهر"), REVERSAL("علامات انعكاس"), UNKNOWN("بيانات غير كافية")
}

@Serializable
data class StrengthSignal(
    val key: String,
    val title: String,
    val active: Boolean,
    val major: Boolean,
    val value: String,
)

@Serializable
data class StrengthReport(
    val state: StrengthState,
    val signals: List<StrengthSignal>,
    val computedAt: Long,
    val basedOnCloseTime: Long,
    val interval: String,
    val unproven: Boolean = true,
) {
    val reasons: List<StrengthSignal> get() = signals.filter { it.active }
}

/**
 * قوة الصفقة والانعكاس — مؤشرات وصفية غير مثبتة تنبؤيًا؛ تُسجّل نتائجها في سجل القرارات ولا تُقدَّم كضمان.
 * تُحسب على شموع مغلقة فقط من إطار الصفقة.
 */
object StrengthAnalyzer {
    private val S = AppConfig.Strength

    fun evaluate(direction: Direction, k: List<Kline>, fundingRate: Double?, interval: String, now: Long): StrengthReport {
        if (k.size < S.MIN_BARS) return StrengthReport(StrengthState.UNKNOWN, emptyList(), now, k.lastOrNull()?.closeTime ?: 0L, interval)
        val long = direction == Direction.LONG
        val signals = ArrayList<StrengthSignal>()
        val closes = DoubleArray(k.size) { k[it].close }
        val structure = Structure.read(k)
        val swings = Structure.swings(k)

        // 1) كسر آخر قاع/قمة ضد الصفقة (رئيسية)
        val broke = if (long) structure.brokeLow else structure.brokeHigh
        val ref = if (long) structure.lastLow else structure.lastHigh
        signals += StrengthSignal(
            "structureBreak", if (long) "كسر آخر قاع" else "اختراق آخر قمة", broke, true,
            ref?.let { "الإغلاق ${fmtPrice(closes.last())} مقابل ${fmtPrice(it.price)}" } ?: "لا قاع/قمة مؤكدة",
        )

        // 2) تباعد RSI ضد الصفقة
        val rsi = Indicators.rsi(closes, AppConfig.Engine.RSI_PERIOD)
        val pts = swings.filter { it.isHigh == long }.takeLast(2)
        var div = false
        var divValue = "لا تباعد"
        if (pts.size == 2 && k.size - pts[1].index <= S.DIVERGENCE_LOOKBACK_BARS) {
            val r1 = rsi[pts[0].index]
            val r2 = rsi[pts[1].index]
            if (!r1.isNaN() && !r2.isNaN()) {
                div = if (long) pts[1].price > pts[0].price && r2 < r1 - S.RSI_DIVERGENCE_MARGIN
                else pts[1].price < pts[0].price && r2 > r1 + S.RSI_DIVERGENCE_MARGIN
                divValue = "RSI ${fmt(r1, 1)} → ${fmt(r2, 1)} والسعر ${fmtPrice(pts[0].price)} → ${fmtPrice(pts[1].price)}"
            }
        }
        signals += StrengthSignal("rsiDivergence", "تباعد RSI", div, false, divValue)

        // 3) حجم ضد الاتجاه
        var against = 0
        var strongest = 0.0
        for (idx in k.size - S.AGAINST_VOLUME_BARS until k.size) {
            val bar = k[idx]
            val isAgainst = if (long) bar.close < bar.open else bar.close > bar.open
            val rv = Indicators.relativeVolume(k, AppConfig.Engine.REL_VOLUME_PERIOD, idx) ?: continue
            if (isAgainst && rv >= S.AGAINST_VOLUME_REL) {
                against++
                if (rv > strongest) strongest = rv
            }
        }
        val volAgainst = against >= 2 || strongest >= S.AGAINST_VOLUME_STRONG_REL
        signals += StrengthSignal("volumeAgainst", "حجم ضد الاتجاه", volAgainst, false, if (against > 0) "$against شمعة معاكسة، أقواها ×${fmt(strongest, 1)}" else "لا شموع معاكسة بحجم مرتفع")

        // 4) انقلاب شراء المبادرين (من حقول kline الرسمية)
        val recent = Indicators.takerBuyRatio(k, S.TAKER_FLIP_BARS)
        val prior = Indicators.takerBuyRatio(k, S.TAKER_FLIP_BARS, k.size - S.TAKER_FLIP_BARS)
        val flip = recent != null && prior != null && (
            if (long) recent < S.TAKER_FLIP_LOW && prior >= 0.5 else recent > S.TAKER_FLIP_HIGH && prior <= 0.5
            )
        signals += StrengthSignal(
            "takerFlip", "انقلاب شراء المبادرين", flip, false,
            if (recent != null && prior != null) "${fmt(prior * 100, 1)}% → ${fmt(recent * 100, 1)}%" else "غير متاح",
        )

        // 5) تمويل متطرف ضد الصفقة (Futures فقط)
        val extreme = fundingRate != null && (if (long) fundingRate >= AppConfig.Engine.EXTREME_FUNDING else fundingRate <= -AppConfig.Engine.EXTREME_FUNDING)
        signals += StrengthSignal(
            "extremeFunding", "تمويل متطرف", extreme, false,
            fundingRate?.let { "${fmtSigned(it * 100, 4)}% لكل فترة" } ?: "غير متاح (فوري أو بيانات قديمة)",
        )

        val major = signals.any { it.active && it.major }
        val minor = signals.count { it.active && !it.major }
        val ema = Indicators.ema(closes, AppConfig.Engine.EMA_FAST)
        val aligned = if (long) closes.last() > ema.last() else closes.last() < ema.last()
        val state = when {
            major || minor >= 3 -> StrengthState.REVERSAL
            minor == 2 -> StrengthState.WEAK
            minor == 1 -> StrengthState.HOLDING
            aligned -> StrengthState.STRONG
            else -> StrengthState.HOLDING
        }
        return StrengthReport(state, signals, now, k.last().closeTime, interval)
    }
}
