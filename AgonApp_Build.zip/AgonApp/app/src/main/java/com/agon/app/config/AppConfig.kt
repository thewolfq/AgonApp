package com.agon.app.config

/**
 * المصدر الوحيد لكل العتبات والأوزان والمدد في «غيث التداول».
 * لا توضع أرقام سحرية خارج هذا الملف. تعديل أوزان المحرك مقفل حتى توفر
 * [Engine.WEIGHTS_LOCKED_UNTIL_OOS_CASES] حالة مقاسة خارج العينة (انظر الدليل).
 */
object AppConfig {
    const val UNPROVEN = "غير مثبت"
    const val DISCLAIMER = "ليس نصيحة مالية. كل الدرجات والمؤشرات غير مثبتة تنبؤيًا."
    const val BACKUP_SCHEMA_VERSION = 1

    /** نقاط النهاية الرسمية. Spot وFutures منفصلان تمامًا. */
    object Endpoints {
        const val SPOT_REST = "https://api.binance.com"
        const val SPOT_WS = "wss://stream.binance.com:9443"

        /** نطاق رسمي لبيانات السوق فقط (بدون حسابات) — بديل اختياري من الإعدادات. */
        const val SPOT_REST_DATA_ONLY = "https://data-api.binance.vision"
        const val SPOT_WS_DATA_ONLY = "wss://data-stream.binance.vision"

        const val FUT_REST = "https://fapi.binance.com"

        /** منذ ترقية 2026-03-06 (القديم أُوقف 2026-04-23): فئتان لبيانات السوق. */
        const val FUT_WS_PUBLIC = "wss://fstream.binance.com/public" // depth / bookTicker
        const val FUT_WS_MARKET = "wss://fstream.binance.com/market" // kline / aggTrade / miniTicker / markPrice
    }

    object Ws {
        const val RECONNECT_BASE_MS = 1_000L
        const val RECONNECT_MAX_MS = 30_000L
        const val RECONNECT_JITTER = 0.25
        const val CLIENT_PING_INTERVAL_MS = 20_000L

        /** الاتصال صالح 24 ساعة رسميًا؛ ندوّره قبلها. */
        const val MAX_CONNECTION_AGE_MS = 23L * 3_600_000L

        /** حد Spot الرسمي 5 رسائل واردة/ثانية؛ نرسل ≤4. */
        const val OUTGOING_MIN_GAP_MS = 250L
        const val URL_STREAMS_MAX = 20
        const val SUBSCRIBE_BATCH = 50
        const val MAX_STREAMS_PER_CONNECTION = 1000 // الحد الرسمي 1024

        /** صمت تدفق «كل السوق» فقط يُعد اشتباه انقطاع. صمت رمز منفرد ليس انقطاعًا. */
        const val ALL_STREAM_SILENCE_RECONNECT_MS = 20_000L
        const val STALE_AFTER_DISCONNECT_MS = 5_000L
        const val UI_THROTTLE_MS = 500L
        const val RESEED_MIN_INTERVAL_MS = 30_000L
        const val NETWORK_CHANGE_DEBOUNCE_MS = 1_000L
    }

    object Rest {
        const val MAX_CONCURRENCY = 4
        const val SPOT_WEIGHT_LIMIT_1M = 6000
        const val FUT_WEIGHT_LIMIT_1M = 2400
        const val SOFT_LIMIT_FRACTION = 0.7
        const val CONNECT_TIMEOUT_MS = 10_000L
        const val READ_TIMEOUT_MS = 25_000L
        const val DEFAULT_RETRY_AFTER_MS = 60_000L
    }

    object Book {
        const val SPOT_SNAPSHOT_LIMIT = 1000
        const val FUT_SNAPSHOT_LIMIT = 1000
        const val STUDY_SNAPSHOT_LIMIT = 100
        const val MAX_BUFFERED_EVENTS = 3000
        const val RESYNC_MIN_GAP_MS = 1_500L
        const val RESYNC_MAX_GAP_MS = 20_000L

        /** نطاق قياس العمق حول السعر الأوسط (±%). عمق الدفتر ليس حجم 24 ساعة. */
        const val DEPTH_BAND_PCT = 1.0
        const val WALL_SHARE = 0.35
        const val VIEW_LEVELS = 8
        const val DEPTH_STREAM_SUFFIX = "@depth@100ms"
    }

    object Symbol {
        val INTERVALS = listOf("1m", "5m", "1h")
        const val KLINE_INIT_LIMIT = 300
        const val KLINE_KEEP = 500
        const val TAKER_WINDOW_MS = 5 * 60_000L
        const val TAKER_MIN_TRADES = 30
        const val OI_REFRESH_MS = 60_000L
        const val FUNDING_STALE_MS = 20_000L
        const val OI_STALE_MS = 180_000L
        const val UI_THROTTLE_MS = 300L
        const val KLINE_STALE_MS = 180_000L
    }

    /**
     * حدّا 3M و4.5M: حجم التداول المقابل (quote volume) خلال 24 ساعة مقوّمًا بـUSDT.
     * ليسا عمق دفتر ولا سيولة مضمونة. 3M للمسح و4.5M للتنبيه.
     */
    object Liquidity {
        const val SCAN_MIN_QUOTE_VOLUME_24H_USDT = 3_000_000.0
        const val ALERT_MIN_QUOTE_VOLUME_24H_USDT = 4_500_000.0
        val STABLE_BASES = setOf("USDT", "USDC", "FDUSD", "TUSD", "BUSD", "DAI", "USDP", "USD1", "EUR", "EURI", "AEUR", "XUSD", "BFUSD", "USDE", "PYUSD", "RLUSD")
        val LEVERAGED_SUFFIXES = listOf("UPUSDT", "DOWNUSDT", "BULLUSDT", "BEARUSDT")
    }

    object Engine {
        // أوزان العوامل الأساسية (مجموعها 1). العامل غير المتاح يُحذف ويعاد التطبيع.
        const val W_TREND = 0.25
        const val W_STRUCTURE = 0.20
        const val W_MOMENTUM = 0.15
        const val W_REL_VOLUME = 0.12
        const val W_TAKER = 0.12
        const val W_BOOK = 0.08
        const val W_DERIVATIVES = 0.08
        const val WEIGHTS_LOCKED_UNTIL_OOS_CASES = 100

        const val EMA_FAST = 20
        const val EMA_SLOW = 50
        const val RSI_PERIOD = 14
        const val TF_WEIGHT_1M = 0.20
        const val TF_WEIGHT_5M = 0.35
        const val TF_WEIGHT_1H = 0.45
        const val SWING_WING = 3
        const val REL_VOLUME_PERIOD = 20
        const val REL_VOLUME_STRONG = 2.5
        const val ROC_BARS = 12
        const val ROC_NORM_PCT = 2.0
        const val TAKER_NORM = 0.15
        const val TAKER_KLINE_BARS = 12
        const val BOOK_IMBALANCE_NORM = 0.5
        const val EXTREME_FUNDING = 0.0005 // 0.05% لكل فترة تمويل
        const val OI_CHANGE_NORM_PCT = 5.0
        const val BIAS_THRESHOLD = 0.25
        const val LEVEL_CLUSTER_PCT = 0.3
        const val LEVELS_PER_SIDE = 4

        // الموانع
        const val SPREAD_WARN_BPS = 8.0
        const val SPREAD_BLOCK_BPS = 15.0
        const val WICK_RATIO_WARN = 0.65
        const val SPIKE_VOLUME_MULT = 8.0
        const val SPIKE_REVERSAL_FRACTION = 0.7
    }

    object Strength {
        const val MIN_BARS = 60
        const val RSI_DIVERGENCE_MARGIN = 2.0
        const val DIVERGENCE_LOOKBACK_BARS = 40
        const val AGAINST_VOLUME_REL = 1.5
        const val AGAINST_VOLUME_STRONG_REL = 2.5
        const val AGAINST_VOLUME_BARS = 3
        const val TAKER_FLIP_BARS = 6
        const val TAKER_FLIP_LOW = 0.45
        const val TAKER_FLIP_HIGH = 0.55
        const val KLINE_INIT_LIMIT = 200
    }

    object Scan {
        const val UNIVERSE_TOP_N = 100
        const val DEEP_STUDY_TOP_N = 5
        const val KLINE_INTERVAL = "5m"
        const val KLINE_LIMIT = 1000
        const val BARS_PER_HOUR = 12
        const val BARS_PER_DAY = 288
        const val RANK_W_CHANGE_1H = 0.5
        const val RANK_W_REL_VOLUME = 0.5
        const val FETCH_CONCURRENCY = 4
        const val STUDY_NOTIFY_MIN_ABS_SCORE = 0.35
        const val AUTO_SCAN_INTERVAL_MS = 30 * 60_000L

        /**
         * القوة النسبية مقابل BTC: نسبة الشموع (في النافذة نفسها) التي تفوّق فيها عائد العملة.
         * 45% قيمة افتراضية «غير معايرة» حتى تتوفر 100 حالة مقاسة (انظر Calibration).
         */
        const val RS_WINDOW_BARS = 48
        const val RS_THRESHOLD_DEFAULT = 0.45
    }

    object Backtest {
        const val MIN_CHANGE_1H_PCT = 1.5
        const val MIN_REL_VOLUME = 2.0
        const val COOLDOWN_BARS = 48 // 4 ساعات على 5m: إشارة واحدة لكل زوج خلالها
        const val HORIZON_BARS = 48
        const val FEE_ROUND_TRIP_PCT = 0.1
        const val SPLIT_IN_SAMPLE = 0.6
        const val BLOCK_LENGTH = 8
        const val BOOTSTRAP_ITERATIONS = 2000
        const val BOOTSTRAP_SEED = 20261110L
        const val MIN_OOS_CASES = 100
    }

    object Alerts {
        const val NEAR_TARGET_FRACTION = 0.80
        const val NEAR_STOP_FRACTION = 0.80
        const val NEAR_LIQ_FRACTION = 0.75
        const val REARM_HYSTERESIS = 0.15
    }

    object Trade {
        /** معدل هامش الصيانة الافتراضي للتقدير فقط؛ يختلف حسب المنصة والشريحة. */
        const val DEFAULT_MAINTENANCE_MARGIN_RATE = 0.005
        const val MAX_LEVERAGE = 125.0
    }

    object Outcome {
        const val H4_MS = 4 * 3_600_000L
        const val H24_MS = 24 * 3_600_000L
        const val CHECK_INTERVAL_MS = 10 * 60_000L
        const val MIN_MEASURED_CASES = 100
    }

    object Watch {
        /** عملة «خامدة»: حجم 24س أقل من حد المسح أو تغير شبه معدوم. اقتراح فقط، لا حذف تلقائي. */
        const val DORMANT_MAX_ABS_CHANGE_PCT = 0.3
    }

    object Backup {
        const val INTERVAL_MS = 24 * 3_600_000L
        const val KEEP_FILES = 14
        const val CHECK_INTERVAL_MS = 60 * 60_000L
    }

    object Metrics {
        const val LATENCY_SAMPLES = 2000
    }
}
