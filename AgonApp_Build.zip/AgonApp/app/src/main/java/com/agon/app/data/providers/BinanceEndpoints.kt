package com.agon.app.data.providers

import com.agon.app.config.AppConfig

data class EndpointConfig(
    val spotRest: String,
    val spotWs: String,
    val futRest: String,
    val futWsPublic: String,
    val futWsMarket: String,
)

/** فئات WebSocket في USDⓈ-M Futures بعد ترقية 2026-03. Spot له قاعدة واحدة. */
enum class StreamCategory { PUBLIC, MARKET }

object BinanceEndpoints {
    fun config(spotDataOnly: Boolean): EndpointConfig = EndpointConfig(
        spotRest = if (spotDataOnly) AppConfig.Endpoints.SPOT_REST_DATA_ONLY else AppConfig.Endpoints.SPOT_REST,
        spotWs = if (spotDataOnly) AppConfig.Endpoints.SPOT_WS_DATA_ONLY else AppConfig.Endpoints.SPOT_WS,
        futRest = AppConfig.Endpoints.FUT_REST,
        futWsPublic = AppConfig.Endpoints.FUT_WS_PUBLIC,
        futWsMarket = AppConfig.Endpoints.FUT_WS_MARKET,
    )

    fun restBase(cfg: EndpointConfig, market: Market): String =
        if (market == Market.SPOT) cfg.spotRest else cfg.futRest

    fun wsBase(cfg: EndpointConfig, market: Market, category: StreamCategory): String = when (market) {
        Market.SPOT -> cfg.spotWs
        Market.FUTURES -> if (category == StreamCategory.PUBLIC) cfg.futWsPublic else cfg.futWsMarket
    }

    /** depth وbookTicker عالية التردد ⇒ PUBLIC؛ الباقي (kline/aggTrade/miniTicker/markPrice) ⇒ MARKET. */
    fun categoryOf(stream: String): StreamCategory {
        val name = stream.substringAfter('@', stream)
        return if (name.startsWith("depth") || name.startsWith("bookTicker") || name.startsWith("rpiDepth")) {
            StreamCategory.PUBLIC
        } else StreamCategory.MARKET
    }

    const val ALL_MINI_TICKER = "!miniTicker@arr"
    fun miniTicker(symbol: String) = "${symbol.lowercase()}@miniTicker"
    fun kline(symbol: String, interval: String) = "${symbol.lowercase()}@kline_$interval"
    fun depth(symbol: String) = "${symbol.lowercase()}${AppConfig.Book.DEPTH_STREAM_SUFFIX}"
    fun aggTrade(symbol: String) = "${symbol.lowercase()}@aggTrade"
    fun markPrice(symbol: String) = "${symbol.lowercase()}@markPrice@1s"
}
