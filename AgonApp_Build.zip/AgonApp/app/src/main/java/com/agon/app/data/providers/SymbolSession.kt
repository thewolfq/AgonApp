package com.agon.app.data.providers

import com.agon.app.config.AppConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import okhttp3.OkHttpClient
import java.util.TreeMap

data class KlineSeries(val closed: List<Kline> = emptyList(), val live: Kline? = null, val loaded: Boolean = false)

data class TakerFlowView(
    val buyNotional: Double = 0.0,
    val sellNotional: Double = 0.0,
    val trades: Int = 0,
    val windowMs: Long = AppConfig.Symbol.TAKER_WINDOW_MS,
    val lastPrice: Double? = null,
    val lastTradeAt: Long = 0L,
) {
    val buyRatio: Double? get() = (buyNotional + sellNotional).let { if (it > 0) buyNotional / it else null }
}

data class BookStatus(
    val state: BookSyncState = BookSyncState.IDLE,
    val resyncs: Int = 0,
    val lastGapReason: String? = null,
    val lastSyncedAt: Long = 0L,
    val snapshotError: String? = null,
    val snapshotFetches: Int = 0,
)

data class SymbolState(
    val market: Market,
    val symbol: String,
    val started: Boolean = false,
    val klines: Map<String, KlineSeries> = emptyMap(),
    val klineError: String? = null,
    /** يزداد عند كل إغلاق شمعة رسمي (x=true) أو إعادة تحميل التاريخ؛ التحليل يُعاد عنده فقط. */
    val closeSeq: Long = 0L,
    val lastCloseTime: Long = 0L,
    val lastCloseInterval: String? = null,
    val book: BookMetrics? = null,
    val bookStatus: BookStatus = BookStatus(),
    val flow: TakerFlowView = TakerFlowView(),
    val mark: Timed<MarkInfo>? = null,
    val oi: Timed<OiPoint>? = null,
    val oiChange1hPct: Double? = null,
    val oiError: String? = null,
    val health: Map<String, WsHealth> = emptyMap(),
    val lastFrameAt: Long = 0L,
    val updatedAt: Long = 0L,
) {
    val connected: Boolean get() = health.isNotEmpty() && health.values.all { it.state == WsState.OPEN }
}

/**
 * جلسة صفحة العملة: تشترك للرمز المفتوح فقط في kline(1m/5m/1h) وdepth وaggTrade
 * (وmarkPrice في Futures)، وتلغي الاشتراك وتغلق الاتصال عند [stop].
 * الدفتر يُبنى من snapshot REST + أحداث البث المتسلسلة؛ عند الفجوة يُعاد البناء.
 */
class SymbolSession(
    val market: Market,
    val symbol: String,
    private val rest: BinanceRest,
    private val http: OkHttpClient,
    private val endpoints: () -> EndpointConfig,
    private val parentScope: CoroutineScope,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val _state = MutableStateFlow(SymbolState(market, symbol))
    val state: StateFlow<SymbolState> = _state

    private var scope: CoroutineScope? = null
    private val conns = java.util.concurrent.ConcurrentHashMap<StreamCategory, StreamConnection>()

    private val lock = Any()
    private val closedByInterval = HashMap<String, TreeMap<Long, Kline>>()
    private val liveByInterval = HashMap<String, Kline?>()
    private val loadedIntervals = HashSet<String>()
    private var closeSeq = 0L
    private var lastCloseTime = 0L
    private var lastCloseInterval: String? = null
    private var klineError: String? = null

    private val sync = OrderBookSynchronizer(market)
    private var bookStatus = BookStatus()
    private var snapshotJob: Job? = null

    private val trades = ArrayDeque<AggTrade>()
    private var buyN = 0.0
    private var sellN = 0.0
    private var lastTrade: AggTrade? = null

    private var mark: MarkInfo? = null
    private var markAt = 0L
    private var oi: OiPoint? = null
    private var oiAt = 0L
    private var oiChange: Double? = null
    private var oiError: String? = null

    @Volatile private var dirty = false
    @Volatile private var running = false

    val latency = LatencyStats(AppConfig.Metrics.LATENCY_SAMPLES)

    fun start() {
        synchronized(lock) {
            if (running) return
            running = true
        }
        val sc = CoroutineScope(parentScope.coroutineContext + SupervisorJob())
        scope = sc
        val streams = buildList {
            AppConfig.Symbol.INTERVALS.forEach { add(BinanceEndpoints.kline(symbol, it)) }
            add(BinanceEndpoints.depth(symbol))
            add(BinanceEndpoints.aggTrade(symbol))
            if (market == Market.FUTURES) add(BinanceEndpoints.markPrice(symbol))
        }
        // Spot: اتصال واحد. Futures: اتصالان حسب الفئة الرسمية (public للعمق، market للباقي).
        val grouped = if (market == Market.SPOT) mapOf(StreamCategory.MARKET to streams)
        else streams.groupBy { BinanceEndpoints.categoryOf(it) }
        for ((cat, list) in grouped) {
            val c = StreamConnection(http, "symbol-${market.id}-$symbol-${cat.name.lowercase()}", sc, { BinanceEndpoints.wsBase(endpoints(), market, cat) }, clock)
            c.addListener(::onStream)
            c.addOpenListener {
                // بعد أي (إعادة) اتصال: الدفتر يُعاد بناؤه، والتاريخ يُعاد تحميله لسد الشموع الفائتة.
                if (list.any { it.contains("@depth") }) synchronized(lock) {
                    sync.reset("إعادة اتصال")
                    bookStatus = bookStatus.copy(state = sync.state, lastGapReason = sync.lastGapReason)
                    dirty = true
                }
                if (list.any { it.contains("@kline") }) sc.launch { loadHistory() }
            }
            conns[cat] = c
            c.setStreams("page", list.toSet())
        }
        sc.launch {
            while (isActive) {
                delay(AppConfig.Symbol.UI_THROTTLE_MS)
                publish(force = false)
            }
        }
        if (market == Market.FUTURES) sc.launch { oiLoop() }
        publish(force = true)
    }

    /** مغادرة الصفحة: UNSUBSCRIBE ثم إغلاق الاتصالات وإلغاء كل المهام. */
    fun stop() {
        synchronized(lock) {
            if (!running) return
            running = false
            snapshotJob?.cancel(); snapshotJob = null
            sync.reset("إيقاف")
            bookStatus = BookStatus()
        }
        conns.values.forEach { it.close() }
        conns.clear()
        scope?.cancel()
        scope = null
        _state.value = _state.value.copy(started = false, health = emptyMap(), book = null, bookStatus = BookStatus())
    }

    fun forceReconnect(reason: String) = conns.values.forEach { it.forceReconnect(reason) }

    private suspend fun loadHistory() {
        var attempt = 0
        for (interval in AppConfig.Symbol.INTERVALS) {
            while (running) {
                try {
                    val list = rest.klines(market, symbol, interval, AppConfig.Symbol.KLINE_INIT_LIMIT)
                    synchronized(lock) {
                        val map = closedByInterval.getOrPut(interval) { TreeMap() }
                        for (k in list) {
                            if (k.closed) map[k.openTime] = k
                            else if (liveByInterval[interval] == null) liveByInterval[interval] = k
                        }
                        while (map.size > AppConfig.Symbol.KLINE_KEEP) map.pollFirstEntry()
                        loadedIntervals.add(interval)
                        klineError = null
                        closeSeq++
                        dirty = true
                    }
                    break
                } catch (t: Throwable) {
                    attempt++
                    synchronized(lock) { klineError = t.message ?: t.javaClass.simpleName; dirty = true }
                    delay((1_000L * attempt).coerceAtMost(15_000L))
                }
            }
        }
        publish(force = true)
    }

    private fun onStream(stream: String, data: kotlinx.serialization.json.JsonElement, receivedAt: Long) {
        val o = data as? JsonObject ?: return
        val kind = stream.substringAfter('@')
        when {
            kind.startsWith("kline_") -> onKline(o, receivedAt)
            kind.startsWith("depth") -> onDepth(o)
            kind == "aggTrade" -> onAggTrade(o, receivedAt)
            kind.startsWith("markPrice") -> BinanceParsers.markPriceWs(o)?.let {
                synchronized(lock) { mark = it; markAt = receivedAt; dirty = true }
            }
        }
    }

    private fun onKline(o: JsonObject, receivedAt: Long) {
        val (interval, k) = BinanceParsers.klineWs(o) ?: return
        o.lng("E")?.let { latency.add(receivedAt - it) }
        var closedNow = false
        synchronized(lock) {
            if (k.closed) {
                // الإغلاق الرسمي x=true: أضف إلى السلسلة المغلقة وأطلق التحليل.
                val map = closedByInterval.getOrPut(interval) { TreeMap() }
                map[k.openTime] = k
                while (map.size > AppConfig.Symbol.KLINE_KEEP) map.pollFirstEntry()
                if (liveByInterval[interval]?.openTime == k.openTime) liveByInterval[interval] = null
                closeSeq++
                lastCloseTime = k.closeTime
                lastCloseInterval = interval
                closedNow = true
            } else {
                liveByInterval[interval] = k
            }
            dirty = true
        }
        if (closedNow) publish(force = true)
    }

    private fun onAggTrade(o: JsonObject, receivedAt: Long) {
        val t = BinanceParsers.aggTrade(o) ?: return
        if (t.qty <= 0.0 || t.price <= 0.0) return
        synchronized(lock) {
            trades.addLast(t)
            if (t.takerSide == Side.BUY) buyN += t.notional else sellN += t.notional
            lastTrade = t
            trimTrades(receivedAt)
            dirty = true
        }
    }

    private fun trimTrades(now: Long) {
        val cutoff = now - AppConfig.Symbol.TAKER_WINDOW_MS
        while (trades.isNotEmpty() && trades.first().tradeTime < cutoff) {
            val old = trades.removeFirst()
            if (old.takerSide == Side.BUY) buyN -= old.notional else sellN -= old.notional
        }
        if (trades.isEmpty()) { buyN = 0.0; sellN = 0.0 }
    }

    private fun onDepth(o: JsonObject) {
        val e = BinanceParsers.depthEvent(o) ?: return
        var needSnapshot = false
        synchronized(lock) {
            when (val r = sync.onEvent(e)) {
                is EventResult.Buffered -> needSnapshot = r.needSnapshot
                is EventResult.Gap -> needSnapshot = true
                else -> Unit
            }
            if (bookStatus.state != sync.state || needSnapshot) {
                bookStatus = bookStatus.copy(state = sync.state, resyncs = sync.resyncCount, lastGapReason = sync.lastGapReason)
            }
            dirty = true
            if (needSnapshot || (sync.state == BookSyncState.BUFFERING && snapshotJob?.isActive != true)) requestSnapshotLocked()
        }
    }

    private fun requestSnapshotLocked() {
        if (snapshotJob?.isActive == true) return
        val sc = scope ?: return
        snapshotJob = sc.launch {
            var wait = AppConfig.Book.RESYNC_MIN_GAP_MS
            // مهلة قصيرة ليتراكم البث قبل اللقطة (يقلل احتمال لقطة أقدم من أول حدث).
            delay(300L)
            while (isActive && running) {
                val limit = if (market == Market.SPOT) AppConfig.Book.SPOT_SNAPSHOT_LIMIT else AppConfig.Book.FUT_SNAPSHOT_LIMIT
                try {
                    val snap = rest.depthSnapshot(market, symbol, limit)
                    val done = synchronized(lock) {
                        bookStatus = bookStatus.copy(snapshotFetches = bookStatus.snapshotFetches + 1, snapshotError = null)
                        when (val r = sync.onSnapshot(snap)) {
                            is SnapshotResult.Synced -> {
                                bookStatus = bookStatus.copy(state = sync.state, resyncs = sync.resyncCount, lastSyncedAt = clock())
                                dirty = true
                                true
                            }
                            is SnapshotResult.Retry -> {
                                bookStatus = bookStatus.copy(state = sync.state, resyncs = sync.resyncCount, lastGapReason = r.reason)
                                dirty = true
                                false
                            }
                        }
                    }
                    if (done) return@launch
                } catch (t: Throwable) {
                    synchronized(lock) { bookStatus = bookStatus.copy(snapshotError = t.message ?: t.javaClass.simpleName); dirty = true }
                }
                delay(wait)
                wait = (wait * 2).coerceAtMost(AppConfig.Book.RESYNC_MAX_GAP_MS)
            }
        }
    }

    private suspend fun oiLoop() {
        while (running) {
            try {
                val point = rest.openInterest(symbol)
                val hist = runCatching { rest.openInterestHist(symbol, "5m", 13) }.getOrNull()
                synchronized(lock) {
                    oi = point
                    oiAt = clock()
                    oiError = null
                    oiChange = hist?.takeIf { it.size >= 2 }?.let { h ->
                        val first = h.first().openInterest
                        if (first > 0) (h.last().openInterest - first) / first * 100.0 else null
                    }
                    dirty = true
                }
            } catch (t: Throwable) {
                synchronized(lock) { oiError = t.message ?: t.javaClass.simpleName; dirty = true }
            }
            delay(AppConfig.Symbol.OI_REFRESH_MS)
        }
    }

    private fun publish(force: Boolean) {
        if (!force && !dirty) {
            // حدّث حالة الاتصال/التقادم حتى دون بيانات جديدة.
            val cur = _state.value
            val health = conns.entries.associate { it.key.name to it.value.health.value }
            if (cur.health != health || clock() - cur.updatedAt > 2_000L) Unit else return
        }
        dirty = false
        val now = clock()
        val snapshot = synchronized(lock) {
            trimTrades(now)
            val kl = AppConfig.Symbol.INTERVALS.associateWith { i ->
                KlineSeries(closedByInterval[i]?.values?.toList() ?: emptyList(), liveByInterval[i], i in loadedIntervals)
            }
            SymbolState(
                market = market, symbol = symbol, started = running,
                klines = kl, klineError = klineError,
                closeSeq = closeSeq, lastCloseTime = lastCloseTime, lastCloseInterval = lastCloseInterval,
                book = if (sync.state == BookSyncState.SYNCED) sync.book.metrics() else null,
                bookStatus = bookStatus.copy(state = sync.state, resyncs = sync.resyncCount),
                flow = TakerFlowView(buyN.coerceAtLeast(0.0), sellN.coerceAtLeast(0.0), trades.size, AppConfig.Symbol.TAKER_WINDOW_MS, lastTrade?.price, lastTrade?.tradeTime ?: 0L),
                mark = if (market == Market.FUTURES) Timed(mark, markAt, mark == null || now - markAt > AppConfig.Symbol.FUNDING_STALE_MS, market, "WS <symbol>@markPrice@1s", "معدل لكل فترة تمويل") else null,
                oi = if (market == Market.FUTURES) Timed(oi, oiAt, oi == null || now - oiAt > AppConfig.Symbol.OI_STALE_MS, market, "REST /fapi/v1/openInterest", "الأصل الأساسي") else null,
                oiChange1hPct = oiChange, oiError = oiError,
                health = conns.entries.associate { it.key.name to it.value.health.value },
                lastFrameAt = conns.values.maxOfOrNull { it.lastFrameAt } ?: 0L,
                updatedAt = now,
            )
        }
        _state.value = snapshot
    }
}
