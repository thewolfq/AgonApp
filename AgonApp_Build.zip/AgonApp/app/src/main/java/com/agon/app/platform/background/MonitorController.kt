package com.agon.app.platform.background

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import androidx.core.content.ContextCompat
import com.agon.app.config.AppConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class MonitorState(
    val running: Boolean = false,
    val startedAt: Long = 0L,
    /** المستخدم طلب المراقبة ولم يوقفها بنفسه. */
    val wanted: Boolean = false,
    val lastHeartbeat: Long = 0L,
    val stoppedReason: String? = null,
) {
    /** مطلوبة لكنها لا تعمل: أوقفها النظام أو Force Stop أو إعادة تشغيل. تحتاج تشغيلًا يدويًا. */
    val stoppedUnexpectedly: Boolean get() = wanted && !running
}

/** أعلام صغيرة متزامنة يحتاجها BootReceiver والخدمة قبل فتح SQLite. */
class MonitorPrefs(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("ghaith_monitor", Context.MODE_PRIVATE)
    var wanted: Boolean
        get() = p.getBoolean("wanted", false)
        set(v) = p.edit().putBoolean("wanted", v).apply()
    var restartAfterBoot: Boolean
        get() = p.getBoolean("restart_after_boot", false)
        set(v) = p.edit().putBoolean("restart_after_boot", v).apply()
    var heartbeat: Long
        get() = p.getLong("heartbeat", 0L)
        set(v) = p.edit().putLong("heartbeat", v).apply()
    var stoppedReason: String?
        get() = p.getString("stopped_reason", null)
        set(v) = p.edit().putString("stopped_reason", v).apply()
}

/**
 * تشغيل/إيقاف المراقبة الخلفية بطلب صريح من المستخدم من داخل التطبيق (وهو في الواجهة،
 * فلا تنطبق قيود بدء الخدمة من الخلفية في Android 12+). لا وعد بالاستمرار بعد Force Stop أو قتل النظام.
 */
class MonitorController(private val context: Context) {
    val prefs = MonitorPrefs(context)
    private val _state = MutableStateFlow(MonitorState(wanted = prefs.wanted, lastHeartbeat = prefs.heartbeat, stoppedReason = prefs.stoppedReason))
    val state: StateFlow<MonitorState> = _state

    /** يعيد رسالة خطأ إن منع النظام البدء، أو null عند النجاح. */
    fun requestStart(): String? = try {
        prefs.wanted = true
        prefs.stoppedReason = null
        _state.update { it.copy(wanted = true, stoppedReason = null) }
        ContextCompat.startForegroundService(context, Intent(context, MonitorService::class.java).setAction(MonitorService.ACTION_START))
        null
    } catch (e: Exception) {
        val msg = "منع النظام بدء المراقبة الآن (${e.javaClass.simpleName}). افتح التطبيق وأعد المحاولة."
        onBlocked(msg)
        msg
    }

    fun requestStop() {
        prefs.wanted = false
        _state.update { it.copy(wanted = false, stoppedReason = null) }
        runCatching { context.startService(Intent(context, MonitorService::class.java).setAction(MonitorService.ACTION_STOP)) }
    }

    fun onStarted(now: Long) {
        prefs.heartbeat = now
        _state.update { it.copy(running = true, startedAt = now, lastHeartbeat = now, stoppedReason = null) }
    }

    fun onHeartbeat(now: Long) {
        prefs.heartbeat = now
        _state.update { it.copy(lastHeartbeat = now) }
    }

    fun onStopped(byUser: Boolean, reason: String?) {
        if (byUser) prefs.wanted = false
        prefs.stoppedReason = if (byUser) null else reason
        _state.update { it.copy(running = false, wanted = prefs.wanted, stoppedReason = if (byUser) null else reason) }
    }

    fun onBlocked(reason: String) {
        prefs.stoppedReason = reason
        _state.update { it.copy(running = false, stoppedReason = reason) }
    }
}

/** يراقب تغيّر الشبكة الافتراضية (Wi‑Fi ↔ بيانات) لإعادة الاتصال فورًا بدل انتظار انقطاع المقبس. */
class NetworkWatcher(context: Context, private val onChange: (String) -> Unit) {
    private val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private var current: Network? = null
    private var lastChangeAt = 0L
    private val _online = MutableStateFlow(true)
    val online: StateFlow<Boolean> = _online

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _online.value = true
            val previous = current
            current = network
            val now = System.currentTimeMillis()
            if (previous != null && previous != network && now - lastChangeAt > AppConfig.Ws.NETWORK_CHANGE_DEBOUNCE_MS) {
                lastChangeAt = now
                onChange("network-switch")
            } else if (previous == null && lastChangeAt > 0) {
                lastChangeAt = now
                onChange("network-restored")
            }
        }

        override fun onLost(network: Network) {
            if (network == current) {
                current = null
                lastChangeAt = System.currentTimeMillis()
                _online.value = false
            }
        }
    }

    fun start() {
        runCatching { cm.registerDefaultNetworkCallback(callback) }
    }
}
