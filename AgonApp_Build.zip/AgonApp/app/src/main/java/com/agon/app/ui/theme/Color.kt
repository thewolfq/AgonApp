package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة «غيث»: أزرق مخضر عميق مع فيروزي المطر
val RainTeal = Color(0xFF3DD6C6)
val RainTealDark = Color(0xFF00796B)
val SkyBlue = Color(0xFF7CC4FF)
val SkyBlueDark = Color(0xFF1565C0)
val Amber = Color(0xFFFFC857)
val AmberDark = Color(0xFF9A5B00)

val Night0 = Color(0xFF0A1216)
val Night1 = Color(0xFF101B21)
val Night2 = Color(0xFF17262E)
val Night3 = Color(0xFF20343E)
val NightOutline = Color(0xFF33505C)
val NightText = Color(0xFFE3EEF1)
val NightTextDim = Color(0xFF9DB3BB)

val Day0 = Color(0xFFF3F7F8)
val Day1 = Color(0xFFFFFFFF)
val Day2 = Color(0xFFE6EEF0)
val DayOutline = Color(0xFFB4C6CC)
val DayText = Color(0xFF10201F)
val DayTextDim = Color(0xFF4E6268)

val UpDark = Color(0xFF2ED58A)
val DownDark = Color(0xFFFF5D73)
val UpLight = Color(0xFF0B8F55)
val DownLight = Color(0xFFC62842)
