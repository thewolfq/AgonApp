package com.agon.app.data.store

import com.agon.app.data.providers.Market
import com.agon.app.domain.alerts.AlertSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** إعدادات غير سرية (تُصدّر مع النسخة). الأسرار في [SecureStore] فقط. */
@Serializable
data class AppSettings(
    /** مصدر Spot: false = api/stream.binance.com، true = نطاق بيانات السوق الرسمي binance.vision. */
    val spotDataOnly: Boolean = false,
    val defaultMarket: Market = Market.SPOT,
    val alerts: AlertSettings = AlertSettings(),
    val notifyStudies: Boolean = true,
    val telegramEnabled: Boolean = false,
    val llmEnabled: Boolean = false,
    val llmEndpoint: String = "",
    val llmModel: String = "",
    val backupDaily: Boolean = false,
    val autoScan: Boolean = false,
    val restartAfterBoot: Boolean = false,
)

class SettingsRepo(private val store: Store) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings
    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded

    suspend fun load() {
        val raw = runCatching { store.kvGet(KEY) }.getOrNull()
        if (raw != null) runCatching { json.decodeFromString(AppSettings.serializer(), raw) }.getOrNull()?.let { _settings.value = it }
        _loaded.value = true
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        _settings.update(transform)
        store.kvPut(KEY, json.encodeToString(AppSettings.serializer(), _settings.value))
    }

    companion object {
        const val KEY = "settings"
    }
}
