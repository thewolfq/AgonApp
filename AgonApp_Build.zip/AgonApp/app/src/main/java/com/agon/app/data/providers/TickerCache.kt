package com.agon.app.data.providers

import java.util.concurrent.ConcurrentHashMap

/**
 * cache آخر قيمة لكل رمز (سوق واحد). خالص وقابل للاختبار.
 * - !miniTicker@arr يرسل الرموز المتغيرة فقط ⇒ نحتفظ بآخر قيمة للباقي دون وسمها قديمة.
 * - الوسم «قديم» يحدث فقط عبر [markAllStale] عند انقطاع الاتصال، ويزول بأول قيمة جديدة.
 */
class TickerCache(val market: Market) {
    private val map = ConcurrentHashMap<String, Ticker>()

    val size: Int get() = map.size
    fun get(symbol: String): Ticker? = map[symbol]
    fun snapshot(): List<Ticker> = ArrayList(map.values)

    fun applyWs(t: Ticker) {
        map[t.symbol] = t
    }

    /** قيم REST لا تستبدل قيمة WS أحدث وصلت بعد بدء الطلب. */
    fun applySeed(list: List<Ticker>, requestStartedAt: Long): Int {
        var applied = 0
        for (t in list) {
            val cur = map[t.symbol]
            if (cur == null || cur.stale || cur.fetchedAt < requestStartedAt) {
                map[t.symbol] = t
                applied++
            }
        }
        return applied
    }

    fun markAllStale(): Int {
        var n = 0
        for ((k, v) in map) {
            if (!v.stale) {
                map[k] = v.copy(stale = true)
                n++
            }
        }
        return n
    }

    fun staleCount(): Int = map.values.count { it.stale }

    /** عمر القيمة بالمللي ثانية؛ العمر الكبير مع اتصال سليم = «بلا تغيير» لا «منقطع». */
    fun ageMs(symbol: String, now: Long): Long? = map[symbol]?.let { now - it.fetchedAt }
}

/** إحصاءات زمن التأخير (حلقة دائرية): p50/p95/n. */
class LatencyStats(private val capacity: Int) {
    private val buf = LongArray(capacity)
    private var count = 0L

    @Synchronized
    fun add(ms: Long) {
        buf[(count % capacity).toInt()] = ms
        count++
    }

    data class Summary(val n: Long, val p50: Long, val p95: Long, val max: Long)

    @Synchronized
    fun summary(): Summary {
        val n = minOf(count, capacity.toLong()).toInt()
        if (n == 0) return Summary(0, 0, 0, 0)
        val sorted = buf.copyOf(n).also { it.sort() }
        return Summary(count, sorted[(n * 0.50).toInt().coerceAtMost(n - 1)], sorted[(n * 0.95).toInt().coerceAtMost(n - 1)], sorted[n - 1])
    }
}
