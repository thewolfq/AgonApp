package com.agon.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.GhaithApp
import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BookSyncState
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.SymbolState
import com.agon.app.data.providers.Ticker
import com.agon.app.domain.engine.Analysis
import com.agon.app.domain.engine.AnalysisInput
import com.agon.app.domain.engine.Analyzer
import com.agon.app.domain.engine.DerivativesInput
import com.agon.app.domain.engine.TakerFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * صفحة العملة: تملك جلسة البث الخاصة بالرمز المفتوح فقط. التحليل يُعاد عند تغيّر closeSeq
 * (إغلاق شمعة رسمي x=true أو إعادة تحميل التاريخ) لا مع كل تحديث حي.
 */
class CoinViewModel(app: Application, val market: Market, val symbol: String) : AndroidViewModel(app) {
    private val c = (app as GhaithApp).container
    private val hub = c.hub(market)
    private val session = c.newSession(market, symbol)
    private val owner = "coin-$symbol"

    val state: StateFlow<SymbolState> = session.state
    val ticker: StateFlow<Ticker?> = hub.version.map { hub.get(symbol) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(2_000), hub.get(symbol))
    private val _analysis = MutableStateFlow<Analysis?>(null)
    val analysis: StateFlow<Analysis?> = _analysis
    val feed = hub.status

    /** هل يوجد الرمز نفسه في السوق الآخر (للتنقل فقط؛ لا تُخلط البيانات). */
    private val _otherMarketExists = MutableStateFlow<Boolean?>(null)
    val otherMarketExists: StateFlow<Boolean?> = _otherMarketExists
    val otherMarket: Market get() = if (market == Market.SPOT) Market.FUTURES else Market.SPOT

    init {
        viewModelScope.launch { state.map { it.closeSeq }.distinctUntilChanged().collectLatest { recompute() } }
        viewModelScope.launch {
            runCatching { c.directory.ensure(market) }
            _otherMarketExists.value = runCatching { c.directory.ensure(otherMarket)[symbol]?.trading == true }.getOrNull()
            refreshSelected()
        }
    }

    private fun refreshSelected() {
        val set = LinkedHashSet<String>().apply { add(symbol) }
        val q = c.directory.quoteOf(market, symbol)
        if (q != null && q != "USDT" && c.directory.info(market, "${q}USDT") != null) set += "${q}USDT"
        hub.setSelected(owner, set)
    }

    fun onStart() {
        session.start()
        refreshSelected()
    }

    /** مغادرة الصفحة أو ذهاب التطبيق للخلفية: إلغاء الاشتراك وإغلاق اتصالات الرمز. */
    fun onStop() {
        session.stop()
        hub.setSelected(owner, emptySet())
    }

    override fun onCleared() {
        onStop()
    }

    fun volumeUsdt(): Double? {
        val t = hub.get(symbol) ?: return null
        val f = c.directory.usdtFactor(market, symbol, hub) ?: return null
        return t.quoteVolume * f
    }

    fun quote(): String? = c.directory.quoteOf(market, symbol)

    private suspend fun recompute() {
        val s = state.value
        val k1m = s.klines["1m"]
        val k5m = s.klines["5m"]
        val k1h = s.klines["1h"]
        if (k1m == null || k5m == null || k1h == null || !k1m.loaded || !k5m.loaded || !k1h.loaded) return
        val now = System.currentTimeMillis()
        val price = k1m.closed.lastOrNull()?.close ?: return
        val deriv = if (market == Market.FUTURES) DerivativesInput(
            fundingRate = s.mark?.value?.fundingRate, fundingStale = s.mark?.stale ?: true, fundingAt = s.mark?.fetchedAt ?: 0L,
            nextFundingTime = s.mark?.value?.nextFundingTime, openInterest = s.oi?.value?.openInterest, oiChangePct1h = s.oiChange1hPct,
            oiStale = s.oi?.stale ?: true, oiAt = s.oi?.fetchedAt ?: 0L,
        ) else null
        val input = AnalysisInput(
            symbol = symbol, market = market, now = now, price = price,
            k1m = k1m.closed, k5m = k5m.closed, k1h = k1h.closed,
            quoteVolume24hUsdt = volumeUsdt(),
            book = s.book, bookSynced = s.bookStatus.state == BookSyncState.SYNCED && s.book != null,
            bookSource = "دفتر حي: snapshot REST + أحداث depth متسلسلة",
            liveFlow = TakerFlow(s.flow.buyNotional, s.flow.sellNotional, s.flow.trades, "aggTrade الحي (${AppConfig.Symbol.TAKER_WINDOW_MS / 60_000}د)"),
            derivatives = deriv, feedHealthy = s.connected,
        )
        _analysis.value = withContext(Dispatchers.Default) { Analyzer.analyze(input) }
    }
}
