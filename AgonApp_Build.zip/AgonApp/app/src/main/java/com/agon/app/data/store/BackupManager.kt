package com.agon.app.data.store

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import com.agon.app.config.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupStatus(
    val folderUri: String? = null,
    val folderLost: Boolean = false,
    val lastAt: Long = 0L,
    val lastResult: String = "",
    val running: Boolean = false,
)

sealed class BackupResult {
    data class Ok(val files: List<String>, val dbCopied: Boolean) : BackupResult()
    object NoFolder : BackupResult()
    /** فُقد إذن المجلد: يجب أن يختاره المستخدم مجددًا. */
    object FolderLost : BackupResult()
    data class Failed(val message: String) : BackupResult()
}

/**
 * النسخ الاحتياطي عبر Storage Access Framework إلى مجلد يختاره المستخدم، وتصدير/استيراد JSON.
 * لا أذونات تخزين عامة؛ الوصول فقط لما منحه المستخدم.
 */
class BackupManager(private val context: Context, private val store: Store, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val _status = MutableStateFlow(BackupStatus())
    val status: StateFlow<BackupStatus> = _status

    suspend fun refreshStatus() {
        val uri = store.kvGet("backup_tree_uri")
        val lost = uri != null && !hasPermission(Uri.parse(uri))
        _status.value = BackupStatus(uri, lost, store.kvGet("backup_last_at")?.toLongOrNull() ?: 0L, store.kvGet("backup_last_result") ?: "", _status.value.running)
    }

    private fun hasPermission(tree: Uri): Boolean =
        context.contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission && it.isReadPermission }

    suspend fun setFolder(tree: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        store.kvPut("backup_tree_uri", tree.toString())
        refreshStatus()
    }

    suspend fun clearFolder() {
        store.kvGet("backup_tree_uri")?.let { u ->
            runCatching { context.contentResolver.releasePersistableUriPermission(Uri.parse(u), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
        }
        store.kvPut("backup_tree_uri", null)
        refreshStatus()
    }

    suspend fun exportJson(target: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val text = BackupCodec.encode(store.exportData(clock()))
            (context.contentResolver.openOutputStream(target, "wt") ?: error("تعذر فتح الملف للكتابة")).use { it.write(text.toByteArray(Charsets.UTF_8)) }
            text.length
        }
    }

    /** يقرأ ويتحقق ثم يستورد ذريًا؛ عند أي خطأ لا تتغير القاعدة. */
    suspend fun importJson(source: Uri): Result<BackupData> = withContext(Dispatchers.IO) {
        runCatching {
            val text = (context.contentResolver.openInputStream(source) ?: error("تعذر فتح الملف")).use { it.readBytes().toString(Charsets.UTF_8) }
            val data = BackupCodec.decode(text)
            store.importData(data)
            data
        }
    }

    suspend fun maybeDaily(enabled: Boolean): BackupResult? {
        if (!enabled) return null
        val last = store.kvGet("backup_last_at")?.toLongOrNull() ?: 0L
        if (clock() - last < AppConfig.Backup.INTERVAL_MS) return null
        return runBackup()
    }

    suspend fun runBackup(): BackupResult = withContext(Dispatchers.IO) {
        val uriText = store.kvGet("backup_tree_uri") ?: return@withContext BackupResult.NoFolder
        val tree = Uri.parse(uriText)
        if (!hasPermission(tree)) {
            store.kvPut("backup_folder_lost", "1")
            store.kvPut("backup_last_result", "فُقد إذن المجلد — اختره مجددًا")
            refreshStatus()
            return@withContext BackupResult.FolderLost
        }
        _status.value = _status.value.copy(running = true)
        val result = try {
            val resolver = context.contentResolver
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(clock()))
            val files = ArrayList<String>()

            // 1) JSON متسق (مسار الاستعادة الأساسي عبر «استيراد»)
            val jsonName = "$PREFIX$stamp.json"
            val jsonDoc = DocumentsContract.createDocument(resolver, parent, "application/json", jsonName) ?: error("تعذر إنشاء الملف في المجلد")
            val text = BackupCodec.encode(store.exportData(clock()))
            (resolver.openOutputStream(jsonDoc, "wt") ?: error("تعذر الكتابة")).use { it.write(text.toByteArray(Charsets.UTF_8)) }
            files += jsonName

            // 2) نسخة آمنة من ملف SQLite (checkpoint + قفل كتابة + تحقق سلامة)
            val tmp = File(context.cacheDir, "backup-copy.db")
            val copied = runCatching { store.safeCopyTo(tmp) }.getOrDefault(false)
            if (copied) {
                val dbName = "$PREFIX$stamp.db"
                val dbDoc = DocumentsContract.createDocument(resolver, parent, "application/octet-stream", dbName)
                if (dbDoc != null) {
                    (resolver.openOutputStream(dbDoc, "wt") ?: error("تعذر الكتابة")).use { out -> tmp.inputStream().use { it.copyTo(out) } }
                    files += dbName
                }
            }
            tmp.delete()
            prune(tree)
            store.kvPut("backup_last_at", clock().toString())
            store.kvPut("backup_folder_lost", null)
            store.kvPut("backup_last_result", "نجح: ${files.joinToString("، ")}" + if (!copied) " (تعذر نسخ ملف .db بأمان؛ JSON كافٍ للاستعادة)" else "")
            BackupResult.Ok(files, copied)
        } catch (e: SecurityException) {
            store.kvPut("backup_folder_lost", "1")
            store.kvPut("backup_last_result", "فُقد إذن المجلد — اختره مجددًا")
            BackupResult.FolderLost
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            store.kvPut("backup_last_result", "فشل: $msg")
            BackupResult.Failed(msg)
        }
        _status.value = _status.value.copy(running = false)
        refreshStatus()
        result
    }

    /** يبقي آخر [AppConfig.Backup.KEEP_FILES] نسخة من كل نوع ويحذف الأقدم (ملفات التطبيق فقط). */
    private fun prune(tree: Uri) {
        runCatching {
            val resolver = context.contentResolver
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val mine = ArrayList<Pair<String, String>>()
            resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    if (name.startsWith(PREFIX)) mine += name to c.getString(0)
                }
            }
            for (ext in listOf(".json", ".db")) {
                mine.filter { it.first.endsWith(ext) }.sortedByDescending { it.first }.drop(AppConfig.Backup.KEEP_FILES).forEach { (_, id) ->
                    runCatching { DocumentsContract.deleteDocument(resolver, DocumentsContract.buildDocumentUriUsingTree(tree, id)) }
                }
            }
        }
    }

    companion object {
        const val PREFIX = "ghaith-backup-"
    }
}
