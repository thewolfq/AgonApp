package com.agon.app.domain.engine

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.Kline
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.SymbolInfo
import com.agon.app.data.providers.Ticker
import kotlinx.serialization.Serializable
import kotlin.math.abs

data class UniverseEntry(
    val symbol: String,
    val base: String,
    val quote: String,
    val market: Market,
    val price: Double,
    /** حجم التسعير 24س محوّلًا إلى USDT (حجم تداول، لا عمق دفتر). */
    val quoteVolumeUsdt: Double,
    val change24hPct: Double,
    val usdtFactor: Double,
)

data class Excluded(val symbol: String, val reason: String)

data class UniverseResult(val entries: List<UniverseEntry>, val excluded: List<Excluded>, val seen: Int)

@Serializable
data class CandidateMetrics(
    val symbol: String,
    val price: Double,
    val change1hPct: Double,
    val relVolume: Double,
    /** حجم 24س الحقيقي محسوبًا من آخر 288 شمعة 5m مغلقة (USDT). */
    val realVolume24hUsdt: Double,
    val bars: Int,
)

@Serializable
data class Candidate(val metrics: CandidateMetrics, val rankScore: Double, val changeRank: Double, val relVolumeRank: Double)

object Scanner {
    /**
     * معامل تحويل عملة التسعير إلى USDT من أسعار السوق نفسه: USDT=1، أو سعر <quote>USDT، أو 1/سعر USDT<quote>.
     * null ⇒ لا تحويل متاح ⇒ يُستبعد الزوج مع بيان السبب.
     */
    fun usdtFactor(quote: String, priceOf: (String) -> Double?): Double? {
        if (quote == "USDT") return 1.0
        priceOf("${quote}USDT")?.takeIf { it > 0 }?.let { return it }
        priceOf("USDT$quote")?.takeIf { it > 0 }?.let { return 1.0 / it }
        return null
    }

    /** فرز أعلى [topN] زوج مؤهل بحجم 24س (USDT) ≥ [minVolUsdt]. زوج واحد لكل أصل أساسي (الأعلى حجمًا). */
    fun selectUniverse(
        tickers: List<Ticker>,
        infos: Map<String, SymbolInfo>,
        minVolUsdt: Double = AppConfig.Liquidity.SCAN_MIN_QUOTE_VOLUME_24H_USDT,
        topN: Int = AppConfig.Scan.UNIVERSE_TOP_N,
    ): UniverseResult {
        val priceBySymbol = tickers.associate { it.symbol to it.close }
        val excluded = ArrayList<Excluded>()
        val ok = ArrayList<UniverseEntry>()
        for (t in tickers) {
            val info = infos[t.symbol]
            if (info == null) { excluded += Excluded(t.symbol, "غير موجود في exchangeInfo"); continue }
            if (!info.trading) { excluded += Excluded(t.symbol, "الحالة ${info.status}"); continue }
            if (info.market == Market.FUTURES && info.contractType != null && info.contractType != "PERPETUAL") {
                excluded += Excluded(t.symbol, "عقد غير دائم (${info.contractType})"); continue
            }
            if (info.base in AppConfig.Liquidity.STABLE_BASES) { excluded += Excluded(t.symbol, "زوج عملة مستقرة/نقدية"); continue }
            if (AppConfig.Liquidity.LEVERAGED_SUFFIXES.any { t.symbol.endsWith(it) && t.symbol.length > it.length + 1 && info.base.length > 3 && (info.base.endsWith("UP") || info.base.endsWith("DOWN") || info.base.endsWith("BULL") || info.base.endsWith("BEAR")) }) {
                excluded += Excluded(t.symbol, "رمز برافعة"); continue
            }
            val factor = usdtFactor(info.quote) { priceBySymbol[it] }
            if (factor == null) { excluded += Excluded(t.symbol, "لا سعر تحويل لعملة التسعير ${info.quote} إلى USDT"); continue }
            val volUsdt = t.quoteVolume * factor
            if (volUsdt < minVolUsdt) { excluded += Excluded(t.symbol, "حجم 24س ${fmt(volUsdt / 1e6)}M USDT تحت حد المسح"); continue }
            if (t.stale) { excluded += Excluded(t.symbol, "بيانات قديمة"); continue }
            ok += UniverseEntry(t.symbol, info.base, info.quote, t.market, t.close, volUsdt, t.changePct, factor)
        }
        val byBase = ok.groupBy { it.base }.map { (_, list) ->
            val best = list.maxByOrNull { it.quoteVolumeUsdt }!!
            list.filter { it !== best }.forEach { excluded += Excluded(it.symbol, "مكرر للأصل ${it.base}؛ اختير ${best.symbol} الأعلى حجمًا") }
            best
        }
        val sorted = byBase.sortedByDescending { it.quoteVolumeUsdt }
        sorted.drop(topN).forEach { excluded += Excluded(it.symbol, "خارج أعلى $topN حجمًا") }
        return UniverseResult(sorted.take(topN), excluded, tickers.size)
    }

    /**
     * إصلاح (4): المرشحون بتغير آخر ساعة والحجم النسبي — لا حركة 24 ساعة.
     * [k5m] شموع 5m مغلقة. الحجم النسبي = حجم آخر ساعة ÷ متوسط الحجم الساعي في ال24س السابقة لها.
     */
    fun candidateMetrics(symbol: String, k5m: List<Kline>, usdtFactor: Double, endExclusive: Int = k5m.size): CandidateMetrics? {
        val h = AppConfig.Scan.BARS_PER_HOUR
        val day = AppConfig.Scan.BARS_PER_DAY
        if (endExclusive < h * 5 || endExclusive > k5m.size) return null
        val last = endExclusive - 1
        val price = k5m[last].close
        val ref = k5m[last - h].close
        if (ref <= 0 || price <= 0) return null
        var hourVol = 0.0
        for (i in endExclusive - h until endExclusive) hourVol += k5m[i].quoteVolume
        val priorStart = maxOf(0, endExclusive - h - day)
        val priorBars = endExclusive - h - priorStart
        var priorVol = 0.0
        for (i in priorStart until endExclusive - h) priorVol += k5m[i].quoteVolume
        val avgHourly = if (priorBars > 0) priorVol / priorBars * h else 0.0
        var dayVol = 0.0
        for (i in maxOf(0, endExclusive - day) until endExclusive) dayVol += k5m[i].quoteVolume
        return CandidateMetrics(
            symbol = symbol, price = price, change1hPct = (price / ref - 1) * 100,
            relVolume = if (avgHourly > 0) hourVol / avgHourly else 0.0,
            realVolume24hUsdt = dayVol * usdtFactor, bars = endExclusive,
        )
    }

    /** ترتيب بالمئينات: |تغير الساعة| والحجم النسبي بالأوزان المعرّفة في config. */
    fun rankCandidates(list: List<CandidateMetrics>, topN: Int = AppConfig.Scan.DEEP_STUDY_TOP_N): List<Candidate> {
        if (list.isEmpty()) return emptyList()
        fun ranks(values: List<Double>): List<Double> {
            val order = values.withIndex().sortedBy { it.value }
            val out = DoubleArray(values.size)
            order.forEachIndexed { rank, iv -> out[iv.index] = if (values.size > 1) rank.toDouble() / (values.size - 1) else 1.0 }
            return out.toList()
        }
        val ch = ranks(list.map { abs(it.change1hPct) })
        val rv = ranks(list.map { it.relVolume })
        return list.indices.map { i ->
            Candidate(list[i], AppConfig.Scan.RANK_W_CHANGE_1H * ch[i] + AppConfig.Scan.RANK_W_REL_VOLUME * rv[i], ch[i], rv[i])
        }.sortedByDescending { it.rankScore }.take(topN)
    }
}

@Serializable
data class RelStrength(
    val windowBars: Int,
    val commonBars: Int,
    val coinReturnPct: Double,
    val btcReturnPct: Double,
    val excessPct: Double,
    /** نسبة الشموع التي تفوّق فيها عائد العملة على BTC في النافذة نفسها. */
    val outperformShare: Double,
    val threshold: Double,
    val thresholdCalibrated: Boolean,
    val weak: Boolean,
)

object RelativeStrength {
    /**
     * إصلاح (5): العملة وBTC تُحسبان على الشموع المشتركة نفسها (مطابقة openTime) في النافذة نفسها.
     * الحد [threshold] افتراضيه 45% ويُعايَر بالبيانات عبر [Calibration].
     */
    fun compute(
        coin: List<Kline>, btc: List<Kline>,
        window: Int = AppConfig.Scan.RS_WINDOW_BARS,
        threshold: Double = AppConfig.Scan.RS_THRESHOLD_DEFAULT,
        calibrated: Boolean = false,
    ): RelStrength? {
        val btcByTime = HashMap<Long, Kline>(btc.size * 2)
        btc.forEach { btcByTime[it.openTime] = it }
        val common = coin.filter { btcByTime.containsKey(it.openTime) }.takeLast(window + 1)
        if (common.size < 3) return null
        var out = 0
        var n = 0
        for (i in 1 until common.size) {
            val c0 = common[i - 1]; val c1 = common[i]
            val b0 = btcByTime.getValue(c0.openTime); val b1 = btcByTime.getValue(c1.openTime)
            if (c0.close <= 0 || b0.close <= 0) continue
            if (c1.close / c0.close > b1.close / b0.close) out++
            n++
        }
        if (n == 0) return null
        val first = common.first(); val last = common.last()
        val coinRet = (last.close / first.close - 1) * 100
        val btcRet = (btcByTime.getValue(last.openTime).close / btcByTime.getValue(first.openTime).close - 1) * 100
        val share = out.toDouble() / n
        return RelStrength(window, n, coinRet, btcRet, coinRet - btcRet, share, threshold, calibrated, share < threshold)
    }
}

@Serializable
data class ThresholdCalibration(
    val threshold: Double,
    val calibrated: Boolean,
    val n: Int,
    val note: String,
    val outOfSampleSeparation: Double? = null,
)

object Calibration {
    /**
     * معايرة حد القوة النسبية من سجل القرارات: أزواج (القوة النسبية، العائد الموقّع بعد 24س) مرتبة زمنيًا.
     * أقل من [minN] حالة ⇒ يبقى الافتراضي موسومًا «غير معاير». وإلا: اختيار الحد على النصف الأول
     * والتحقق على النصف الثاني (خارج العينة)؛ لا يُعتمد إن لم يصمد الفصل خارج العينة.
     */
    fun calibrateThreshold(
        samples: List<Pair<Double, Double>>,
        default: Double = AppConfig.Scan.RS_THRESHOLD_DEFAULT,
        minN: Int = AppConfig.Outcome.MIN_MEASURED_CASES,
    ): ThresholdCalibration {
        if (samples.size < minN) {
            return ThresholdCalibration(default, false, samples.size, "غير معاير: ${samples.size}/$minN حالة مقاسة. يُستخدم الافتراضي ${fmt(default * 100, 0)}%.")
        }
        val half = samples.size / 2
        val train = samples.subList(0, half)
        val test = samples.subList(half, samples.size)
        fun separation(data: List<Pair<Double, Double>>, th: Double): Double? {
            val above = data.filter { it.first >= th }.map { it.second }
            val below = data.filter { it.first < th }.map { it.second }
            if (above.size < 5 || below.size < 5) return null
            return above.average() - below.average()
        }
        var best = default
        var bestSep = separation(train, default) ?: Double.NEGATIVE_INFINITY
        var th = 0.30
        while (th <= 0.701) {
            val sep = separation(train, th)
            if (sep != null && sep > bestSep) { bestSep = sep; best = th }
            th += 0.05
        }
        val oos = separation(test, best)
        return if (oos != null && oos > 0) {
            ThresholdCalibration(best, true, samples.size, "معاير على ${train.size} حالة ومتحقق على ${test.size} خارج العينة.", oos)
        } else {
            ThresholdCalibration(default, false, samples.size, "المعايرة لم تصمد خارج العينة؛ يبقى الافتراضي ${fmt(default * 100, 0)}%.", oos)
        }
    }
}
