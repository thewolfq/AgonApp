package com.agon.app.data.providers

import com.agon.app.config.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

class RestException(val code: Int, message: String) : IOException(message)
class RateLimitedException(val retryAtMs: Long, message: String) : IOException(message)

@Serializable
private data class ExSymbol(
    val symbol: String,
    val status: String = "",
    val baseAsset: String = "",
    val quoteAsset: String = "",
    val contractType: String? = null,
    val onboardDate: Long? = null,
    val deliveryDate: Long? = null,
)

@Serializable
private data class ExInfo(val symbols: List<ExSymbol> = emptyList())

/** يتتبع الوزن المستخدم من ترويسات Binance ويحترم 429/418 وRetry-After لكل سوق. */
class RestLimiter(private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val blockedUntil = ConcurrentHashMap<Market, Long>()
    val usedWeight1m = ConcurrentHashMap<Market, Int>()
    private val weightSeenAt = ConcurrentHashMap<Market, Long>()

    fun blockedUntil(market: Market): Long = blockedUntil[market] ?: 0L

    suspend fun await(market: Market) {
        val now = clock()
        val until = blockedUntil[market] ?: 0L
        if (until > now) throw RateLimitedException(until, "حد الطلبات مفعّل حتى ${(until - now) / 1000}ث")
        val limit = if (market == Market.SPOT) AppConfig.Rest.SPOT_WEIGHT_LIMIT_1M else AppConfig.Rest.FUT_WEIGHT_LIMIT_1M
        val used = usedWeight1m[market] ?: 0
        val seen = weightSeenAt[market] ?: 0L
        if (used > limit * AppConfig.Rest.SOFT_LIMIT_FRACTION && now - seen < 60_000L) {
            // انتظر بداية الدقيقة التالية بدل تجاوز الحد.
            delay((60_000L - now % 60_000L).coerceIn(500L, 60_000L))
            usedWeight1m[market] = 0
        }
    }

    fun observe(market: Market, code: Int, usedWeightHeader: String?, retryAfterHeader: String?) {
        usedWeightHeader?.toIntOrNull()?.let { usedWeight1m[market] = it; weightSeenAt[market] = clock() }
        if (code == 429 || code == 418) {
            val waitMs = retryAfterHeader?.toLongOrNull()?.times(1000) ?: AppConfig.Rest.DEFAULT_RETRY_AFTER_MS
            blockedUntil[market] = clock() + waitMs
        }
    }
}

/**
 * REST الرسمي لـBinance. يُستخدم فقط للقائمة الأولية، التاريخ، لقطات الدفتر، التمويل وOI.
 * التحديث الحي عبر WebSocket؛ لا استطلاع أسعار متكرر هنا.
 */
class BinanceRest(
    private val http: OkHttpClient,
    private val endpoints: () -> EndpointConfig,
    val limiter: RestLimiter = RestLimiter(),
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val permits = Semaphore(AppConfig.Rest.MAX_CONCURRENCY)
    private val json = BinanceParsers.json

    private suspend fun get(market: Market, path: String, params: List<Pair<String, String>> = emptyList()): String =
        withContext(Dispatchers.IO) {
            limiter.await(market)
            permits.withPermit {
                val builder = (BinanceEndpoints.restBase(endpoints(), market) + path).toHttpUrl().newBuilder()
                params.forEach { builder.addQueryParameter(it.first, it.second) }
                http.newCall(Request.Builder().url(builder.build()).build()).execute().use { resp ->
                    limiter.observe(market, resp.code, resp.header("x-mbx-used-weight-1m"), resp.header("Retry-After"))
                    val body = resp.body?.string().orEmpty()
                    if (resp.code == 429 || resp.code == 418) {
                        throw RateLimitedException(limiter.blockedUntil(market), "تجاوز حد الطلبات (HTTP ${resp.code})")
                    }
                    if (resp.code == 451) throw RestException(451, "المصدر غير متاح من منطقتك (HTTP 451)")
                    if (!resp.isSuccessful) throw RestException(resp.code, "HTTP ${resp.code}: ${body.take(160)}")
                    body
                }
            }
        }

    /** Spot: GET /api/v3/exchangeInfo (وزن 20). Futures: GET /fapi/v1/exchangeInfo (وزن 1). */
    suspend fun exchangeInfo(market: Market): List<SymbolInfo> {
        val body = if (market == Market.SPOT) {
            get(market, "/api/v3/exchangeInfo", listOf("showPermissionSets" to "false"))
        } else get(market, "/fapi/v1/exchangeInfo")
        return withContext(Dispatchers.Default) {
            json.decodeFromString(ExInfo.serializer(), body).symbols.map {
                SymbolInfo(market, it.symbol, it.baseAsset, it.quoteAsset, it.status, it.contractType, it.onboardDate, it.deliveryDate)
            }
        }
    }

    /**
     * القائمة الأولية الرسمية لنافذة 24 ساعة المتحركة.
     * Spot: GET /api/v3/ticker/24hr?type=MINI (وزن 80 للكل). Futures: GET /fapi/v1/ticker/24hr (وزن 40 للكل).
     */
    suspend fun tickers24h(market: Market, symbols: Collection<String>? = null): List<Ticker> {
        val body = when {
            market == Market.SPOT && symbols != null && symbols.isNotEmpty() && symbols.size <= 80 ->
                get(market, "/api/v3/ticker/24hr", listOf("type" to "MINI", "symbols" to symbols.joinToString(",", "[", "]") { "\"$it\"" }))
            market == Market.SPOT -> get(market, "/api/v3/ticker/24hr", listOf("type" to "MINI"))
            symbols != null && symbols.size == 1 -> get(market, "/fapi/v1/ticker/24hr", listOf("symbol" to symbols.first()))
            else -> get(market, "/fapi/v1/ticker/24hr")
        }
        val now = clock()
        return withContext(Dispatchers.Default) {
            when (val root = json.parseToJsonElement(body)) {
                is JsonArray -> root.mapNotNull { (it as? JsonObject)?.let { o -> BinanceParsers.restTicker(o, market, now) } }
                is JsonObject -> listOfNotNull(BinanceParsers.restTicker(root, market, now))
                else -> emptyList()
            }.let { list -> if (symbols == null) list else list.filter { it.symbol in symbols } }
        }
    }

    /** GET /api/v3/klines أو /fapi/v1/klines. آخر عنصر قد يكون شمعة جارية (closed=false). */
    suspend fun klines(market: Market, symbol: String, interval: String, limit: Int, startTime: Long? = null, endTime: Long? = null): List<Kline> {
        val params = mutableListOf("symbol" to symbol, "interval" to interval, "limit" to limit.toString())
        startTime?.let { params += "startTime" to it.toString() }
        endTime?.let { params += "endTime" to it.toString() }
        val body = get(market, if (market == Market.SPOT) "/api/v3/klines" else "/fapi/v1/klines", params)
        val now = clock()
        return withContext(Dispatchers.Default) {
            (json.parseToJsonElement(body) as? JsonArray)?.mapNotNull { (it as? JsonArray)?.let { a -> BinanceParsers.klineRest(a, now) } } ?: emptyList()
        }
    }

    /** لقطة الدفتر: GET /api/v3/depth أو /fapi/v1/depth. */
    suspend fun depthSnapshot(market: Market, symbol: String, limit: Int): DepthSnapshot {
        val body = get(market, if (market == Market.SPOT) "/api/v3/depth" else "/fapi/v1/depth", listOf("symbol" to symbol, "limit" to limit.toString()))
        return (json.parseToJsonElement(body) as? JsonObject)?.let { BinanceParsers.depthSnapshot(it, clock()) }
            ?: throw IOException("لقطة دفتر غير صالحة")
    }

    /** Futures فقط: GET /fapi/v1/premiumIndex (سعر العلامة ومعدل التمويل ووقت التمويل القادم). */
    suspend fun premiumIndex(symbol: String): MarkInfo {
        val body = get(Market.FUTURES, "/fapi/v1/premiumIndex", listOf("symbol" to symbol))
        return (json.parseToJsonElement(body) as? JsonObject)?.let { BinanceParsers.premiumIndex(it) }
            ?: throw IOException("premiumIndex غير صالح")
    }

    /** Futures فقط: GET /fapi/v1/openInterest — الوحدة: الأصل الأساسي. */
    suspend fun openInterest(symbol: String): OiPoint {
        val body = get(Market.FUTURES, "/fapi/v1/openInterest", listOf("symbol" to symbol))
        val o = json.parseToJsonElement(body) as? JsonObject ?: throw IOException("openInterest غير صالح")
        return OiPoint(o.lng("time") ?: clock(), o.dbl("openInterest") ?: throw IOException("openInterest مفقود"), null)
    }

    /** Futures فقط: GET /futures/data/openInterestHist — sumOpenInterestValue بـUSDT. */
    suspend fun openInterestHist(symbol: String, period: String, limit: Int): List<OiPoint> {
        val body = get(Market.FUTURES, "/futures/data/openInterestHist", listOf("symbol" to symbol, "period" to period, "limit" to limit.toString()))
        return (json.parseToJsonElement(body) as? JsonArray)?.mapNotNull {
            val o = it as? JsonObject ?: return@mapNotNull null
            OiPoint(o.lng("timestamp") ?: return@mapNotNull null, o.dbl("sumOpenInterest") ?: return@mapNotNull null, o.dbl("sumOpenInterestValue"))
        } ?: emptyList()
    }
}
