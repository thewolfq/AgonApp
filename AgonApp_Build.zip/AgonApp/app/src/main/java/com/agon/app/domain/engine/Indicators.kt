package com.agon.app.domain.engine

import com.agon.app.data.providers.Kline
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

fun fmt(x: Double, decimals: Int = 2): String = String.format(Locale.US, "%.${decimals}f", x)

fun fmtSigned(x: Double, decimals: Int = 2): String = (if (x >= 0) "+" else "") + fmt(x, decimals)

fun Double.clampUnit(): Double = coerceIn(-1.0, 1.0)

object Indicators {
    fun ema(values: DoubleArray, period: Int): DoubleArray {
        val out = DoubleArray(values.size) { Double.NaN }
        if (period <= 0 || values.size < period) return out
        var sum = 0.0
        for (i in 0 until period) sum += values[i]
        var prev = sum / period
        out[period - 1] = prev
        val k = 2.0 / (period + 1)
        for (i in period until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    fun sma(values: DoubleArray, period: Int, endExclusive: Int = values.size): Double {
        if (period <= 0 || endExclusive < period) return Double.NaN
        var sum = 0.0
        for (i in endExclusive - period until endExclusive) sum += values[i]
        return sum / period
    }

    /** RSI بتنعيم Wilder. القيم قبل اكتمال الفترة = NaN. */
    fun rsi(closes: DoubleArray, period: Int): DoubleArray {
        val out = DoubleArray(closes.size) { Double.NaN }
        if (closes.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = closes[i] - closes[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        gain /= period
        loss /= period
        out[period] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        for (i in period + 1 until closes.size) {
            val d = closes[i] - closes[i - 1]
            gain = (gain * (period - 1) + max(d, 0.0)) / period
            loss = (loss * (period - 1) + max(-d, 0.0)) / period
            out[i] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        }
        return out
    }

    fun atr(k: List<Kline>, period: Int): Double {
        if (k.size <= period) return Double.NaN
        var sum = 0.0
        for (i in k.size - period until k.size) {
            val prevClose = k[i - 1].close
            sum += max(k[i].high - k[i].low, max(abs(k[i].high - prevClose), abs(k[i].low - prevClose)))
        }
        return sum / period
    }

    /** الحجم النسبي: حجم آخر شمعة مغلقة ÷ متوسط [period] شمعة قبلها. */
    fun relativeVolume(k: List<Kline>, period: Int, index: Int = k.size - 1): Double? {
        if (index < period || index >= k.size) return null
        var sum = 0.0
        for (i in index - period until index) sum += k[i].quoteVolume
        val avg = sum / period
        return if (avg > 0) k[index].quoteVolume / avg else null
    }

    /** نسبة شراء المبادرين من حقول kline الرسمية (takerBuyQuote ÷ quoteVolume) لآخر [bars] شمعة تنتهي عند [endExclusive]. */
    fun takerBuyRatio(k: List<Kline>, bars: Int, endExclusive: Int = k.size): Double? {
        if (endExclusive < bars || bars <= 0) return null
        var buy = 0.0
        var total = 0.0
        for (i in endExclusive - bars until endExclusive) {
            buy += k[i].takerBuyQuote
            total += k[i].quoteVolume
        }
        return if (total > 0) buy / total else null
    }
}
