package com.agon.app.data.providers

import com.agon.app.config.AppConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import java.util.concurrent.CopyOnWriteArrayList

enum class HubMode(val label: String) { IDLE("متوقف"), ALL("كل السوق"), SELECTED("رموز مختارة") }

sealed class SeedState {
    object Idle : SeedState()
    object Loading : SeedState()
    data class Ready(val at: Long, val count: Int) : SeedState()
    data class Error(val message: String, val at: Long) : SeedState()
}

data class FeedStatus(
    val market: Market,
    val mode: HubMode = HubMode.IDLE,
    val ws: WsHealth = WsHealth(),
    val seed: SeedState = SeedState.Idle,
    val lastFrameAt: Long = 0L,
    val staleMarked: Boolean = false,
    val symbols: Int = 0,
)

/**
 * مركز أسعار سوق واحد (Spot أو Futures — لا خلط).
 * - الوضع العام: !miniTicker@arr (الرموز المتغيرة فقط) فوق cache لآخر قيمة.
 * - وضع الرموز المختارة: <symbol>@miniTicker للصفقات والمراقبة (أخف للخلفية).
 * - القائمة الأولية وإعادة البذر بعد إعادة الاتصال من REST الرسمي.
 */
class TickerHub(
    val market: Market,
    private val rest: BinanceRest,
    val conn: StreamConnection,
    private val scope: CoroutineScope,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    val cache = TickerCache(market)
    val latency = LatencyStats(AppConfig.Metrics.LATENCY_SAMPLES)

    private val _version = MutableStateFlow(0L)
    val version: StateFlow<Long> = _version
    private val _status = MutableStateFlow(FeedStatus(market))
    val status: StateFlow<FeedStatus> = _status

    private val lock = Any()
    private val allOwners = HashSet<String>()
    private val selectedByOwner = HashMap<String, Set<String>>()
    private val tickListeners = CopyOnWriteArrayList<(Ticker) -> Unit>()
    @Volatile private var dirty = false
    @Volatile private var mode = HubMode.IDLE
    @Volatile private var staleMarked = false
    @Volatile private var lastSeedAt = 0L
    @Volatile private var seed: SeedState = SeedState.Idle
    private val seedMutex = Mutex()

    private val listener: StreamListener = { stream, data, receivedAt ->
        if (stream == BinanceEndpoints.ALL_MINI_TICKER && data is JsonArray) {
            val list = BinanceParsers.miniTickerArray(data, market, receivedAt)
            for (t in list) accept(t)
            list.firstOrNull()?.let { latency.add(receivedAt - it.eventTime) }
        } else if (stream.endsWith("@miniTicker") && data is JsonObject) {
            BinanceParsers.miniTicker(data, market, receivedAt)?.let {
                accept(it)
                latency.add(receivedAt - it.eventTime)
            }
        }
    }

    init {
        conn.addListener(listener)
        conn.addOpenListener { scope.launch { seed(force = false, afterReconnect = true) } }
        scope.launch {
            while (isActive) {
                delay(AppConfig.Ws.UI_THROTTLE_MS)
                if (dirty) {
                    dirty = false
                    _version.update { it + 1 }
                }
            }
        }
        scope.launch {
            while (isActive) {
                delay(1_000L)
                watchdog()
            }
        }
    }

    private fun accept(t: Ticker) {
        cache.applyWs(t)
        dirty = true
        for (l in tickListeners) l(t)
    }

    private fun watchdog() {
        val h = conn.health.value
        val now = clock()
        if (mode != HubMode.IDLE) {
            if (h.state != WsState.OPEN) {
                val since = if (h.disconnectedAt > 0) h.disconnectedAt else now
                if (!staleMarked && cache.size > 0 && now - since >= AppConfig.Ws.STALE_AFTER_DISCONNECT_MS) {
                    // انقطاع فعلي للاتصال: كل القيم تصبح «قديمة» حتى يصل جديد.
                    cache.markAllStale()
                    staleMarked = true
                    dirty = true
                }
            } else if (mode == HubMode.ALL && conn.lastFrameAt > 0 && now - conn.lastFrameAt > AppConfig.Ws.ALL_STREAM_SILENCE_RECONNECT_MS) {
                // صمت تدفق «كل السوق» بالكامل غير طبيعي ⇒ اشتباه انقطاع صامت. (لا ينطبق على رمز منفرد.)
                conn.forceReconnect("silent-all-market-stream")
            }
        }
        _status.value = FeedStatus(market, mode, h, seed, conn.lastFrameAt, staleMarked, cache.size)
    }

    fun addTickListener(l: (Ticker) -> Unit) { tickListeners.add(l) }
    fun removeTickListener(l: (Ticker) -> Unit) { tickListeners.remove(l) }

    fun acquireAll(owner: String) {
        synchronized(lock) { allOwners.add(owner) }
        refreshStreams()
    }

    fun releaseAll(owner: String) {
        synchronized(lock) { allOwners.remove(owner) }
        refreshStreams()
    }

    fun setSelected(owner: String, symbols: Set<String>) {
        synchronized(lock) { if (symbols.isEmpty()) selectedByOwner.remove(owner) else selectedByOwner[owner] = symbols }
        refreshStreams()
    }

    fun selectedSymbols(): Set<String> = synchronized(lock) { selectedByOwner.values.flatten().toSet() }

    private fun refreshStreams() {
        val streams: Set<String>
        val newMode: HubMode
        synchronized(lock) {
            val selected = selectedByOwner.values.flatten().toSet()
            when {
                allOwners.isNotEmpty() -> { streams = setOf(BinanceEndpoints.ALL_MINI_TICKER); newMode = HubMode.ALL }
                selected.isNotEmpty() -> { streams = selected.map { BinanceEndpoints.miniTicker(it) }.toSet(); newMode = HubMode.SELECTED }
                else -> { streams = emptySet(); newMode = HubMode.IDLE }
            }
        }
        val changed = newMode != mode
        mode = newMode
        conn.setStreams("tickers", streams)
        if (newMode != HubMode.IDLE && (changed || seed is SeedState.Idle || seed is SeedState.Error)) {
            scope.launch { seed(force = changed && newMode == HubMode.ALL) }
        }
    }

    /** القائمة الأولية الرسمية (REST ticker/24hr)، بحد أدنى للفاصل بين الطلبات. */
    suspend fun seed(force: Boolean, afterReconnect: Boolean = false) {
        if (mode == HubMode.IDLE && !force) return
        seedMutex.withLock {
            val now = clock()
            val needAfterOutage = afterReconnect && staleMarked
            if (!force && !needAfterOutage && now - lastSeedAt < AppConfig.Ws.RESEED_MIN_INTERVAL_MS && seed is SeedState.Ready) return
            if (cache.size == 0) seed = SeedState.Loading
            _status.update { it.copy(seed = seed) }
            val started = clock()
            try {
                val symbols = if (mode == HubMode.SELECTED) selectedSymbols() else null
                val list = rest.tickers24h(market, symbols)
                cache.applySeed(list, started)
                lastSeedAt = clock()
                if (conn.health.value.state == WsState.OPEN) staleMarked = false
                seed = SeedState.Ready(lastSeedAt, list.size)
                dirty = true
            } catch (t: Throwable) {
                seed = SeedState.Error(t.message ?: t.javaClass.simpleName, clock())
            }
            _status.update { it.copy(seed = seed, symbols = cache.size) }
        }
    }

    fun get(symbol: String): Ticker? = cache.get(symbol)
    fun snapshot(): List<Ticker> = cache.snapshot()
    fun forceReconnect(reason: String) = conn.forceReconnect(reason)
}
