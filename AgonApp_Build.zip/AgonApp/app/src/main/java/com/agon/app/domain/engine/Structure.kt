package com.agon.app.domain.engine

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BookMetrics
import com.agon.app.data.providers.Kline
import kotlinx.serialization.Serializable
import kotlin.math.abs

data class Swing(val index: Int, val time: Long, val price: Double, val isHigh: Boolean)

enum class StructureKind(val label: String, val score: Double) {
    UP("قمم وقيعان صاعدة", 1.0),
    DOWN("قمم وقيعان هابطة", -1.0),
    RANGE("نطاق / غير واضح", 0.0),
    UNKNOWN("بيانات غير كافية", 0.0),
}

data class StructureRead(
    val kind: StructureKind,
    val lastHigh: Swing?,
    val prevHigh: Swing?,
    val lastLow: Swing?,
    val prevLow: Swing?,
    /** إغلاق آخر شمعة مغلقة تحت آخر قاع مؤكد / فوق آخر قمة مؤكدة. */
    val brokeLow: Boolean,
    val brokeHigh: Boolean,
)

object Structure {
    /** قمم/قيعان متأرجحة مؤكدة بـ[wing] شمعة على كل جانب (شموع مغلقة فقط). */
    fun swings(k: List<Kline>, wing: Int = AppConfig.Engine.SWING_WING): List<Swing> {
        val out = ArrayList<Swing>()
        for (i in wing until k.size - wing) {
            var isHigh = true
            var isLow = true
            for (j in 1..wing) {
                if (k[i].high <= k[i - j].high || k[i].high < k[i + j].high) isHigh = false
                if (k[i].low >= k[i - j].low || k[i].low > k[i + j].low) isLow = false
                if (!isHigh && !isLow) break
            }
            if (isHigh) out.add(Swing(i, k[i].openTime, k[i].high, true))
            if (isLow) out.add(Swing(i, k[i].openTime, k[i].low, false))
        }
        return out
    }

    fun read(k: List<Kline>, wing: Int = AppConfig.Engine.SWING_WING): StructureRead {
        val sw = swings(k, wing)
        val highs = sw.filter { it.isHigh }.takeLast(2)
        val lows = sw.filter { !it.isHigh }.takeLast(2)
        val lastHigh = highs.lastOrNull()
        val lastLow = lows.lastOrNull()
        val kind = if (highs.size < 2 || lows.size < 2) StructureKind.UNKNOWN else {
            val hh = highs[1].price > highs[0].price
            val hl = lows[1].price > lows[0].price
            when {
                hh && hl -> StructureKind.UP
                !hh && !hl -> StructureKind.DOWN
                else -> StructureKind.RANGE
            }
        }
        val lastClose = k.lastOrNull()?.close
        return StructureRead(
            kind = kind, lastHigh = lastHigh, prevHigh = highs.getOrNull(highs.size - 2).takeIf { highs.size == 2 },
            lastLow = lastLow, prevLow = lows.getOrNull(lows.size - 2).takeIf { lows.size == 2 },
            brokeLow = lastClose != null && lastLow != null && lastClose < lastLow.price,
            brokeHigh = lastClose != null && lastHigh != null && lastClose > lastHigh.price,
        )
    }
}

@Serializable
enum class LevelKind(val label: String) { SUPPORT("دعم"), RESISTANCE("مقاومة") }

@Serializable
data class Level(
    val price: Double,
    val kind: LevelKind,
    val reasons: List<String>,
    val touches: Int,
    val distancePct: Double,
)

object Levels {
    private data class Candidate(val price: Double, val reason: String)

    /** دعوم ومقاومات مع أسبابها: قمم/قيعان متأرجحة (1س و5د)، أعلى/أدنى 24س، وجدران الدفتر. */
    fun compute(price: Double, k1h: List<Kline>, k5m: List<Kline>, book: BookMetrics?): List<Level> {
        if (price <= 0) return emptyList()
        val c = ArrayList<Candidate>()
        Structure.swings(k1h).takeLast(16).forEach { c.add(Candidate(it.price, if (it.isHigh) "قمة متأرجحة 1س" else "قاع متأرجح 1س")) }
        Structure.swings(k5m).takeLast(16).forEach { c.add(Candidate(it.price, if (it.isHigh) "قمة متأرجحة 5د" else "قاع متأرجح 5د")) }
        if (k1h.size >= 24) {
            val day = k1h.takeLast(24)
            c.add(Candidate(day.maxOf { it.high }, "أعلى 24 ساعة"))
            c.add(Candidate(day.minOf { it.low }, "أدنى 24 ساعة"))
        }
        book?.bidWall?.takeIf { it.share >= AppConfig.Book.WALL_SHARE }?.let { c.add(Candidate(it.price, "جدار طلبات في الدفتر (${fmt(it.share * 100, 0)}% من عمق الجانب)")) }
        book?.askWall?.takeIf { it.share >= AppConfig.Book.WALL_SHARE }?.let { c.add(Candidate(it.price, "جدار عروض في الدفتر (${fmt(it.share * 100, 0)}% من عمق الجانب)")) }
        if (c.isEmpty()) return emptyList()

        val sorted = c.sortedBy { it.price }
        val clusters = ArrayList<MutableList<Candidate>>()
        for (cand in sorted) {
            val last = clusters.lastOrNull()
            val anchor = last?.map { it.price }?.average()
            if (last != null && anchor != null && abs(cand.price - anchor) / anchor * 100 <= AppConfig.Engine.LEVEL_CLUSTER_PCT) last.add(cand)
            else clusters.add(mutableListOf(cand))
        }
        val levels = clusters.map { cl ->
            val p = cl.map { it.price }.average()
            val reasons = cl.groupBy { it.reason }.map { (r, list) -> if (list.size > 1) "$r ×${list.size}" else r }
            Level(p, if (p < price) LevelKind.SUPPORT else LevelKind.RESISTANCE, reasons, cl.size, (p - price) / price * 100)
        }
        val n = AppConfig.Engine.LEVELS_PER_SIDE
        val supports = levels.filter { it.kind == LevelKind.SUPPORT }.sortedByDescending { it.price }.take(n)
        val resistances = levels.filter { it.kind == LevelKind.RESISTANCE }.sortedBy { it.price }.take(n)
        return resistances.reversed() + supports
    }
}
