package com.agon.app.data.providers

import com.agon.app.config.AppConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import okhttp3.OkHttpClient
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

typealias StreamListener = (stream: String, data: JsonElement, receivedAt: Long) -> Unit

/**
 * اتصال «combined streams» واحد (/stream) مع اشتراكات ديناميكية لعدة مالكين.
 * يعيد الاشتراك في كل التدفقات المطلوبة بعد كل إعادة اتصال، ويغلق الاتصال عندما لا يبقى طلب.
 */
class StreamConnection(
    http: OkHttpClient,
    val name: String,
    scope: CoroutineScope,
    private val baseUrlProvider: () -> String,
    clock: () -> Long = { System.currentTimeMillis() },
) {
    private val lock = Any()
    private val owners = HashMap<String, Set<String>>()
    private val subscribed = HashSet<String>()
    private var urlStreams: Set<String> = emptySet()
    private val listeners = CopyOnWriteArrayList<StreamListener>()
    private val openListeners = CopyOnWriteArrayList<() -> Unit>()
    private val ids = AtomicInteger(1)

    @Volatile var lastServerError: String? = null
        private set

    val client = WsClient(
        http = http, name = name, scope = scope, clock = clock,
        urlProvider = {
            synchronized(lock) {
                val desired = desiredLocked()
                urlStreams = desired.sorted().take(AppConfig.Ws.URL_STREAMS_MAX).toSet()
                subscribed.clear()
                baseUrlProvider().trimEnd('/') + "/stream?streams=" + urlStreams.joinToString("/")
            }
        },
        onOpen = {
            synchronized(lock) {
                subscribed.addAll(urlStreams)
                syncLocked()
            }
            openListeners.forEach { runCatching { it() } }
        },
        onText = ::dispatch,
    )

    val health: StateFlow<WsHealth> get() = client.health
    val lastFrameAt: Long get() = client.lastFrameAt

    fun addListener(l: StreamListener) { listeners.add(l) }
    fun removeListener(l: StreamListener) { listeners.remove(l) }
    fun addOpenListener(l: () -> Unit) { openListeners.add(l) }

    private fun desiredLocked(): Set<String> {
        val all = LinkedHashSet<String>()
        owners.values.forEach { all.addAll(it) }
        return if (all.size > AppConfig.Ws.MAX_STREAMS_PER_CONNECTION) all.take(AppConfig.Ws.MAX_STREAMS_PER_CONNECTION).toSet() else all
    }

    fun desired(): Set<String> = synchronized(lock) { desiredLocked() }

    /** يضبط تدفقات مالك واحد؛ الاتحاد بين المالكين هو المطلوب فعليًا. */
    fun setStreams(owner: String, streams: Set<String>) {
        val startNeeded: Boolean
        val stopNeeded: Boolean
        synchronized(lock) {
            val before = desiredLocked().isNotEmpty()
            if (streams.isEmpty()) owners.remove(owner) else owners[owner] = streams
            val after = desiredLocked().isNotEmpty()
            startNeeded = after && !before
            stopNeeded = !after && before
            if (after && before && client.isOpen) syncLocked()
        }
        if (startNeeded) client.start()
        if (stopNeeded) close()
    }

    private fun syncLocked() {
        val desired = desiredLocked()
        val toAdd = desired - subscribed
        val toRemove = subscribed - desired
        toRemove.chunked(AppConfig.Ws.SUBSCRIBE_BATCH).forEach { client.send(control("UNSUBSCRIBE", it)) }
        toAdd.chunked(AppConfig.Ws.SUBSCRIBE_BATCH).forEach { client.send(control("SUBSCRIBE", it)) }
        subscribed.removeAll(toRemove)
        subscribed.addAll(toAdd)
    }

    private fun control(method: String, params: List<String>): String =
        "{\"method\":\"$method\",\"params\":[" + params.joinToString(",") { "\"$it\"" } + "],\"id\":${ids.getAndIncrement()}}"

    private fun dispatch(text: String, receivedAt: Long) {
        val root = BinanceParsers.json.parseToJsonElement(text) as? JsonObject ?: return
        val stream = root.str("stream")
        val data = root["data"]
        if (stream != null && data != null) {
            if (data is JsonObject && data.str("e") == "serverShutdown") {
                client.forceReconnect("serverShutdown")
                return
            }
            for (l in listeners) l(stream, data, receivedAt)
            return
        }
        if (root.str("e") == "serverShutdown") {
            client.forceReconnect("serverShutdown")
            return
        }
        root.obj("error")?.let { lastServerError = "${it.lng("code")}: ${it.str("msg")}" }
    }

    fun forceReconnect(reason: String) = client.forceReconnect(reason)

    /** إلغاء الاشتراك صراحةً ثم إغلاق الاتصال. */
    fun close() {
        synchronized(lock) {
            if (client.isOpen && subscribed.isNotEmpty()) {
                subscribed.chunked(AppConfig.Ws.SUBSCRIBE_BATCH).take(3).forEach { client.sendNow(control("UNSUBSCRIBE", it)) }
            }
            owners.clear()
            subscribed.clear()
        }
        client.stop()
    }
}
