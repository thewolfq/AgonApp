package com.agon.app.data.providers

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * شموع الأطر الأعلى (4h و1d) لمركز القرارات فقط.
 * مستقلة تمامًا عن AppConfig.Rest/INTERVALS والمحركات الحالية: لا تلمس SymbolSession ولا Analyzer.
 */

/** حسابات UTC لافتتاح اليوم والأسبوع (الأسبوع يبدأ الاثنين 00:00 UTC). */
object UtcTime {
    const val DAY_MS = 86_400_000L

    fun dayStart(ms: Long): Long = ms - Math.floorMod(ms, DAY_MS)

    /** 1970-01-01 كان خميسًا، لذا (رقم اليوم + 3) % 7 = عدد الأيام منذ آخر اثنين. */
    fun weekStart(ms: Long): Long {
        val day = dayStart(ms)
        val daysSinceMonday = Math.floorMod(Math.floorDiv(day, DAY_MS) + 3L, 7L)
        return day - daysSinceMonday * DAY_MS
    }
}

enum class HtfInterval(val code: String, val ms: Long, val ttlMs: Long, val defaultLimit: Int) {
    H4("4h", 4 * 3_600_000L, 5 * 60_000L, 200),
    D1("1d", UtcTime.DAY_MS, 15 * 60_000L, 120),
}

data class HtfSnapshot(
    val market: Market,
    val symbol: String,
    val interval: HtfInterval,
    val klines: List<Kline>,
    val fetchedAt: Long,
    /** الحد الذي طُلب من Binance وقت الجلب (لتجنب إعادة الطلب إن أعادت Binance أقل). */
    val requestedLimit: Int,
    /** true = فشل التحديث وهذه نسخة أقدم من الكاش؛ على المستهلك التعامل معها كبيانات قديمة. */
    val stale: Boolean = false,
) {
    /** الشموع المكتملة فقط بحسب الساعة الآن؛ لا تُستخدم الشمعة الجارية كتأكيد نهائي. */
    fun closed(now: Long): List<Kline> = klines.filter { it.closeTime < now }

    /** الشمعة الجارية إن وُجدت. */
    fun forming(now: Long): Kline? = klines.lastOrNull()?.takeIf { it.closeTime >= now }

    fun limited(limit: Int): HtfSnapshot = if (klines.size <= limit) this else copy(klines = klines.takeLast(limit))
}

/** افتتاح اليوم والأسبوع بتوقيت UTC (null إن لم تتوفر الشمعة المطلوبة). */
data class UtcOpens(val dailyOpen: Double?, val weeklyOpen: Double?, val dayStartMs: Long, val weekStartMs: Long) {
    companion object {
        fun from(daily: List<Kline>, now: Long): UtcOpens {
            val d = UtcTime.dayStart(now)
            val w = UtcTime.weekStart(now)
            return UtcOpens(
                dailyOpen = daily.firstOrNull { it.openTime == d }?.open,
                weeklyOpen = daily.firstOrNull { it.openTime == w }?.open,
                dayStartMs = d, weekStartMs = w,
            )
        }
    }
}

/**
 * جالب شموع 4h/1d مع كاش وإزالة تكرار الطلبات المتزامنة.
 * - الكاش يبقى صالحًا ما لم ينتهِ TTL أو تنتهِ الشمعة الجارية (ظهرت شمعة جديدة).
 * - طلبات متزامنة لنفس (سوق، رمز، إطار) تشترك في طلب شبكة واحد.
 * - عند فشل التحديث وتوفر كاش أقدم يُعاد مع stale=true؛ وبلا كاش يُرمى الخطأ.
 * الطلبات تمر عبر BinanceRest.limiter الحالي فتحترم حدود الوزن وRetry-After.
 */
class HtfCandleFetcher(
    private val fetch: suspend (Market, String, String, Int) -> List<Kline>,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private data class Key(val market: Market, val symbol: String, val interval: HtfInterval)

    private val cache = ConcurrentHashMap<Key, HtfSnapshot>()
    private val locks = ConcurrentHashMap<Key, Mutex>()

    suspend fun candles(market: Market, symbol: String, interval: HtfInterval, limit: Int = interval.defaultLimit): HtfSnapshot {
        require(limit in 1..MAX_LIMIT) { "limit خارج النطاق" }
        val key = Key(market, symbol, interval)
        cache[key]?.takeIf { fresh(it, limit, clock()) }?.let { return it.limited(limit) }
        return locks.getOrPut(key) { Mutex() }.withLock {
            val now = clock()
            val cached = cache[key]
            if (cached != null && fresh(cached, limit, now)) return@withLock cached.limited(limit)
            val want = maxOf(limit, interval.defaultLimit)
            try {
                val k = fetch(market, symbol, interval.code, want).sortedBy { it.openTime }
                if (k.isEmpty()) throw IOException("لا شموع ${interval.code} لـ$symbol")
                val snap = HtfSnapshot(market, symbol, interval, k, now, want)
                cache[key] = snap
                snap.limited(limit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (cached != null) cached.copy(stale = true).limited(limit) else throw e
            }
        }
    }

    /** افتتاح اليوم والأسبوع (UTC) من شموع 1d. */
    suspend fun utcOpens(market: Market, symbol: String): UtcOpens {
        val snap = candles(market, symbol, HtfInterval.D1, WEEKLY_OPEN_LOOKBACK_DAYS)
        return UtcOpens.from(snap.klines, clock())
    }

    fun clear() {
        cache.clear()
    }

    private fun fresh(s: HtfSnapshot, limit: Int, now: Long): Boolean {
        if (s.requestedLimit < limit) return false
        if (now - s.fetchedAt >= s.interval.ttlMs) return false
        val last = s.klines.lastOrNull() ?: return false
        // الشمعة الجارية انتهت منذ الجلب ⇒ توجد شمعة جديدة، لا يكفي الكاش.
        return last.closeTime < s.fetchedAt || now <= last.closeTime
    }

    companion object {
        const val MAX_LIMIT = 1000
        const val WEEKLY_OPEN_LOOKBACK_DAYS = 10
    }
}
