package com.agon.app.domain.model

import com.agon.app.data.providers.Market
import kotlinx.serialization.Serializable

@Serializable
enum class Direction(val label: String, val sign: Int) {
    LONG("شراء", 1), SHORT("بيع", -1)
}

/** إطار الصفقة → إطار الشموع المستخدم لقياس القوة. */
@Serializable
enum class TradeFrame(val label: String, val interval: String) {
    FAST("سريع", "5m"), DAILY("يومي", "1h"), LONG_TERM("آجل", "4h")
}

@Serializable
enum class TradeStatus { OPEN, CLOSED }

@Serializable
enum class WatchTag(val label: String) {
    WATCH("مراقبة"), STUDY("دراسة"), DEFERRED("مؤجلة")
}

@Serializable
data class WatchItem(
    val id: Long = 0,
    val symbol: String,
    val market: Market,
    val tag: WatchTag = WatchTag.WATCH,
    val position: Int = 0,
    val addedAt: Long = 0,
)

@Serializable
data class Trade(
    val id: Long = 0,
    val symbol: String,
    val market: Market,
    val direction: Direction,
    val frame: TradeFrame,
    val entry: Double,
    val leverage: Double = 1.0,
    val target: Double,
    val stop: Double,
    /** حجم المركز الاسمي بعملة التسعير (USDT غالبًا). */
    val size: Double = 0.0,
    val note: String = "",
    /** سعر التصفية كما يظهر في منصة المستخدم — المرجع إن وُجد. */
    val liqManual: Double? = null,
    val status: TradeStatus = TradeStatus.OPEN,
    val openedAt: Long = 0,
    val closedAt: Long? = null,
    val closePrice: Double? = null,
    val closeReason: String? = null,
)

@Serializable
data class AlertStateRow(
    val key: String,
    val tradeId: Long,
    val type: String,
    val detail: String = "",
    val firedAt: Long,
    val value: Double = 0.0,
)

@Serializable
data class AlertRecord(
    val id: Long = 0,
    val ts: Long,
    val tradeId: Long,
    val symbol: String,
    val market: Market,
    val type: String,
    val title: String,
    val body: String,
    val price: Double,
    val critical: Boolean,
    val delivered: Boolean = true,
)

@Serializable
data class StudyCard(
    val id: Long = 0,
    val ts: Long,
    val scanId: Long,
    val symbol: String,
    val market: Market,
    val rank: Int,
    val score: Double,
    val bias: String,
    val price: Double,
    /** JSON لـStudyPayload: العوامل والمستويات والموانع والمقاييس. */
    val payload: String,
    /** JSON لنتيجة النموذج اللغوي (فيتو مخاطر) إن فُعّل. */
    val llm: String? = null,
)

/** لقطة قرار صغيرة عند كل دراسة/تنبيه + النتيجة بعد 4 و24 ساعة. */
@Serializable
data class DecisionRecord(
    val id: Long = 0,
    val ts: Long,
    val kind: String,
    val refId: Long = 0,
    val symbol: String,
    val market: Market,
    /** +1 صاعد، -1 هابط، 0 محايد (لا يُقاس اتجاهه). */
    val direction: Int,
    val score: Double? = null,
    val price: Double,
    val funding: Double? = null,
    val openInterest: Double? = null,
    /** JSON: العوامل ومساهماتها والدفتر والقوة النسبية. */
    val snapshot: String = "{}",
    val price4h: Double? = null,
    val ret4h: Double? = null,
    val price24h: Double? = null,
    val ret24h: Double? = null,
    val note: String = "",
)

@Serializable
data class MarketEvent(
    val id: Long = 0,
    /** وقت الحدث (قادم أو ماضٍ) بالمللي ثانية. */
    val ts: Long,
    val symbol: String = "",
    val title: String,
    /** listing | delisting | hack | unlock | suspicious | funding | news | note */
    val kind: String,
    val source: String,
    /** official | user | llm-unverified */
    val evidence: String,
    val note: String = "",
    val createdAt: Long = 0,
)

@Serializable
data class SavedLevel(
    val id: Long = 0,
    val symbol: String,
    val market: Market,
    val price: Double,
    val kind: String,
    val reason: String,
    val createdAt: Long = 0,
)
