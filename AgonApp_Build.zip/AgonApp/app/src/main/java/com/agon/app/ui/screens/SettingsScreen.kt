@file:OptIn(ExperimentalMaterial3Api::class)

package com.agon.app.ui.screens

import android.Manifest
import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BookSyncState
import com.agon.app.data.providers.Market
import com.agon.app.domain.engine.Severity
import com.agon.app.domain.engine.TradeCalculator
import com.agon.app.domain.engine.TradeInput
import com.agon.app.domain.engine.fmt
import com.agon.app.domain.engine.fmtSigned
import com.agon.app.domain.model.Direction
import com.agon.app.domain.model.MarketEvent
import com.agon.app.domain.model.SavedLevel
import com.agon.app.domain.model.Trade
import com.agon.app.domain.model.TradeFrame
import com.agon.app.domain.model.TradeStatus
import com.agon.app.domain.model.WatchTag
import com.agon.app.ui.CoinViewModel
import com.agon.app.ui.MainViewModel
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.LocalMarketColors

@Composable
private fun Bar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = { Text(title, maxLines = 1) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } },
        actions = actions, windowInsets = WindowInsets(0, 0, 0, 0),
    )
}

private val pad = PaddingValues(16.dp)
private val gap = Arrangement.spacedBy(12.dp)

// ============================ العملة ============================

@Composable
fun CoinScreen(vm: MainViewModel, market: Market, symbol: String, onBack: () -> Unit, onNewTrade: () -> Unit, onOpenOther: (Market) -> Unit) {
    val app = LocalContext.current.applicationContext as Application
    val cvm: CoinViewModel = viewModel(key = "coin:${market.id}:$symbol", factory = viewModelFactory { initializer { CoinViewModel(app, market, symbol) } })
    val s by cvm.state.collectAsStateWithLifecycle()
    val t by cvm.ticker.collectAsStateWithLifecycle()
    val a by cvm.analysis.collectAsStateWithLifecycle()
    val other by cvm.otherMarketExists.collectAsStateWithLifecycle()
    val watch by vm.watchlist.collectAsStateWithLifecycle()
    val now by rememberNow()
    var tf by rememberSaveable { mutableStateOf("5m") }
    val m = LocalMarketColors.current
    // اشتراك للرمز المفتوح فقط؛ يُلغى عند مغادرة الصفحة أو ذهاب التطبيق للخلفية.
    LifecycleStartEffect(symbol, market) {
        cvm.onStart()
        onStopOrDispose { cvm.onStop() }
    }
    val watched = watch.any { it.symbol == symbol && it.market == market }
    Column(Modifier.fillMaxSize()) {
        Bar("$symbol · ${market.label}", onBack) {
            IconButton(onClick = { vm.toggleWatch(symbol, market) }) { Icon(if (watched) Icons.Default.Star else Icons.Default.StarBorder, "مراقبة") }
            IconButton(onClick = onNewTrade) { Icon(Icons.Default.Add, "صفقة جديدة") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = gap) {
            item {
                SectionCard("السعر", subtitle = if (s.connected) "البث متصل · آخر إطار ${agoText(now, s.lastFrameAt)}" else "البث غير متصل — القيم قد تكون قديمة") {
                    val price = s.flow.lastPrice ?: t?.close
                    Num(priceText(price), style = MaterialTheme.typography.headlineMedium, weight = FontWeight.Bold, mono = true)
                    StatRow("تغير 24س", pctText(t?.changePct), signColor(t?.changePct))
                    StatRow("حجم التسعير 24س (USDT)", cvm.volumeUsdt()?.let { volText(it) } ?: "غير قابل للتحويل", hint = "حجم تداول 24س، ليس عمق دفتر ولا سيولة مضمونة. حد المسح 3M وحد التنبيه 4.5M.")
                    if (t?.stale == true) Pill("سعر 24س قديم", m.warn)
                }
            }
            item {
                SectionCard("الشارت", subtitle = "الشمعة المفرّغة جارية ولا تدخل التحليل") {
                    SegmentRow(AppConfig.Symbol.INTERVALS, tf, { it }, { tf = it })
                    val series = s.klines[tf]
                    when {
                        series == null || !series.loaded -> if (s.klineError != null) ErrorState(s.klineError ?: "") else LoadingState("جارٍ تحميل الشموع…")
                        series.closed.isEmpty() -> EmptyState(Icons.Default.BarChart, "لا شموع", "لا بيانات لهذا الإطار.")
                        else -> CandleChart(series, a?.levels ?: emptyList(), Modifier.height(240.dp))
                    }
                }
            }
            item {
                val an = a
                SectionCard("التحليل الحي", subtitle = an?.let { "حُسب عند إغلاق شمعة ${timeText(it.basedOnCloseTime)} (x=true)" } ?: "ينتظر اكتمال الشموع", trailing = { UnprovenBadge() }) {
                    if (an == null) LoadingState("بانتظار أول إغلاق شمعة…") else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Pill(an.bias.label, if (an.bias.sign > 0) m.up else if (an.bias.sign < 0) m.down else MaterialTheme.colorScheme.onSurfaceVariant)
                            Num("مجموع المساهمات ${fmtSigned(an.score)}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text("لا نسبة ثقة: تُعرض العوامل ومساهمة كل منها فقط.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        an.factors.forEach { f ->
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(f.title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Num(if (f.available) "${fmtSigned(f.contribution, 3)} · وزن ${fmt(f.weight * 100, 0)}%" else "محذوف", style = MaterialTheme.typography.labelMedium, color = if (f.available) signColor(f.contribution) else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (f.available) ContributionBar(f.contribution, Modifier.fillMaxWidth())
                                Text(f.value, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider()
                        StatRow("الاتجاه", an.trends.joinToString("  ") { "${it.tf}:${it.label}" })
                        StatRow("الهيكل 1h / 5m", "${an.structure1h} / ${an.structure5m}")
                        StatRow("الحجم النسبي", an.relVolume?.let { "×${fmt(it)}" } ?: "—")
                        StatRow("RSI 5m", an.rsi5m?.let { fmt(it, 1) } ?: "—")
                        StatRow("شراء المبادرين", an.takerBuyRatio?.let { "${fmt(it * 100, 1)}%" } ?: "—", hint = an.takerSource)
                    }
                }
            }
            item {
                SectionCard("شراء المبادرين الحي (aggTrade)", subtitle = "نافذة ${AppConfig.Symbol.TAKER_WINDOW_MS / 60_000} دقائق · m=true يعني المبادر بائع") {
                    StatRow("شراء مبادر", volText(s.flow.buyNotional), m.up)
                    StatRow("بيع مبادر", volText(s.flow.sellNotional), m.down)
                    StatRow("نسبة الشراء", s.flow.buyRatio?.let { "${fmt(it * 100, 1)}%" } ?: "—")
                    StatRow("عدد الصفقات", s.flow.trades.toString())
                }
            }
            item {
                val bs = s.bookStatus
                SectionCard("دفتر الطلبات", subtitle = "snapshot REST + أحداث depth متسلسلة", trailing = { Pill(bs.state.label, if (bs.state == BookSyncState.SYNCED) m.up else m.warn) }) {
                    val b = s.book
                    if (b == null) {
                        Text(bs.snapshotError?.let { "خطأ اللقطة: $it" } ?: "جارٍ بناء الدفتر من snapshot رسمي…", style = MaterialTheme.typography.bodySmall)
                    } else {
                        StatRow("أفضل طلب / عرض", "${priceText(b.bestBid)} / ${priceText(b.bestAsk)}")
                        StatRow("الفارق", "${fmt(b.spreadBps, 2)} نقطة أساس")
                        StatRow("عمق الطلبات ±${fmt(b.bandPct, 0)}%", volText(b.bidNotional), m.up)
                        StatRow("عمق العروض ±${fmt(b.bandPct, 0)}%", volText(b.askNotional), m.down)
                        StatRow("الاختلال", pctText(b.imbalance * 100, 0), signColor(b.imbalance))
                    }
                    StatRow("إعادات البناء بعد فجوة", bs.resyncs.toString(), hint = bs.lastGapReason)
                }
            }
            item {
                SectionCard("التمويل وOI", subtitle = if (market == Market.FUTURES) "USDⓈ-M Futures فقط" else "خاص بسوق العقود — لا يُخلط مع الفوري") {
                    if (market == Market.FUTURES) {
                        val mk = s.mark
                        StatRow("معدل التمويل (لكل فترة)", mk?.value?.let { "${fmtSigned(it.fundingRate * 100, 4)}%" } ?: "غير متاح", hint = mk?.let { "${it.source} · ${agoText(now, it.fetchedAt)}${if (it.stale) " · قديم" else ""}" })
                        StatRow("التمويل القادم", mk?.value?.let { dateTimeText(it.nextFundingTime) } ?: "—")
                        val oi = s.oi
                        StatRow("Open Interest (${oi?.unit ?: ""})", oi?.value?.let { volText(it.openInterest) } ?: "غير متاح", hint = oi?.let { "${it.source} · ${agoText(now, it.fetchedAt)}${if (it.stale) " · قديم" else ""}" } ?: s.oiError)
                        StatRow("تغير OI ساعة", pctText(s.oiChange1hPct))
                    } else {
                        Text("التمويل وOI غير موجودين في السوق الفوري؛ عاملهما محذوف من التحليل هنا.", style = MaterialTheme.typography.bodySmall)
                    }
                    if (other == true) TextButton(onClick = { onOpenOther(cvm.otherMarket) }) { Text("افتح $symbol في ${cvm.otherMarket.label}") }
                }
            }
            a?.let { an ->
                item {
                    SectionCard("الدعم والمقاومة") {
                        if (an.levels.isEmpty()) Text("لا مستويات كافية.", style = MaterialTheme.typography.bodySmall)
                        an.levels.forEach { l ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Num("${l.kind.label} ${priceText(l.price)} (${pctText(l.distancePct)})", style = MaterialTheme.typography.bodyMedium, color = if (l.distancePct < 0) m.up else m.down)
                                    Text(l.reasons.joinToString("، "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { vm.saveLevel(SavedLevel(symbol = symbol, market = market, price = l.price, kind = l.kind.name, reason = l.reasons.joinToString("، "))) }) { Icon(Icons.Default.Save, "حفظ المستوى") }
                            }
                        }
                    }
                }
                item {
                    SectionCard("الموانع") {
                        if (an.blockers.isEmpty()) Text("لا موانع مرصودة الآن.", style = MaterialTheme.typography.bodySmall)
                        an.blockers.forEach { b ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Pill(if (b.severity == Severity.BLOCK) "مانع" else "تحذير", if (b.severity == Severity.BLOCK) m.down else m.warn)
                                Column { Text(b.title, style = MaterialTheme.typography.bodyMedium); Text(b.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            }
                        }
                    }
                }
                item { SectionCard("السيناريو المعاكس") { Text(an.counterScenario, style = MaterialTheme.typography.bodyMedium) } }
            }
            item { Disclaimer() }
        }
    }
}

// ============================ المراقبة ============================

@Composable
fun WatchlistScreen(vm: MainViewModel, onOpen: (Market, String) -> Unit) {
    val watch by vm.watchlist.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    val tick by vm.priceTick.collectAsStateWithLifecycle()
    var q by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf<String?>(null) }
    var cleanup by remember { mutableStateOf(false) }
    val picked = remember { mutableStateListOf<Long>() }
    val m = LocalMarketColors.current
    // خامدة/ضعيفة النشاط: اقتراح فقط، والحذف بقرار المستخدم.
    val dormant = remember(watch, tick) {
        watch.filter { w ->
            val t = vm.ticker(w.market, w.symbol) ?: return@filter false
            val v = vm.volUsdt(w.market, w.symbol)
            (v != null && v < AppConfig.Liquidity.SCAN_MIN_QUOTE_VOLUME_24H_USDT) || kotlin.math.abs(t.changePct) < AppConfig.Watch.DORMANT_MAX_ABS_CHANGE_PCT
        }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            OutlinedTextField(q, { q = it; vm.searchSymbols(it) }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("أضف أي زوج بالبحث (السوقان)") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        }
        if (q.isNotBlank()) {
            if (search.loading) item { LoadingState("جارٍ البحث في exchangeInfo…") }
            search.error?.let { e -> item { Text("تعذر تحميل بعض الرموز: $e", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) } }
            if (!search.loading && search.results.isEmpty() && search.error == null) item { Text("لا زوج يطابق «$q».", style = MaterialTheme.typography.bodySmall) }
            items(search.results, key = { "s-${it.market.id}-${it.symbol}" }) { info ->
                Row(Modifier.fillMaxWidth().clickable { vm.addWatch(info.symbol, info.market, WatchTag.WATCH) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Num(info.symbol, Modifier.weight(1f), weight = FontWeight.SemiBold)
                    Pill(info.market.label)
                    Icon(Icons.Default.Add, "إضافة", Modifier.padding(start = 8.dp))
                }
            }
            item { HorizontalDivider() }
        }
        item { SegmentRow(listOf<String?>(null) + WatchTag.entries.map { it.name }, filter, { n -> n?.let { WatchTag.valueOf(it).label } ?: "الكل" }, { filter = it }) }
        if (dormant.isNotEmpty()) item {
            SectionCard("اقتراح تنظيف", subtitle = "${dormant.size} عملة تبدو خامدة أو ضعيفة النشاط. لا حذف تلقائي.") {
                TextButton(onClick = { picked.clear(); cleanup = true }) { Text("مراجعة") }
            }
        }
        val shown = watch.filter { filter == null || it.tag.name == filter }
        if (shown.isEmpty()) item { EmptyState(Icons.Default.Visibility, "قائمة المراقبة فارغة", "ابحث عن زوج أعلاه أو اضغط النجمة في السوق.") }
        items(shown, key = { it.id }) { w ->
            val t = remember(tick, w.id) { vm.ticker(w.market, w.symbol) }
            Card(Modifier.fillMaxWidth().clickable { onOpen(w.market, w.symbol) }) {
                Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        IconButton(onClick = { val ids = watch.map { it.id }.toMutableList(); val i = ids.indexOf(w.id); if (i > 0) { ids.removeAt(i); ids.add(i - 1, w.id); vm.reorderWatch(ids) } }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.KeyboardArrowUp, "أعلى") }
                        IconButton(onClick = { val ids = watch.map { it.id }.toMutableList(); val i = ids.indexOf(w.id); if (i in 0 until ids.lastIndex) { ids.removeAt(i); ids.add(i + 1, w.id); vm.reorderWatch(ids) } }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.KeyboardArrowDown, "أسفل") }
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Num(w.symbol, weight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Pill(w.market.label)
                            Pill(w.tag.label, m.warn, Modifier.clickable { vm.setWatchTag(w.id, WatchTag.entries[(w.tag.ordinal + 1) % WatchTag.entries.size]) })
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Num(priceText(t?.close), mono = true)
                        Num(if (t?.stale == true) "قديم" else pctText(t?.changePct), style = MaterialTheme.typography.labelMedium, color = signColor(t?.changePct))
                    }
                    IconButton(onClick = { vm.removeWatch(listOf(w.id)) }) { Icon(Icons.Default.Delete, "حذف") }
                }
            }
        }
    }
    if (cleanup) AlertDialog(
        onDismissRequest = { cleanup = false }, title = { Text("تنظيف المراقبة") },
        text = {
            Column {
                Text("اختر ما تريد حذفه. لن يُحذف شيء دون اختيارك.", style = MaterialTheme.typography.bodySmall)
                dormant.forEach { w ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(w.id in picked, { if (it) picked.add(w.id) else picked.remove(w.id) })
                        Num("${w.symbol} · ${w.market.label}")
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = picked.isNotEmpty(), onClick = { vm.removeWatch(picked.toList()); cleanup = false }) { Text("حذف المحدد") } },
        dismissButton = { TextButton(onClick = { cleanup = false }) { Text("إلغاء") } },
    )
}

// ============================ صفقاتي ============================

@Composable
fun TradesScreen(vm: MainViewModel, onEdit: (Long) -> Unit, onNew: () -> Unit, onOpen: (Market, String) -> Unit) {
    val trades by vm.trades.collectAsStateWithLifecycle()
    val alerts by vm.alertLog.collectAsStateWithLifecycle()
    val strength by vm.strength.collectAsStateWithLifecycle()
    val tick by vm.priceTick.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf("open") }
    val m = LocalMarketColors.current
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp), verticalArrangement = gap) {
            item { SegmentRow(listOf("open", "closed", "alerts"), tab, { when (it) { "open" -> "مفتوحة"; "closed" -> "مغلقة"; else -> "التنبيهات" } }, { tab = it }) }
            if (tab == "alerts") {
                if (alerts.isEmpty()) item { EmptyState(Icons.Default.Notifications, "لا تنبيهات", "تظهر هنا تنبيهات الهدف والوقف والتصفية وتغير القوة.") }
                else item { TextButton(onClick = { vm.clearAlertLog() }) { Text("مسح السجل") } }
                items(alerts, key = { "a${it.id}" }) { a ->
                    SectionCard(a.title, subtitle = dateTimeText(a.ts), trailing = { if (a.critical) Pill("حرج", m.down) else if (!a.delivered) Pill("بلا إشعار", m.warn) }) { Text(a.body, style = MaterialTheme.typography.bodySmall) }
                }
            } else {
                val list = trades.filter { (it.status == TradeStatus.OPEN) == (tab == "open") }
                if (list.isEmpty()) item { EmptyState(Icons.Default.AccountBalanceWallet, if (tab == "open") "لا صفقات مفتوحة" else "لا صفقات مغلقة", "سجّل صفقتك للمتابعة والتنبيه. التطبيق لا ينفّذ صفقات.", actionLabel = "صفقة جديدة", onAction = onNew) }
                items(list, key = { "t${it.id}" }) { t ->
                    val price = remember(tick, t.id) { vm.ticker(t.market, t.symbol) }
                    val mt = remember(t) { TradeCalculator.compute(TradeCalculator.inputOf(t)) }
                    val rep = strength[t.id]
                    SectionCard(
                        "${t.symbol} · ${t.direction.label}", subtitle = "${t.market.label} · ${t.frame.label} · رافعة ×${fmt(t.leverage, 0)}",
                        trailing = { rep?.let { Pill(it.state.label, if (it.state.ordinal <= 1) m.up else m.down) } },
                        modifier = Modifier.clickable { onOpen(t.market, t.symbol) },
                    ) {
                        if (t.status == TradeStatus.OPEN) {
                            val p = price?.close
                            StatRow("السعر الحي", priceText(p) + if (price?.stale == true) " (قديم)" else "")
                            StatRow("الربح/الخسارة بعد الرافعة", pctText(p?.let { TradeCalculator.pnlPctOnMargin(t, it) }), signColor(p?.let { TradeCalculator.pnlPctOnMargin(t, it) }))
                        } else StatRow("أُغلقت", "${priceText(t.closePrice)} · ${dateTimeText(t.closedAt ?: 0)}")
                        StatRow("الدخول / الهدف / الوقف", "${priceText(t.entry)} / ${priceText(t.target)} / ${priceText(t.stop)}")
                        StatRow("العائد/المخاطرة", mt.rewardRisk?.let { fmt(it) } ?: "—")
                        StatRow("الخسارة عند الوقف (من الهامش)", mt.lossPctOnMargin?.let { "-${fmt(it)}%" } ?: "—", m.down)
                        StatRow("التصفية (${mt.liqSource.label})", priceText(mt.liqReference))
                        if (mt.liqBeforeStop) Pill("تحذير: التصفية أقرب من الوقف", m.down, filled = true)
                        rep?.reasons?.forEach { r -> Text("• ${r.title}: ${r.value}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        if (rep != null) Text("حالة القوة ${AppConfig.UNPROVEN} تنبؤيًا.", style = MaterialTheme.typography.labelSmall, color = m.warn)
                        if (t.note.isNotBlank()) Text(t.note, style = MaterialTheme.typography.bodySmall)
                        Row {
                            if (t.status == TradeStatus.OPEN) { TextButton(onClick = { onEdit(t.id) }) { Text("تعديل") }; TextButton(onClick = { vm.closeTrade(t, "يدوي") }) { Text("إغلاق") } }
                            TextButton(onClick = { vm.deleteTrade(t.id) }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(onClick = onNew, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp), icon = { Icon(Icons.Default.Add, null) }, text = { Text("صفقة") })
    }
}

@Composable
fun TradeEditorScreen(vm: MainViewModel, tradeId: Long, presetMarket: Market?, presetSymbol: String, onDone: () -> Unit) {
    val trades by vm.trades.collectAsStateWithLifecycle()
    val existing = trades.firstOrNull { it.id == tradeId }
    var loaded by rememberSaveable { mutableStateOf(false) }
    var symbol by rememberSaveable { mutableStateOf(presetSymbol) }
    var market by rememberSaveable { mutableStateOf(presetMarket ?: Market.FUTURES) }
    var dir by rememberSaveable { mutableStateOf(Direction.LONG) }
    var frame by rememberSaveable { mutableStateOf(TradeFrame.FAST) }
    var entry by rememberSaveable { mutableStateOf("") }
    var lev by rememberSaveable { mutableStateOf("1") }
    var target by rememberSaveable { mutableStateOf("") }
    var stop by rememberSaveable { mutableStateOf("") }
    var size by rememberSaveable { mutableStateOf("") }
    var liq by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(existing) {
        if (existing != null && !loaded) {
            loaded = true; symbol = existing.symbol; market = existing.market; dir = existing.direction; frame = existing.frame
            entry = existing.entry.toString(); lev = existing.leverage.toString(); target = existing.target.toString(); stop = existing.stop.toString()
            size = if (existing.size > 0) existing.size.toString() else ""; liq = existing.liqManual?.toString() ?: ""; note = existing.note
        }
    }
    val m = LocalMarketColors.current
    val metrics = TradeCalculator.compute(TradeInput(market, dir, entry.toDoubleOrNull(), if (market == Market.SPOT) 1.0 else lev.toDoubleOrNull(), target.toDoubleOrNull(), stop.toDoubleOrNull(), size.toDoubleOrNull(), liq.toDoubleOrNull()))
    val sym = symbol.trim().uppercase()
    val num = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    Column(Modifier.fillMaxSize().imePadding()) {
        Bar(if (tradeId == 0L) "صفقة جديدة" else "تعديل الصفقة", onDone)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { OutlinedTextField(symbol, { symbol = it.uppercase() }, Modifier.fillMaxWidth(), label = { Text("الزوج (مثل BTCUSDT)") }, singleLine = true) }
            item { SegmentRow(Market.entries.toList(), market, { it.label }, { market = it; if (it == Market.SPOT) dir = Direction.LONG }) }
            item { SegmentRow(Direction.entries.toList(), dir, { it.label }, { dir = it }) }
            item { SegmentRow(TradeFrame.entries.toList(), frame, { it.label }, { frame = it }) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(entry, { entry = it }, Modifier.weight(1f), label = { Text("الدخول") }, singleLine = true, keyboardOptions = num)
                    TextButton(onClick = { vm.ticker(market, sym)?.let { entry = it.close.toString() } ?: vm.say("لا سعر حي لهذا الزوج الآن") }) { Text("السعر الحالي") }
                }
            }
            if (market == Market.FUTURES) item { OutlinedTextField(lev, { lev = it }, Modifier.fillMaxWidth(), label = { Text("الرافعة") }, singleLine = true, keyboardOptions = num) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(target, { target = it }, Modifier.weight(1f), label = { Text("الهدف") }, singleLine = true, keyboardOptions = num)
                    OutlinedTextField(stop, { stop = it }, Modifier.weight(1f), label = { Text("الوقف") }, singleLine = true, keyboardOptions = num)
                }
            }
            item { OutlinedTextField(size, { size = it }, Modifier.fillMaxWidth(), label = { Text("الحجم الاسمي (بعملة التسعير)") }, singleLine = true, keyboardOptions = num) }
            if (market == Market.FUTURES) item { OutlinedTextField(liq, { liq = it }, Modifier.fillMaxWidth(), label = { Text("سعر التصفية كما في منصتك (اختياري)") }, singleLine = true, keyboardOptions = num) }
            item { OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("ملاحظة") }) }
            item {
                SectionCard("الحاسبة") {
                    metrics.errors.forEach { Text("• $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    if (metrics.valid) {
                        StatRow("العائد/المخاطرة", metrics.rewardRisk?.let { fmt(it) } ?: "—")
                        StatRow("الربح عند الهدف (من الهامش)", "+${fmt(metrics.profitPctOnMargin ?: 0.0)}%", m.up)
                        StatRow("الخسارة عند الوقف (من الهامش)", "-${fmt(metrics.lossPctOnMargin ?: 0.0)}%", m.down)
                        metrics.margin?.let { StatRow("الهامش", fmt(it)) }
                        metrics.lossQuote?.let { StatRow("الخسارة بالقيمة", fmt(it), m.down) }
                        StatRow("التصفية (${metrics.liqSource.label})", priceText(metrics.liqReference))
                        metrics.liqEstimate?.let { StatRow("التقدير التقريبي", priceText(it)) }
                        if (metrics.liqBeforeStop) Pill("تحذير: التصفية أقرب من الوقف", m.down, filled = true)
                        metrics.warnings.forEach { Text("• $it", color = m.warn, style = MaterialTheme.typography.bodySmall) }
                        if (market == Market.FUTURES) Text(TradeCalculator.LIQ_NOTE, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Button(
                    enabled = metrics.valid && sym.length >= 5, modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        vm.saveTrade(
                            Trade(
                                id = tradeId, symbol = sym, market = market, direction = dir, frame = frame, entry = entry.toDouble(),
                                leverage = if (market == Market.SPOT) 1.0 else (lev.toDoubleOrNull() ?: 1.0), target = target.toDouble(), stop = stop.toDouble(),
                                size = size.toDoubleOrNull() ?: 0.0, note = note.trim(), liqManual = liq.toDoubleOrNull(), openedAt = existing?.openedAt ?: 0L,
                            ),
                            onDone,
                        )
                    },
                ) { Text("حفظ الصفقة") }
            }
            item { Disclaimer() }
        }
    }
}

// ============================ الدراسات ============================

@Composable
fun StudiesScreen(vm: MainViewModel, onOpen: (Market, String) -> Unit) {
    val scan by vm.scan.collectAsStateWithLifecycle()
    val cards by vm.studies.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    val official by vm.official.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf("cards") }
    var market by rememberSaveable { mutableStateOf(Market.SPOT) }
    var title by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("") }
    val m = LocalMarketColors.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = gap) {
        item { SegmentRow(listOf("cards", "events"), tab, { if (it == "cards") "البطاقات" else "الأخبار والأحداث" }, { tab = it }) }
        if (tab == "cards") {
            item {
                SectionCard("المسح الحتمي", subtitle = "أعلى 100 زوج (حجم 24س ≥ 3M USDT) ← تغير الساعة والحجم النسبي ← دراسة أفضل 5") {
                    SegmentRow(Market.entries.toList(), market, { it.label }, { market = it })
                    Button(onClick = { vm.runScan(market) }, enabled = !scan.running) { Text(if (scan.running) "جارٍ المسح…" else "ابدأ المسح") }
                    if (scan.running) LinearProgressIndicator(progress = { scan.progress }, modifier = Modifier.fillMaxWidth())
                    if (scan.stage.isNotEmpty()) Text(scan.stage, style = MaterialTheme.typography.bodySmall)
                    scan.error?.let { Text("خطأ: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    if (scan.universe > 0) Text("فُحص ${scan.seen} · مؤهل ${scan.universe} · مستبعد ${scan.excluded.size} (مع السبب)", style = MaterialTheme.typography.labelSmall)
                    scan.llmNote?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
                }
            }
            if (cards.isEmpty()) item { EmptyState(Icons.Default.Science, "لا دراسات بعد", "شغّل المسح لإنشاء بطاقات لأفضل 5 مرشحين.") }
            items(cards, key = { "c${it.id}" }) { card ->
                val p = remember(card.id) { vm.decodeStudy(card) }
                val v = remember(card.id, card.llm) { vm.decodeVerdict(card) }
                SectionCard("#${card.rank} ${card.symbol}", subtitle = "${card.market.label} · ${dateTimeText(card.ts)}", trailing = { UnprovenBadge() }, modifier = Modifier.clickable { onOpen(card.market, card.symbol) }) {
                    StatRow("مجموع المساهمات", fmtSigned(card.score), signColor(card.score))
                    p?.let {
                        StatRow("تغير آخر ساعة", pctText(it.candidate.metrics.change1hPct), signColor(it.candidate.metrics.change1hPct))
                        StatRow("الحجم النسبي", "×${fmt(it.candidate.metrics.relVolume, 1)}")
                        StatRow("حجم 24س", "${volText(it.volume24hUsdt)} USDT", hint = if (it.alertEligible) null else "تحت حد التنبيه 4.5M: بلا إشعار")
                        it.relStrength?.let { rs -> StatRow("قوة نسبية مقابل BTC (نفس النافذة)", "${fmt(rs.outperformShare * 100, 0)}% · حد ${fmt(rs.threshold * 100, 0)}%${if (rs.thresholdCalibrated) "" else " غير معاير"}") }
                        it.analysis.factors.filter { f -> f.available }.forEach { f -> StatRow(f.title, fmtSigned(f.contribution, 3), signColor(f.contribution)) }
                        it.analysis.blockers.forEach { b -> Text("• ${b.title}: ${b.detail}", style = MaterialTheme.typography.labelSmall, color = m.warn) }
                    }
                    v?.let { Text(if (it.error != null) "النموذج اللغوي: ${it.error}" else "فيتو مخاطر: ${if (it.veto) "نعم" else "لا"} · الدليل: ${it.evidenceLevel} · ${it.reason} (المصدر: ${it.source.ifBlank { "—" }} ${it.date})", style = MaterialTheme.typography.labelSmall) }
                    TextButton(onClick = { vm.deleteStudy(card.id) }) { Text("حذف") }
                }
            }
        } else {
            item {
                SectionCard("أحداث رسمية من Binance", subtitle = "تمويل قادم وإدراج/تسوية عقود من API الرسمي. لا مصدر أخبار آلي ولا كشط صفحات.") {
                    Button(onClick = { vm.loadOfficialEvents() }, enabled = !official.loading) { Text(if (official.loading) "جارٍ التحميل…" else "تحديث") }
                    official.error?.let { Text("تعذر: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    if (official.loadedAt > 0 && official.items.isEmpty() && official.error == null) Text("لا أحداث رسمية قادمة.", style = MaterialTheme.typography.bodySmall)
                    official.items.take(40).forEach { e -> StatRow("${e.symbol} · ${e.title}", dateTimeText(e.ts), hint = e.source) }
                }
            }
            item {
                SectionCard("إضافة خبر/حدث يدوي") {
                    OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("العنوان") }, singleLine = true)
                    OutlinedTextField(source, { source = it }, Modifier.fillMaxWidth(), label = { Text("المصدر/الرابط") }, singleLine = true)
                    Button(enabled = title.isNotBlank(), onClick = { vm.addEvent(MarketEvent(ts = System.currentTimeMillis(), title = title.trim(), kind = "note", source = source.trim().ifBlank { "المستخدم" }, evidence = "user")); title = ""; source = "" }) { Text("إضافة") }
                }
            }
            if (events.isEmpty()) item { EmptyState(Icons.Default.Event, "لا أحداث محفوظة", "أضف حدثًا يدويًا، أو فعّل النموذج اللغوي الاختياري.") }
            items(events, key = { "e${it.id}" }) { e ->
                SectionCard(e.title, subtitle = "${e.symbol} ${dateTimeText(e.ts)} · ${e.source}", trailing = { Pill(if (e.evidence == "llm-unverified") AppConfig.UNPROVEN else e.evidence, m.warn) }) {
                    if (e.note.isNotBlank()) Text(e.note, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.deleteEvent(e.id) }) { Text("حذف") }
                }
            }
        }
        item { Disclaimer() }
    }
}

// ============================ الدليل ============================

@Composable
fun EvidenceScreen(vm: MainViewModel) {
    val decisions by vm.decisions.collectAsStateWithLifecycle()
    val radar by vm.radar.collectAsStateWithLifecycle()
    val cal by vm.calibration.collectAsStateWithLifecycle()
    val now by rememberNow()
    val tech = remember(now / 5000) { vm.techMetrics() }
    val m = LocalMarketColors.current
    val measured = decisions.filter { it.direction != 0 && it.ret24h != null }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = gap) {
        item {
            SectionCard("القياس", subtitle = "لا إشارة مؤكدة قبل ${AppConfig.Outcome.MIN_MEASURED_CASES} حالة خارج العينة", trailing = { UnprovenBadge() }) {
                StatRow("لقطات القرار", decisions.size.toString())
                StatRow("مقاسة بعد 24س", "${measured.size}/${AppConfig.Outcome.MIN_MEASURED_CASES}")
                StatRow("نسبة الإصابة 24س", if (measured.isEmpty()) "—" else "${fmt(measured.count { (it.ret24h ?: 0.0) > 0 } * 100.0 / measured.size, 0)}%")
                StatRow("متوسط العائد الموقّع 24س", if (measured.isEmpty()) "—" else pctText(measured.mapNotNull { it.ret24h }.average()))
                Text("أوزان المحرك مقفلة حتى ${AppConfig.Engine.WEIGHTS_LOCKED_UNTIL_OOS_CASES} حالة مقاسة خارج العينة.", style = MaterialTheme.typography.labelSmall, color = m.warn)
                StatRow("حد القوة النسبية", "${fmt(cal.threshold * 100, 0)}%", hint = cal.note)
                TextButton(onClick = { vm.measureOutcomes() }) { Text("قِس النتائج المستحقة الآن") }
            }
        }
        item {
            SectionCard("قياس الرادار", subtitle = "نفس مجتمع آخر مسح · حجم 24س الحقيقي · إشارة لكل زوج مع تهدئة · block bootstrap") {
                Button(onClick = { vm.runRadar() }) { Text("أعد القياس") }
                val r = radar
                if (r == null) Text("لا قياس بعد. شغّل المسح ثم أعد القياس.", style = MaterialTheme.typography.bodySmall) else {
                    StatRow("السوق / المجتمع / الإشارات", "${r.market} / ${r.symbolsWithData} / ${r.totalSignals}")
                    StatRow("داخل العينة n", "${r.inSample.n} · ${pctText(r.inSample.meanPct)}")
                    StatRow("خارج العينة n", "${r.outOfSample.n} · ${pctText(r.outOfSample.meanPct)}")
                    StatRow("فترة 95% خارج العينة", "[${pctText(r.outOfSample.ciLowPct)}, ${pctText(r.outOfSample.ciHighPct)}]")
                    Text(r.verdict, style = MaterialTheme.typography.bodySmall, color = if (r.proven) m.up else m.warn)
                    Text(r.definition, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            SectionCard("قياسات تقنية (هذا الجهاز، هذه الجلسة)", subtitle = "زمن حدث Binance إلى الاستلام؛ يشمل فرق الساعة") {
                StatRow("فوري p50/p95/n", "${tech.spot.p50}ms / ${tech.spot.p95}ms / ${tech.spot.n}")
                StatRow("عقود p50/p95/n", "${tech.futures.p50}ms / ${tech.futures.p95}ms / ${tech.futures.n}")
                StatRow("سعر ← إشعار p50/p95/n", "${tech.alert.p50}ms / ${tech.alert.p95}ms / ${tech.alert.n}")
                StatRow("إعادات الاتصال فوري/عقود", "${tech.spotReconnects} / ${tech.futuresReconnects}")
                StatRow("الذاكرة heap/native", "${tech.heapMb}MB / ${tech.nativeMb}MB")
                StatRow("وزن REST المستخدم/دقيقة", "${tech.spotWeight} / ${tech.futuresWeight}")
                Text("البطارية: غير مقاسة داخل التطبيق.", style = MaterialTheme.typography.labelSmall)
            }
        }
        item { Text("سجل القرارات", style = MaterialTheme.typography.titleMedium) }
        if (decisions.isEmpty()) item { EmptyState(Icons.Default.History, "السجل فارغ", "تُسجّل لقطة عند كل دراسة وتنبيه ثم نتيجتها بعد 4 و24 ساعة.") }
        items(decisions.take(150), key = { "d${it.id}" }) { d ->
            SectionCard("${d.symbol} · ${d.kind}", subtitle = "${d.market.label} · ${dateTimeText(d.ts)}") {
                StatRow("السعر / الدرجة", "${priceText(d.price)} / ${d.score?.let { fmtSigned(it) } ?: "—"}")
                StatRow("بعد 4س", d.ret4h?.let { pctText(it) } ?: "لم تُقس", signColor(d.ret4h))
                StatRow("بعد 24س", d.ret24h?.let { pctText(it) } ?: "لم تُقس", signColor(d.ret24h))
                if (d.note.isNotBlank()) Text(d.note, style = MaterialTheme.typography.labelSmall)
            }
        }
        item { Disclaimer() }
    }
}

// ============================ الإعدادات ============================

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val monitor by vm.monitor.collectAsStateWithLifecycle()
    val backup by vm.backup.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var llmKey by remember { mutableStateOf("") }
    var tgToken by remember { mutableStateOf("") }
    var tgChat by remember { mutableStateOf("") }
    var endpoint by remember(s.llmEndpoint) { mutableStateOf(s.llmEndpoint) }
    var model by remember(s.llmModel) { mutableStateOf(s.llmModel) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.startMonitor() else vm.say("رُفض إذن الإشعارات؛ المراقبة الخلفية لن تبدأ بلا إشعار ظاهر") }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? -> uri?.let { vm.setBackupFolder(it) } }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? -> uri?.let { vm.exportJson(it) } }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let { vm.importJson(it) } }
    Column(Modifier.fillMaxSize().imePadding()) {
        Bar("الإعدادات", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = gap) {
            item {
                SectionCard("المصادر", subtitle = "Binance الرسمي فقط. Spot وUSDⓈ-M Futures منفصلان.") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("مصدر Spot البديل (binance.vision — بيانات سوق فقط)", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(s.spotDataOnly, { v -> vm.updateSettings { it.copy(spotDataOnly = v) } })
                    }
                    Text("Spot: ${if (s.spotDataOnly) AppConfig.Endpoints.SPOT_WS_DATA_ONLY else AppConfig.Endpoints.SPOT_WS}\nFutures: ${AppConfig.Endpoints.FUT_WS_MARKET} + ${AppConfig.Endpoints.FUT_WS_PUBLIC}\nCoinGlass وغيره: غير مفعّل؛ عبر API رسمي فقط دون كشط.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                SectionCard("المراقبة الخلفية", subtitle = if (monitor.running) "تعمل منذ ${dateTimeText(monitor.startedAt)}" else "متوقفة" + (monitor.stoppedReason?.let { " — $it" } ?: "")) {
                    Text("اختيارية، بإشعار دائم وزر إيقاف. قد يوقفها النظام أو Doze أو قيود الشركة المصنعة، ولا تُستأنف بعد Force Stop؛ عندها شغّلها يدويًا من هنا.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !monitor.running, onClick = {
                            if (Build.VERSION.SDK_INT >= 33 && !vm.canNotify()) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.startMonitor()
                        }) { Text("تشغيل") }
                        OutlinedButton(enabled = monitor.running || monitor.wanted, onClick = { vm.stopMonitor() }) { Text("إيقاف") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("محاولة التشغيل بعد إقلاع الجهاز (إن سمح النظام)", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(s.restartAfterBoot, { v -> vm.updateSettings { it.copy(restartAfterBoot = v) } })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("مسح دوري أثناء المراقبة", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(s.autoScan, { v -> vm.updateSettings { it.copy(autoScan = v) } })
                    }
                    Text("استثناء تحسين البطارية اختياري: يقلل احتمال إيقاف الخدمة ويزيد استهلاك البطارية.", style = MaterialTheme.typography.labelSmall)
                    TextButton(onClick = {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))) }
                            .onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
                    }) { Text("طلب الاستثناء") }
                }
            }
            item {
                SectionCard("التنبيهات") {
                    StatRow("اقتراب الهدف عند", "${fmt(s.alerts.nearTargetFraction * 100, 0)}% من المسافة")
                    Slider(s.alerts.nearTargetFraction.toFloat(), { v -> vm.updateSettings { it.copy(alerts = it.alerts.copy(nearTargetFraction = (v * 20).toInt() / 20.0)) } }, valueRange = 0.5f..0.95f)
                    StatRow("اقتراب الوقف عند", "${fmt(s.alerts.nearStopFraction * 100, 0)}%")
                    Slider(s.alerts.nearStopFraction.toFloat(), { v -> vm.updateSettings { it.copy(alerts = it.alerts.copy(nearStopFraction = (v * 20).toInt() / 20.0)) } }, valueRange = 0.5f..0.95f)
                    com.agon.app.domain.alerts.AlertType.entries.forEach { type ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(type.title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Switch(type in s.alerts.enabled, { on -> vm.updateSettings { it.copy(alerts = it.alerts.copy(enabled = if (on) it.alerts.enabled + type else it.alerts.enabled - type)) } })
                        }
                    }
                    TextButton(onClick = { vm.testNotification() }) { Text("إشعار تجريبي") }
                }
            }
            item {
                SectionCard("Telegram (قناة احتياطية اختيارية)", subtitle = if (vm.hasSecret(MainViewModel.SECRET_TG_TOKEN)) "الرمز محفوظ مشفرًا" else "غير مُعد") {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("تفعيل", Modifier.weight(1f)); Switch(s.telegramEnabled, { v -> vm.updateSettings { it.copy(telegramEnabled = v) } }) }
                    OutlinedTextField(tgToken, { tgToken = it }, Modifier.fillMaxWidth(), label = { Text("رمز البوت") }, singleLine = true)
                    OutlinedTextField(tgChat, { tgChat = it }, Modifier.fillMaxWidth(), label = { Text("معرّف المحادثة") }, singleLine = true)
                    Row {
                        TextButton(onClick = { if (tgToken.isNotBlank()) vm.setSecret(MainViewModel.SECRET_TG_TOKEN, tgToken); if (tgChat.isNotBlank()) vm.setSecret(MainViewModel.SECRET_TG_CHAT, tgChat); tgToken = ""; tgChat = "" }) { Text("حفظ") }
                        TextButton(onClick = { vm.testTelegram() }) { Text("اختبار") }
                        TextButton(onClick = { vm.setSecret(MainViewModel.SECRET_TG_TOKEN, null); vm.setSecret(MainViewModel.SECRET_TG_CHAT, null) }) { Text("حذف") }
                    }
                }
            }
            item {
                SectionCard("النموذج اللغوي (اختياري — فيتو مخاطر فقط)", subtitle = if (vm.hasSecret(MainViewModel.SECRET_LLM)) "المفتاح محفوظ مشفرًا" else "لا مفتاح") {
                    Text("المفتاح يُحفظ على جهازك مشفرًا بمفتاح Android Keystore ولا يُصدَّر. جهاز مخترق أو بصلاحيات root قد يكشفه؛ استخدم مفتاحًا محدود الإنفاق وقابلًا للإلغاء. النموذج بلا بحث حي قد لا يعرف الأخبار الحديثة.", style = MaterialTheme.typography.labelSmall)
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("تفعيل", Modifier.weight(1f)); Switch(s.llmEnabled, { v -> vm.updateSettings { it.copy(llmEnabled = v) } }) }
                    OutlinedTextField(endpoint, { endpoint = it }, Modifier.fillMaxWidth(), label = { Text("رابط chat/completions (https)") }, singleLine = true)
                    OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("اسم النموذج") }, singleLine = true)
                    OutlinedTextField(llmKey, { llmKey = it }, Modifier.fillMaxWidth(), label = { Text("مفتاح API") }, singleLine = true)
                    Row {
                        TextButton(onClick = { vm.updateSettings { it.copy(llmEndpoint = endpoint.trim(), llmModel = model.trim()) }; if (llmKey.isNotBlank()) { vm.setSecret(MainViewModel.SECRET_LLM, llmKey); llmKey = "" } }) { Text("حفظ") }
                        TextButton(onClick = { vm.setSecret(MainViewModel.SECRET_LLM, null) }) { Text("حذف المفتاح") }
                    }
                }
            }
            item {
                SectionCard("النسخ والتصدير والاستيراد", subtitle = backup.folderUri?.let { "المجلد محدد" } ?: "لم يُختر مجلد") {
                    if (backup.folderLost) Pill("فُقد إذن المجلد — اختره مجددًا", MaterialTheme.colorScheme.error, filled = true)
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("نسخ يومي (عند فتح التطبيق أو أثناء المراقبة)", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium); Switch(s.backupDaily, { v -> vm.updateSettings { it.copy(backupDaily = v) } }) }
                    StatRow("آخر نسخ", dateTimeText(backup.lastAt), hint = backup.lastResult.ifBlank { null })
                    Row {
                        TextButton(onClick = { pickFolder.launch(null) }) { Text("اختيار المجلد") }
                        TextButton(enabled = !backup.running, onClick = { vm.backupNow() }) { Text("انسخ الآن") }
                    }
                    Row {
                        TextButton(onClick = { exporter.launch("ghaith-export.json") }) { Text("تصدير JSON") }
                        TextButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("استيراد JSON") }
                    }
                    Text("الاستيراد يستبدل البيانات الحالية ذريًا. الأسرار لا تُصدَّر.", style = MaterialTheme.typography.labelSmall)
                }
            }
            item { SectionCard("حول") { Text("غيث التداول 0.1.0 · com.ghaith.app\nتطبيق شخصي للمراقبة والتحليل فقط: لا ينفّذ صفقات، لا مفاتيح تداول أو سحب، بلا إعلانات أو تتبع.", style = MaterialTheme.typography.bodySmall); Disclaimer() } }
        }
    }
}
