package com.agon.app.core

import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BinanceEndpoints
import com.agon.app.data.providers.BinanceParsers
import com.agon.app.data.providers.BinanceRest
import com.agon.app.data.providers.Kline
import com.agon.app.data.providers.LatencyStats
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.Ticker
import com.agon.app.data.providers.TickerHub
import com.agon.app.data.store.AppSettings
import com.agon.app.data.store.Store
import com.agon.app.domain.alerts.AlertEngine
import com.agon.app.domain.alerts.AlertEvent
import com.agon.app.domain.alerts.AlertType
import com.agon.app.domain.engine.StrengthAnalyzer
import com.agon.app.domain.engine.StrengthReport
import com.agon.app.domain.model.AlertRecord
import com.agon.app.domain.model.AlertStateRow
import com.agon.app.domain.model.DecisionRecord
import com.agon.app.domain.model.Trade
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.concurrent.ConcurrentHashMap

data class MonitorStats(
    val active: Boolean = false,
    val openTrades: Int = 0,
    val symbols: Int = 0,
    val lastTickAt: Long = 0L,
    val alertsFired: Int = 0,
    val duplicatesBlocked: Int = 0,
    val lastError: String? = null,
)

/**
 * يراقب الصفقات المفتوحة وقائمة المراقبة عبر تدفقات الرموز المختارة (لا استطلاع REST)،
 * يقيّم التنبيهات عند كل سعر ويحسب القوة عند إغلاق شمعة إطار الصفقة (x=true).
 * منع التكرار: إدراج ذري في alert_state قبل أي إشعار.
 */
class TradeMonitor(
    private val store: Store,
    private val hubs: Map<Market, TickerHub>,
    private val rest: BinanceRest,
    private val directory: SymbolDirectory,
    private val sink: AlertSink,
    private val telegram: TelegramNotifier,
    private val settings: StateFlow<AppSettings>,
    private val scope: CoroutineScope,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val owners = HashSet<String>()
    private var job: Job? = null
    @Volatile private var active = false
    @Volatile private var tradesByKey: Map<String, List<Trade>> = emptyMap()
    private val fired: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val series = ConcurrentHashMap<String, List<Kline>>()
    private val seriesJobs = ConcurrentHashMap<String, Job>()
    private val lastFunding = ConcurrentHashMap<Long, Double>()
    private val ticks = Channel<Ticker>(512, BufferOverflow.DROP_OLDEST)

    private val _reports = MutableStateFlow<Map<Long, StrengthReport>>(emptyMap())
    val reports: StateFlow<Map<Long, StrengthReport>> = _reports
    private val _stats = MutableStateFlow(MonitorStats())
    val stats: StateFlow<MonitorStats> = _stats

    /** زمن من استلام السعر إلى تسليم الإشعار للنظام (ms). */
    val alertLatency = LatencyStats(AppConfig.Metrics.LATENCY_SAMPLES)

    private fun key(market: Market, symbol: String) = "${market.id}:$symbol"
    private fun seriesKey(t: Trade) = "${t.id}:${t.frame.interval}"

    init {
        for ((market, hub) in hubs) {
            hub.addTickListener { t -> if (active && tradesByKey.containsKey(key(market, t.symbol))) ticks.trySend(t) }
            hub.conn.addListener { stream, data, _ ->
                if (active && stream.contains("@kline_") && data is JsonObject) onKline(market, stream, data)
            }
        }
    }

    fun start(owner: String) {
        synchronized(owners) {
            owners.add(owner)
            if (job?.isActive == true) return
            active = true
            job = scope.launch {
                fired.clear()
                runCatching { fired.addAll(store.alertStates().map { it.key }) }
                launch { store.changes.collectLatest { delay(150); runCatching { reload() }.onFailure { e -> if (e is CancellationException) throw e; err(e) } } }
                for (t in ticks) {
                    try {
                        onTick(t)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        err(e)
                    }
                }
            }
            _stats.update { it.copy(active = true) }
        }
    }

    fun stop(owner: String) {
        synchronized(owners) {
            owners.remove(owner)
            if (owners.isNotEmpty()) return
            active = false
            job?.cancel(); job = null
            seriesJobs.values.forEach { it.cancel() }
            seriesJobs.clear()
            for (hub in hubs.values) {
                hub.setSelected(OWNER, emptySet())
                hub.conn.setStreams(KLINE_OWNER, emptySet())
            }
            _stats.update { it.copy(active = false) }
        }
    }

    private fun err(e: Throwable) = _stats.update { it.copy(lastError = e.message ?: e.javaClass.simpleName) }

    private suspend fun reload() {
        val open = store.openTrades()
        val watch = store.watchlist()
        tradesByKey = open.groupBy { key(it.market, it.symbol) }
        var symbolCount = 0
        for ((market, hub) in hubs) {
            val syms = LinkedHashSet<String>()
            open.filter { it.market == market }.forEach { syms += it.symbol }
            watch.filter { it.market == market }.forEach { syms += it.symbol }
            // أزواج التحويل إلى USDT للأزواج غير المسعّرة بـUSDT (إن وُجد الزوج رسميًا).
            syms.toList().forEach { s ->
                val q = directory.quoteOf(market, s)
                if (q != null && q != "USDT" && directory.info(market, "${q}USDT") != null) syms += "${q}USDT"
            }
            symbolCount += syms.size
            hub.setSelected(OWNER, syms)
            hub.conn.setStreams(KLINE_OWNER, open.filter { it.market == market }.map { BinanceEndpoints.kline(it.symbol, it.frame.interval) }.toSet())
        }
        val liveKeys = open.map { seriesKey(it) }.toSet()
        series.keys.filter { it !in liveKeys }.forEach { series.remove(it) }
        val ids = open.map { it.id }.toSet()
        _reports.update { m -> m.filterKeys { it in ids } }
        for (t in open) {
            val sk = seriesKey(t)
            if (!series.containsKey(sk) && seriesJobs[sk]?.isActive != true) {
                seriesJobs[sk] = scope.launch { initSeries(t) }
            }
        }
        _stats.update { it.copy(openTrades = open.size, symbols = symbolCount) }
    }

    /** تهيئة المؤشرات مرة واحدة من REST؛ التحديث بعدها من WS عند الإغلاق فقط. */
    private suspend fun initSeries(t: Trade) {
        repeat(4) { attempt ->
            try {
                val k = rest.klines(t.market, t.symbol, t.frame.interval, AppConfig.Strength.KLINE_INIT_LIMIT).filter { it.closed }
                series[seriesKey(t)] = k
                evaluateStrength(t)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                err(e)
                delay(2_000L * (attempt + 1))
            }
        }
    }

    private fun onKline(market: Market, stream: String, data: JsonObject) {
        val (interval, k) = BinanceParsers.klineWs(data) ?: return
        if (!k.closed) return // التحليل عند الإغلاق الرسمي فقط
        val symbol = stream.substringBefore('@').uppercase()
        val list = tradesByKey[key(market, symbol)] ?: return
        for (t in list) {
            if (t.frame.interval != interval) continue
            val sk = seriesKey(t)
            val cur = series[sk] ?: continue
            if (cur.isNotEmpty() && k.openTime <= cur.last().openTime) continue
            series[sk] = (cur + k).takeLast(AppConfig.Strength.KLINE_INIT_LIMIT + 100)
            scope.launch { runCatching { evaluateStrength(t) }.onFailure { e -> if (e !is CancellationException) err(e) } }
        }
    }

    private suspend fun onTick(t: Ticker) {
        val list = tradesByKey[key(t.market, t.symbol)] ?: return
        _stats.update { it.copy(lastTickAt = t.fetchedAt) }
        val s = settings.value.alerts
        for (trade in list) {
            val ev = AlertEngine.evaluate(trade, t.close, fired, s)
            for (key in ev.rearm) {
                store.rearmAlert(key)
                fired.remove(key)
            }
            for (e in ev.fire) fire(trade, e, t.fetchedAt, notify = true, note = "")
        }
    }

    private suspend fun fire(trade: Trade, e: AlertEvent, receivedAt: Long, notify: Boolean, note: String) {
        val now = clock()
        // إدراج ذري: إن كان المفتاح موجودًا (أُطلق سابقًا ولو في عملية سابقة) لا إشعار.
        val inserted = store.tryFireAlert(AlertStateRow(e.key, trade.id, e.type.name, e.detail, now, e.value))
        fired.add(e.key)
        if (!inserted) {
            _stats.update { it.copy(duplicatesBlocked = it.duplicatesBlocked + 1) }
            return
        }
        deliver(trade, e, receivedAt, notify, note)
    }

    private suspend fun deliver(trade: Trade, e: AlertEvent, receivedAt: Long, notify: Boolean, note: String) {
        val now = clock()
        val delivered = notify && sink.alert(e.key, e.title, e.body, e.type.critical)
        if (delivered) alertLatency.add(clock() - receivedAt)
        store.logAlert(AlertRecord(0, now, trade.id, trade.symbol, trade.market, e.type.name, e.title, e.body + if (note.isNotEmpty()) " — $note" else "", e.price, e.type.critical, delivered))
        store.insertDecision(
            DecisionRecord(
                ts = now, kind = "alert:${e.type.name}", refId = trade.id, symbol = trade.symbol, market = trade.market,
                direction = trade.direction.sign, score = e.value, price = e.price, funding = lastFunding[trade.id],
                snapshot = buildJsonObject {
                    put("entry", trade.entry); put("target", trade.target); put("stop", trade.stop); put("leverage", trade.leverage)
                    put("value", e.value); put("detail", e.detail)
                    _reports.value[trade.id]?.let { r ->
                        put("strength", r.state.name)
                        put("signals", buildJsonArray { r.reasons.forEach { s -> add(buildJsonObject { put("key", s.key); put("value", s.value) }) } })
                    }
                }.toString(),
                note = note,
            ),
        )
        _stats.update { it.copy(alertsFired = it.alertsFired + 1) }
        if (notify && settings.value.telegramEnabled && telegram.configured()) {
            scope.launch { telegram.send("${e.title}\n${e.body}\n\n${AppConfig.DISCLAIMER}") }
        }
    }

    private suspend fun evaluateStrength(t: Trade) {
        val k = series[seriesKey(t)] ?: return
        val funding = if (t.market == Market.FUTURES) runCatching { rest.premiumIndex(t.symbol).fundingRate }.getOrNull() else null
        if (funding != null) lastFunding[t.id] = funding
        val now = clock()
        val report = StrengthAnalyzer.evaluate(t.direction, k, funding, t.frame.interval, now)
        _reports.update { it + (t.id to report) }
        val stateKey = AlertEngine.key(t.id, AlertType.STRENGTH_CHANGED)
        val previous = store.alertState(stateKey)?.detail
        val hub = hubs.getValue(t.market)
        val price = hub.get(t.symbol)?.close ?: k.lastOrNull()?.close ?: return
        val event = AlertEngine.strengthChange(t, previous, report, price, settings.value.alerts) ?: return
        store.upsertAlertState(AlertStateRow(stateKey, t.id, AlertType.STRENGTH_CHANGED.name, report.state.name, now, report.state.ordinal.toDouble()))
        if (previous == null) return // أول قراءة = خط أساس لا «تغير»
        // حد التنبيه 4.5M: حجم التسعير 24س بـUSDT. تحت الحد يُسجّل التغير دون إشعار.
        val ticker = hub.get(t.symbol)
        val factor = directory.usdtFactor(t.market, t.symbol, hub)
        val volUsdt = if (ticker != null && factor != null) ticker.quoteVolume * factor else null
        val liquid = volUsdt != null && volUsdt >= AppConfig.Liquidity.ALERT_MIN_QUOTE_VOLUME_24H_USDT
        val note = when {
            volUsdt == null -> "لم يُرسل إشعار: تعذر تقويم حجم 24س بـUSDT"
            !liquid -> "لم يُرسل إشعار: حجم 24س تحت حد التنبيه 4.5M USDT"
            else -> ""
        }
        deliver(t, event, now, notify = liquid, note = note)
    }

    companion object {
        const val OWNER = "monitor"
        const val KLINE_OWNER = "trade-klines"
    }
}
