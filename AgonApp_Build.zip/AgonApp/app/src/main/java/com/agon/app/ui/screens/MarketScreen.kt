package com.agon.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.SeedState
import com.agon.app.ui.MainViewModel
import com.agon.app.ui.MarketRow
import com.agon.app.ui.MarketSort
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.ErrorState
import com.agon.app.ui.components.FeedStatusRow
import com.agon.app.ui.components.LoadingState
import com.agon.app.ui.components.Num
import com.agon.app.ui.components.Pill
import com.agon.app.ui.components.SegmentRow
import com.agon.app.ui.components.pctText
import com.agon.app.ui.components.priceText
import com.agon.app.ui.components.signColor
import com.agon.app.ui.components.volText
import com.agon.app.ui.theme.LocalMarketColors
import kotlinx.coroutines.delay

/** ساعة تتحدث كل ثانية لعرض «قبل X» وحالات التقادم. */
@Composable
fun rememberNow(): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) {
        delay(1_000)
        value = System.currentTimeMillis()
    }
}

@Composable
fun MarketScreen(vm: MainViewModel, onOpen: (Market, String) -> Unit) {
    val ui by vm.marketUi.collectAsStateWithLifecycle()
    val market by vm.market.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()
    val usdtOnly by vm.usdtOnly.collectAsStateWithLifecycle()
    val watch by vm.watchlist.collectAsStateWithLifecycle()
    val now by rememberNow()
    val focus = LocalFocusManager.current

    // الاشتراك في !miniTicker@arr فقط والشاشة ظاهرة؛ يُلغى عند المغادرة أو ذهاب التطبيق للخلفية.
    LifecycleStartEffect(market) {
        vm.marketVisible(market, true)
        onStopOrDispose { vm.marketVisible(market, false) }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SegmentRow(Market.entries.toList(), market, { it.label }, { vm.market.value = it })
            OutlinedTextField(
                value = query, onValueChange = { vm.query.value = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("ابحث عن زوج، مثل BTC") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { vm.query.value = "" }) { Icon(Icons.Default.Close, "مسح") } },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                shape = MaterialTheme.shapes.medium,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = usdtOnly, onClick = { vm.usdtOnly.value = !usdtOnly }, label = { Text("USDT فقط") })
                SegmentRow(MarketSort.entries.toList(), sort, { it.label }, { vm.sort.value = it }, Modifier.weight(1f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                FeedStatusRow(ui.status, now, Modifier.weight(1f))
                Num("${ui.rows.size}/${ui.total}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        val seed = ui.status.seed
        when {
            ui.market != market || (ui.total == 0 && (seed is SeedState.Loading || seed is SeedState.Idle)) -> LoadingState("جارٍ تجهيز القائمة الرسمية من Binance (${market.label})…")
            ui.total == 0 && seed is SeedState.Error -> ErrorState(
                "${seed.message}\nإن كان المصدر محجوبًا في منطقتك جرّب مصدر Spot البديل من الإعدادات > المصادر.",
                onRetry = { vm.retrySeed(market) },
            )
            ui.rows.isEmpty() -> EmptyState(Icons.Default.Search, "لا نتائج", if (query.isNotEmpty()) "لا يوجد زوج يطابق «$query». جرّب إلغاء «USDT فقط»." else "لا أزواج متاحة بهذا الفلتر.")
            else -> {
                val watched = watch.filter { it.market == market }.map { it.symbol }.toSet()
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(ui.rows, key = { it.symbol }) { row ->
                        MarketRowItem(row, row.symbol in watched, onClick = { onOpen(market, row.symbol) }, onStar = { vm.toggleWatch(row.symbol, market) })
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}

@Composable
private fun MarketRowItem(row: MarketRow, watched: Boolean, onClick: () -> Unit, onStar: () -> Unit) {
    val m = LocalMarketColors.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).alpha(if (row.stale) 0.55f else 1f).padding(start = 4.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onStar) {
            Icon(if (watched) Icons.Default.Star else Icons.Default.StarBorder, if (watched) "إزالة من المراقبة" else "إضافة للمراقبة", tint = if (watched) m.warn else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Num(row.symbol, style = MaterialTheme.typography.titleSmall, weight = FontWeight.SemiBold)
                if (row.stale) Pill("قديم", m.warn)
            }
            Text(
                if (row.volUsdt != null) "حجم 24س ${volText(row.volUsdt)} USDT" else "حجم 24س ${volText(row.quoteVolume)} (بعملة التسعير؛ لا تحويل)",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Num(priceText(row.price), style = MaterialTheme.typography.titleSmall, weight = FontWeight.Medium, mono = true)
            Num(pctText(row.changePct), style = MaterialTheme.typography.labelMedium, color = signColor(row.changePct))
        }
    }
}
