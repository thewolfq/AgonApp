package com.agon.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.GhaithApp
import com.agon.app.config.AppConfig
import com.agon.app.core.AppContainer
import com.agon.app.data.providers.FeedStatus
import com.agon.app.data.providers.LatencyStats
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.SeedState
import com.agon.app.data.providers.SymbolInfo
import com.agon.app.data.providers.Ticker
import com.agon.app.data.providers.TickerHub
import com.agon.app.data.store.AppSettings
import com.agon.app.data.store.BackupResult
import com.agon.app.data.store.SecureStore
import com.agon.app.domain.engine.Scanner
import com.agon.app.domain.model.AlertRecord
import com.agon.app.domain.model.DecisionRecord
import com.agon.app.domain.model.MarketEvent
import com.agon.app.domain.model.SavedLevel
import com.agon.app.domain.model.StudyCard
import com.agon.app.domain.model.Trade
import com.agon.app.domain.model.TradeStatus
import com.agon.app.domain.model.WatchItem
import com.agon.app.domain.model.WatchTag
import com.agon.app.platform.background.Notifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MarketSort(val label: String) {
    VOLUME("الحجم"), CHANGE_UP("الأكثر صعودًا"), CHANGE_DOWN("الأكثر هبوطًا"), PRICE("السعر"), NAME("الاسم")
}

data class MarketRow(
    val symbol: String,
    val price: Double,
    val changePct: Double,
    val quoteVolume: Double,
    /** حجم التسعير 24س بـUSDT؛ null = لا تحويل متاح. */
    val volUsdt: Double?,
    val stale: Boolean,
    val fetchedAt: Long,
)

data class MarketUi(
    val market: Market = Market.SPOT,
    val status: FeedStatus = FeedStatus(Market.SPOT),
    val rows: List<MarketRow> = emptyList(),
    val total: Int = 0,
)

private data class MarketParams(val market: Market, val query: String, val sort: MarketSort, val usdtOnly: Boolean)

data class OfficialEvent(val ts: Long, val symbol: String, val title: String, val kind: String, val source: String)

data class OfficialEventsUi(val loading: Boolean = false, val error: String? = null, val items: List<OfficialEvent> = emptyList(), val loadedAt: Long = 0L)

data class SymbolSearchUi(val loading: Boolean = false, val error: String? = null, val results: List<SymbolInfo> = emptyList())

data class TechMetrics(
    val spot: LatencyStats.Summary, val futures: LatencyStats.Summary, val alert: LatencyStats.Summary,
    val spotReconnects: Int, val futuresReconnects: Int, val heapMb: Long, val nativeMb: Long,
    val spotWeight: Int, val futuresWeight: Int,
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    val c: AppContainer = (app as GhaithApp).container

    val settings: StateFlow<AppSettings> = c.settingsRepo.settings
    val monitor = c.monitor.state
    val monitorStats = c.tradeMonitor.stats
    val strength = c.tradeMonitor.reports
    val scan = c.studies.state
    val radar = c.studies.radar
    val calibration = c.studies.calibration
    val backup = c.backup.status
    val online = c.network.online

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages
    fun say(text: String) { _messages.tryEmit(text) }

    // ---------------- السوق ----------------
    val market = MutableStateFlow(Market.SPOT)
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(MarketSort.VOLUME)
    val usdtOnly = MutableStateFlow(true)

    val marketUi: StateFlow<MarketUi> = combine(market, query, sort, usdtOnly) { m, q, s, u -> MarketParams(m, q.trim().uppercase(), s, u) }
        .flatMapLatest { p ->
            val hub = c.hub(p.market)
            combine(hub.version, hub.status) { _, st -> buildMarket(p, hub, st) }
        }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(2_000), MarketUi())

    private fun buildMarket(p: MarketParams, hub: TickerHub, status: FeedStatus): MarketUi {
        val all = hub.snapshot()
        val infos = c.directory.cached(p.market)
        val filtered = all.filter { t ->
            (p.query.isNotEmpty() || t.quoteVolume > 0) &&
                (infos == null || infos[t.symbol]?.trading != false) &&
                (!p.usdtOnly || t.symbol.endsWith("USDT")) &&
                (p.query.isEmpty() || t.symbol.contains(p.query))
        }
        val rows = filtered.map { t ->
            val factor = if (t.symbol.endsWith("USDT")) 1.0 else c.directory.quoteOf(p.market, t.symbol)?.let { q -> Scanner.usdtFactor(q) { s -> hub.get(s)?.close } }
            MarketRow(t.symbol, t.close, t.changePct, t.quoteVolume, factor?.let { t.quoteVolume * it }, t.stale, t.fetchedAt)
        }
        val sorted = when (p.sort) {
            MarketSort.VOLUME -> rows.sortedByDescending { it.volUsdt ?: -1.0 }
            MarketSort.CHANGE_UP -> rows.sortedByDescending { it.changePct }
            MarketSort.CHANGE_DOWN -> rows.sortedBy { it.changePct }
            MarketSort.PRICE -> rows.sortedByDescending { it.price }
            MarketSort.NAME -> rows.sortedBy { it.symbol }
        }
        return MarketUi(p.market, status, sorted, all.size)
    }

    fun marketVisible(m: Market, visible: Boolean) {
        if (visible) {
            c.hub(m).acquireAll(MARKET_OWNER)
            // دليل الرموز لتحويل الحجم وتصفية غير المتداول؛ الفشل هنا لا يمنع عرض الأسعار.
            viewModelScope.launch { runCatching { c.directory.ensure(m) } }
        } else c.hub(m).releaseAll(MARKET_OWNER)
    }

    fun retrySeed(m: Market) = viewModelScope.launch { c.hub(m).seed(force = true) }

    // ---------------- قوائم SQLite ----------------
    private fun <T> dbFlow(initial: T, load: suspend () -> T): StateFlow<T> =
        c.store.changes.mapLatest { runCatching { load() }.getOrDefault(initial) }.stateIn(viewModelScope, SharingStarted.Eagerly, initial)

    val watchlist: StateFlow<List<WatchItem>> = dbFlow(emptyList()) { c.store.watchlist() }
    val trades: StateFlow<List<Trade>> = dbFlow(emptyList()) { c.store.trades() }
    val alertLog: StateFlow<List<AlertRecord>> = dbFlow(emptyList()) { c.store.alertLog() }
    val studies: StateFlow<List<StudyCard>> = dbFlow(emptyList()) { c.store.studies() }
    val decisions: StateFlow<List<DecisionRecord>> = dbFlow(emptyList()) { c.store.decisions() }
    val events: StateFlow<List<MarketEvent>> = dbFlow(emptyList()) { c.store.events() }
    val levels: StateFlow<List<SavedLevel>> = dbFlow(emptyList()) { c.store.levels() }
    private val _dbReady = MutableStateFlow(false)
    val dbReady: StateFlow<Boolean> = _dbReady

    /** نبضة أسعار لإعادة رسم القوائم التي تقرأ من cache المراكز. */
    val priceTick: StateFlow<Long> = combine(c.hub(Market.SPOT).version, c.hub(Market.FUTURES).version) { a, b -> a + b }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(2_000), 0L)

    fun ticker(market: Market, symbol: String): Ticker? = c.hub(market).get(symbol)
    fun feed(market: Market): StateFlow<FeedStatus> = c.hub(market).status
    fun volUsdt(market: Market, symbol: String): Double? {
        val t = ticker(market, symbol) ?: return null
        val f = c.directory.usdtFactor(market, symbol, c.hub(market)) ?: return null
        return t.quoteVolume * f
    }

    init {
        viewModelScope.launch {
            runCatching { c.store.watchlist() }
            _dbReady.value = true
        }
    }

    // ---------------- المراقبة ----------------
    fun toggleWatch(symbol: String, market: Market) = viewModelScope.launch {
        val existing = watchlist.value.firstOrNull { it.symbol == symbol && it.market == market }
        if (existing != null) {
            c.store.removeWatch(listOf(existing.id)); say("أُزيل $symbol من المراقبة")
        } else {
            c.store.addWatch(symbol, market, WatchTag.WATCH, System.currentTimeMillis()); say("أُضيف $symbol (${market.label}) إلى المراقبة")
        }
    }

    fun addWatch(symbol: String, market: Market, tag: WatchTag) = viewModelScope.launch {
        val added = c.store.addWatch(symbol, market, tag, System.currentTimeMillis())
        say(if (added) "أُضيف $symbol (${market.label})" else "$symbol موجود مسبقًا")
    }

    fun removeWatch(ids: Collection<Long>) = viewModelScope.launch { c.store.removeWatch(ids); say("حُذف ${ids.size} من المراقبة") }
    fun setWatchTag(id: Long, tag: WatchTag) = viewModelScope.launch { c.store.setWatchTag(id, tag) }
    fun reorderWatch(ids: List<Long>) = viewModelScope.launch { c.store.reorderWatch(ids) }

    private val _search = MutableStateFlow(SymbolSearchUi())
    val search: StateFlow<SymbolSearchUi> = _search

    /** بحث في كل أزواج Binance المتداولة (السوقين) من exchangeInfo الرسمي. */
    fun searchSymbols(text: String) = viewModelScope.launch {
        val q = text.trim().uppercase()
        if (q.isEmpty()) { _search.value = SymbolSearchUi(); return@launch }
        _search.value = _search.value.copy(loading = true, error = null)
        val out = ArrayList<SymbolInfo>()
        var error: String? = null
        for (m in Market.entries) {
            try {
                out += c.directory.ensure(m).values.filter { it.trading && it.symbol.contains(q) && (m == Market.SPOT || it.contractType == null || it.contractType == "PERPETUAL") }
            } catch (e: Exception) {
                error = "${m.label}: ${e.message ?: e.javaClass.simpleName}"
            }
        }
        val ranked = out.sortedWith(compareBy<SymbolInfo>({ !it.symbol.startsWith(q) }, { it.symbol.length }, { it.symbol }, { it.market.ordinal })).take(60)
        _search.value = SymbolSearchUi(false, error, ranked)
    }

    // ---------------- الصفقات ----------------
    fun saveTrade(t: Trade, onDone: () -> Unit) = viewModelScope.launch {
        runCatching { c.store.saveTrade(if (t.openedAt == 0L) t.copy(openedAt = System.currentTimeMillis()) else t) }
            .onSuccess { say(if (t.id == 0L) "حُفظت الصفقة" else "حُدّثت الصفقة"); onDone() }
            .onFailure { say("تعذر الحفظ: ${it.message}") }
    }

    fun closeTrade(t: Trade, reason: String) = viewModelScope.launch {
        val price = ticker(t.market, t.symbol)?.takeIf { !it.stale }?.close
        c.store.closeTrade(t.id, price, reason, System.currentTimeMillis())
        say("أُغلقت ${t.symbol}" + (price?.let { " عند ${com.agon.app.domain.engine.fmtPrice(it)}" } ?: " (بلا سعر حي)"))
    }

    fun deleteTrade(id: Long) = viewModelScope.launch { c.store.deleteTrade(id); say("حُذفت الصفقة") }
    fun clearAlertLog() = viewModelScope.launch { c.store.clearAlertLog() }
    fun openTradesCount(): Int = trades.value.count { it.status == TradeStatus.OPEN }

    // ---------------- المراقبة الخلفية ----------------
    fun canNotify(): Boolean = c.notifier.canNotify()

    fun startMonitor(): Boolean {
        if (!c.notifier.canNotify()) {
            say("فعّل الإشعارات أولًا: المراقبة الخلفية تتطلب إشعارًا دائمًا ظاهرًا")
            return false
        }
        val err = c.monitor.requestStart()
        say(err ?: "بدأت المراقبة الخلفية")
        return err == null
    }

    fun stopMonitor() { c.monitor.requestStop(); say("أُوقفت المراقبة الخلفية") }

    fun testNotification() {
        val ok = c.notifier.alert("test", "إشعار تجريبي — غيث التداول", "هكذا ستظهر تنبيهات صفقاتك.", false)
        say(if (ok) "أُرسل إشعار تجريبي" else "الإشعارات غير مفعّلة لهذا التطبيق")
    }

    // ---------------- الدراسات والدليل ----------------
    fun runScan(m: Market) = c.studies.launchScan(m)

    fun runRadar() = viewModelScope.launch {
        c.studies.runRadar().onSuccess { say("أُعيد قياس الرادار: ${it.totalSignals} إشارة") }.onFailure { say(it.message ?: "تعذر القياس") }
    }

    fun measureOutcomes() = viewModelScope.launch {
        val n = runCatching { c.outcomes.runOnce() }.getOrDefault(0)
        c.studies.refreshCalibration()
        say(if (n > 0) "قيست $n نتيجة" else "لا نتائج مستحقة الآن (تُقاس بعد 4 و24 ساعة)")
    }

    fun deleteStudy(id: Long) = viewModelScope.launch { c.store.deleteStudy(id) }
    fun decodeStudy(card: StudyCard) = c.studies.decodePayload(card.payload)
    fun decodeVerdict(card: StudyCard) = card.llm?.let { c.llm.decode(it) }

    fun addEvent(e: MarketEvent) = viewModelScope.launch { c.store.insertEvent(e.copy(createdAt = System.currentTimeMillis())); say("أُضيف الحدث") }
    fun deleteEvent(id: Long) = viewModelScope.launch { c.store.deleteEvent(id) }
    fun saveLevel(l: SavedLevel) = viewModelScope.launch { c.store.insertLevel(l.copy(createdAt = System.currentTimeMillis())); say("حُفظ المستوى") }
    fun deleteLevel(id: Long) = viewModelScope.launch { c.store.deleteLevel(id) }

    private val _official = MutableStateFlow(OfficialEventsUi())
    val official: StateFlow<OfficialEventsUi> = _official

    /**
     * أحداث من مصادر Binance الرسمية فقط: مواعيد التمويل القادمة (premiumIndex) لرموز العقود في المراقبة/الصفقات،
     * وإدراجات/تسويات العقود المجدولة (onboardDate/deliveryDate في exchangeInfo). لا كشط صفحات إعلانات.
     */
    fun loadOfficialEvents() = viewModelScope.launch {
        _official.value = _official.value.copy(loading = true, error = null)
        val now = System.currentTimeMillis()
        val out = ArrayList<OfficialEvent>()
        var error: String? = null
        try {
            val infos = c.directory.ensure(Market.FUTURES, force = now - c.directory.loadedAt(Market.FUTURES) > 30 * 60_000L)
            for (i in infos.values) {
                if (i.contractType != "PERPETUAL") continue
                val onboard = i.onboardDate ?: 0L
                if (onboard in (now - 14 * 86_400_000L)..(now + 60 * 86_400_000L)) {
                    out += OfficialEvent(onboard, i.symbol, if (onboard > now) "إدراج عقد دائم مجدول" else "إدراج عقد دائم حديث", "listing", "fapi exchangeInfo.onboardDate")
                }
                val delivery = i.deliveryDate ?: 0L
                if (delivery in now..(now + 365 * 86_400_000L)) {
                    out += OfficialEvent(delivery, i.symbol, "تسوية/شطب عقد دائم مجدول", "delisting", "fapi exchangeInfo.deliveryDate")
                }
            }
            val futSymbols = (watchlist.value.filter { it.market == Market.FUTURES }.map { it.symbol } +
                trades.value.filter { it.market == Market.FUTURES && it.status == TradeStatus.OPEN }.map { it.symbol }).distinct().take(12)
            for (s in futSymbols) {
                runCatching { c.rest.premiumIndex(s) }.getOrNull()?.let { m ->
                    if (m.nextFundingTime > now) out += OfficialEvent(m.nextFundingTime, s, "تمويل قادم بمعدل ${com.agon.app.domain.engine.fmtSigned(m.fundingRate * 100, 4)}%", "funding", "fapi premiumIndex")
                }
            }
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
        }
        _official.value = OfficialEventsUi(false, error, out.sortedBy { it.ts }, now)
    }

    // ---------------- الإعدادات ----------------
    fun updateSettings(transform: (AppSettings) -> AppSettings) = viewModelScope.launch {
        val before = settings.value
        c.settingsRepo.update(transform)
        val after = settings.value
        if (before.spotDataOnly != after.spotDataOnly) c.onSourcesChanged()
        if (before.restartAfterBoot != after.restartAfterBoot) c.monitor.prefs.restartAfterBoot = after.restartAfterBoot
    }

    fun hasSecret(name: String): Boolean = c.secure.has(name)

    fun setSecret(name: String, value: String?) {
        val ok = c.secure.put(name, value)
        say(if (!ok) "تعذر التشفير؛ لم يُحفظ شيء" else if (value.isNullOrBlank()) "حُذف المفتاح من الجهاز" else "حُفظ مشفرًا على الجهاز")
    }

    fun testTelegram() = viewModelScope.launch {
        c.telegram.send("غيث التداول: رسالة تجريبية من القناة الاحتياطية.")
            .onSuccess { say("أُرسلت رسالة Telegram التجريبية") }.onFailure { say(it.message ?: "فشل Telegram") }
    }

    fun setBackupFolder(uri: Uri) = viewModelScope.launch { c.backup.setFolder(uri); say("تم اختيار مجلد النسخ") }
    fun clearBackupFolder() = viewModelScope.launch { c.backup.clearFolder() }

    fun backupNow() = viewModelScope.launch {
        when (val r = c.backup.runBackup()) {
            is BackupResult.Ok -> say("تم النسخ: ${r.files.size} ملف" + if (!r.dbCopied) " (JSON فقط)" else "")
            BackupResult.NoFolder -> say("اختر مجلد النسخ أولًا")
            BackupResult.FolderLost -> say("فُقد إذن المجلد — اختره مجددًا")
            is BackupResult.Failed -> say("فشل النسخ: ${r.message}")
        }
    }

    fun exportJson(uri: Uri) = viewModelScope.launch {
        c.backup.exportJson(uri).onSuccess { say("تم التصدير (${it / 1024 + 1} ك.ب)") }.onFailure { say("فشل التصدير: ${it.message}") }
    }

    fun importJson(uri: Uri) = viewModelScope.launch {
        c.backup.importJson(uri).onSuccess {
            c.settingsRepo.load()
            say("تم الاستيراد: ${it.trades.size} صفقة، ${it.watchlist.size} مراقبة، ${it.decisions.size} قرار")
        }.onFailure { say("فشل الاستيراد (لم يتغير شيء): ${it.message}") }
    }

    fun techMetrics(): TechMetrics {
        val rt = Runtime.getRuntime()
        return TechMetrics(
            c.hub(Market.SPOT).latency.summary(), c.hub(Market.FUTURES).latency.summary(), c.tradeMonitor.alertLatency.summary(),
            c.hub(Market.SPOT).status.value.ws.reconnects, c.hub(Market.FUTURES).status.value.ws.reconnects,
            (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024), android.os.Debug.getNativeHeapAllocatedSize() / (1024 * 1024),
            c.rest.limiter.usedWeight1m[Market.SPOT] ?: 0, c.rest.limiter.usedWeight1m[Market.FUTURES] ?: 0,
        )
    }

    fun seedState(m: Market): SeedState = c.hub(m).status.value.seed

    companion object {
        const val MARKET_OWNER = "market-ui"
        val SECRET_LLM = SecureStore.LLM_KEY
        val SECRET_TG_TOKEN = SecureStore.TELEGRAM_TOKEN
        val SECRET_TG_CHAT = SecureStore.TELEGRAM_CHAT
        val NOTIF_TEST_ID = Notifier.TEST_ID
        val UNPROVEN = AppConfig.UNPROVEN
    }
}
