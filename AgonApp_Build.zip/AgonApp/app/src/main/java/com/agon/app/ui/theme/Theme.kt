package com.agon.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = RainTeal, onPrimary = Color(0xFF00201C), primaryContainer = Color(0xFF0E4A44), onPrimaryContainer = Color(0xFFB4F3EA),
    secondary = SkyBlue, onSecondary = Color(0xFF00264A), secondaryContainer = Color(0xFF123A5C), onSecondaryContainer = Color(0xFFD2E8FF),
    tertiary = Amber, onTertiary = Color(0xFF2E1F00), tertiaryContainer = Color(0xFF4A3608), onTertiaryContainer = Color(0xFFFFE3A6),
    background = Night0, onBackground = NightText, surface = Night1, onSurface = NightText,
    surfaceVariant = Night2, onSurfaceVariant = NightTextDim, surfaceContainer = Night1, surfaceContainerHigh = Night2,
    surfaceContainerHighest = Night3, surfaceContainerLow = Night1, surfaceContainerLowest = Night0,
    outline = NightOutline, outlineVariant = Night3,
    error = Color(0xFFFF6B6B), onError = Color(0xFF3A0006), errorContainer = Color(0xFF5C1118), onErrorContainer = Color(0xFFFFD9DC),
)

private val LightColorScheme = lightColorScheme(
    primary = RainTealDark, onPrimary = Color.White, primaryContainer = Color(0xFFB9ECE5), onPrimaryContainer = Color(0xFF00201C),
    secondary = SkyBlueDark, onSecondary = Color.White, secondaryContainer = Color(0xFFD4E6FB), onSecondaryContainer = Color(0xFF051D3A),
    tertiary = AmberDark, onTertiary = Color.White, tertiaryContainer = Color(0xFFFFE2B0), onTertiaryContainer = Color(0xFF2E1B00),
    background = Day0, onBackground = DayText, surface = Day1, onSurface = DayText,
    surfaceVariant = Day2, onSurfaceVariant = DayTextDim, surfaceContainer = Day1, surfaceContainerHigh = Day2,
    surfaceContainerHighest = Color(0xFFD9E4E7), surfaceContainerLow = Day1, surfaceContainerLowest = Color.White,
    outline = DayOutline, outlineVariant = Day2,
    error = Color(0xFFC62828), onError = Color.White, errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
)

/** ألوان دلالية للسوق خارج مخطط Material. */
data class MarketColors(val up: Color, val down: Color, val warn: Color)

val LocalMarketColors = staticCompositionLocalOf { MarketColors(UpDark, DownDark, Amber) }

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp), extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun AgonAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme
    val market = if (darkTheme) MarketColors(UpDark, DownDark, Amber) else MarketColors(UpLight, DownLight, AmberDark)
    CompositionLocalProvider(LocalMarketColors provides market) {
        MaterialTheme(colorScheme = colors, shapes = AppShapes, content = content)
    }
}
