package com.agon.app.data.store

data class Migration(val version: Int, val name: String, val statements: List<String>)

/**
 * Migrations مرقمة ومتتالية. كل إصدار يُطبّق داخل معاملة واحدة (SQLiteOpenHelper).
 * لا تُعدّل migration منشورة؛ أضف رقمًا جديدًا. لا جداول للأسعار أو الشموع عمدًا.
 */
object Migrations {
    private val M1 = Migration(
        1, "base schema",
        listOf(
            """CREATE TABLE watchlist(
                id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, market TEXT NOT NULL,
                tag TEXT NOT NULL DEFAULT 'WATCH', position INTEGER NOT NULL DEFAULT 0, added_at INTEGER NOT NULL,
                UNIQUE(symbol, market))""",
            """CREATE TABLE trades(
                id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, market TEXT NOT NULL,
                direction TEXT NOT NULL, frame TEXT NOT NULL, entry REAL NOT NULL, leverage REAL NOT NULL DEFAULT 1,
                target REAL NOT NULL, stop REAL NOT NULL, size REAL NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '',
                liq_manual REAL, status TEXT NOT NULL DEFAULT 'OPEN', opened_at INTEGER NOT NULL,
                closed_at INTEGER, close_price REAL, close_reason TEXT)""",
            """CREATE TABLE alert_state(
                key TEXT PRIMARY KEY NOT NULL, trade_id INTEGER NOT NULL, type TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT '', fired_at INTEGER NOT NULL, value REAL NOT NULL DEFAULT 0)""",
            """CREATE TABLE alert_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, trade_id INTEGER NOT NULL,
                symbol TEXT NOT NULL, market TEXT NOT NULL, type TEXT NOT NULL, title TEXT NOT NULL,
                body TEXT NOT NULL, price REAL NOT NULL, critical INTEGER NOT NULL DEFAULT 0, delivered INTEGER NOT NULL DEFAULT 1)""",
            """CREATE TABLE studies(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, scan_id INTEGER NOT NULL,
                symbol TEXT NOT NULL, market TEXT NOT NULL, rank INTEGER NOT NULL, score REAL NOT NULL,
                bias TEXT NOT NULL, price REAL NOT NULL, payload TEXT NOT NULL, llm TEXT)""",
            """CREATE TABLE decision_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, kind TEXT NOT NULL, ref_id INTEGER NOT NULL DEFAULT 0,
                symbol TEXT NOT NULL, market TEXT NOT NULL, direction INTEGER NOT NULL DEFAULT 0, score REAL,
                price REAL NOT NULL, funding REAL, open_interest REAL, snapshot TEXT NOT NULL DEFAULT '{}',
                price_4h REAL, ret_4h REAL, price_24h REAL, ret_24h REAL, note TEXT NOT NULL DEFAULT '')""",
            """CREATE TABLE kv(key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)""",
            "CREATE INDEX idx_trades_status ON trades(status)",
            "CREATE INDEX idx_alert_state_trade ON alert_state(trade_id)",
        ),
    )

    private val M2 = Migration(
        2, "events, saved levels, log indexes",
        listOf(
            """CREATE TABLE events(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, symbol TEXT NOT NULL DEFAULT '',
                title TEXT NOT NULL, kind TEXT NOT NULL, source TEXT NOT NULL, evidence TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL)""",
            """CREATE TABLE levels(
                id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, market TEXT NOT NULL,
                price REAL NOT NULL, kind TEXT NOT NULL, reason TEXT NOT NULL, created_at INTEGER NOT NULL)""",
            "CREATE INDEX idx_decision_ts ON decision_log(ts)",
            "CREATE INDEX idx_alert_log_ts ON alert_log(ts)",
            "CREATE INDEX idx_studies_scan ON studies(scan_id)",
        ),
    )

    val ALL: List<Migration> = listOf(M1, M2)
    val LATEST: Int = ALL.last().version

    /** الإصدارات الواجب تطبيقها للانتقال من [from] (0 = قاعدة جديدة) إلى [to]. */
    fun between(from: Int, to: Int): List<Migration> = ALL.filter { it.version in (from + 1)..to }

    /** يتحقق أن الترقيم يبدأ من 1 ومتتالٍ بلا فجوات أو تكرار. */
    fun validate(): Boolean = ALL.mapIndexed { i, m -> m.version == i + 1 }.all { it } && ALL.all { it.statements.isNotEmpty() }
}
