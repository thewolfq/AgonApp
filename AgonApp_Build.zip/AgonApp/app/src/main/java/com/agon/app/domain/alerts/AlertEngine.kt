package com.agon.app.domain.alerts

import com.agon.app.config.AppConfig
import com.agon.app.domain.engine.StrengthReport
import com.agon.app.domain.engine.StrengthState
import com.agon.app.domain.engine.TradeCalculator
import com.agon.app.domain.engine.fmt
import com.agon.app.domain.engine.fmtPrice
import com.agon.app.domain.model.Direction
import com.agon.app.domain.model.Trade
import kotlinx.serialization.Serializable

@Serializable
enum class AlertType(val title: String, val critical: Boolean) {
    TARGET_NEAR("اقتراب الهدف", false),
    TARGET_HIT("تحقق الهدف", false),
    STOP_NEAR("اقتراب الوقف", false),
    STOP_CROSSED("تجاوز الوقف", true),
    LIQ_NEAR("اقتراب التصفية", true),
    STRENGTH_CHANGED("تغير حالة القوة", false),
}

@Serializable
data class AlertSettings(
    val nearTargetFraction: Double = AppConfig.Alerts.NEAR_TARGET_FRACTION,
    val nearStopFraction: Double = AppConfig.Alerts.NEAR_STOP_FRACTION,
    val nearLiqFraction: Double = AppConfig.Alerts.NEAR_LIQ_FRACTION,
    val rearmHysteresis: Double = AppConfig.Alerts.REARM_HYSTERESIS,
    val enabled: Set<AlertType> = AlertType.entries.toSet(),
)

data class AlertEvent(
    /** معرف منع التكرار؛ يُحفظ في SQLite (alert_state.key). */
    val key: String,
    val tradeId: Long,
    val type: AlertType,
    val title: String,
    val body: String,
    val price: Double,
    val value: Double,
    val detail: String = "",
)

data class Evaluation(val fire: List<AlertEvent>, val rearm: List<String>)

/**
 * محرك تنبيهات خالص: يقرر ما يُطلق بناءً على السعر ومجموعة المفاتيح المُطلقة سابقًا.
 * الحالة نفسها لا تُطلق مرتين؛ تنبيهات «الاقتراب» تُعاد تسليحها فقط بعد تراجع بهامش hysteresis.
 */
object AlertEngine {
    fun key(tradeId: Long, type: AlertType) = "trade:$tradeId:${type.name}"

    /** 0 عند الدخول، 1 عند الهدف (موقّع). */
    fun progressToTarget(t: Trade, price: Double): Double {
        val d = t.target - t.entry
        return if (d == 0.0) 0.0 else (price - t.entry) / d
    }

    /** 0 عند الدخول، 1 عند الوقف. */
    fun progressToStop(t: Trade, price: Double): Double {
        val d = t.stop - t.entry
        return if (d == 0.0) 0.0 else (price - t.entry) / d
    }

    fun progressToLiq(t: Trade, liq: Double, price: Double): Double {
        val d = liq - t.entry
        return if (d == 0.0) 0.0 else (price - t.entry) / d
    }

    /** سعر التصفية المرجعي: اليدوي أولًا، ثم التقدير. */
    fun referenceLiq(t: Trade): Double? = TradeCalculator.compute(TradeCalculator.inputOf(t)).liqReference

    fun evaluate(t: Trade, price: Double, fired: Set<String>, s: AlertSettings = AlertSettings()): Evaluation {
        val fire = ArrayList<AlertEvent>()
        val rearm = ArrayList<String>()
        if (price <= 0) return Evaluation(fire, rearm)
        val dir = if (t.direction == Direction.LONG) "شراء" else "بيع"
        val head = "${t.symbol} ($dir · ${t.market.label})"

        fun handle(nearType: AlertType, hitType: AlertType?, progress: Double, nearAt: Double, nearBody: String, hitBody: String) {
            val nearKey = key(t.id, nearType)
            val hitKey = hitType?.let { key(t.id, it) }
            if (hitType != null && hitKey != null && progress >= 1.0) {
                if (hitType in s.enabled && hitKey !in fired) fire += AlertEvent(hitKey, t.id, hitType, "${hitType.title} — ${t.symbol}", "$head: $hitBody", price, progress)
                return
            }
            if (progress >= nearAt) {
                val hitFired = hitKey != null && hitKey in fired
                if (nearType in s.enabled && nearKey !in fired && !hitFired) {
                    fire += AlertEvent(nearKey, t.id, nearType, "${nearType.title} — ${t.symbol}", "$head: $nearBody", price, progress)
                }
            } else if (nearKey in fired && progress < nearAt - s.rearmHysteresis) {
                rearm += nearKey
            }
        }

        val pT = progressToTarget(t, price)
        handle(
            AlertType.TARGET_NEAR, AlertType.TARGET_HIT, pT, s.nearTargetFraction,
            "السعر ${fmtPrice(price)} قطع ${fmt(pT * 100, 0)}% من المسافة إلى الهدف ${fmtPrice(t.target)}",
            "السعر ${fmtPrice(price)} بلغ الهدف ${fmtPrice(t.target)}",
        )
        val pS = progressToStop(t, price)
        handle(
            AlertType.STOP_NEAR, AlertType.STOP_CROSSED, pS, s.nearStopFraction,
            "السعر ${fmtPrice(price)} قطع ${fmt(pS * 100, 0)}% من المسافة إلى الوقف ${fmtPrice(t.stop)}",
            "السعر ${fmtPrice(price)} تجاوز الوقف ${fmtPrice(t.stop)}",
        )
        referenceLiq(t)?.let { liq ->
            val pL = progressToLiq(t, liq, price)
            handle(
                AlertType.LIQ_NEAR, null, pL, s.nearLiqFraction,
                "حرج: السعر ${fmtPrice(price)} قطع ${fmt(pL * 100, 0)}% من المسافة إلى التصفية ${fmtPrice(liq)}" +
                    if (t.liqManual == null) " (تقدير تقريبي)" else "",
                "",
            )
        }
        return Evaluation(fire, rearm)
    }

    /** تنبيه تغير القوة: يُطلق فقط عندما تختلف الحالة عن آخر حالة محفوظة للصفقة. */
    fun strengthChange(t: Trade, previous: String?, report: StrengthReport, price: Double, s: AlertSettings = AlertSettings()): AlertEvent? {
        if (report.state == StrengthState.UNKNOWN) return null
        if (previous == report.state.name) return null
        if (AlertType.STRENGTH_CHANGED !in s.enabled) return null
        val reasons = report.reasons.joinToString("، ") { "${it.title} (${it.value})" }.ifEmpty { "لا إشارات معاكسة" }
        val prevLabel = previous?.let { p -> StrengthState.entries.firstOrNull { it.name == p }?.label } ?: "—"
        return AlertEvent(
            key = key(t.id, AlertType.STRENGTH_CHANGED), tradeId = t.id, type = AlertType.STRENGTH_CHANGED,
            title = "${AlertType.STRENGTH_CHANGED.title} — ${t.symbol}",
            body = "${t.symbol}: من «$prevLabel» إلى «${report.state.label}». السبب: $reasons. (${AppConfig.UNPROVEN})",
            price = price, value = report.state.ordinal.toDouble(), detail = report.state.name,
        )
    }
}
