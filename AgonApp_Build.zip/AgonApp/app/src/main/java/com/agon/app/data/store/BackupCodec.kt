package com.agon.app.data.store

import com.agon.app.config.AppConfig
import com.agon.app.domain.model.AlertRecord
import com.agon.app.domain.model.AlertStateRow
import com.agon.app.domain.model.DecisionRecord
import com.agon.app.domain.model.MarketEvent
import com.agon.app.domain.model.SavedLevel
import com.agon.app.domain.model.StudyCard
import com.agon.app.domain.model.Trade
import com.agon.app.domain.model.WatchItem
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

class BackupFormatException(message: String) : Exception(message)

/** محتوى النسخة/التصدير. لا يحتوي أسرارًا (مفاتيح API وTelegram تبقى في التخزين الآمن فقط) ولا أسعارًا/شموعًا. */
@Serializable
data class BackupData(
    val app: String = BackupCodec.APP_ID,
    val schemaVersion: Int = AppConfig.BACKUP_SCHEMA_VERSION,
    val dbVersion: Int = 0,
    val exportedAt: Long = 0,
    val watchlist: List<WatchItem> = emptyList(),
    val trades: List<Trade> = emptyList(),
    val alertStates: List<AlertStateRow> = emptyList(),
    val alertLog: List<AlertRecord> = emptyList(),
    val studies: List<StudyCard> = emptyList(),
    val decisions: List<DecisionRecord> = emptyList(),
    val events: List<MarketEvent> = emptyList(),
    val levels: List<SavedLevel> = emptyList(),
    val settings: Map<String, String> = emptyMap(),
)

object BackupCodec {
    const val APP_ID = "ghaith-trading"
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }

    fun encode(d: BackupData): String = json.encodeToString(BackupData.serializer(), d)

    fun decode(text: String): BackupData {
        val d = try {
            json.decodeFromString(BackupData.serializer(), text)
        } catch (t: Exception) {
            throw BackupFormatException("الملف ليس نسخة «غيث التداول» صالحة: ${t.message?.take(120)}")
        }
        if (d.app != APP_ID) throw BackupFormatException("الملف لا يخص هذا التطبيق (app=${d.app})")
        if (d.schemaVersion > AppConfig.BACKUP_SCHEMA_VERSION) {
            throw BackupFormatException("إصدار النسخة ${d.schemaVersion} أحدث من المدعوم ${AppConfig.BACKUP_SCHEMA_VERSION}؛ حدّث التطبيق")
        }
        return d
    }
}
