package com.agon.app.data.providers

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.longOrNull

fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
fun JsonObject.dbl(key: String): Double? = (this[key] as? JsonPrimitive)?.let { it.doubleOrNull ?: it.contentOrNull?.toDoubleOrNull() }
fun JsonObject.lng(key: String): Long? = (this[key] as? JsonPrimitive)?.let { it.longOrNull ?: it.contentOrNull?.toLongOrNull() }
fun JsonObject.bool(key: String): Boolean? = (this[key] as? JsonPrimitive)?.booleanOrNull
fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject
fun JsonObject.arr(key: String): JsonArray? = this[key] as? JsonArray

private fun JsonElement.asDouble(): Double? = (this as? JsonPrimitive)?.let { it.doubleOrNull ?: it.contentOrNull?.toDoubleOrNull() }
private fun JsonElement.asLong(): Long? = (this as? JsonPrimitive)?.let { it.longOrNull ?: it.contentOrNull?.toLongOrNull() }

/** محللات خالصة (بدون Android) لرسائل Binance الرسمية؛ مغطاة باختبارات وحدة. */
object BinanceParsers {
    val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /** 24hrMiniTicker: c إغلاق، o افتتاح، h، l، v حجم الأساس، q حجم التسعير، E وقت الحدث. */
    fun miniTicker(o: JsonObject, market: Market, now: Long): Ticker? {
        val symbol = o.str("s") ?: return null
        val close = o.dbl("c") ?: return null
        return Ticker(
            market = market, symbol = symbol, close = close,
            open = o.dbl("o") ?: close, high = o.dbl("h") ?: close, low = o.dbl("l") ?: close,
            baseVolume = o.dbl("v") ?: 0.0, quoteVolume = o.dbl("q") ?: 0.0,
            eventTime = o.lng("E") ?: now, fetchedAt = now, source = TickSource.WS,
        )
    }

    fun miniTickerArray(arr: JsonArray, market: Market, now: Long): List<Ticker> =
        arr.mapNotNull { (it as? JsonObject)?.let { o -> miniTicker(o, market, now) } }

    /** GET ticker/24hr (FULL أو MINI): lastPrice/openPrice/highPrice/lowPrice/volume/quoteVolume/closeTime. */
    fun restTicker(o: JsonObject, market: Market, now: Long): Ticker? {
        val symbol = o.str("symbol") ?: return null
        val close = o.dbl("lastPrice") ?: return null
        return Ticker(
            market = market, symbol = symbol, close = close,
            open = o.dbl("openPrice") ?: close, high = o.dbl("highPrice") ?: close, low = o.dbl("lowPrice") ?: close,
            baseVolume = o.dbl("volume") ?: 0.0, quoteVolume = o.dbl("quoteVolume") ?: 0.0,
            eventTime = o.lng("closeTime") ?: now, fetchedAt = now, source = TickSource.REST,
        )
    }

    /** صف klines من REST: [openTime, o, h, l, c, v, closeTime, quoteVol, trades, takerBuyBase, takerBuyQuote, _]. */
    fun klineRest(a: JsonArray, now: Long): Kline? {
        if (a.size < 11) return null
        val closeTime = a[6].asLong() ?: return null
        return Kline(
            openTime = a[0].asLong() ?: return null, closeTime = closeTime,
            open = a[1].asDouble() ?: return null, high = a[2].asDouble() ?: return null,
            low = a[3].asDouble() ?: return null, close = a[4].asDouble() ?: return null,
            volume = a[5].asDouble() ?: 0.0, quoteVolume = a[7].asDouble() ?: 0.0,
            takerBuyBase = a[9].asDouble() ?: 0.0, takerBuyQuote = a[10].asDouble() ?: 0.0,
            closed = closeTime < now,
        )
    }

    /** حدث kline من WS. يعيد (الإطار، الشمعة). الإغلاق من الحقل الرسمي k.x فقط. */
    fun klineWs(o: JsonObject): Pair<String, Kline>? {
        val k = o.obj("k") ?: return null
        val interval = k.str("i") ?: return null
        val kline = Kline(
            openTime = k.lng("t") ?: return null, closeTime = k.lng("T") ?: return null,
            open = k.dbl("o") ?: return null, high = k.dbl("h") ?: return null,
            low = k.dbl("l") ?: return null, close = k.dbl("c") ?: return null,
            volume = k.dbl("v") ?: 0.0, quoteVolume = k.dbl("q") ?: 0.0,
            takerBuyBase = k.dbl("V") ?: 0.0, takerBuyQuote = k.dbl("Q") ?: 0.0,
            closed = k.bool("x") ?: false,
        )
        return interval to kline
    }

    fun aggTrade(o: JsonObject): AggTrade? {
        val price = o.dbl("p") ?: return null
        val qty = o.dbl("q") ?: return null
        val maker = o.bool("m") ?: return null
        return AggTrade(price, qty, o.lng("T") ?: 0L, o.lng("E") ?: 0L, buyerIsMaker = maker)
    }

    private fun levels(a: JsonArray?): List<PriceLevel> = a?.mapNotNull { row ->
        val r = row as? JsonArray ?: return@mapNotNull null
        if (r.size < 2) return@mapNotNull null
        val p = r[0].asDouble() ?: return@mapNotNull null
        val q = r[1].asDouble() ?: return@mapNotNull null
        PriceLevel(p, q)
    } ?: emptyList()

    /** depthUpdate: U أول معرف، u آخر معرف، pu (Futures) آخر معرف للحدث السابق. */
    fun depthEvent(o: JsonObject): DepthEvent? {
        val first = o.lng("U") ?: return null
        val last = o.lng("u") ?: return null
        return DepthEvent(
            eventTime = o.lng("E") ?: 0L, firstId = first, finalId = last, prevFinalId = o.lng("pu"),
            bids = levels(o.arr("b")), asks = levels(o.arr("a")),
        )
    }

    fun depthSnapshot(o: JsonObject, now: Long): DepthSnapshot? {
        val id = o.lng("lastUpdateId") ?: return null
        return DepthSnapshot(id, levels(o.arr("bids")), levels(o.arr("asks")), now)
    }

    /** markPriceUpdate: p سعر العلامة، i المؤشر، r معدل التمويل، T وقت التمويل القادم. */
    fun markPriceWs(o: JsonObject): MarkInfo? {
        val mark = o.dbl("p") ?: return null
        return MarkInfo(mark, o.dbl("i") ?: mark, o.dbl("r") ?: return null, o.lng("T") ?: 0L, o.lng("E") ?: 0L)
    }

    /** GET /fapi/v1/premiumIndex. */
    fun premiumIndex(o: JsonObject): MarkInfo? {
        val mark = o.dbl("markPrice") ?: return null
        return MarkInfo(mark, o.dbl("indexPrice") ?: mark, o.dbl("lastFundingRate") ?: return null, o.lng("nextFundingTime") ?: 0L, o.lng("time") ?: 0L)
    }
}
