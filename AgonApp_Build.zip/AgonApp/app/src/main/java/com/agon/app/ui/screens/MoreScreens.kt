@file:OptIn(ExperimentalMaterial3Api::class)

package com.agon.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.ui.components.SectionCard

private val morePad = PaddingValues(16.dp)
private val moreGap = Arrangement.spacedBy(12.dp)

/** تبويب «المزيد»: حاوية للتبويبات الجديدة. لا اتصال بالمحركات ولا بالشبكة. */
@Composable
fun MoreScreen(onOpenAbout: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = morePad, verticalArrangement = moreGap) {
        item {
            Card(Modifier.fillMaxWidth().clickable(onClick = onOpenAbout)) {
                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("عن التطبيق", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** شاشة تعريفية ثابتة فقط: لا تقرأ من المحركات ولا تستهلك موارد مستمرة. */
@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "—"
    }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("عن التطبيق", maxLines = 1) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = morePad, verticalArrangement = moreGap) {
            item {
                SectionCard("غيث التداول – GAITH TRADING", subtitle = "الإصدار $version") {
                    Text("نبذة عن التطبيق", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        "تطبيق استشاري متخصص في تحليل أسواق العملات الرقمية، ومراقبة حركة الأسعار والتقلبات، " +
                            "واكتشاف الفرص التداولية المحتملة، وتقييم الإشارات وإدارة المخاطر من خلال التحليلات الفنية " +
                            "والبيانات الفعلية للسوق.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            item {
                SectionCard("المطوّر") {
                    Text("عبد الوارث الذيب", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "جميع الحقوق محفوظة © 2026",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
