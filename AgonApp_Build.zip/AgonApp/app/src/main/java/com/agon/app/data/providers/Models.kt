package com.agon.app.data.providers

import kotlinx.serialization.Serializable

/** السوقان منفصلان في المصدر والتخزين والتحليل. */
@Serializable
enum class Market(val id: String, val label: String) {
    SPOT("spot", "فوري"),
    FUTURES("futures", "عقود USDⓈ-M");

    companion object {
        fun fromId(id: String?): Market = entries.firstOrNull { it.id == id || it.name == id } ?: SPOT
    }
}

enum class Side { BUY, SELL }

enum class TickSource { REST, WS }

/**
 * قيمة 24 ساعة لرمز واحد. [fetchedAt] وقت الاستلام المحلي، [eventTime] وقت الحدث من Binance (ms).
 * [stale] تُضبط فقط عند انقطاع الاتصال؛ غياب تحديث الرمز في miniTicker ليس انقطاعًا.
 * الوحدات: الأسعار بعملة التسعير، [baseVolume] بالأصل الأساسي، [quoteVolume] بعملة التسعير.
 */
data class Ticker(
    val market: Market,
    val symbol: String,
    val close: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val baseVolume: Double,
    val quoteVolume: Double,
    val eventTime: Long,
    val fetchedAt: Long,
    val source: TickSource,
    val stale: Boolean = false,
) {
    val changePct: Double get() = if (open > 0) (close - open) / open * 100.0 else 0.0
}

data class Kline(
    val openTime: Long,
    val closeTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val quoteVolume: Double,
    val takerBuyBase: Double,
    val takerBuyQuote: Double,
    /** علامة الإغلاق الرسمية x=true (WS) أو closeTime < الآن (REST). */
    val closed: Boolean,
)

/**
 * صفقة مجمّعة. الحقل الرسمي m = «هل المشتري هو صانع السوق؟».
 * m=true ⇒ المشتري صانع ⇒ المبادر (taker) بائع. m=false ⇒ المبادر مشترٍ.
 */
data class AggTrade(
    val price: Double,
    val qty: Double,
    val tradeTime: Long,
    val eventTime: Long,
    val buyerIsMaker: Boolean,
) {
    val takerSide: Side get() = if (buyerIsMaker) Side.SELL else Side.BUY
    val notional: Double get() = price * qty
}

data class PriceLevel(val price: Double, val qty: Double)

/** حدث فرق العمق. [prevFinalId] (pu) موجود في Futures فقط. */
data class DepthEvent(
    val eventTime: Long,
    val firstId: Long,
    val finalId: Long,
    val prevFinalId: Long?,
    val bids: List<PriceLevel>,
    val asks: List<PriceLevel>,
)

data class DepthSnapshot(
    val lastUpdateId: Long,
    val bids: List<PriceLevel>,
    val asks: List<PriceLevel>,
    val fetchedAt: Long,
)

data class SymbolInfo(
    val market: Market,
    val symbol: String,
    val base: String,
    val quote: String,
    val status: String,
    val contractType: String? = null,
    val onboardDate: Long? = null,
    val deliveryDate: Long? = null,
) {
    val trading: Boolean get() = status == "TRADING"
}

/** قيمة موقّتة مع مصدرها ووحدتها وسوقها. */
data class Timed<T>(
    val value: T?,
    val fetchedAt: Long,
    val stale: Boolean,
    val market: Market,
    val source: String,
    val unit: String,
)

/** من markPrice (WS) أو premiumIndex (REST). معدل التمويل كسر لكل فترة تمويل (الفترة تختلف بالرمز). */
data class MarkInfo(
    val markPrice: Double,
    val indexPrice: Double,
    val fundingRate: Double,
    val nextFundingTime: Long,
    val eventTime: Long,
)

/** OI من REST فقط. [openInterest] بوحدة الأصل الأساسي (عقود)، [valueUsdt] إن توفر من openInterestHist. */
data class OiPoint(val time: Long, val openInterest: Double, val valueUsdt: Double?)
