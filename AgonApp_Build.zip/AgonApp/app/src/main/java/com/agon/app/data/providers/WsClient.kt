package com.agon.app.data.providers

import com.agon.app.config.AppConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

enum class WsState(val label: String) {
    IDLE("متوقف"), CONNECTING("جارٍ الاتصال"), OPEN("متصل"), WAITING_RETRY("إعادة اتصال"),
}

data class WsHealth(
    val state: WsState = WsState.IDLE,
    val connectedAt: Long = 0L,
    val disconnectedAt: Long = 0L,
    val connects: Int = 0,
    val reconnects: Int = 0,
    val lastReason: String = "",
    val lastError: String? = null,
    val lastRecoveryMs: Long = 0L,
)

/**
 * عميل WebSocket خالص (OkHttp) مع إعادة اتصال أسّية + jitter، تدوير قبل 24 ساعة،
 * وطابور إرسال محدود المعدل. الرد على ping الخادم يتولاه OkHttp تلقائيًا (pong بنفس الحمولة).
 * لا يعتمد على Android ليُستخدم في اختبار التحمل المعزول.
 */
class WsClient(
    private val http: OkHttpClient,
    val name: String,
    private val scope: CoroutineScope,
    private val urlProvider: () -> String,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val onOpen: () -> Unit = {},
    private val onText: (String, Long) -> Unit,
) {
    private val _health = MutableStateFlow(WsHealth())
    val health: StateFlow<WsHealth> = _health

    private val lock = Any()
    private var socket: WebSocket? = null
    @Volatile private var generation = 0
    @Volatile private var wanted = false
    private var attempt = 0
    private var retryJob: Job? = null
    private var rotateJob: Job? = null
    private var senderJob: Job? = null
    private val outgoing = Channel<Pair<Int, String>>(Channel.UNLIMITED)

    @Volatile var lastFrameAt: Long = 0L
        private set
    val frames = AtomicLong(0)

    val isOpen: Boolean get() = _health.value.state == WsState.OPEN

    fun start() {
        synchronized(lock) {
            if (wanted) return
            wanted = true
            attempt = 0
            if (senderJob == null) {
                senderJob = scope.launch {
                    for ((gen, msg) in outgoing) {
                        if (gen != generation) continue
                        val s = synchronized(lock) { socket }
                        if (s != null && s.send(msg)) delay(AppConfig.Ws.OUTGOING_MIN_GAP_MS)
                    }
                }
            }
        }
        connect("start")
    }

    fun stop() {
        synchronized(lock) {
            if (!wanted) return
            wanted = false
            generation++
            retryJob?.cancel(); retryJob = null
            rotateJob?.cancel(); rotateJob = null
            socket?.close(1000, "client stop")
            socket = null
            _health.update { it.copy(state = WsState.IDLE, lastReason = "stop", disconnectedAt = clock()) }
        }
    }

    /** يُستدعى عند تبديل الشبكة (Wi‑Fi/4G) أو الاشتباه بانقطاع صامت. */
    fun forceReconnect(reason: String) {
        if (!wanted) return
        synchronized(lock) {
            attempt = 0
            if (_health.value.state == WsState.OPEN) _health.update { it.copy(disconnectedAt = clock()) }
        }
        connect(reason)
    }

    /** رسالة تحكم (SUBSCRIBE/UNSUBSCRIBE). تُهمل إن تغيّر الاتصال قبل إرسالها. */
    fun send(text: String) {
        outgoing.trySend(generation to text)
    }

    /** إرسال فوري يتجاوز الطابور (يُستخدم لإلغاء الاشتراك قبل الإغلاق مباشرة). */
    fun sendNow(text: String): Boolean = synchronized(lock) { socket?.send(text) ?: false }

    private fun connect(reason: String) {
        synchronized(lock) {
            if (!wanted) return
            retryJob?.cancel(); retryJob = null
            rotateJob?.cancel(); rotateJob = null
            socket?.cancel()
            generation++
            val gen = generation
            _health.update { it.copy(state = WsState.CONNECTING, lastReason = reason) }
            val url = try {
                urlProvider()
            } catch (t: Throwable) {
                _health.update { it.copy(lastError = "url: ${t.message}") }
                null
            }
            if (url == null) {
                scheduleRetryLocked(gen, "bad-url")
                return
            }
            socket = try {
                http.newWebSocket(Request.Builder().url(url).build(), Listener(gen))
            } catch (t: Throwable) {
                _health.update { it.copy(lastError = t.message ?: t.javaClass.simpleName) }
                scheduleRetryLocked(gen, "connect-error")
                null
            }
        }
    }

    private fun scheduleRetryLocked(gen: Int, reason: String) {
        if (!wanted || gen != generation) return
        attempt++
        val base = min(
            AppConfig.Ws.RECONNECT_MAX_MS.toDouble(),
            AppConfig.Ws.RECONNECT_BASE_MS * 2.0.pow((attempt - 1).coerceAtMost(10)),
        )
        val jitter = 1.0 + (Random.nextDouble() * 2 - 1) * AppConfig.Ws.RECONNECT_JITTER
        val wait = (base * jitter).toLong().coerceAtLeast(200L)
        val now = clock()
        _health.update {
            it.copy(
                state = WsState.WAITING_RETRY, lastReason = reason,
                disconnectedAt = if (it.state == WsState.OPEN || it.disconnectedAt == 0L) now else it.disconnectedAt,
            )
        }
        retryJob?.cancel()
        retryJob = scope.launch {
            delay(wait)
            connect("retry#$attempt($reason)")
        }
    }

    private inner class Listener(private val gen: Int) : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            synchronized(lock) {
                if (gen != generation) return
                attempt = 0
                val now = clock()
                lastFrameAt = now
                _health.update {
                    it.copy(
                        state = WsState.OPEN, connectedAt = now, connects = it.connects + 1,
                        reconnects = if (it.connects > 0) it.reconnects + 1 else 0,
                        lastRecoveryMs = if (it.disconnectedAt > 0) now - it.disconnectedAt else 0L,
                        disconnectedAt = 0L, lastError = null,
                    )
                }
                rotateJob?.cancel()
                rotateJob = scope.launch {
                    delay(AppConfig.Ws.MAX_CONNECTION_AGE_MS)
                    forceReconnect("rotation-before-24h")
                }
            }
            runCatching { onOpen() }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (gen != generation) return
            val now = clock()
            lastFrameAt = now
            frames.incrementAndGet()
            try {
                onText(text, now)
            } catch (t: Throwable) {
                _health.update { it.copy(lastError = "handler: ${t.javaClass.simpleName}: ${t.message}") }
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            synchronized(lock) { scheduleRetryLocked(gen, "closed:$code") }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            synchronized(lock) {
                if (gen != generation) return
                val http = response?.code?.let { " http=$it" } ?: ""
                _health.update { it.copy(lastError = "${t.javaClass.simpleName}: ${t.message}$http") }
                scheduleRetryLocked(gen, "failure")
            }
        }
    }
}
