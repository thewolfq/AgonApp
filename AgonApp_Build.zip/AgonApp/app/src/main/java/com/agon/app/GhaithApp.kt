package com.agon.app

import android.app.Application
import com.agon.app.core.AppContainer

class GhaithApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
