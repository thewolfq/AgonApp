package com.agon.app.data.store

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * تخزين الأسرار التي يقدمها المستخدم (مفتاح النموذج اللغوي، رمز بوت Telegram) محليًا:
 * AES-256-GCM بمفتاح في Android Keystore لا يغادر الجهاز؛ النص المشفر في SharedPreferences خاصة.
 * لا تُسجّل القيم ولا تُصدّر في النسخ. المخاطر الباقية: جهاز بصلاحيات root أو مخترق أو مفتوح القفل
 * يستطيع استخدام المفتاح؛ استخدم مفاتيح محدودة الصلاحية والإنفاق وقابلة للإلغاء.
 */
class SecureStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("ghaith_secure", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return gen.generateKey()
    }

    /** يحفظ القيمة مشفرة؛ null أو فارغ يحذفها. يعيد false إن فشل التشفير (لا يُحفظ نص صريح أبدًا). */
    fun put(name: String, value: String?): Boolean {
        if (value.isNullOrBlank()) {
            prefs.edit().remove(name).apply()
            return true
        }
        return try {
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val ct = cipher.doFinal(value.trim().toByteArray(Charsets.UTF_8))
            val blob = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
            prefs.edit().putString(name, blob).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun get(name: String): String? {
        val blob = prefs.getString(name, null) ?: return null
        return try {
            val (iv, ct) = blob.split(":").map { Base64.decode(it, Base64.NO_WRAP) }
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    fun has(name: String): Boolean = prefs.contains(name)

    companion object {
        private const val ALIAS = "ghaith_secrets_v1"
        private const val TRANSFORM = "AES/GCM/NoPadding"
        const val LLM_KEY = "llm_api_key"
        const val TELEGRAM_TOKEN = "telegram_bot_token"
        const val TELEGRAM_CHAT = "telegram_chat_id"
    }
}
