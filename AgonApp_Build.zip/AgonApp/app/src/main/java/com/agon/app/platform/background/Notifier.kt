package com.agon.app.platform.background

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.config.AppConfig
import com.agon.app.core.AlertSink

/** قنوات الإشعارات وإرسالها. لا يُخفى إشعار المراقبة الدائم أبدًا. */
class Notifier(private val context: Context) : AlertSink {
    private val manager = NotificationManagerCompat.from(context)

    fun ensureChannels() {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_MONITOR, "المراقبة الخلفية", NotificationManager.IMPORTANCE_LOW).apply { description = "إشعار دائم أثناء تشغيل المراقبة" })
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "تنبيهات الصفقات", NotificationManager.IMPORTANCE_HIGH).apply { description = "الهدف والوقف وتغير القوة" })
        nm.createNotificationChannel(NotificationChannel(CH_CRITICAL, "تنبيهات حرجة", NotificationManager.IMPORTANCE_HIGH).apply { description = "تجاوز الوقف واقتراب التصفية"; enableVibration(true) })
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "حالة التطبيق", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "توقف المراقبة، الدراسات، النسخ" })
    }

    /** يشمل إذن POST_NOTIFICATIONS في Android 13+ وحظر الإشعارات من النظام. */
    fun canNotify(): Boolean = manager.areNotificationsEnabled()

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun monitorNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            context, 1, Intent(context, MonitorService::class.java).setAction(MonitorService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(context, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_stat_ghaith)
            .setContentTitle("غيث التداول — المراقبة تعمل")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp())
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, "إيقاف المراقبة", stop)
            .build()
    }

    fun updateMonitor(text: String) {
        if (canNotify()) runCatching { manager.notify(MONITOR_ID, monitorNotification(text)) }
    }

    override fun alert(key: String, title: String, body: String, critical: Boolean): Boolean {
        if (!canNotify()) return false
        val n = NotificationCompat.Builder(context, if (critical) CH_CRITICAL else CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_ghaith)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\n${AppConfig.DISCLAIMER}"))
            .setPriority(if (critical) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (critical) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_EVENT)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()
        return try {
            // معرف ثابت لكل مفتاح حالة: إعادة الإرسال تستبدل ولا تكرر.
            manager.notify(key, ALERT_ID, n)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun status(id: Int, title: String, body: String) {
        if (!canNotify()) return
        val n = NotificationCompat.Builder(context, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_ghaith)
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true).setContentIntent(openApp()).build()
        runCatching { manager.notify(id, n) }
    }

    fun cancel(id: Int) = manager.cancel(id)

    companion object {
        const val CH_MONITOR = "monitor"
        const val CH_ALERTS = "alerts"
        const val CH_CRITICAL = "critical"
        const val CH_STATUS = "status"
        const val MONITOR_ID = 1001
        const val STOPPED_ID = 1002
        const val BACKUP_ID = 1003
        const val TEST_ID = 1004
        const val ALERT_ID = 2000
    }
}
