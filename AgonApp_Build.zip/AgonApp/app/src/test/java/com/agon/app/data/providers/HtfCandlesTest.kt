package com.agon.app.data.providers

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.IOException
import java.time.Instant

class HtfCandlesTest {
    private fun ms(iso: String) = Instant.parse(iso).toEpochMilli()

    /** سلسلة شموع تنتهي بشمعة جارية تحتوي now؛ سعر الافتتاح = 100 + الفهرس. */
    private fun series(interval: HtfInterval, now: Long, n: Int): List<Kline> {
        val curOpen = now - Math.floorMod(now, interval.ms)
        return (0 until n).map { i ->
            val open = curOpen - (n - 1 - i) * interval.ms
            val close = open + interval.ms - 1
            Kline(open, close, 100.0 + i, 101.0 + i, 99.0 + i, 100.5 + i, 10.0, 1000.0, 5.0, 500.0, close < now)
        }
    }

    private class Env(start: Long) {
        var now = start
        var calls = 0
        var lastInterval: String? = null
        var failNext = false
        var delayMs = 0L
    }

    private fun fetcher(env: Env, n: Int = 50) = HtfCandleFetcher(
        fetch = { _, _, interval, _ ->
            env.calls++
            env.lastInterval = interval
            if (env.delayMs > 0) delay(env.delayMs)
            if (env.failNext) throw IOException("boom")
            series(if (interval == "4h") HtfInterval.H4 else HtfInterval.D1, env.now, n)
        },
        clock = { env.now },
    )

    @Test
    fun utc_dayAndWeekStart() {
        val t = ms("2026-11-12T10:30:00Z") // الخميس
        assertEquals(ms("2026-11-12T00:00:00Z"), UtcTime.dayStart(t))
        assertEquals(ms("2026-11-09T00:00:00Z"), UtcTime.weekStart(t))
        val mon = ms("2026-11-09T00:00:00Z")
        assertEquals(mon, UtcTime.weekStart(mon))
        assertEquals(mon, UtcTime.weekStart(ms("2026-11-15T23:59:59Z"))) // الأحد يتبع اثنين الأسبوع نفسه
        assertEquals(ms("2026-11-16T00:00:00Z"), UtcTime.weekStart(ms("2026-11-16T00:00:01Z")))
    }

    @Test
    fun cache_secondCallWithinTtlDoesNotHitNetwork() = runBlocking {
        val env = Env(ms("2026-11-12T01:00:00Z"))
        val f = fetcher(env)
        f.candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        env.now += 60_000
        f.candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        assertEquals(1, env.calls)
        assertEquals("4h", env.lastInterval)
    }

    @Test
    fun cache_refetchesAfterTtl() = runBlocking {
        val env = Env(ms("2026-11-12T01:00:00Z"))
        val f = fetcher(env)
        f.candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        env.now += HtfInterval.H4.ttlMs + 1
        f.candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        assertEquals(2, env.calls)
    }

    @Test
    fun cache_refetchesWhenFormingCandleEnds() = runBlocking {
        val env = Env(ms("2026-11-12T03:59:59Z")) // قبل إغلاق شمعة 00:00–04:00 بثانية
        val f = fetcher(env)
        f.candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        env.now += 2_000 // عبرنا الإغلاق والـTTL لم ينتهِ
        f.candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        assertEquals(2, env.calls)
    }

    @Test
    fun concurrentCallersShareOneRequest() = runBlocking {
        val env = Env(ms("2026-11-12T01:00:00Z")).also { it.delayMs = 50 }
        val f = fetcher(env)
        coroutineScope {
            (1..5).map { async { f.candles(Market.SPOT, "ETHUSDT", HtfInterval.D1) } }.awaitAll()
        }
        assertEquals(1, env.calls)
    }

    @Test
    fun failureReturnsStaleCacheOrThrows() = runBlocking {
        val env = Env(ms("2026-11-12T01:00:00Z"))
        val f = fetcher(env)
        // بلا كاش: الخطأ يظهر ولا نختلق بيانات.
        env.failNext = true
        try {
            f.candles(Market.FUTURES, "SOLUSDT", HtfInterval.H4)
            fail("expected IOException")
        } catch (e: IOException) {
        }
        env.failNext = false
        val ok = f.candles(Market.FUTURES, "SOLUSDT", HtfInterval.H4)
        assertFalse(ok.stale)
        env.now += HtfInterval.H4.ttlMs + 1
        env.failNext = true
        val stale = f.candles(Market.FUTURES, "SOLUSDT", HtfInterval.H4)
        assertTrue(stale.stale)
        assertEquals(ok.klines.size, stale.klines.size)
    }

    @Test
    fun marketsAreCachedSeparately() = runBlocking {
        val env = Env(ms("2026-11-12T01:00:00Z"))
        val f = fetcher(env)
        f.candles(Market.SPOT, "BTCUSDT", HtfInterval.H4)
        f.candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        assertEquals(2, env.calls)
    }

    @Test
    fun formingCandleIsNeverReportedAsClosed() = runBlocking {
        val env = Env(ms("2026-11-12T01:00:00Z"))
        val snap = fetcher(env, n = 30).candles(Market.FUTURES, "BTCUSDT", HtfInterval.H4)
        assertEquals(30, snap.klines.size)
        assertEquals(29, snap.closed(env.now).size)
        assertNotNull(snap.forming(env.now))
        assertTrue(snap.closed(env.now).all { it.closeTime < env.now })
        // بعد انتهاء الشمعة الجارية تصبح مكتملة محسوبة بالساعة لا بعلامة الجلب القديمة.
        assertEquals(30, snap.closed(snap.klines.last().closeTime + 1).size)
        assertNull(snap.forming(snap.klines.last().closeTime + 1))
    }

    @Test
    fun utcOpens_dailyAndWeekly() = runBlocking {
        val env = Env(ms("2026-11-12T10:30:00Z")) // الخميس
        val opens = fetcher(env, n = 10).utcOpens(Market.FUTURES, "BTCUSDT")
        assertEquals(ms("2026-11-12T00:00:00Z"), opens.dayStartMs)
        assertEquals(ms("2026-11-09T00:00:00Z"), opens.weekStartMs)
        assertEquals(109.0, opens.dailyOpen!!, 1e-9) // آخر شمعة (اليوم)
        assertEquals(106.0, opens.weeklyOpen!!, 1e-9) // قبل 3 أيام = الاثنين
    }
}
