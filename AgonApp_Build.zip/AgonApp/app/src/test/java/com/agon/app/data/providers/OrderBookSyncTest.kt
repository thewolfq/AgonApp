package com.agon.app.data.providers

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class OrderBookSyncTest {
    private fun ev(first: Long, last: Long, pu: Long? = null, bids: List<PriceLevel> = emptyList(), asks: List<PriceLevel> = emptyList()) =
        DepthEvent(0L, first, last, pu, bids, asks)

    private fun snap(id: Long, bids: List<PriceLevel> = listOf(PriceLevel(10.0, 5.0), PriceLevel(9.0, 1.0)), asks: List<PriceLevel> = listOf(PriceLevel(11.0, 3.0), PriceLevel(12.0, 1.0))) =
        DepthSnapshot(id, bids, asks, 0L)

    @Test
    fun spot_buffersFirst_thenSyncsFromSnapshot_andNeverBuildsFromWsAlone() {
        val s = OrderBookSynchronizer(Market.SPOT)
        val r1 = s.onEvent(ev(101, 105, bids = listOf(PriceLevel(10.0, 1.0))))
        assertTrue(r1 is EventResult.Buffered && r1.needSnapshot)
        assertEquals(BookSyncState.BUFFERING, s.state)
        assertTrue("الدفتر فارغ قبل اللقطة", s.book.bids.isEmpty() && s.book.asks.isEmpty())
        s.onEvent(ev(106, 110, bids = listOf(PriceLevel(10.0, 2.0))))
        s.onEvent(ev(111, 115, asks = listOf(PriceLevel(11.0, 0.0))))

        // لقطة أقدم من أول حدث مخزن ⇒ أعد الجلب
        assertTrue(s.onSnapshot(snap(90)) is SnapshotResult.Retry)
        assertEquals(BookSyncState.BUFFERING, s.state)

        val r = s.onSnapshot(snap(107))
        assertTrue(r is SnapshotResult.Synced)
        r as SnapshotResult.Synced
        assertEquals(1, r.droppedBuffered) // u=105 <= 107
        assertEquals(2, r.appliedBuffered)
        assertEquals(BookSyncState.SYNCED, s.state)
        assertEquals(2.0, s.book.bids[10.0]!!, 0.0)
        assertNull("الكمية صفر تحذف المستوى", s.book.asks[11.0])
        assertEquals(115L, s.book.lastUpdateId)
    }

    @Test
    fun spot_ignoresOld_appliesSequential_detectsGap_andResyncs() {
        val s = OrderBookSynchronizer(Market.SPOT)
        s.onEvent(ev(101, 105))
        assertTrue(s.onSnapshot(snap(104)) is SnapshotResult.Synced)
        assertEquals(105L, s.book.lastUpdateId)

        assertSame(EventResult.Applied, s.onEvent(ev(106, 108, bids = listOf(PriceLevel(9.0, 0.0)))))
        assertNull(s.book.bids[9.0])
        assertSame(EventResult.Ignored, s.onEvent(ev(90, 100)))
        assertEquals(108L, s.book.lastUpdateId)

        // U > id + 1 ⇒ فجوة ⇒ إسقاط وإعادة بناء
        val g = s.onEvent(ev(120, 125))
        assertTrue(g is EventResult.Gap)
        assertEquals(BookSyncState.BUFFERING, s.state)
        assertEquals(1, s.resyncCount)
        // لا تُطبّق أحداث أثناء إعادة البناء
        assertTrue(s.onEvent(ev(126, 130)) is EventResult.Buffered)
        assertTrue(s.onSnapshot(snap(127)) is SnapshotResult.Synced)
        assertEquals(130L, s.book.lastUpdateId)
    }

    @Test
    fun spot_snapshotExactlyBeforeFirstEvent_isAccepted() {
        val s = OrderBookSynchronizer(Market.SPOT)
        s.onEvent(ev(101, 105))
        // lastUpdateId = U - 1 ⇒ الحدث الأول هو التالي مباشرة (U <= id + 1)
        assertTrue(s.onSnapshot(snap(100)) is SnapshotResult.Synced)
        assertEquals(105L, s.book.lastUpdateId)
    }

    @Test
    fun futures_firstEventMustCoverSnapshot_thenPuChain() {
        val s = OrderBookSynchronizer(Market.FUTURES)
        s.onEvent(ev(10, 20, pu = 9))
        s.onEvent(ev(21, 30, pu = 20, bids = listOf(PriceLevel(10.0, 7.0))))
        s.onEvent(ev(31, 40, pu = 30))
        val r = s.onSnapshot(snap(25))
        assertTrue(r is SnapshotResult.Synced)
        r as SnapshotResult.Synced
        assertEquals(1, r.droppedBuffered) // u=20 < 25
        assertEquals(2, r.appliedBuffered)
        assertEquals(7.0, s.book.bids[10.0]!!, 0.0)

        assertSame(EventResult.Applied, s.onEvent(ev(41, 50, pu = 40)))
        // pu لا يساوي u السابق ⇒ فجوة
        val g = s.onEvent(ev(55, 60, pu = 52))
        assertTrue(g is EventResult.Gap)
        assertEquals(BookSyncState.BUFFERING, s.state)
        assertEquals(1, s.resyncCount)
    }

    @Test
    fun futures_snapshotOlderThanStream_requiresNewSnapshot() {
        val s = OrderBookSynchronizer(Market.FUTURES)
        s.onEvent(ev(100, 110, pu = 99))
        assertTrue(s.onSnapshot(snap(50)) is SnapshotResult.Retry)
        assertEquals(BookSyncState.BUFFERING, s.state)
    }

    @Test
    fun futures_snapshotNewerThanAllBuffered_validatesFirstLiveEvent() {
        val s = OrderBookSynchronizer(Market.FUTURES)
        s.onEvent(ev(10, 20, pu = 9))
        val r = s.onSnapshot(snap(30)) as SnapshotResult.Synced
        assertEquals(0, r.appliedBuffered)
        assertSame(EventResult.Ignored, s.onEvent(ev(21, 29, pu = 20)))
        assertSame(EventResult.Applied, s.onEvent(ev(30, 35, pu = 29)))
        assertSame(EventResult.Applied, s.onEvent(ev(36, 40, pu = 35)))
        assertTrue(s.onEvent(ev(45, 50, pu = 44)) is EventResult.Gap)
    }

    @Test
    fun metrics_spreadImbalanceAndBand() {
        val b = LocalOrderBook()
        b.load(DepthSnapshot(1, listOf(PriceLevel(100.0, 3.0), PriceLevel(99.5, 1.0), PriceLevel(90.0, 50.0)), listOf(PriceLevel(100.1, 1.0), PriceLevel(100.5, 1.0), PriceLevel(120.0, 50.0)), 0))
        val m = b.metrics(bandPct = 1.0, viewLevels = 2)!!
        assertEquals(100.0, m.bestBid, 0.0)
        assertEquals(100.1, m.bestAsk, 0.0)
        assertEquals(9.995, m.spreadBps, 0.01)
        // المستويات خارج ±1% لا تدخل العمق
        assertEquals(100.0 * 3 + 99.5, m.bidNotional, 1e-6)
        assertEquals(100.1 + 100.5, m.askNotional, 1e-6)
        assertTrue(m.imbalance > 0)
        assertEquals(2, m.topBids.size)
    }
}
