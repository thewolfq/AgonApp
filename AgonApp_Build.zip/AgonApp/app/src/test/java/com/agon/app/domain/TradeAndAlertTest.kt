package com.agon.app.domain

import com.agon.app.TestData
import com.agon.app.data.providers.Market
import com.agon.app.domain.alerts.AlertEngine
import com.agon.app.domain.alerts.AlertSettings
import com.agon.app.domain.alerts.AlertType
import com.agon.app.domain.engine.LiqSource
import com.agon.app.domain.engine.StrengthAnalyzer
import com.agon.app.domain.engine.TradeCalculator
import com.agon.app.domain.engine.TradeInput
import com.agon.app.domain.model.Direction
import com.agon.app.domain.model.Trade
import com.agon.app.domain.model.TradeFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TradeAndAlertTest {
    private fun inp(dir: Direction = Direction.LONG, market: Market = Market.FUTURES, entry: Double? = 100.0, lev: Double? = 10.0, target: Double? = 110.0, stop: Double? = 95.0, size: Double? = 1000.0, liq: Double? = null) =
        TradeInput(market, dir, entry, lev, target, stop, size, liq)

    // ---------- حاسبة الصفقة ----------

    @Test
    fun calc_longRiskRewardAndLeveragedLoss() {
        val m = TradeCalculator.compute(inp())
        assertTrue(m.valid)
        assertEquals(2.0, m.rewardRisk!!, 1e-9)
        assertEquals(10.0, m.targetMovePct!!, 1e-9)
        assertEquals(5.0, m.stopMovePct!!, 1e-9)
        assertEquals(50.0, m.lossPctOnMargin!!, 1e-9) // 5% × 10
        assertEquals(100.0, m.profitPctOnMargin!!, 1e-9)
        assertEquals(100.0, m.margin!!, 1e-9)
        assertEquals(50.0, m.lossQuote!!, 1e-9)
        assertEquals(100.0, m.profitQuote!!, 1e-9)
    }

    @Test
    fun calc_validatesTargetAndStopDirection() {
        assertFalse(TradeCalculator.compute(inp(target = 90.0)).valid)
        assertFalse(TradeCalculator.compute(inp(stop = 101.0)).valid)
        val s = TradeCalculator.compute(inp(dir = Direction.SHORT, target = 90.0, stop = 104.0))
        assertTrue(s.valid)
        assertEquals(2.5, s.rewardRisk!!, 1e-9)
        assertFalse(TradeCalculator.compute(inp(dir = Direction.SHORT, target = 110.0, stop = 104.0)).valid)
        assertFalse(TradeCalculator.compute(inp(dir = Direction.SHORT, target = 90.0, stop = 99.0)).valid)
        assertFalse("لا بيع مكشوف في الفوري", TradeCalculator.compute(inp(dir = Direction.SHORT, market = Market.SPOT, target = 90.0, stop = 104.0)).valid)
        assertFalse(TradeCalculator.compute(inp(entry = null)).valid)
        assertFalse(TradeCalculator.compute(inp(lev = 500.0)).valid)
    }

    @Test
    fun calc_liquidationEstimate_manualIsReference_andRedWarningWhenCloserThanStop() {
        // Long 10x: 100 × (1 − 0.1 + 0.005) = 90.5
        val est = TradeCalculator.compute(inp())
        assertEquals(90.5, est.liqEstimate!!, 1e-9)
        assertEquals(LiqSource.ESTIMATE, est.liqSource)
        assertFalse(est.liqBeforeStop) // 90.5 < 95

        // اليدوي هو المرجع حتى لو خالف التقدير
        val manual = TradeCalculator.compute(inp(liq = 96.0))
        assertEquals(96.0, manual.liqReference!!, 0.0)
        assertEquals(LiqSource.MANUAL, manual.liqSource)
        assertTrue(manual.liqBeforeStop)
        assertTrue(manual.warnings.any { it.contains("التصفية أقرب من الوقف") })

        // رافعة عالية: التقدير أقرب من الوقف
        val high = TradeCalculator.compute(inp(lev = 50.0))
        assertEquals(98.5, high.liqEstimate!!, 1e-9)
        assertTrue(high.liqBeforeStop)

        // Short 10x: 100 × (1 + 0.1 − 0.005) = 109.5
        val short = TradeCalculator.compute(inp(dir = Direction.SHORT, target = 90.0, stop = 104.0))
        assertEquals(109.5, short.liqEstimate!!, 1e-9)
        assertFalse(short.liqBeforeStop)

        // الفوري: لا رافعة ولا تصفية
        val spot = TradeCalculator.compute(inp(market = Market.SPOT, lev = 20.0))
        assertNull(spot.liqEstimate)
        assertEquals(LiqSource.NONE, spot.liqSource)
        assertEquals(5.0, spot.lossPctOnMargin!!, 1e-9)
    }

    // ---------- التنبيهات ----------

    private fun trade(dir: Direction = Direction.LONG, entry: Double = 100.0, target: Double = 110.0, stop: Double = 95.0, lev: Double = 10.0, liq: Double? = null) =
        Trade(id = 7, symbol = "BTCUSDT", market = Market.FUTURES, direction = dir, frame = TradeFrame.FAST, entry = entry, leverage = lev, target = target, stop = stop, size = 1000.0, liqManual = liq)

    @Test
    fun alerts_nearTargetAt80PercentOfDistance_thenHit_noDuplicates() {
        val t = trade()
        val fired = HashSet<String>()
        assertTrue(AlertEngine.evaluate(t, 107.9, fired).fire.isEmpty()) // 79%
        val near = AlertEngine.evaluate(t, 108.0, fired).fire
        assertEquals(listOf(AlertType.TARGET_NEAR), near.map { it.type })
        assertEquals("trade:7:TARGET_NEAR", near[0].key)
        fired += near.map { it.key }
        // نفس الحالة لا تتكرر مهما تكررت الأسعار
        repeat(50) { assertTrue(AlertEngine.evaluate(t, 108.0 + it * 0.01, fired).fire.isEmpty()) }
        val hit = AlertEngine.evaluate(t, 110.0, fired).fire
        assertEquals(listOf(AlertType.TARGET_HIT), hit.map { it.type })
        fired += hit.map { it.key }
        assertTrue(AlertEngine.evaluate(t, 111.0, fired).fire.isEmpty())
        // بعد التحقق لا يعود «الاقتراب» حتى لو أعيد تسليحه
        fired.remove("trade:7:TARGET_NEAR")
        assertTrue(AlertEngine.evaluate(t, 109.0, fired).fire.isEmpty())
    }

    @Test
    fun alerts_gapStraightToTarget_firesOnlyHit() {
        val ev = AlertEngine.evaluate(trade(), 112.0, emptySet()).fire
        assertEquals(listOf(AlertType.TARGET_HIT), ev.map { it.type })
    }

    @Test
    fun alerts_stopNearAndCrossed_andRearmWithHysteresis() {
        val t = trade()
        val fired = HashSet<String>()
        val near = AlertEngine.evaluate(t, 96.0, fired) // 80% نحو الوقف
        assertEquals(listOf(AlertType.STOP_NEAR), near.fire.map { it.type })
        fired += near.fire.map { it.key }
        // تراجع بسيط لا يعيد التسليح (ضمن الهامش)
        assertTrue(AlertEngine.evaluate(t, 96.5, fired).rearm.isEmpty())
        // تراجع تحت 65% يعيد التسليح
        val back = AlertEngine.evaluate(t, 97.0, fired)
        assertEquals(listOf("trade:7:STOP_NEAR"), back.rearm)
        fired -= back.rearm.toSet()
        assertEquals(listOf(AlertType.STOP_NEAR), AlertEngine.evaluate(t, 95.9, fired).fire.map { it.type })
        val crossed = AlertEngine.evaluate(t, 94.9, fired).fire
        assertEquals(listOf(AlertType.STOP_CROSSED), crossed.map { it.type })
        assertTrue(crossed[0].type.critical)
    }

    @Test
    fun alerts_shortDirectionIsMirrored() {
        val t = trade(dir = Direction.SHORT, target = 90.0, stop = 104.0)
        assertEquals(listOf(AlertType.TARGET_NEAR), AlertEngine.evaluate(t, 92.0, emptySet()).fire.map { it.type })
        assertTrue(AlertEngine.evaluate(t, 108.0, emptySet()).fire.any { it.type == AlertType.STOP_CROSSED })
        assertTrue(AlertEngine.evaluate(t, 101.0, emptySet()).fire.isEmpty())
    }

    @Test
    fun alerts_liquidationNearIsCritical_usesManualPriceFirst() {
        // تقدير 90.5؛ اليدوي 93 ⇒ المسافة 7، و 75% منها عند 94.75
        val t = trade(stop = 92.0, liq = 93.0)
        assertEquals(93.0, AlertEngine.referenceLiq(t)!!, 0.0)
        assertTrue(AlertEngine.evaluate(t, 95.0, emptySet()).fire.none { it.type == AlertType.LIQ_NEAR })
        val ev = AlertEngine.evaluate(t, 94.7, emptySet()).fire.first { it.type == AlertType.LIQ_NEAR }
        assertTrue(ev.type.critical)
        assertFalse(ev.body.contains("تقدير تقريبي"))
        // بلا يدوي يُستخدم التقدير ويُوسم
        val est = AlertEngine.evaluate(trade(stop = 85.0), 92.0, emptySet()).fire.first { it.type == AlertType.LIQ_NEAR }
        assertTrue(est.body.contains("تقدير تقريبي"))
    }

    @Test
    fun alerts_disabledTypesAreSkipped_andCustomNearFraction() {
        val t = trade()
        val s = AlertSettings(nearTargetFraction = 0.5, enabled = setOf(AlertType.TARGET_NEAR))
        assertEquals(listOf(AlertType.TARGET_NEAR), AlertEngine.evaluate(t, 105.0, emptySet(), s).fire.map { it.type })
        assertTrue(AlertEngine.evaluate(t, 94.0, emptySet(), s).fire.isEmpty())
    }

    @Test
    fun alerts_strengthChangeOnlyWhenStateDiffers() {
        val t = trade()
        val k = TestData.fromCloses((0 until 120).map { 100.0 + it * 0.2 })
        val report = StrengthAnalyzer.evaluate(Direction.LONG, k, null, "5m", 0)
        val first = AlertEngine.strengthChange(t, null, report, 120.0)
        assertNotNull(first)
        assertEquals(report.state.name, first!!.detail)
        assertTrue(first.body.contains("غير مثبت"))
        // الحالة نفسها لا تُطلق ثانية
        assertNull(AlertEngine.strengthChange(t, report.state.name, report, 120.0))
        assertNotNull(AlertEngine.strengthChange(t, "WEAK", report, 120.0))
    }
}
