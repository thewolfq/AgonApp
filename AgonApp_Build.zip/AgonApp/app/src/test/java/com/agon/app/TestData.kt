package com.agon.app

import com.agon.app.data.providers.Kline

object TestData {
    const val BAR_MS = 300_000L

    /** شمعة مغلقة من إغلاقين متتاليين. */
    fun bar(i: Int, open: Double, close: Double, quoteVolume: Double = 20_000.0, takerShare: Double = 0.5, wick: Double = 0.05, barMs: Long = BAR_MS, t0: Long = 1_700_000_000_000L): Kline {
        val hi = maxOf(open, close) + wick
        val lo = minOf(open, close) - wick
        return Kline(t0 + i * barMs, t0 + (i + 1) * barMs - 1, open, hi, lo, close, quoteVolume / close, quoteVolume, quoteVolume / close * takerShare, quoteVolume * takerShare, true)
    }

    fun fromCloses(closes: List<Double>, volume: (Int) -> Double = { 20_000.0 }, takerShare: (Int) -> Double = { 0.5 }, barMs: Long = BAR_MS): List<Kline> =
        closes.mapIndexed { i, c -> bar(i, if (i == 0) c else closes[i - 1], c, volume(i), takerShare(i), barMs = barMs) }

    /** اتجاه صاعد متعرج (قمم وقيعان صاعدة). */
    fun zigzagUp(n: Int, start: Double = 100.0, drift: Double = 0.08, amp: Double = 1.5, period: Int = 10): List<Double> =
        (0 until n).map { i ->
            val phase = i % period
            val tri = if (phase < period / 2) phase.toDouble() / (period / 2) else 1 - (phase - period / 2).toDouble() / (period / 2)
            start + drift * i + amp * tri
        }
}
