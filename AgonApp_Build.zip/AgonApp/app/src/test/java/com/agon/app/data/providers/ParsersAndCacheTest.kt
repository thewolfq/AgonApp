package com.agon.app.data.providers

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ParsersAndCacheTest {
    private fun obj(s: String) = BinanceParsers.json.parseToJsonElement(s) as JsonObject

    @Test
    fun aggTrade_makerFlagIsNotInverted() {
        // m=true: المشتري صانع السوق ⇒ المبادر بائع
        val sell = BinanceParsers.aggTrade(obj("""{"e":"aggTrade","E":1672515782136,"s":"BNBBTC","a":12345,"p":"0.001","q":"100","f":100,"l":105,"T":1672515782136,"m":true,"M":true}"""))!!
        assertTrue(sell.buyerIsMaker)
        assertEquals(Side.SELL, sell.takerSide)
        // m=false: المشتري هو المبادر
        val buy = BinanceParsers.aggTrade(obj("""{"e":"aggTrade","E":1,"s":"BTCUSDT","p":"50000","q":"0.5","T":2,"m":false}"""))!!
        assertEquals(Side.BUY, buy.takerSide)
        assertEquals(25_000.0, buy.notional, 1e-9)
        assertNull("بلا حقل m لا نخمّن الاتجاه", BinanceParsers.aggTrade(obj("""{"p":"1","q":"1"}""")))
    }

    @Test
    fun miniTicker_parsesOfficialPayload() {
        val t = BinanceParsers.miniTicker(obj("""{"e":"24hrMiniTicker","E":1672515782136,"s":"BNBBTC","c":"0.0025","o":"0.0010","h":"0.0025","l":"0.0010","v":"10000","q":"18"}"""), Market.SPOT, 99L)!!
        assertEquals("BNBBTC", t.symbol)
        assertEquals(0.0025, t.close, 0.0)
        assertEquals(18.0, t.quoteVolume, 0.0)
        assertEquals(1672515782136L, t.eventTime)
        assertEquals(99L, t.fetchedAt)
        assertEquals(150.0, t.changePct, 1e-9)
        assertEquals(TickSource.WS, t.source)
    }

    @Test
    fun klineWs_closedOnlyFromOfficialXFlag() {
        val base = """{"e":"kline","E":1672515782136,"s":"BNBBTC","k":{"t":1672515780000,"T":1672515839999,"s":"BNBBTC","i":"1m","o":"0.0010","c":"0.0020","h":"0.0025","l":"0.0015","v":"1000","n":100,"x":%s,"q":"1.0000","V":"500","Q":"0.500"}}"""
        val (i1, live) = BinanceParsers.klineWs(obj(base.format("false")))!!
        assertEquals("1m", i1)
        assertFalse(live.closed)
        val (_, closed) = BinanceParsers.klineWs(obj(base.format("true")))!!
        assertTrue(closed.closed)
        assertEquals(0.5, closed.takerBuyQuote, 0.0)
    }

    @Test
    fun klineRest_lastCandleIsLiveUntilCloseTimePasses() {
        val row = BinanceParsers.json.parseToJsonElement("""[1000,"1","2","0.5","1.5","10",1999,"15",7,"4","6","0"]""") as JsonArray
        assertFalse(BinanceParsers.klineRest(row, now = 1500)!!.closed)
        assertTrue(BinanceParsers.klineRest(row, now = 2000)!!.closed)
    }

    @Test
    fun depthEvent_spotAndFuturesFields() {
        val spot = BinanceParsers.depthEvent(obj("""{"e":"depthUpdate","E":1,"s":"BNBBTC","U":157,"u":160,"b":[["0.0024","10"]],"a":[["0.0026","100"]]}"""))!!
        assertEquals(157L, spot.firstId); assertEquals(160L, spot.finalId); assertNull(spot.prevFinalId)
        val fut = BinanceParsers.depthEvent(obj("""{"e":"depthUpdate","E":1,"T":1,"s":"BTCUSDT","U":11742309239582,"u":11742309241602,"pu":11742309239523,"b":[["85547.70","0.020"]],"a":[["85723.10","0.000"]]}"""))!!
        assertEquals(11742309239523L, fut.prevFinalId)
        assertEquals(0.0, fut.asks[0].qty, 0.0)
    }

    @Test
    fun endpoints_futuresStreamsRoutedByOfficialCategory() {
        assertEquals(StreamCategory.PUBLIC, BinanceEndpoints.categoryOf(BinanceEndpoints.depth("BTCUSDT")))
        assertEquals(StreamCategory.MARKET, BinanceEndpoints.categoryOf(BinanceEndpoints.aggTrade("BTCUSDT")))
        assertEquals(StreamCategory.MARKET, BinanceEndpoints.categoryOf(BinanceEndpoints.kline("BTCUSDT", "1m")))
        assertEquals(StreamCategory.MARKET, BinanceEndpoints.categoryOf(BinanceEndpoints.ALL_MINI_TICKER))
        val cfg = BinanceEndpoints.config(spotDataOnly = false)
        assertTrue(BinanceEndpoints.wsBase(cfg, Market.FUTURES, StreamCategory.PUBLIC).endsWith("/public"))
        assertTrue(BinanceEndpoints.wsBase(cfg, Market.FUTURES, StreamCategory.MARKET).endsWith("/market"))
        // Spot وFutures لا يتشاركان أي نطاق
        assertFalse(BinanceEndpoints.restBase(cfg, Market.SPOT) == BinanceEndpoints.restBase(cfg, Market.FUTURES))
    }

    private fun tick(sym: String, price: Double, at: Long, src: TickSource = TickSource.WS) =
        Ticker(Market.SPOT, sym, price, price, price, price, 1.0, 1.0, at, at, src)

    @Test
    fun cache_silenceOfOneSymbolIsNotStale_onlyDisconnectMarksStale() {
        val c = TickerCache(Market.SPOT)
        c.applyWs(tick("QUIET", 1.0, 1_000))
        c.applyWs(tick("BUSY", 2.0, 1_000))
        // البث يرسل المتغير فقط: BUSY يتحدث لدقيقة وQUIET صامت
        for (t in 2_000L..60_000L step 1_000L) c.applyWs(tick("BUSY", 2.0 + t / 1e6, t))
        assertFalse("الصمت ليس انقطاعًا", c.get("QUIET")!!.stale)
        assertEquals(1.0, c.get("QUIET")!!.close, 0.0)
        assertEquals(59_000L, c.ageMs("QUIET", 60_000L))
        assertEquals(0, c.staleCount())

        // انقطاع فعلي
        assertEquals(2, c.markAllStale())
        assertTrue(c.get("QUIET")!!.stale && c.get("BUSY")!!.stale)
        // قيمة جديدة تزيل الوسم لذلك الرمز فقط
        c.applyWs(tick("BUSY", 3.0, 70_000))
        assertFalse(c.get("BUSY")!!.stale)
        assertTrue(c.get("QUIET")!!.stale)
        // إعادة البذر من REST تزيل الوسم عن الصامت دون الكتابة فوق WS الأحدث
        c.applySeed(listOf(tick("QUIET", 1.1, 71_000, TickSource.REST), tick("BUSY", 2.5, 71_000, TickSource.REST)), requestStartedAt = 69_000)
        assertFalse(c.get("QUIET")!!.stale)
        assertEquals(1.1, c.get("QUIET")!!.close, 0.0)
        assertEquals("WS الأحدث لا يُستبدل بـREST أقدم", 3.0, c.get("BUSY")!!.close, 0.0)
    }

    @Test
    fun latencyStats_percentiles() {
        val s = LatencyStats(100)
        (1..100).forEach { s.add(it.toLong()) }
        val r = s.summary()
        assertEquals(100L, r.n)
        assertEquals(51L, r.p50)
        assertEquals(96L, r.p95)
        assertNotNull(r)
    }
}
