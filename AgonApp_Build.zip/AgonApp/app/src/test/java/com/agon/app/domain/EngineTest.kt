package com.agon.app.domain

import com.agon.app.TestData
import com.agon.app.config.AppConfig
import com.agon.app.data.providers.BookMetrics
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.SymbolInfo
import com.agon.app.data.providers.TickSource
import com.agon.app.data.providers.Ticker
import com.agon.app.domain.engine.AnalysisInput
import com.agon.app.domain.engine.Analyzer
import com.agon.app.domain.engine.Backtest
import com.agon.app.domain.engine.BacktestConfig
import com.agon.app.domain.engine.Bias
import com.agon.app.domain.engine.Calibration
import com.agon.app.domain.engine.CandidateMetrics
import com.agon.app.domain.engine.DerivativesInput
import com.agon.app.domain.engine.Indicators
import com.agon.app.domain.engine.RelativeStrength
import com.agon.app.domain.engine.Scanner
import com.agon.app.domain.engine.Severity
import com.agon.app.domain.engine.StrengthAnalyzer
import com.agon.app.domain.engine.StrengthState
import com.agon.app.domain.engine.Structure
import com.agon.app.domain.engine.StructureKind
import com.agon.app.domain.engine.Weights
import com.agon.app.domain.model.Direction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class EngineTest {
    private val up5m = TestData.fromCloses(TestData.zigzagUp(200))
    private val up1h = TestData.fromCloses(TestData.zigzagUp(200), barMs = 3_600_000L)
    private val up1m = TestData.fromCloses(TestData.zigzagUp(200), barMs = 60_000L)

    private fun book(imbalance: Double = 0.4, spreadBps: Double = 1.0) = BookMetrics(
        100.0, 100.01, 100.005, spreadBps, 700.0, 300.0, imbalance, null, null, 1.0, emptyList(), emptyList(), 1, 10, 10,
    )

    private fun input(
        market: Market = Market.SPOT, book: BookMetrics? = null, synced: Boolean = false, vol: Double? = 50e6,
        deriv: DerivativesInput? = null, healthy: Boolean = true,
    ) = AnalysisInput(
        symbol = "TESTUSDT", market = market, now = up1m.last().closeTime + 1_000, price = up5m.last().close,
        k1m = up1m, k5m = up5m, k1h = up1h, quoteVolume24hUsdt = vol, book = book, bookSynced = synced,
        bookSource = "test", liveFlow = null, derivatives = deriv, feedHealthy = healthy,
    )

    // ---------- إصلاح (1): إعادة التطبيع عند غياب الدفتر ----------

    @Test
    fun weights_missingFactorIsRemovedAndRenormalized_notZeroWithFixedWeight() {
        val raw = listOf(
            Weights.Raw("a", "a", 0.52, true, 1.0, "", ""),
            Weights.Raw("b", "b", 0.40, true, 1.0, "", ""),
            Weights.Raw("book", "book", 0.08, false, 0.0, "", ""),
        )
        val f = Weights.normalize(raw)
        assertEquals(1.0, f.filter { it.available }.sumOf { it.weight }, 1e-12)
        assertEquals(0.0, f.first { it.key == "book" }.weight, 0.0)
        // الطريقة الخاطئة (صفر بوزن 0.08) تعطي 0.92؛ الصحيحة تعطي 1.0
        assertEquals(1.0, f.sumOf { it.contribution }, 1e-12)
    }

    @Test
    fun analyzer_withoutBook_dropsBookFactor_andWeightsSumToOne() {
        val a = Analyzer.analyze(input(book = null, synced = false))
        val bookF = a.factors.first { it.key == "book" }
        assertFalse(bookF.available)
        assertEquals(0.0, bookF.weight, 0.0)
        assertEquals(0.0, bookF.contribution, 0.0)
        assertEquals(1.0, a.factors.filter { it.available }.sumOf { it.weight }, 1e-9)
        // المشتقات غير متاحة في الفوري وتُحذف أيضًا
        assertFalse(a.factors.first { it.key == "derivatives" }.available)
        assertEquals(a.score, a.factors.sumOf { it.contribution }, 1e-9)
        assertTrue(a.unproven)
    }

    @Test
    fun analyzer_withSyncedBook_includesBookFactorAtRenormalizedWeight() {
        val without = Analyzer.analyze(input())
        val with = Analyzer.analyze(input(book = book(), synced = true))
        val f = with.factors.first { it.key == "book" }
        assertTrue(f.available)
        assertTrue(f.weight > AppConfig.Engine.W_BOOK) // أعيد تطبيعه لغياب المشتقات
        assertEquals(1.0, with.factors.filter { it.available }.sumOf { it.weight }, 1e-9)
        assertTrue(with.factors.first { it.key == "trend" }.weight < without.factors.first { it.key == "trend" }.weight)
        // دفتر غير مُزامَن لا يُستخدم حتى لو توفرت أرقامه
        assertFalse(Analyzer.analyze(input(book = book(), synced = false)).factors.first { it.key == "book" }.available)
    }

    @Test
    fun analyzer_uptrendReadsUp_andBaseWeightsSumToOne() {
        val a = Analyzer.analyze(input(book = book(), synced = true))
        assertEquals(1.0, a.factors.sumOf { it.baseWeight }, 1e-9)
        assertTrue(a.factors.first { it.key == "trend" }.score > 0)
        assertEquals(Bias.UP, a.bias)
        assertTrue(a.counterScenario.isNotBlank())
    }

    @Test
    fun analyzer_futuresStaleFundingIsDropped_freshIsUsed() {
        val stale = DerivativesInput(0.001, true, 0, null, null, null, true, 0)
        assertFalse(Analyzer.analyze(input(Market.FUTURES, deriv = stale)).factors.first { it.key == "derivatives" }.available)
        val fresh = DerivativesInput(0.001, false, 0, null, 1000.0, 3.0, false, 0)
        val f = Analyzer.analyze(input(Market.FUTURES, deriv = fresh)).factors.first { it.key == "derivatives" }
        assertTrue(f.available)
    }

    @Test
    fun blockers_liquidityThresholdsAre24hQuoteVolumeInUsdt() {
        fun liq(v: Double?) = Analyzer.blockers(input(vol = v, book = book(), synced = true)).firstOrNull { it.key == "liquidity" }
        assertEquals(Severity.BLOCK, liq(2_999_999.0)!!.severity)
        assertEquals(Severity.WARN, liq(3_000_000.0)!!.severity)
        assertEquals(Severity.WARN, liq(4_499_999.0)!!.severity)
        assertNull(liq(4_500_000.0))
        assertEquals(Severity.BLOCK, liq(null)!!.severity)
        assertEquals(3_000_000.0, AppConfig.Liquidity.SCAN_MIN_QUOTE_VOLUME_24H_USDT, 0.0)
        assertEquals(4_500_000.0, AppConfig.Liquidity.ALERT_MIN_QUOTE_VOLUME_24H_USDT, 0.0)
    }

    @Test
    fun blockers_spreadAndStaleData() {
        val wide = Analyzer.blockers(input(book = book(spreadBps = 20.0), synced = true))
        assertEquals(Severity.BLOCK, wide.first { it.key == "spread" }.severity)
        val offline = Analyzer.blockers(input(healthy = false))
        assertEquals(Severity.BLOCK, offline.first { it.key == "stale" }.severity)
        val old = Analyzer.blockers(input().copy(now = up1m.last().closeTime + 10 * 60_000L))
        assertEquals(Severity.BLOCK, old.first { it.key == "stale" }.severity)
    }

    // ---------- المؤشرات والهيكل ----------

    @Test
    fun indicators_rsiBoundsAndEma() {
        val rising = DoubleArray(50) { 100.0 + it }
        assertEquals(100.0, Indicators.rsi(rising, 14).last(), 1e-9)
        val falling = DoubleArray(50) { 100.0 - it }
        assertEquals(0.0, Indicators.rsi(falling, 14).last(), 1e-9)
        val flat = DoubleArray(30) { 5.0 }
        assertEquals(5.0, Indicators.ema(flat, 10).last(), 1e-12)
        assertTrue(Indicators.ema(flat, 10)[3].isNaN())
    }

    @Test
    fun structure_detectsHigherHighsAndLows() {
        assertEquals(StructureKind.UP, Structure.read(up5m).kind)
        val down = TestData.fromCloses(TestData.zigzagUp(200, drift = -0.08))
        assertEquals(StructureKind.DOWN, Structure.read(down).kind)
        assertEquals(StructureKind.UNKNOWN, Structure.read(up5m.take(8)).kind)
    }

    // ---------- القوة والانعكاس ----------

    @Test
    fun strength_monotonicTrendWithNoAdverseSignals_isStrong_andUnproven() {
        val k = TestData.fromCloses((0 until 120).map { 100.0 + it * 0.2 })
        val r = StrengthAnalyzer.evaluate(Direction.LONG, k, null, "5m", 0)
        assertEquals(StrengthState.STRONG, r.state)
        assertTrue(r.unproven)
        assertTrue(r.reasons.isEmpty())
    }

    @Test
    fun strength_breakOfLastSwingLowAgainstLong_isReversalWithReason() {
        val closes = TestData.zigzagUp(100).toMutableList()
        val lastLow = Structure.read(TestData.fromCloses(closes)).lastLow!!.price
        repeat(4) { closes.add(closes.last() - 1.2) }
        assertTrue(closes.last() < lastLow)
        val r = StrengthAnalyzer.evaluate(Direction.LONG, TestData.fromCloses(closes), null, "5m", 0)
        assertEquals(StrengthState.REVERSAL, r.state)
        val reason = r.reasons.first { it.key == "structureBreak" }
        assertTrue(reason.major && reason.value.isNotBlank())
        // نفس الحركة لا تكسر هيكل صفقة البيع
        val shortR = StrengthAnalyzer.evaluate(Direction.SHORT, TestData.fromCloses(closes), null, "5m", 0)
        assertFalse(shortR.signals.first { it.key == "structureBreak" }.active)
    }

    @Test
    fun strength_extremeFundingAndTakerFlip() {
        val closes = (0 until 120).map { 100.0 + it * 0.2 }
        val k = TestData.fromCloses(closes)
        val funded = StrengthAnalyzer.evaluate(Direction.LONG, k, 0.001, "5m", 0)
        assertTrue(funded.signals.first { it.key == "extremeFunding" }.active)
        assertEquals(StrengthState.HOLDING, funded.state)
        assertFalse(StrengthAnalyzer.evaluate(Direction.SHORT, k, 0.001, "5m", 0).signals.first { it.key == "extremeFunding" }.active)

        // نسبة شراء المبادرين تنقلب من 60% إلى 30% في آخر 6 شموع
        val flipped = TestData.fromCloses(closes, takerShare = { if (it >= 114) 0.30 else 0.60 })
        val r = StrengthAnalyzer.evaluate(Direction.LONG, flipped, 0.001, "5m", 0)
        assertTrue(r.signals.first { it.key == "takerFlip" }.active)
        assertEquals(StrengthState.WEAK, r.state)
        assertEquals(StrengthState.UNKNOWN, StrengthAnalyzer.evaluate(Direction.LONG, k.take(20), null, "5m", 0).state)
    }

    // ---------- الماسح ----------

    private fun tk(sym: String, price: Double, quoteVol: Double, stale: Boolean = false) =
        Ticker(Market.SPOT, sym, price, price * 0.99, price, price, quoteVol / price, quoteVol, 0, 0, TickSource.REST, stale)

    private fun info(sym: String, base: String, quote: String, status: String = "TRADING") = SymbolInfo(Market.SPOT, sym, base, quote, status)

    @Test
    fun scanner_quoteConversionToUsdt_orExclusionWithReason() {
        val prices = mapOf("BTCUSDT" to 70_000.0, "USDTTRY" to 40.0)
        assertEquals(1.0, Scanner.usdtFactor("USDT") { prices[it] }!!, 0.0)
        assertEquals(70_000.0, Scanner.usdtFactor("BTC") { prices[it] }!!, 0.0)
        assertEquals(0.025, Scanner.usdtFactor("TRY") { prices[it] }!!, 1e-12)
        assertNull(Scanner.usdtFactor("XYZ") { prices[it] })

        val tickers = listOf(
            tk("BTCUSDT", 70_000.0, 20e6), tk("AAAUSDT", 2.0, 10e6), tk("AAABTC", 0.00003, 100.0),
            tk("BBBUSDT", 1.0, 2e6), tk("CCCXYZ", 1.0, 9e9), tk("USDCUSDT", 1.0, 50e6), tk("DDDUSDT", 1.0, 8e6), tk("EEEUSDT", 1.0, 9e6, stale = true),
        )
        val infos = listOf(
            info("BTCUSDT", "BTC", "USDT"), info("AAAUSDT", "AAA", "USDT"), info("AAABTC", "AAA", "BTC"), info("BBBUSDT", "BBB", "USDT"),
            info("CCCXYZ", "CCC", "XYZ"), info("USDCUSDT", "USDC", "USDT"), info("DDDUSDT", "DDD", "USDT", "BREAK"), info("EEEUSDT", "EEE", "USDT"),
        ).associateBy { it.symbol }
        val u = Scanner.selectUniverse(tickers, infos)
        assertEquals(listOf("BTCUSDT", "AAAUSDT"), u.entries.map { it.symbol })
        fun reason(s: String) = u.excluded.first { it.symbol == s }.reason
        assertTrue(reason("CCCXYZ").contains("تحويل"))
        assertTrue(reason("BBBUSDT").contains("حد المسح"))
        assertTrue(reason("AAABTC").contains("مكرر")) // 100 BTC × 70000 = 7M USDT مؤهل لكنه مكرر
        assertTrue(reason("USDCUSDT").contains("مستقرة"))
        assertTrue(reason("DDDUSDT").contains("BREAK"))
        assertTrue(reason("EEEUSDT").contains("قديمة"))
        assertEquals(u.seen, u.entries.size + u.excluded.size)
    }

    @Test
    fun scanner_candidatesRankedByLastHourAndRelativeVolume_not24hMove() {
        // عملة تحركت 30% قبل 20 ساعة ثم سكنت، وأخرى تحركت 3% في الساعة الأخيرة بحجم مرتفع
        val old = TestData.fromCloses((0 until 400).map { if (it < 150) 100.0 else 130.0 })
        val fresh = TestData.fromCloses((0 until 400).map { if (it < 390) 100.0 else 100.0 + (it - 389) * 0.3 }, volume = { if (it >= 388) 200_000.0 else 20_000.0 })
        val mOld = Scanner.candidateMetrics("OLD", old, 1.0)!!
        val mFresh = Scanner.candidateMetrics("FRESH", fresh, 1.0)!!
        assertEquals(0.0, mOld.change1hPct, 1e-9)
        assertEquals(1.0, mOld.relVolume, 1e-9)
        assertTrue(mFresh.change1hPct > 2.9 && mFresh.relVolume > 5)
        assertEquals(20_000.0 * 276 + 200_000.0 * 12, mFresh.realVolume24hUsdt, 1e-3)
        val ranked = Scanner.rankCandidates(listOf(mOld, mFresh, CandidateMetrics("MID", 1.0, 1.0, 1.5, 5e6, 400)), topN = 2)
        assertEquals(listOf("FRESH", "MID"), ranked.map { it.metrics.symbol })
    }

    // ---------- إصلاح (5): القوة النسبية في النافذة نفسها ----------

    @Test
    fun relativeStrength_usesSameAlignedWindowForCoinAndBtc() {
        val btc = TestData.fromCloses((0 until 100).map { 100.0 + it * 0.1 })
        val strong = TestData.fromCloses((0 until 100).map { 50.0 * Math.pow(1.004, it.toDouble()) })
        val rs = RelativeStrength.compute(strong, btc, window = 48)!!
        assertEquals(48, rs.commonBars)
        assertEquals(1.0, rs.outperformShare, 0.0)
        assertFalse(rs.weak)
        assertFalse(rs.thresholdCalibrated)
        assertEquals(0.45, rs.threshold, 0.0)
        // نفس النافذة: عائد BTC محسوب بين نفس أول/آخر شمعة مشتركة
        val expectedBtc = (btc[99].close / btc[51].close - 1) * 100
        assertEquals(expectedBtc, rs.btcReturnPct, 1e-9)

        // BTC ينقصه آخر 20 شمعة ⇒ النافذة تنتهي عند آخر شمعة مشتركة لا عند آخر شمعة للعملة
        val rs2 = RelativeStrength.compute(strong, btc.take(80), window = 48)!!
        assertEquals((strong[79].close / strong[31].close - 1) * 100, rs2.coinReturnPct, 1e-9)
        // سلسلة مطابقة لـBTC لا تتفوق أبدًا ⇒ أقل من 45% ⇒ ضعيفة
        assertTrue(RelativeStrength.compute(btc, btc)!!.weak)
        assertNull(RelativeStrength.compute(strong, emptyList()))
    }

    @Test
    fun calibration_staysDefaultUnder100Cases_andCalibratesOutOfSampleAfter() {
        val few = (0 until 99).map { 0.5 to 1.0 }
        val c1 = Calibration.calibrateThreshold(few)
        assertFalse(c1.calibrated)
        assertEquals(0.45, c1.threshold, 0.0)

        val many = (0 until 200).map { i -> val rs = 0.2 + (i % 8) * 0.1; rs to if (rs >= 0.6) 2.0 else -2.0 }
        val c2 = Calibration.calibrateThreshold(many)
        assertTrue(c2.calibrated)
        assertTrue(abs(c2.threshold - 0.6) < 0.051)
        assertTrue(c2.outOfSampleSeparation!! > 0)

        // علاقة تنقلب خارج العينة ⇒ لا تُعتمد
        val unstable = (0 until 200).map { i -> val rs = 0.2 + (i % 8) * 0.1; val s = if (i < 100) 1 else -1; rs to (if (rs >= 0.6) 2.0 else -2.0) * s }
        assertFalse(Calibration.calibrateThreshold(unstable).calibrated)
    }

    // ---------- إصلاح (2) و(3): scanSignals + block bootstrap ----------

    private fun spikeSeries(baseVol: Double) = TestData.fromCloses(
        (0 until 800).map { i -> if (i < 390) 100.0 else if (i < 400) 100.0 + (i - 389) * 0.3 else 103.0 },
        volume = { if (it in 389..400) baseVol * 10 else baseVol },
    )

    @Test
    fun scanSignals_oneSignalPerPairWithinCooldown() {
        val series = mapOf("AAAUSDT" to spikeSeries(20_000.0))
        val withCooldown = Backtest.scanSignals(series, mapOf("AAAUSDT" to 1.0))
        assertEquals(1, withCooldown.size)
        assertEquals(1, withCooldown[0].direction)
        assertTrue(withCooldown[0].forwardReturnPct > 0)
        // بلا تهدئة تتكرر الإشارة على الشموع المتتالية للحركة نفسها
        val noCooldown = Backtest.scanSignals(series, mapOf("AAAUSDT" to 1.0), BacktestConfig(cooldownBars = 1))
        assertTrue(noCooldown.size > 3)
        val idx = withCooldown.map { it.index }
        assertTrue(idx.zipWithNext().all { (a, b) -> b - a >= AppConfig.Backtest.COOLDOWN_BARS })
    }

    @Test
    fun scanSignals_usesReal24hVolumeAtSignalTime_withUsdtConversion() {
        // 1000/شمعة ⇒ 288k في 24س < 3M ⇒ لا إشارات
        assertTrue(Backtest.scanSignals(mapOf("LOW" to spikeSeries(1_000.0)), mapOf("LOW" to 1.0)).isEmpty())
        // نفس السلسلة مسعّرة بعملة تساوي 100 USDT ⇒ 28.8M ⇒ مؤهلة
        val conv = Backtest.scanSignals(mapOf("LOW" to spikeSeries(1_000.0)), mapOf("LOW" to 100.0))
        assertEquals(1, conv.size)
        assertTrue(conv[0].volume24hUsdt >= 3_000_000.0)
        // بلا معامل تحويل ⇒ يُستبعد الزوج
        assertTrue(Backtest.scanSignals(mapOf("LOW" to spikeSeries(20_000.0)), emptyMap()).isEmpty())
    }

    @Test
    fun blockBootstrap_isDeterministicAndBracketsMean() {
        val v = DoubleArray(300) { i -> Math.sin(i / 7.0) + (i % 5) * 0.1 - 0.15 }
        val a = Backtest.blockBootstrap(v, 8, 1000, 42)
        val b = Backtest.blockBootstrap(v, 8, 1000, 42)
        assertEquals(a, b)
        assertTrue(a.low <= a.mean && a.mean <= a.high)
        assertTrue(a.high - a.low > 0)
        val c = Backtest.blockBootstrap(DoubleArray(50) { 1.5 }, 8, 200, 1)
        assertEquals(1.5, c.low, 1e-12); assertEquals(1.5, c.high, 1e-12)
        // الكتل توسّع الفترة لسلسلة مرتبطة زمنيًا مقارنة بالعينة المستقلة (طول الكتلة 1)
        val trend = DoubleArray(300) { i -> if ((i / 30) % 2 == 0) 1.0 else -1.0 }
        val iid = Backtest.blockBootstrap(trend, 1, 2000, 7)
        val blk = Backtest.blockBootstrap(trend, 30, 2000, 7)
        assertTrue(blk.high - blk.low > iid.high - iid.low)
    }

    @Test
    fun radarReport_unprovenBelow100OutOfSampleCases() {
        val series = (0 until 5).associate { "S$it" to spikeSeries(20_000.0) }
        val out = Backtest.scanSignals(series, series.keys.associateWith { 1.0 })
        val report = Backtest.evaluate(out, "spot", 5, 5, 0)
        assertEquals(5, report.totalSignals)
        assertFalse(report.proven)
        assertTrue(report.verdict.contains(AppConfig.UNPROVEN))
        assertNotNull(report.definition)
    }
}
