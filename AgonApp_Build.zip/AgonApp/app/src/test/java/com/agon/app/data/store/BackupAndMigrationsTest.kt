package com.agon.app.data.store

import com.agon.app.data.providers.Market
import com.agon.app.domain.model.AlertStateRow
import com.agon.app.domain.model.DecisionRecord
import com.agon.app.domain.model.Direction
import com.agon.app.domain.model.Trade
import com.agon.app.domain.model.TradeFrame
import com.agon.app.domain.model.WatchItem
import com.agon.app.domain.model.WatchTag
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BackupAndMigrationsTest {
    private val sample = BackupData(
        dbVersion = Migrations.LATEST, exportedAt = 123L,
        watchlist = listOf(WatchItem(1, "BTCUSDT", Market.SPOT, WatchTag.STUDY, 0, 5), WatchItem(2, "ETHUSDT", Market.FUTURES, WatchTag.DEFERRED, 1, 6)),
        trades = listOf(Trade(3, "SOLUSDT", Market.FUTURES, Direction.SHORT, TradeFrame.DAILY, 150.0, 5.0, 130.0, 158.0, 500.0, "ملاحظة عربية", 171.5)),
        alertStates = listOf(AlertStateRow("trade:3:TARGET_NEAR", 3, "TARGET_NEAR", "", 99, 0.81)),
        decisions = listOf(DecisionRecord(4, 10, "study", 9, "SOLUSDT", Market.FUTURES, -1, -0.4, 150.0, 0.0001, 12345.0, "{\"k\":1}", ret4h = 1.2)),
        settings = mapOf("settings" to "{}"),
    )

    @Test
    fun backup_roundTripPreservesEverything() {
        val text = BackupCodec.encode(sample)
        val back = BackupCodec.decode(text)
        assertEquals(sample, back)
        assertTrue(text.contains("\"app\": \"ghaith-trading\""))
    }

    @Test
    fun backup_containsNoSecretsOrPriceHistoryFields() {
        val text = BackupCodec.encode(sample).lowercase()
        listOf("token", "apikey", "api_key", "secret", "klines", "candles").forEach { assertFalse("حقل غير متوقع: $it", text.contains(it)) }
    }

    @Test
    fun backup_rejectsForeignCorruptAndNewerFiles() {
        fun rejects(text: String) = try { BackupCodec.decode(text); false } catch (e: BackupFormatException) { true }
        assertTrue(rejects("not json"))
        assertTrue(rejects("{\"app\":\"other\"}"))
        assertTrue(rejects("{\"app\":\"ghaith-trading\",\"schemaVersion\":999}"))
        // حقول مجهولة من إصدار لاحق متوافق تُتجاهل
        try {
            BackupCodec.decode("{\"app\":\"ghaith-trading\",\"schemaVersion\":1,\"futureField\":true}")
        } catch (e: Exception) {
            fail("يجب قبول الحقول المجهولة: ${e.message}")
        }
    }

    @Test
    fun migrations_areNumberedContiguouslyFromOne() {
        assertTrue(Migrations.validate())
        assertEquals(Migrations.ALL.size, Migrations.LATEST)
        assertEquals(listOf(1, 2), Migrations.between(0, 2).map { it.version })
        assertEquals(listOf(2), Migrations.between(1, 2).map { it.version })
        assertTrue(Migrations.between(2, 2).isEmpty())
        // لا جداول لحفظ الأسعار أو الشموع
        val ddl = Migrations.ALL.flatMap { it.statements }.joinToString("\n").lowercase()
        listOf("create table klines", "create table candles", "create table prices", "create table tickers").forEach { assertFalse(ddl.contains(it)) }
    }
}
