package com.agon.app.soak

import com.agon.app.data.providers.BinanceEndpoints
import com.agon.app.data.providers.BinanceRest
import com.agon.app.data.providers.BookSyncState
import com.agon.app.data.providers.Market
import com.agon.app.data.providers.StreamCategory
import com.agon.app.data.providers.StreamConnection
import com.agon.app.data.providers.SymbolSession
import com.agon.app.data.providers.TickerHub
import com.agon.app.data.providers.WsState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.system.exitProcess

/**
 * اختبار WebSocket معزول (JVM، بلا Android) يشغّل نفس أصناف الإنتاج:
 * TickerHub (!miniTicker@arr) + SymbolSession (kline 1m/5m/1h + depth + aggTrade) على Spot
 * عبر النطاق الرسمي لبيانات السوق (data-stream.binance.vision).
 *
 * الاستخدام: SoakMain <minutes> <outDir> <forceReconnectEverySec> [spot|futures]
 * يقطع الاتصال قسريًا كل N ثانية لمحاكاة تبديل الشبكة، ويقيس زمن التعافي وإعادة مزامنة الدفتر.
 */
object SoakMain {
    private fun pct(sorted: List<Long>, p: Double): Long = if (sorted.isEmpty()) -1 else sorted[(sorted.size * p).toInt().coerceAtMost(sorted.size - 1)]

    @JvmStatic
    fun main(args: Array<String>) {
        val minutes = args.getOrNull(0)?.toDoubleOrNull() ?: 30.0
        val outDir = File(args.getOrNull(1) ?: "soak-out").apply { mkdirs() }
        val forceEverySec = args.getOrNull(2)?.toLongOrNull() ?: 300L
        val market = if (args.getOrNull(3) == "futures") Market.FUTURES else Market.SPOT
        val symbol = "BTCUSDT"
        val log = File(outDir, "soak.log")
        fun say(s: String) {
            val line = "${java.time.Instant.now()} $s"
            println(line)
            log.appendText(line + "\n")
        }

        val endpoints = BinanceEndpoints.config(spotDataOnly = true)
        val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).connectTimeout(10, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).build()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val rest = BinanceRest(http, { endpoints })
        val hubConn = StreamConnection(http, "soak-hub", scope, { BinanceEndpoints.wsBase(endpoints, market, StreamCategory.MARKET) })
        val hub = TickerHub(market, rest, hubConn, scope)
        val session = SymbolSession(market, symbol, rest, http, { endpoints }, scope)

        val t0 = System.currentTimeMillis()
        val endAt = t0 + (minutes * 60_000).toLong()
        say("START market=${market.id} symbol=$symbol minutes=$minutes forceEverySec=$forceEverySec ws=${BinanceEndpoints.wsBase(endpoints, market, StreamCategory.MARKET)}")

        var firstPriceMs = -1L
        var firstBookSyncMs = -1L
        var maxHubSilenceMs = 0L
        var seconds = 0
        var hubOpenSeconds = 0
        var bookSyncedSeconds = 0
        var quietNotStaleMax = 0
        var staleWhileOpenViolations = 0
        var forced = 0
        val hubRecoveries = ArrayList<Long>()
        val sessionRecoveries = ArrayList<Long>()
        val bookResyncTimes = ArrayList<Long>()
        var bookChecks = 0
        var bookCheckOk = 0
        var maxHeapMb = 0L
        var closes = 0L
        var pendingHubForceAt = 0L
        var pendingSessionForceAt = 0L
        var pendingBookAt = 0L
        var lastForceAt = t0
        var lastReport = t0
        var lastBookCheck = t0
        var errors = 0

        runBlocking {
            hub.acquireAll("soak")
            session.start()
            while (System.currentTimeMillis() < endAt) {
                delay(250)
                val now = System.currentTimeMillis()
                val hs = hubConn.health.value
                val st = session.state.value
                if (firstPriceMs < 0 && hub.get(symbol) != null) { firstPriceMs = now - t0; say("first price for $symbol after ${firstPriceMs}ms (source=${hub.get(symbol)?.source})") }
                if (firstBookSyncMs < 0 && st.bookStatus.state == BookSyncState.SYNCED) { firstBookSyncMs = now - t0; say("book first SYNCED after ${firstBookSyncMs}ms snapshots=${st.bookStatus.snapshotFetches}") }
                if (pendingHubForceAt > 0 && hs.state == WsState.OPEN && hubConn.lastFrameAt > pendingHubForceAt) { hubRecoveries += hubConn.lastFrameAt - pendingHubForceAt; pendingHubForceAt = 0 }
                if (pendingSessionForceAt > 0 && st.connected && st.lastFrameAt > pendingSessionForceAt) { sessionRecoveries += st.lastFrameAt - pendingSessionForceAt; pendingSessionForceAt = 0 }
                if (pendingBookAt > 0 && pendingSessionForceAt == 0L && st.bookStatus.state == BookSyncState.SYNCED && st.bookStatus.lastSyncedAt > pendingBookAt) { bookResyncTimes += st.bookStatus.lastSyncedAt - pendingBookAt; pendingBookAt = 0 }

                if (now - t0 >= (seconds + 1) * 1000L) {
                    seconds++
                    if (hs.state == WsState.OPEN) {
                        hubOpenSeconds++
                        if (hubConn.lastFrameAt > 0) maxHubSilenceMs = maxOf(maxHubSilenceMs, now - hubConn.lastFrameAt)
                        val snap = hub.snapshot()
                        // رموز لم تتغير منذ دقيقة والاتصال سليم: يجب ألا تُوسم «قديمة»
                        val quiet = snap.count { now - it.fetchedAt > 60_000 }
                        quietNotStaleMax = maxOf(quietNotStaleMax, quiet)
                        if (!hub.status.value.staleMarked && snap.any { it.stale }) staleWhileOpenViolations++
                    }
                    if (st.bookStatus.state == BookSyncState.SYNCED) bookSyncedSeconds++
                    closes = st.closeSeq
                    val rt = Runtime.getRuntime()
                    maxHeapMb = maxOf(maxHeapMb, (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024))
                }

                if (forceEverySec > 0 && now - lastForceAt >= forceEverySec * 1000 && endAt - now > 30_000) {
                    lastForceAt = now
                    forced++
                    if (forced % 2 == 1) {
                        pendingHubForceAt = now
                        hub.forceReconnect("soak-simulated-network-change")
                        say("FORCE #$forced hub reconnect")
                    } else {
                        pendingSessionForceAt = now
                        pendingBookAt = now
                        session.forceReconnect("soak-simulated-network-change")
                        say("FORCE #$forced symbol-session reconnect (book must rebuild from a new snapshot)")
                    }
                }

                if (now - lastBookCheck >= 60_000 && st.bookStatus.state == BookSyncState.SYNCED && st.book != null) {
                    lastBookCheck = now
                    try {
                        val restTop = rest.depthSnapshot(market, symbol, 5)
                        val local = session.state.value.book
                        if (local != null && restTop.bids.isNotEmpty()) {
                            bookChecks++
                            val diffPct = abs(local.bestBid - restTop.bids[0].price) / restTop.bids[0].price * 100
                            val ok = diffPct < 0.05 && local.bestBid < local.bestAsk
                            if (ok) bookCheckOk++
                            say("book-check #$bookChecks localBid=${local.bestBid} restBid=${restTop.bids[0].price} diff=${String.format(Locale.US, "%.4f", diffPct)}% crossed=${local.bestBid >= local.bestAsk} ok=$ok")
                        }
                    } catch (t: Throwable) { errors++; say("book-check error: ${t.message}") }
                }

                if (now - lastReport >= 60_000) {
                    lastReport = now
                    val lat = hub.latency.summary()
                    say("t=${(now - t0) / 1000}s hub=${hs.state} frames=${hubConn.client.frames.get()} symbols=${hub.cache.size} reconnects=${hs.reconnects} lat(E->recv) p50=${lat.p50} p95=${lat.p95} n=${lat.n} | book=${st.bookStatus.state} resyncs=${st.bookStatus.resyncs} snapshots=${st.bookStatus.snapshotFetches} closes=$closes flowTrades=${st.flow.trades} buyRatio=${st.flow.buyRatio} heapMb=$maxHeapMb quietNotStale=$quietNotStaleMax hubErr=${hs.lastError} gap=${st.bookStatus.lastGapReason}")
                }
            }

            val hs = hubConn.health.value
            val st = session.state.value
            val lat = hub.latency.summary()
            val klat = session.latency.summary()
            // مغادرة الصفحة: يجب أن يُغلق الاتصال ويتوقف البث
            session.stop()
            delay(1500)
            val afterStop = session.state.value
            val json = buildString {
                append("{\n")
                fun kv(k: String, v: Any?, last: Boolean = false) = append("  \"$k\": ${if (v is String) "\"$v\"" else v}${if (last) "" else ","}\n")
                kv("environment", "JVM harness in build sandbox (not an Android device)")
                kv("market", market.id); kv("symbol", symbol)
                kv("wsBase", BinanceEndpoints.wsBase(endpoints, market, StreamCategory.MARKET))
                kv("startedAt", java.time.Instant.ofEpochMilli(t0).toString())
                kv("durationSec", (System.currentTimeMillis() - t0) / 1000)
                kv("timeToFirstPriceMs", firstPriceMs)
                kv("timeToFirstBookSyncMs", firstBookSyncMs)
                kv("hubFrames", hubConn.client.frames.get())
                kv("hubSymbolsCached", hub.cache.size)
                kv("hubConnects", hs.connects); kv("hubReconnects", hs.reconnects)
                kv("hubOpenSeconds", hubOpenSeconds); kv("sampledSeconds", seconds)
                kv("hubMaxSilenceWhileOpenMs", maxHubSilenceMs)
                kv("latencyEventToReceive_p50_ms", lat.p50); kv("latencyEventToReceive_p95_ms", lat.p95); kv("latencyEventToReceive_n", lat.n)
                kv("klineLatency_p50_ms", klat.p50); kv("klineLatency_p95_ms", klat.p95); kv("klineLatency_n", klat.n)
                kv("latencyNote", "E (Binance event time) to local receive; includes clock skew between sandbox and Binance")
                kv("forcedReconnects", forced)
                kv("hubRecoveryMs_p50", pct(hubRecoveries.sorted(), 0.5)); kv("hubRecoveryMs_max", hubRecoveries.maxOrNull() ?: -1); kv("hubRecoveries_n", hubRecoveries.size)
                kv("sessionRecoveryMs_p50", pct(sessionRecoveries.sorted(), 0.5)); kv("sessionRecoveryMs_max", sessionRecoveries.maxOrNull() ?: -1); kv("sessionRecoveries_n", sessionRecoveries.size)
                kv("bookResyncMs_p50", pct(bookResyncTimes.sorted(), 0.5)); kv("bookResyncMs_max", bookResyncTimes.maxOrNull() ?: -1); kv("bookResyncs_n", bookResyncTimes.size)
                kv("bookSyncedSeconds", bookSyncedSeconds)
                kv("bookGapResyncs", st.bookStatus.resyncs); kv("bookSnapshotFetches", st.bookStatus.snapshotFetches)
                kv("bookTopOfBookChecks", bookChecks); kv("bookTopOfBookChecksOk", bookCheckOk)
                kv("klineCloseEvents", closes)
                kv("quietSymbolsOver60sWhileOpen_max", quietNotStaleMax)
                kv("staleFlagWhileConnectedViolations", staleWhileOpenViolations)
                kv("maxHeapMb_jvm", maxHeapMb)
                kv("restUsedWeight1m_last", rest.limiter.usedWeight1m[market] ?: 0)
                kv("errors", errors)
                kv("afterStop_started", afterStop.started); kv("afterStop_connections", afterStop.health.size, last = true)
                append("}\n")
            }
            File(outDir, "soak-report.json").writeText(json)
            say("REPORT\n$json")
            say("DONE")
        }
        scope.cancel()
        http.dispatcher.executorService.shutdown()
        http.connectionPool.evictAll()
        exitProcess(0)
    }
}
