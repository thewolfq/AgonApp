# غيث التداول — تعليمات إعادة البناء على Android 16

## ما تم التحقق منه
- أرشيف المشروع الأصلي سليم ويمكن استخراج ملفاته.
- ملف APK السابق غير سليم كأرشيف ZIP؛ فشل فك الضغط داخل `classes.dex` و`classes12.dex`، لذلك لا يصلح لإعادة التثبيت أو الإصلاح المباشر.
- إعدادات المشروع الحالية: `applicationId=com.ghaith.app`، و`minSdk=26`، و`compileSdk=36`، و`targetSdk=36`.
- لم يتم تغيير كود التطبيق في هذه النسخة؛ أزيل فقط ملف `local.properties` لأنه يحتوي على مسار SDK خاص بجهاز آخر.

## المتطلبات
- Android Studio Meerkat (2024.3.1) أو أحدث.
- JDK 17 لاستخدام Gradle/Android Gradle Plugin.
- Android SDK Platform 36.
- Android SDK Build-Tools 36.0.0.
- Gradle 8.11.1. يتطلب Android Gradle Plugin 8.10.1 هذا الإصدار أو أحدث ضمن سلسلة 8.11.1.

## ملاحظة مهمة عن Gradle Wrapper
الأرشيف الأصلي لا يحتوي على `gradle/wrapper/gradle-wrapper.jar`، رغم وجود `gradlew` و`gradlew.bat` وملف `gradle-wrapper.properties`.
بعد تثبيت Gradle 8.11.1 محلياً وإضافة أمر `gradle` إلى PATH، افتح الطرفية في مجلد المشروع ونفّذ:

```bash
gradle wrapper --gradle-version 8.11.1
```

هذا ينشئ ملف Gradle Wrapper الناقص. بعد ذلك نفّذ على Linux/macOS:

```bash
./gradlew clean assembleDebug testDebugUnitTest
```

وعلى Windows:

```bat
gradlew.bat clean assembleDebug testDebugUnitTest
```

## مكان ملف APK الناتج
إذا انتهى البناء بنجاح، ستجد نسخة Debug هنا:

`app/build/outputs/apk/debug/app-debug.apk`

انقل هذا الملف إلى الهاتف وثبّته. أو ثبّته عبر ADB:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## التوقيع
إعداد Debug يستخدم `debug.keystore` الموجود في المشروع. هذا مناسب للاختبار المحلي فقط، وليس مفتاح توقيع إصدار Google Play. للنشر العام يجب إعداد مفتاح Release خاص وآمن وعدم فقدانه.

## حدود هذه النسخة
هذه حزمة مصدر مجهّزة لإعادة البناء وليست APK جديداً. لم يتم تشغيل Gradle build أو اختبارات Kotlin في بيئة الفحص لعدم توفر Android SDK/Gradle Wrapper JAR ولتعذر تنزيل الأدوات من الشبكة هنا. لذلك لا تعتبرها نسخة مختبرة على الهاتف حتى ينجح البناء والتثبيت فعلياً.
