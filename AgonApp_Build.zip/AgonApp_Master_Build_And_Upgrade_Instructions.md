# تعليمات بناء وفحص AgonApp 0.3.0

1. ارفع محتويات `AgonApp_Build.zip` إلى جذر مستودع GitHub، مع إظهار `.github` و`gradlew` و`settings.gradle.kts` في الجذر.
2. شغّل GitHub Actions workflow باسم CI. يجب أن تنجح اختبارات `testDebugUnitTest` و`core-domain:test` و`core-data:test` و`core-store:test` و`lintDebug` و`assembleDebug` و`assembleDebugAndroidTest` وفحص 16KB.
3. شغّل workflow باسم Instrumented يدوياً؛ يجب أن ينجح `connectedDebugAndroidTest` على محاكي API 36.
4. نزّل APK من artifact `app-debug`. قد يقدمه GitHub داخل ZIP خاص بالـartifact؛ استخرج APK مرة واحدة، أو استخدم GitHub Release asset عند إعداد إصدار موقّع.
5. لا تستخدم APK Debug كتحديث فوق نسخة قديمة قبل التأكد من تطابق شهادة التوقيع. لا تحذف النسخة القديمة أو بياناتها لمجرد تجربة APK.
6. لا توجد مفاتيح إصدار مضمنة. لإعداد توقيع دائم، خزّن `KEYSTORE_BASE64` و`KEYSTORE_PASSWORD` و`KEY_ALIAS` و`KEY_PASSWORD` في GitHub Secrets فقط، ولا ترفعها إلى المستودع.
7. لا تعتبر أي فحص ناجحاً إلا إذا ظهر نجاحه فعلياً في GitHub. راجع `REPAIR_AND_VALIDATION_REPORT.md` لمعرفة حدود التحقق المنفذ محلياً.

المشروع يستهدف `compileSdk 36` و`targetSdk 36` وJDK 17، ويحافظ على `applicationId=com.ghaith.trading`. لا يدّعي هذا الإصدار تكاملات خارجية لم يثبت وجودها في الشفرة.
