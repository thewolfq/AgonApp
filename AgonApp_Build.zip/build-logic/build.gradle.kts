plugins {
    `kotlin-dsl`
}

kotlin {
    jvmToolchain(libs.versions.jvmTarget.get().toInt())
}

dependencies {
    compileOnly(libs.android.gradlePlugin)
    compileOnly(libs.kotlin.gradlePlugin)
    compileOnly(libs.compose.gradlePlugin)
}

gradlePlugin {
    plugins {
        register("gaithJvmLibrary") {
            id = "gaith.jvm.library"
            implementationClass = "GaithJvmLibraryPlugin"
        }
        register("gaithAndroidLibrary") {
            id = "gaith.android.library"
            implementationClass = "GaithAndroidLibraryPlugin"
        }
        register("gaithAndroidApplication") {
            id = "gaith.android.application"
            implementationClass = "GaithAndroidApplicationPlugin"
        }
    }
}
