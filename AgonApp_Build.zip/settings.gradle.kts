pluginManagement {
    includeBuild("build-logic")
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "gaith-trading"

// الوحدات الخمس (§2.1 من 01_architecture): build-logic (مُضمَّن أعلاه) + الأربع التالية.
include(":core-domain")
include(":core-data")
include(":core-store")
include(":app")
