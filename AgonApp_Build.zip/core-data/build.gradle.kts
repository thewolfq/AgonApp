plugins {
    id("gaith.jvm.library")
}

// M0: هيكل الوحدة فقط. BinanceData.kt يُبنى في M1 (§4 من 01_architecture).
dependencies {
    implementation(project(":core-domain"))
    testImplementation(libs.junit)
}
