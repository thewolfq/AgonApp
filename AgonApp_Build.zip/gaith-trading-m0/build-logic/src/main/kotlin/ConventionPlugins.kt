import com.android.build.api.dsl.ApplicationExtension
import com.android.build.api.dsl.CommonExtension
import com.android.build.api.dsl.LibraryExtension
import org.gradle.api.GradleException
import org.gradle.api.JavaVersion
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.artifacts.VersionCatalogsExtension
import org.gradle.api.tasks.testing.Test
import org.gradle.api.tasks.testing.logging.TestExceptionFormat
import org.gradle.api.tasks.testing.logging.TestLogEvent
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.dsl.KotlinAndroidProjectExtension
import org.jetbrains.kotlin.gradle.dsl.KotlinJvmProjectExtension

/*
 * إضافات الاتفاق (Convention Plugins) — §2.1 و§6.3 من 01_architecture.
 * توحّد: إصدارات SDK (26/36) من الكتالوج، إعداد Kotlin الصارم (التحذيرات أخطاء)،
 * إعداد Lint (فشل عند أي خطأ)، وإعداد سجلات الاختبار الكاملة.
 * لا رقم مدفون: كل الإصدارات تُقرأ من gradle/libs.versions.toml.
 */

private fun Project.catalogVersion(name: String): String {
    val catalog = extensions.getByType(VersionCatalogsExtension::class.java).named("libs")
    val version = catalog.findVersion(name)
    if (!version.isPresent) {
        throw GradleException("libs.versions.toml: missing version '$name'")
    }
    return version.get().requiredVersion
}

private fun Project.javaVersionFromCatalog(): JavaVersion =
    JavaVersion.toVersion(catalogVersion("jvmTarget"))

private fun Project.jvmTargetFromCatalog(): JvmTarget =
    JvmTarget.fromTarget(catalogVersion("jvmTarget"))

private fun Project.configureTestLogging() {
    tasks.withType(Test::class.java).configureEach {
        testLogging {
            events(TestLogEvent.PASSED, TestLogEvent.SKIPPED, TestLogEvent.FAILED)
            exceptionFormat = TestExceptionFormat.FULL
            showExceptions = true
            showCauses = true
            showStackTraces = true
            showStandardStreams = true
        }
    }
}

private fun Project.configureAndroidCommon(extension: CommonExtension<*, *, *, *, *, *>) {
    extension.compileSdk = catalogVersion("compileSdk").toInt()
    extension.defaultConfig.minSdk = catalogVersion("minSdk").toInt()
    extension.compileOptions.sourceCompatibility = javaVersionFromCatalog()
    extension.compileOptions.targetCompatibility = javaVersionFromCatalog()
    extension.lint.abortOnError = true
    extension.lint.checkReleaseBuilds = true
    extension.lint.warningsAsErrors = false
    extension.testOptions.unitTests.isReturnDefaultValues = false

    extensions.configure(KotlinAndroidProjectExtension::class.java) {
        compilerOptions {
            jvmTarget.set(jvmTargetFromCatalog())
            allWarningsAsErrors.set(true)
        }
    }
    configureTestLogging()
}

/** وحدة Kotlin/JVM نقية (core-domain، core-data). */
class GaithJvmLibraryPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            pluginManager.apply("org.jetbrains.kotlin.jvm")
            extensions.configure(KotlinJvmProjectExtension::class.java) {
                jvmToolchain(catalogVersion("jvmTarget").toInt())
                compilerOptions {
                    jvmTarget.set(jvmTargetFromCatalog())
                    allWarningsAsErrors.set(true)
                }
            }
            tasks.withType(Test::class.java).configureEach {
                useJUnit()
            }
            configureTestLogging()
        }
    }
}

/** وحدة مكتبة Android (core-store). */
class GaithAndroidLibraryPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            pluginManager.apply("com.android.library")
            pluginManager.apply("org.jetbrains.kotlin.android")
            extensions.configure(LibraryExtension::class.java) {
                configureAndroidCommon(this)
                defaultConfig.testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
            }
        }
    }
}

/** وحدة التطبيق (app) مع Compose. */
class GaithAndroidApplicationPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            pluginManager.apply("com.android.application")
            pluginManager.apply("org.jetbrains.kotlin.android")
            pluginManager.apply("org.jetbrains.kotlin.plugin.compose")
            extensions.configure(ApplicationExtension::class.java) {
                configureAndroidCommon(this)
                defaultConfig.targetSdk = catalogVersion("targetSdk").toInt()
                defaultConfig.testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
                buildFeatures.compose = true
            }
        }
    }
}
