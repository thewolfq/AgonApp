package com.ghaith.trading

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.testTag
import com.ghaith.trading.ui.theme.GaithTheme

/*
 * MainActivity — النشاط الوحيد (§6.3 من 01_architecture).
 * M0: العرض من الحافة إلى الحافة، RTL عبر GaithTheme، Insets عبر Scaffold،
 * والرجوع التنبؤي مفعّل في البيان (enableOnBackInvokedCallback).
 * مضيف التنقل والشاشات السبع تُبنى في M3/M5 (AppNavigation.kt). لا أزرار في M0.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            GaithTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { insets ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(insets),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.semantics { testTag = TAG_APP_TITLE },
                        )
                    }
                }
            }
        }
    }

    companion object {
        const val TAG_APP_TITLE = "app_title"
    }
}
