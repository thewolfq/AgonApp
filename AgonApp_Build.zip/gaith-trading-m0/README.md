# غيث التداول - GAITH TRADING

تطبيق Android للتحليل الكمي وإدارة المخاطر والتداول **الورقي** فقط على عقود Binance USDT-M الدائمة
(هامش معزول، اتجاه واحد). لا يحتوي التطبيق على أي مسار لإرسال أوامر حقيقية.

- `applicationId`: `com.ghaith.trading`
- `minSdk 26` · `targetSdk 36` · `compileSdk 36`
- المرحلة الحالية: **M0** (انظر `BUILD_MANIFEST.md` لحالة كل بوابة وبنود `NOT_RUN`).

## الوحدات

| الوحدة | النوع | الدور |
|---|---|---|
| `build-logic` | Included build (Convention Plugins) | توحيد إعداد Kotlin/Android/Lint/الاختبارات |
| `core-domain` | Kotlin/JVM نقي | النواة المالية (لا `android.*`، لا Double/Float في المال) |
| `core-data` | Kotlin/JVM | عميل Binance العام (M1) |
| `core-store` | Android library | SQLite الإطاري بنمط Append-Only (M1) |
| `app` | Android application (Compose) | الواجهة RTL |

## البناء محلياً

المتطلبات: JDK 17، Android SDK (platform `android-36`، build-tools `35.0.0`).

```bash
echo "sdk.dir=/path/to/Android/sdk" > local.properties   # لا يُرفع (في .gitignore)
./gradlew test assembleDebug          # اختبارات JVM + ArchUnit + APK تطوير
./gradlew lintDebug                   # الفحص الثابت (يفشل عند أي خطأ)
./gradlew :core-domain:test --tests 'com.ghaith.trading.domain.arch.ArchitectureRulesTest'
```

الـAPK الناتج: `app/build/outputs/apk/debug/app-debug.apk`.

> ملاحظة التحقق من التبعيات: `gradle/verification-metadata.xml` يحوي SHA-256 لكل مكوّن مُنزَّل،
> وقد وُلّد على Linux x86_64. بعض أدوات Android (مثل `aapt2`) لها مصنِّف حسب نظام التشغيل؛
> على macOS/Windows أعد توليد البيانات (انظر «إجراء التحديث»).

## CI (GitHub Actions)

| الملف | المحفّز | الخطوات |
|---|---|---|
| `.github/workflows/ci.yml` | `push`/`pull_request` على `main` | التحقق من الـwrapper → `testDebugUnitTest` + اختبارات JVM → ArchUnit → `lintDebug` → `assembleDebug` → فحص 16KB → رفع APK + SHA-256 |
| `.github/workflows/instrumented.yml` | يدوي `workflow_dispatch` | محاكي API 36 → `connectedDebugAndroidTest` |
| `.github/workflows/release.yml` | وسم `v*` | اختبارات + Lint → `assembleRelease` (R8) → توقيع أو بديل غير موقّع → `mapping.txt` → أرشيف المصدر → `MANIFEST.sha256` |

### أسرار التوقيع (اختيارية)

في *Settings → Secrets and variables → Actions*:
`KEYSTORE_BASE64`، `KEYSTORE_PASSWORD`، `KEY_ALIAS`، `KEY_PASSWORD`.

توليد `KEYSTORE_BASE64` محلياً: `base64 -w0 release.jks`.
عند غياب أي منها لا يفشل الأنبوب، ويُخرج `release-unsigned.apk`.

### توقيع `release-unsigned.apk` محلياً بـ `apksigner`

```bash
BT=$ANDROID_HOME/build-tools/35.0.0
$BT/zipalign -f -P 16 -v 4 release-unsigned.apk aligned.apk
$BT/apksigner sign --ks /path/to/release.jks --ks-key-alias <alias> --out gaith-trading.apk aligned.apk
$BT/apksigner verify --verbose --print-certs gaith-trading.apk
adb install -r gaith-trading.apk
```

لا تضع ملف `.jks`/`.keystore` داخل المستودع (مستثنى في `.gitignore`).

## اختبارات الأجهزة (Instrumented)

- عبر CI: *Actions → Instrumented → Run workflow*.
- على الجهاز: فعّل «تصحيح USB» ثم `./gradlew connectedDebugAndroidTest`.
- حالتها `NOT_RUN` حتى يُرفق ناتج تشغيل فعلي (التقارير في `**/build/reports/androidTests/`).

## إجراء التحديث (تبعيات/أدوات)

1. عدّل الإصدار الدقيق في `gradle/libs.versions.toml` (لا `+` ولا `latest`).
2. أعد توليد بيانات التحقق:
   `./gradlew --write-verification-metadata sha256 test lintDebug assembleDebug assembleDebugAndroidTest assembleRelease`
3. راجع الفرق في `gradle/verification-metadata.xml` قبل الدمج.
4. شغّل CI كاملاً (بما فيه Instrumented يدوياً).
5. حدّث `BUILD_MANIFEST.md` (مراجعة التوافق) و`MANIFEST.sha256` يولّده مسار الإطلاق.

## مفتاح القراءة الاختياري (يُستعمل من M1/M5)

- التطبيق يعمل كاملاً **بلا مفتاح**؛ المفتاح يجلب شرائح الهامش والرسوم الموقّعة بدل `ESTIMATED`.
- أنشئ مفتاحاً **للقراءة فقط** (التداول والسحب معطّلان). التطبيق لا يحوي مسار أوامر أصلاً.
- تقييد المفتاح بعنوان IP موثوق مستحسن، لكن عنوان الجوال المتغير قد يُفشل المصادقة
  ويظهر حينها `ApiKeyStatus=INVALID` في الإعدادات.
- يُخزَّن المفتاح مشفراً بـ Android Keystore (`AES/GCM/NoPadding`) ولا يُكتب نصاً صريحاً.
