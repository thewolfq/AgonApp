# غيث التداول - GAITH TRADING

تطبيق Android للتحليل الكمي وإدارة المخاطر والتداول **الورقي** فقط على عقود Binance USDT-M الدائمة
(هامش معزول، اتجاه واحد). لا يحتوي التطبيق على أي مسار لإرسال أوامر حقيقية.

- `applicationId`: `com.ghaith.trading`
- `minSdk 26` · `targetSdk 36` · `compileSdk 36`
- إصدار التطبيق في هذا الأرشيف: **0.3.0** (versionCode 3). النطاق المنفذ موضح في قسم الإصدار أدناه؛ بقية مراحل المواصفة الأصلية ليست مكتملة بعد، راجع `BUILD_MANIFEST.md`.

## الوحدات

| الوحدة | النوع | الدور |
|---|---|---|
| `build-logic` | Included build (Convention Plugins) | توحيد إعداد Kotlin/Android/Lint/الاختبارات |
| `core-domain` | Kotlin/JVM نقي | النواة المالية (لا `android.*`، لا Double/Float في المال) |
| `core-data` | Kotlin/JVM | هيكل الوحدة المحجوز لمرحلة M1؛ عميل Binance الفعلي موجود حاليًا في `app/data/BinanceApi.kt` |
| `core-store` | Android library | هيكل الوحدة المحجوز لمرحلة M1؛ حفظ الحساب الفعلي حاليًا عبر `SharedPreferences` في `app/data/PaperStore.kt` وليس SQLite بعد |
| `app` | Android application (Compose) | الواجهة RTL |

## البناء محلياً

المتطلبات: JDK 17، Android SDK (platform `android-36`، build-tools `35.0.0`).

```bash
echo "sdk.dir=/path/to/Android/sdk" > local.properties   # لا يُرفع (في .gitignore)
./gradlew test assembleDebug          # اختبارات JVM + ArchUnit + APK تطوير
./gradlew lintDebug                   # الفحص الثابت (يفشل عند أي خطأ)
./gradlew :core-domain:test --tests 'com.ghaith.trading.domain.arch.ArchitectureRulesTest'
```

الـAPK الناتج: `app/build/outputs/apk/debug/app-debug.apk`.

> ملاحظة التحقق من التبعيات: `gradle/verification-metadata.xml` يحوي SHA-256 لكل مكوّن مُنزَّل،
> وقد وُلّد على Linux x86_64. بعض أدوات Android (مثل `aapt2`) لها مصنِّف حسب نظام التشغيل؛
> على macOS/Windows أعد توليد البيانات (انظر «إجراء التحديث»).

## الرفع إلى GitHub (مهم)

- فكّ الضغط وارفع **محتويات** المجلد بحيث يكون `.github/` و`gradlew` و`settings.gradle.kts` في **جذر المستودع** مباشرة.
  وجود الملفات داخل مجلد فرعي يمنع GitHub من رؤية الـworkflows فلا يبدأ أي بناء.
- لا حاجة لضبط صلاحية `gradlew`: الـworkflow يصلحها تلقائياً (`chmod +x` وإزالة CRLF).
- الـCI يعمل على أي فرع ويدوياً: *Actions → CI → Run workflow*. الـAPK في Artifacts باسم `app-debug`. ارفع محتويات ZIP بعد فك الضغط؛ لا يوجد workflow مخصص لرفع ZIP مغلف كما هو.

## دليل الاستخدام داخل التطبيق

1. افتح تبويب **السوق** بعد الاتصال بالإنترنت، واختر عقود آجلة عند البحث عن أصل لتجربة صفقة Futures، أو سبوت لمعاينة سوق السبوت. اختيار أي رمز ينقلك إلى الحاسبة؛ حساب الصفقات الورقية نفسه يستخدم أسعار عقود USDT-M الآجلة.
2. في **الحاسبة** اختر شراء (Long) أو بيع (Short)، ثم أدخل سعر الدخول والوقف والهدف الاختياري والرافعة ومبلغ المخاطرة. زر «السعر الحالي» يملأ سعر الدخول من بيانات العقود الآجلة. راجع الكمية والهامش والعمولات والتصفية التقريبية وصافي الخسارة والربح ونسبة المخاطرة إلى العائد قبل فتح الصفقة.
3. اضغط **فتح صفقة تجريبية** للانتقال إلى «صفقاتي». راقب السعر والربح الصافي بعد العمولات، أو أغلق المركز يدويًا. الوقف والهدف والتصفية تُراجع عند وصول تحديث سعر جديد.
4. **إعادة ضبط الحساب** تعيد رصيد البداية إلى 10,000 USDT وتمسح سجل الصفقات والمراكز والنسخة الاحتياطية. لا تستخدمها إلا عندما تريد حذف بيانات الحساب التجريبي فعلًا.

**مهم:** هذا ليس تنفيذًا حقيقيًا على Binance. تتم مراقبة الأسعار أثناء ظهور التطبيق فقط؛ وعند مغادرته أو فقد تغذية الأسعار تُغلق المراكز التجريبية التي لها آخر سعر محفوظ، ويُسجل أن الإغلاق تم بذلك السعر المحفوظ لا بسعر تنفيذ حقيقي. وإذا لم يتوفر سعر موثوق يبقى المركز مفتوحًا ويظهر تحذير بدل اختلاق سعر.

## CI (GitHub Actions)

| الملف | المحفّز | الخطوات |
|---|---|---|
| `.github/workflows/ci.yml` | أي `push` / `pull_request` + يدوي `workflow_dispatch` | التحقق من الـwrapper → `testDebugUnitTest` + اختبارات JVM → ArchUnit → `lintDebug` → `assembleDebug` → فحص 16KB → رفع APK + SHA-256 |
| `.github/workflows/instrumented.yml` | يدوي `workflow_dispatch` | محاكي API 36 → `connectedDebugAndroidTest` |
| `.github/workflows/release.yml` | وسم `v*` | اختبارات + Lint → `assembleRelease` (R8) → توقيع أو بديل غير موقّع → `mapping.txt` → أرشيف المصدر → `MANIFEST.sha256` |

### توقيع APK والتحديث فوق نسخة مثبتة

تحديث التطبيق يتطلب ثلاثة شروط معًا: `applicationId` نفسه، و`versionCode` أعلى، وشهادة التوقيع نفسها تمامًا. لذلك فإن APK التطوير `app-debug` مخصص للفحص؛ توقيع debug الذي ينشأ على مشغّل GitHub ليس مفتاح إصدار ثابتًا بين عمليات البناء.

في *Settings → Secrets and variables → Actions* ضع أسرار التوقيع الأربعة: `KEYSTORE_BASE64`، `KEYSTORE_PASSWORD`، `KEY_ALIAS`، `KEY_PASSWORD`. يجب أن تكون هذه **نفس keystore الأصلية** التي وقّعت النسخة المثبتة على الهاتف. لا تنشئ مفتاحًا جديدًا بديلًا إذا كان الهدف تحديث تطبيق مثبت؛ المفتاح المفقود لا يمكن استعادته من ملفات المصدر أو من APK وحده.

توليد `KEYSTORE_BASE64` محلياً: `base64 -w0 release.jks`. إذا لم تُضبط الأسرار، ينتج مسار الإصدار `release-unsigned.apk` غير الموقّع، وهو ليس APK جاهزًا للتثبيت قبل توقيعه. احتفظ بنسخة آمنة خارج GitHub للمفتاح وكلمات مروره.

### توقيع `release-unsigned.apk` محلياً بـ `apksigner`

```bash
BT=$ANDROID_HOME/build-tools/35.0.0
$BT/zipalign -f -P 16 -v 4 release-unsigned.apk aligned.apk
$BT/apksigner sign --ks /path/to/release.jks --ks-key-alias <alias> --out gaith-trading.apk aligned.apk
$BT/apksigner verify --verbose --print-certs gaith-trading.apk
adb install -r gaith-trading.apk
```

لا تضع ملف `.jks`/`.keystore` داخل المستودع (مستثنى في `.gitignore`).

## اختبارات الأجهزة (Instrumented)

- عبر CI: *Actions → Instrumented → Run workflow*.
- على الجهاز: فعّل «تصحيح USB» ثم `./gradlew connectedDebugAndroidTest`.
- حالتها `NOT_RUN` حتى يُرفق ناتج تشغيل فعلي (التقارير في `**/build/reports/androidTests/`).

## إجراء التحديث (تبعيات/أدوات)

1. عدّل الإصدار الدقيق في `gradle/libs.versions.toml` (لا `+` ولا `latest`).
2. أعد توليد بيانات التحقق:
   `./gradlew --write-verification-metadata sha256 test lintDebug assembleDebug assembleDebugAndroidTest assembleRelease`
3. راجع الفرق في `gradle/verification-metadata.xml` قبل الدمج.
4. شغّل CI كاملاً (بما فيه Instrumented يدوياً).
5. حدّث `BUILD_MANIFEST.md` (مراجعة التوافق) و`MANIFEST.sha256` يولّده مسار الإطلاق.

## مفتاح القراءة الاختياري (يُستعمل من M1/M5)

- التطبيق يعمل كاملاً **بلا مفتاح**؛ المفتاح يجلب شرائح الهامش والرسوم الموقّعة بدل `ESTIMATED`.
- أنشئ مفتاحاً **للقراءة فقط** (التداول والسحب معطّلان). التطبيق لا يحوي مسار أوامر أصلاً.
- تقييد المفتاح بعنوان IP موثوق مستحسن، لكن عنوان الجوال المتغير قد يُفشل المصادقة
  ويظهر حينها `ApiKeyStatus=INVALID` في الإعدادات.
- يُخزَّن المفتاح مشفراً بـ Android Keystore (`AES/GCM/NoPadding`) ولا يُكتب نصاً صريحاً.

## الإصدار 0.3.0 — النطاق المنفّذ حاليًا

- **السوق:** أسعار عقود USDT-M الآجلة والسبوت من بينانس، بحث وفرز، وتحديث كل 10 ثوانٍ أثناء ظهور التطبيق.
- **الحاسبة:** كمية المركز من مبلغ المخاطرة، الهامش، عمولة الدخول، سعر التصفية التقريبي، الخسارة عند الوقف، وصافي الربح ونسبة المخاطرة إلى العائد بعد الرسوم.
- **صفقاتي:** تداول ورقي برصيد 10,000 USDT، وقف/هدف/تصفية تلقائية، إغلاق يدوي، سجل، وحفظ محلي مع نسخة احتياطية.
- الأرباح المفتوحة تعرض الصافي بعد عمولتي الدخول والخروج المقدّرة. قيمة الحساب لا تخصم عمولة الدخول مرتين.
- تُحفظ آخر أسعار رموز المراكز؛ وعند فقد تغذية الأسعار أو مغادرة التطبيق تُغلق المراكز التي يتوفر لها سعر محفوظ مع تسجيل السبب. لا يُغلق مركز بلا سعر موثوق، ويظهر تحذير بذلك.
- شاشة «حول التطبيق» تعرض اسم المطوّر وحقوق 2026.
- يحتاج إنترنت. إن حجبت منطقتك بينانس يظهر تنبيه أعلى الشاشة (جرّب VPN).

**تنبيه نطاق مهم:** هذا الإصدار تطبيق عملي محدود بالأسواق والحاسبة والتداول الورقي. لا يحتوي بعد على بقية مواصفة M1–M6 مثل SQLite append-only، محركات الاستراتيجيات والاختبار التاريخي، خدمات المراقبة الخلفية، أو لوحة التحليل المتقدمة. وحدتا `core-data` و`core-store` ما زالتا هياكل تمهيدية. لا تعتبره تنفيذًا مكتملًا للمواصفة الأصلية حتى تُنجز تلك المراحل وتُختبر.
