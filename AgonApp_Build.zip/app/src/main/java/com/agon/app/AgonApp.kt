// File: AgonApp.kt
package com.agon.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.agon.app.coach.MatchCoach
import com.agon.app.data.PreferencesManager
import com.agon.app.data.TradeHistoryRepository
import com.agon.app.engine.PlaymakerEngine
import com.agon.app.risk.GoalkeeperRisk
import com.agon.app.scanner.MarketScanner
import com.agon.app.scanner.ScannerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * تطبيق AgonApp — يحتوي على كل singletons (DI يدوي بسيط).
 */
class AgonApp : Application() {

    lateinit var preferencesManager: PreferencesManager
    lateinit var tradeHistoryRepository: TradeHistoryRepository
    lateinit var marketScanner: MarketScanner
    lateinit var scannerRepository: ScannerRepository
    lateinit var playmakerEngine: PlaymakerEngine
    lateinit var goalkeeperRisk: GoalkeeperRisk
    lateinit var matchCoach: MatchCoach

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()

        preferencesManager = PreferencesManager(this)
        tradeHistoryRepository = TradeHistoryRepository(preferencesManager)
        marketScanner = MarketScanner(cacheDir)
        scannerRepository = ScannerRepository(marketScanner, appScope)
        playmakerEngine = PlaymakerEngine()
        goalkeeperRisk = GoalkeeperRisk(preferencesManager)
        matchCoach = MatchCoach()

        createNotificationChannel()
        appScope.launch { preferencesManager.resetDailyLossesIfNewDay() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "تنبيهات الصفقات",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "إشعارات فتح وإغلاق الصفقات" }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "agon_trades"
    }
}
