// File: SignalsViewModel.kt
package com.agon.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.PreferencesManager
import com.agon.app.engine.PlaymakerEngine
import com.agon.app.models.CircuitBreakerState
import com.agon.app.models.TradeCard
import com.agon.app.risk.GoalkeeperRisk
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel لشاشة الإشارات.
 */
class SignalsViewModel(
    private val engine: PlaymakerEngine,
    private val risk: GoalkeeperRisk,
    private val prefs: PreferencesManager
) : ViewModel() {

    data class UiState(
        val currentSignal: TradeCard? = null,
        val isLoading: Boolean = false,
        val errorMessage: String? = null,
        val guardianInstructions: String = "",
        val circuitBreaker: CircuitBreakerState = CircuitBreakerState()
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            prefs.circuitBreakerFlow.collect { cb ->
                _state.update { it.copy(circuitBreaker = cb) }
            }
        }
    }

    fun analyzeSymbol(symbol: String, currentPrice: Double) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, errorMessage = null) }
            engine.analyze(symbol, currentPrice).fold(
                onSuccess = { card ->
                    if (card == null) {
                        _state.update {
                            it.copy(isLoading = false, errorMessage = "لا توجد إشارة قوية على $symbol")
                        }
                    } else {
                        val config = prefs.riskConfigFlow.first()
                        val openCount = prefs.openTradesFlow.first().size
                        val validation = risk.validateAndPrepare(card, config.capitalUsdt, openCount)
                        if (validation.isValid && validation.tradeCard != null) {
                            _state.update {
                                it.copy(
                                    isLoading = false,
                                    currentSignal = validation.tradeCard,
                                    guardianInstructions = validation.guardianInstructions ?: "",
                                    errorMessage = null
                                )
                            }
                        } else {
                            _state.update {
                                it.copy(isLoading = false, errorMessage = validation.errorMessage)
                            }
                        }
                    }
                },
                onFailure = { e ->
                    _state.update { it.copy(isLoading = false, errorMessage = e.message ?: "خطأ") }
                }
            )
        }
    }

    fun dismiss() {
        _state.update { it.copy(currentSignal = null, errorMessage = null, guardianInstructions = "") }
    }
}
