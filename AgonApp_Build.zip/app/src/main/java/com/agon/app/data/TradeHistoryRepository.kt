// File: TradeHistoryRepository.kt
package com.agon.app.data

import com.agon.app.models.TradeHistoryEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * مستودع سجل الصفقات — يقرأ ويكتب عبر PreferencesManager.
 */
class TradeHistoryRepository(private val prefs: PreferencesManager) {

    fun getAllEntries(): Flow<List<TradeHistoryEntry>> = prefs.historyFlow

    suspend fun addEntry(entry: TradeHistoryEntry) {
        val current = prefs.historyFlow.first()
        prefs.saveHistory(current + entry)
    }

    suspend fun clearHistory() {
        prefs.clearHistory()
    }

    fun getTotalPnl(): Flow<Double> = prefs.historyFlow.map { list ->
        list.sumOf { it.pnlUsdt }
    }

    fun getWinRate(): Flow<Double> = prefs.historyFlow.map { list ->
        if (list.isEmpty()) 0.0
        else list.count { it.pnlUsdt > 0 } * 100.0 / list.size
    }

    fun getDailyPnl(startMillis: Long, endMillis: Long): Flow<Double> =
        prefs.historyFlow.map { list ->
            list.filter { it.closedAt in startMillis..endMillis }.sumOf { it.pnlUsdt }
        }
}
