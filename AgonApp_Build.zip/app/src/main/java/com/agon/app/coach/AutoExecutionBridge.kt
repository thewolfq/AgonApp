// File: AutoExecutionBridge.kt
package com.agon.app.coach

/**
 * واجهة التنفيذ الآلي — معطّلة في v1 (تدريب يدوي فقط).
 */
interface AutoExecutionBridge {
    val isEnabled: Boolean
    val bridgeName: String
    suspend fun placeOrder(symbol: String, side: String, type: String, quantity: Double, price: Double?): Result<String>
    suspend fun cancelOrder(symbol: String, orderId: String): Result<Unit>
    suspend fun getBalance(): Result<Double>
}

object DisabledAutoExecutionBridge : AutoExecutionBridge {
    override val isEnabled: Boolean = false
    override val bridgeName: String = "Disabled (Training Mode Only)"
    override suspend fun placeOrder(symbol: String, side: String, type: String, quantity: Double, price: Double?): Result<String> =
        Result.failure(UnsupportedOperationException("الربط الآلي غير مفعّل في v1"))
    override suspend fun cancelOrder(symbol: String, orderId: String): Result<Unit> =
        Result.failure(UnsupportedOperationException("الربط الآلي غير مفعّل في v1"))
    override suspend fun getBalance(): Result<Double> =
        Result.failure(UnsupportedOperationException("الربط الآلي غير مفعّل في v1"))
}
