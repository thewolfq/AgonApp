// File: Theme.kt
package com.agon.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AgonDarkColors = darkColorScheme(
    primary = EmeraldGreen,
    onPrimary = DarkNavy,
    secondary = WarningOrange,
    onSecondary = DarkNavy,
    background = DarkNavy,
    onBackground = TextPrimary,
    surface = CardBackground,
    onSurface = TextPrimary,
    error = CoralRed,
    onError = Color.White
)

/**
 * ثيم التطبيق — وضع داكن إجباري بألوان كحلي/زمردي/مرجاني.
 */
@Composable
fun AgonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AgonDarkColors,
        typography = AgonTypography,
        content = content
    )
}
