// File: SettingsViewModel.kt
package com.agon.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.PreferencesManager
import com.agon.app.data.TradeHistoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel لشاشة الإعدادات.
 */
class SettingsViewModel(
    private val prefs: PreferencesManager,
    private val history: TradeHistoryRepository
) : ViewModel() {

    data class UiState(
        val capital: Double = 10.0,
        val riskPercent: Double = 1.5,
        val totalPnl: Double = 0.0,
        val winRate: Double = 0.0,
        val historyCount: Int = 0
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            prefs.riskConfigFlow.collect { config ->
                _state.update {
                    it.copy(capital = config.capitalUsdt, riskPercent = config.riskPerTradePercent)
                }
            }
        }
        viewModelScope.launch {
            history.getTotalPnl().collect { pnl -> _state.update { it.copy(totalPnl = pnl) } }
        }
        viewModelScope.launch {
            history.getWinRate().collect { wr -> _state.update { it.copy(winRate = wr) } }
        }
        viewModelScope.launch {
            history.getAllEntries().collect { list ->
                _state.update { it.copy(historyCount = list.size) }
            }
        }
    }

    fun setCapital(d: Double) {
        viewModelScope.launch { prefs.setCapital(d) }
    }

    fun setRiskPercent(d: Double) {
        viewModelScope.launch { prefs.setRiskPercent(d) }
    }

    fun clearHistory() {
        viewModelScope.launch { history.clearHistory() }
    }

    fun resetCircuitBreaker() {
        viewModelScope.launch { prefs.resetCircuitBreaker() }
    }
}
