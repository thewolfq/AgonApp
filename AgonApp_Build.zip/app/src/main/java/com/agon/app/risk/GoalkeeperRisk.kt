// File: GoalkeeperRisk.kt
package com.agon.app.risk

import com.agon.app.data.PreferencesManager
import com.agon.app.models.TradeCard
import kotlinx.coroutines.flow.first
import kotlin.math.abs
import kotlin.math.ceil

/**
 * الحارس — يحسب حجم الصفقة، الرافعة، ويطبق قواعد إدارة المخاطر.
 */
class GoalkeeperRisk(private val prefs: PreferencesManager) {

    data class RiskValidation(
        val isValid: Boolean,
        val tradeCard: TradeCard?,
        val errorMessage: String?,
        val guardianInstructions: String?
    )

    suspend fun validateAndPrepare(
        tradeCard: TradeCard,
        capital: Double,
        openTradesCount: Int
    ): RiskValidation {
        prefs.resetDailyLossesIfNewDay()
        val circuit = prefs.circuitBreakerFlow.first()
        if (circuit.isActive) {
            return RiskValidation(false, null, "قاطع التشغيل مفعّل: خسارتان متتاليتان. توقف حتى الغد.", null)
        }
        circuit.cooldownUntil?.let { cd ->
            if (System.currentTimeMillis() < cd) {
                val min = ((cd - System.currentTimeMillis()) / 60000).toInt() + 1
                return RiskValidation(false, null, "فترة هدوء: انتظر $min دقيقة.", null)
            }
        }

        val riskConfig = prefs.riskConfigFlow.first()
        if (openTradesCount >= riskConfig.maxConcurrentTrades) {
            return RiskValidation(false, null,
                "الحد الأقصى للصفقات المتزامنة (${riskConfig.maxConcurrentTrades}) وصل.", null)
        }

        val entry = (tradeCard.entryZoneLow + tradeCard.entryZoneHigh) / 2.0
        val slPct = abs(entry - tradeCard.stopLossPrice) / entry
        if (slPct <= 0.0) return RiskValidation(false, null, "وقف الخسارة غير صالح.", null)

        val riskAmount = capital * (riskConfig.riskPerTradePercent / 100.0)
        var positionSize = riskAmount / slPct
        if (positionSize < 5.0) positionSize = 5.0

        var leverage = ceil(positionSize / capital).toInt().coerceIn(1, 10)
        val maxPos = capital * leverage
        if (positionSize > maxPos) positionSize = maxPos

        if (positionSize < 5.0) {
            return RiskValidation(false, null,
                "رأس المال صغير جداً. الحد الأدنى للصفقة على Binance Futures هو 5 USDT.", null)
        }

        val quantity = positionSize / entry
        val sb = StringBuilder()
        sb.appendLine("تعليمات الحارس:")
        sb.appendLine("- الرافعة: ${leverage}x")
        sb.appendLine("- حجم الصفقة: ${"%.2f".format(positionSize)} USDT")
        sb.appendLine("- الكمية: ${"%.6f".format(quantity)}")
        sb.appendLine("- وقف الخسارة Stop-Market: ${tradeCard.stopLossPrice}")
        sb.appendLine("- منطقة الدخول: ${tradeCard.entryZoneLow} - ${tradeCard.entryZoneHigh}")
        tradeCard.takeProfits.forEach { tp ->
            val pct = (tp.percentToClose * 100).toInt()
            sb.appendLine("- TP${tp.level}: ${tp.price} ($pct%)")
        }
        sb.appendLine("- ملاحظة: بعد TP1، انقل الوقف يدوياً إلى سعر الدخول")

        val updated = tradeCard.copy(leverageSuggestion = leverage, positionSizeUsdt = positionSize)
        return RiskValidation(true, updated, null, sb.toString().trim())
    }

    suspend fun recordTradeResult(isWin: Boolean) {
        if (!isWin) prefs.incrementLosses()
    }
}
