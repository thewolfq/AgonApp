// File: MainActivity.kt
package com.agon.app.ui

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.agon.app.AgonApp
import com.agon.app.models.Direction
import com.agon.app.models.OpenTrade
import com.agon.app.models.TradeStatus
import com.agon.app.ui.screens.LiveMatchScreen
import com.agon.app.ui.screens.ScannerScreen
import com.agon.app.ui.screens.SettingsScreen
import com.agon.app.ui.screens.SignalsScreen
import com.agon.app.ui.theme.AgonTheme
import com.agon.app.ui.viewmodel.LiveMatchViewModel
import com.agon.app.ui.viewmodel.ScannerViewModel
import com.agon.app.ui.viewmodel.SettingsViewModel
import com.agon.app.ui.viewmodel.SignalsViewModel

data class TabItem(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("scanner", "الملعب", Icons.Default.SportsSoccer),
    TabItem("signals", "الإشارات", Icons.Default.Analytics),
    TabItem("live", "المباراة", Icons.Default.PlayArrow),
    TabItem("settings", "الإدارة", Icons.Default.Settings)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as AgonApp
        val factory = AgonViewModelFactory(app)

        setContent {
            AgonTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    RequestNotificationPermission()
                    AppRoot(factory)
                }
            }
        }
    }
}

@Composable
private fun RequestNotificationPermission() {
    if (Build.VERSION.SDK_INT >= 33) {
        val launcher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { }
        LaunchedEffect(Unit) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@Composable
private fun AppRoot(factory: AgonViewModelFactory) {
    val navController = rememberNavController()
    var currentRoute by remember { mutableStateOf("scanner") }

    val scannerVm: ScannerViewModel = viewModel(factory = factory)
    val signalsVm: SignalsViewModel = viewModel(factory = factory)
    val liveVm: LiveMatchViewModel = viewModel(factory = factory)
    val settingsVm: SettingsViewModel = viewModel(factory = factory)

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            currentRoute = tab.route
                            navController.navigate(tab.route) {
                                popUpTo("scanner") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "scanner",
            modifier = Modifier.padding(padding)
        ) {
            composable("scanner") {
                val state by scannerVm.state.collectAsState()
                val query by scannerVm.query.collectAsState()
                ScannerScreen(
                    state = state,
                    query = query,
                    onQueryChange = scannerVm::onQueryChange,
                    onRefresh = { scannerVm.refreshNow() },
                    onPairClick = { pair ->
                        signalsVm.analyzeSymbol(pair.symbol, pair.lastPrice)
                        currentRoute = "signals"
                        navController.navigate("signals") {
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable("signals") {
                val state by signalsVm.state.collectAsState()
                SignalsScreen(
                    state = state,
                    onCopy = { },
                    onOpenTrade = { card ->
                        val entry = (card.entryZoneLow + card.entryZoneHigh) / 2.0
                        val tps = card.takeProfits.map { it.copy() }
                        val trade = OpenTrade(
                            symbol = card.symbol,
                            direction = card.direction,
                            entryPrice = entry,
                            currentPrice = entry,
                            quantity = if (entry > 0) card.positionSizeUsdt / entry else 0.0,
                            stopLoss = card.stopLossPrice,
                            takeProfits = tps,
                            status = TradeStatus.OPEN,
                            openedAt = System.currentTimeMillis(),
                            healthIndex = 50
                        )
                        liveVm.addOpenTrade(trade)
                        currentRoute = "live"
                        navController.navigate("live")
                    }
                )
            }
            composable("live") {
                val state by liveVm.state.collectAsState()
                LiveMatchScreen(
                    state = state,
                    onCloseTrade = { id, price, status -> liveVm.closeTrade(id, price, status) }
                )
            }
            composable("settings") {
                val state by settingsVm.state.collectAsState()
                SettingsScreen(
                    state = state,
                    onCapitalChange = settingsVm::setCapital,
                    onRiskChange = settingsVm::setRiskPercent,
                    onClearHistory = settingsVm::clearHistory,
                    onResetCircuitBreaker = settingsVm::resetCircuitBreaker
                )
            }
        }
    }
}
