// File: SettingsScreen.kt
package com.agon.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.ui.theme.CardBackground
import com.agon.app.ui.theme.CoralRed
import com.agon.app.ui.theme.EmeraldGreen
import com.agon.app.ui.theme.TextSecondary
import com.agon.app.ui.viewmodel.SettingsViewModel
import kotlin.math.roundToInt

/**
 * شاشة الإعدادات.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    state: SettingsViewModel.UiState,
    onCapitalChange: (Double) -> Unit,
    onRiskChange: (Double) -> Unit,
    onClearHistory: () -> Unit,
    onResetCircuitBreaker: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("الإدارة") }) }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Capital
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("رأس المال (USDT)", fontWeight = FontWeight.Bold)
                    Text("القيمة: \$${"%.1f".format(state.capital)}", color = EmeraldGreen)
                    Slider(
                        value = state.capital.toFloat(),
                        onValueChange = { onCapitalChange(it.toDouble()) },
                        valueRange = 5f..100f
                    )
                }
            }

            // Risk
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("المخاطرة لكل صفقة", fontWeight = FontWeight.Bold)
                    Text("القيمة: ${"%.1f".format(state.riskPercent)}%", color = EmeraldGreen)
                    Slider(
                        value = state.riskPercent.toFloat(),
                        onValueChange = { onRiskChange(it.toDouble()) },
                        valueRange = 0.5f..3.0f
                    )
                }
            }

            // Stats
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("الإحصائيات", fontWeight = FontWeight.Bold)
                    Text("الربح/الخسارة الكلي: \$${"%.2f".format(state.totalPnl)}",
                        color = if (state.totalPnl >= 0) EmeraldGreen else CoralRed)
                    Text("نسبة الفوز: ${state.winRate.roundToInt()}%", color = TextSecondary)
                    Text("عدد الصفقات: ${state.historyCount}", color = TextSecondary)
                }
            }

            // Mode
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("الوضع الحالي", fontWeight = FontWeight.Bold)
                    Text("وضع التدريب اليدوي (v1)", color = EmeraldGreen)
                    Text("الربط الآلي (API) قريباً في v2", color = TextSecondary)
                }
            }

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onResetCircuitBreaker,
                    modifier = Modifier.weight(1f)
                ) { Text("إعادة ضبط الحارس", color = EmeraldGreen) }
                Button(
                    onClick = onClearHistory,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = CoralRed)
                ) { Text("مسح السجل", color = MaterialTheme.colorScheme.onPrimary) }
            }
        }
    }
}
