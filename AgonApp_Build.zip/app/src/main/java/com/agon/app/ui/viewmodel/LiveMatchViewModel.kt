// File: LiveMatchViewModel.kt
package com.agon.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.coach.MatchCoach
import com.agon.app.data.PreferencesManager
import com.agon.app.models.Direction
import com.agon.app.models.OpenTrade
import com.agon.app.models.TradeHistoryEntry
import com.agon.app.models.TradeMode
import com.agon.app.models.TradeStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel لشاشة المباراة الحية.
 */
class LiveMatchViewModel(
    private val coach: MatchCoach,
    private val prefs: PreferencesManager
) : ViewModel() {

    data class UiState(
        val openTrades: List<OpenTrade> = emptyList()
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            prefs.openTradesFlow.collect { trades ->
                _state.update { it.copy(openTrades = trades) }
            }
        }
    }

    fun addOpenTrade(trade: OpenTrade) {
        viewModelScope.launch {
            val current = prefs.openTradesFlow.first()
            prefs.saveOpenTrades(current + trade)
        }
    }

    fun closeTrade(tradeId: String, exitPrice: Double, status: TradeStatus) {
        viewModelScope.launch {
            val current = prefs.openTradesFlow.first()
            val closed = current.firstOrNull { it.id == tradeId } ?: return@launch
            val updated = current.filterNot { it.id == tradeId }
            prefs.saveOpenTrades(updated)
            val pnl = if (closed.direction == Direction.LONG)
                (exitPrice - closed.entryPrice) * closed.quantity
            else
                (closed.entryPrice - exitPrice) * closed.quantity
            val pnlPct = if (closed.entryPrice > 0) pnl / closed.entryPrice * 100.0 else 0.0
            val history = TradeHistoryEntry(
                symbol = closed.symbol,
                direction = closed.direction,
                entryPrice = closed.entryPrice,
                exitPrice = exitPrice,
                pnlUsdt = pnl,
                pnlPercent = pnlPct,
                status = status,
                mode = TradeMode.INTRADAY,
                openedAt = closed.openedAt,
                closedAt = System.currentTimeMillis()
            )
            val h = prefs.historyFlow.first()
            prefs.saveHistory(h + history)
        }
    }
}
