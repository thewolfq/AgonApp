// File: Indicators.kt
package com.agon.app.engine

import kotlin.math.abs
import kotlin.math.max

/**
 * مؤشرات فنية بحتة — كل الدوال تعيد 0.0 عند نقص البيانات.
 */
object Indicators {

    fun sma(prices: List<Double>, period: Int): Double {
        if (prices.size < period || period <= 0) return 0.0
        return prices.takeLast(period).sum() / period
    }

    fun ema(prices: List<Double>, period: Int): Double {
        if (prices.isEmpty() || prices.size < period || period <= 0) return 0.0
        val multiplier = 2.0 / (period + 1)
        var ema = prices.take(period).sum() / period
        for (i in period until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
        }
        return ema
    }

    fun rsi(prices: List<Double>, period: Int = 14): Double {
        if (prices.size < period + 1) return 0.0
        var avgGain = 0.0
        var avgLoss = 0.0
        for (i in 1..period) {
            val change = prices[i] - prices[i - 1]
            if (change > 0) avgGain += change else avgLoss -= change
        }
        avgGain /= period
        avgLoss /= period
        for (i in period + 1 until prices.size) {
            val change = prices[i] - prices[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) -change else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun atr(highs: List<Double>, lows: List<Double>, closes: List<Double>, period: Int = 14): Double {
        if (highs.size < period + 1 || highs.size != lows.size || highs.size != closes.size) return 0.0
        val trs = mutableListOf<Double>()
        for (i in 1 until highs.size) {
            val hl = highs[i] - lows[i]
            val hc = abs(highs[i] - closes[i - 1])
            val lc = abs(lows[i] - closes[i - 1])
            trs.add(max(hl, max(hc, lc)))
        }
        if (trs.size < period) return 0.0
        var atr = trs.take(period).sum() / period
        for (i in period until trs.size) {
            atr = (atr * (period - 1) + trs[i]) / period
        }
        return atr
    }

    fun rvol(volumes: List<Double>, period: Int = 20): Double {
        if (volumes.size < period + 1) return 1.0
        val avg = volumes.dropLast(1).takeLast(period).sum() / period
        if (avg == 0.0) return 1.0
        return volumes.last() / avg
    }
}
