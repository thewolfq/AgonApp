// File: PairRow.kt
package com.agon.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.models.ScannedPair
import com.agon.app.ui.theme.CardBackground
import com.agon.app.ui.theme.CoralRed
import com.agon.app.ui.theme.EmeraldGreen
import com.agon.app.ui.theme.TextSecondary

/**
 * صف زوج في قائمة الماسح.
 */
@Composable
fun PairRow(pair: ScannedPair, onClick: () -> Unit) {
    val changeColor = if (pair.priceChangePercent >= 0) EmeraldGreen else CoralRed
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(pair.symbol, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("الحجم: ${formatVolume(pair.quoteVolume)}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("%.4f".format(pair.lastPrice), style = MaterialTheme.typography.titleMedium)
                Text(
                    "${if (pair.priceChangePercent >= 0) "+" else ""}%.2f%%".format(pair.priceChangePercent),
                    style = MaterialTheme.typography.bodySmall,
                    color = changeColor
                )
            }
        }
    }
}

private fun formatVolume(volume: Double): String = when {
    volume >= 1_000_000_000 -> "%.2fB".format(volume / 1_000_000_000)
    volume >= 1_000_000 -> "%.2fM".format(volume / 1_000_000)
    volume >= 1_000 -> "%.2fK".format(volume / 1_000)
    else -> "%.2f".format(volume)
}
