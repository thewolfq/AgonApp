// File: TradeCardView.kt
package com.agon.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.models.Direction
import com.agon.app.models.SignalStrength
import com.agon.app.models.TradeCard
import com.agon.app.ui.theme.CardBackground
import com.agon.app.ui.theme.CoralRed
import com.agon.app.ui.theme.DarkNavyLight
import com.agon.app.ui.theme.EmeraldGreen
import com.agon.app.ui.theme.TextSecondary
import com.agon.app.ui.theme.WarningOrange

/**
 * بطاقة صفقة كاملة قابلة للنسخ.
 */
@Composable
fun TradeCardView(card: TradeCard, guardianInstructions: String, onCopy: () -> Unit) {
    val context = LocalContext.current
    val dirColor = if (card.direction == Direction.LONG) EmeraldGreen else CoralRed
    val dirLabel = if (card.direction == Direction.LONG) "شراء (LONG)" else "بيع (SHORT)"

    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(card.symbol, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier.background(dirColor, RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(dirLabel, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("درجة الإشارة: ${card.signalScore}/100 (${strengthLabel(card.signalStrength)})",
                    style = MaterialTheme.typography.bodyMedium, color = EmeraldGreen)
                Spacer(Modifier.height(12.dp))
                Text("منطقة الدخول: ${"%.4f".format(card.entryZoneLow)} - ${"%.4f".format(card.entryZoneHigh)}",
                    style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Text("وقف الخسارة: ${"%.4f".format(card.stopLossPrice)}",
                    style = MaterialTheme.typography.bodyMedium, color = CoralRed, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                card.takeProfits.forEach { tp ->
                    Text("TP${tp.level}: ${"%.4f".format(tp.price)} (${(tp.percentToClose * 100).toInt()}%)",
                        style = MaterialTheme.typography.bodySmall, color = EmeraldGreen)
                }
                Spacer(Modifier.height(8.dp))
                Text("R:R = 1:${"%.2f".format(card.riskRewardRatio)} • رافعة: ${card.leverageSuggestion}x • حجم: ${"%.2f".format(card.positionSizeUsdt)} USDT",
                    style = MaterialTheme.typography.bodySmall, color = TextSecondary)

                Spacer(Modifier.height(12.dp))
                Text("تبرير المدرب:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(card.arabicReasoning, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

                Spacer(Modifier.height(12.dp))
                Column(
                    modifier = Modifier.fillMaxWidth().background(DarkNavyLight, RoundedCornerShape(8.dp)).padding(10.dp)
                ) {
                    Text("الخطة ب (الجناحان):", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = WarningOrange)
                    Spacer(Modifier.height(4.dp))
                    Text(card.counterScenario.triggerCondition, style = MaterialTheme.typography.bodySmall)
                    Text(card.counterScenario.reasoning, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }

                if (guardianInstructions.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Column(
                        modifier = Modifier.fillMaxWidth().background(DarkNavyLight, RoundedCornerShape(8.dp)).padding(10.dp)
                    ) {
                        Text("تعليمات الحارس:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EmeraldGreen)
                        Text(guardianInstructions, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        val text = buildClipboardText(card, guardianInstructions)
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Trade", text))
                        onCopy()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Text("📋 نسخ معطيات التنفيذ", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun strengthLabel(s: SignalStrength) = when (s) {
    SignalStrength.WEAK -> "ضعيفة"
    SignalStrength.MODERATE -> "متوسطة"
    SignalStrength.STRONG -> "قوية"
}

private fun buildClipboardText(card: TradeCard, guardian: String): String = buildString {
    appendLine("═══ ${card.symbol} • ${if (card.direction == Direction.LONG) "شراء" else "بيع"} ═══")
    appendLine("درجة الإشارة: ${card.signalScore}/100")
    appendLine("منطقة الدخول: ${card.entryZoneLow} - ${card.entryZoneHigh}")
    appendLine("وقف الخسارة: ${card.stopLossPrice}")
    card.takeProfits.forEach { tp ->
        appendLine("TP${tp.level}: ${tp.price} (${(tp.percentToClose * 100).toInt()}%)")
    }
    if (guardian.isNotEmpty()) {
        appendLine()
        appendLine(guardian)
    }
}
