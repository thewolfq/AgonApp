// File: MarketScanner.kt
package com.agon.app.scanner

import com.agon.app.models.ScannedPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * ماسح السوق — يجلب أزواج USDT-M Futures من Binance مع معالجة
 * Rate Limiting و Geo-Blocking.
 */
class MarketScanner(cacheDir: File) {

    private val client = OkHttpClient.Builder()
        .cache(Cache(cacheDir, 5L * 1024 * 1024))
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    @Volatile private var lastFetchTime = 0L

    companion object {
        private const val MIN_QUOTE_VOLUME = 2_000_000.0
        private const val CACHE_SECONDS = 15
        private const val URL = "https://fapi.binance.com/fapi/v1/ticker/24hr"
    }

    /**
     * يجلب قائمة الأزواج المؤهلة (quoteVolume >= 2M)، مرتبة تنازلياً.
     */
    suspend fun scan(): Result<List<ScannedPair>> = withContext(Dispatchers.IO) {
        try {
            val now = System.currentTimeMillis()
            val request = Request.Builder()
                .url(URL)
                .header("Cache-Control", "max-age=$CACHE_SECONDS")
                .build()

            client.newCall(request).execute().use { response ->
                when (response.code) {
                    429, 418 -> {
                        val retry = response.header("Retry-After")?.toLongOrNull() ?: 30L
                        return@withContext Result.failure(
                            Exception("تم تجاوز حد الطلبات، جاري الانتظار ${retry}ث")
                        )
                    }
                    451, 403 -> {
                        return@withContext Result.failure(
                            Exception("الوصول إلى Binance محجوب من منطقتك. جرب VPN")
                        )
                    }
                }
                if (response.code !in 200..299) {
                    return@withContext Result.failure(
                        Exception("خطأ الشبكة: ${response.code}")
                    )
                }

                val body = response.body?.string()
                    ?: return@withContext Result.failure(Exception("لا بيانات"))

                lastFetchTime = now
                val arr = JSONArray(body)
                val result = mutableListOf<ScannedPair>()

                for (i in 0 until arr.length()) {
                    try {
                        val obj = arr.getJSONObject(i)
                        val symbol = obj.optString("symbol", "")
                        if (!symbol.endsWith("USDT") || symbol.contains("_")) continue
                        val volume = obj.optString("quoteVolume", "0").toDoubleOrNull() ?: 0.0
                        if (volume < MIN_QUOTE_VOLUME) continue
                        result.add(
                            ScannedPair(
                                symbol = symbol,
                                lastPrice = obj.optString("lastPrice", "0").toDoubleOrNull() ?: 0.0,
                                priceChangePercent = obj.optString("priceChangePercent", "0").toDoubleOrNull() ?: 0.0,
                                quoteVolume = volume,
                                lastUpdated = now
                            )
                        )
                    } catch (_: Exception) { /* تجاهل العنصر التالف */ }
                }
                result.sortByDescending { it.quoteVolume }
                Result.success(result)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
