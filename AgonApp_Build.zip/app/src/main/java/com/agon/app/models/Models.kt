// File: Models.kt
package com.agon.app.models

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * زوج مفحوص من السوق مع بياناته الأساسية.
 */
@Serializable
data class ScannedPair(
    val symbol: String,
    val lastPrice: Double,
    val priceChangePercent: Double,
    val quoteVolume: Double,
    val lastUpdated: Long
)

/**
 * لقطة المؤشرات الفنية لحظة توليد الإشارة.
 */
@Serializable
data class IndicatorSnapshot(
    val ema20: Double,
    val ema50: Double,
    val rsi14: Double,
    val atr14: Double,
    val rvol: Double,
    val closePrice: Double
)

/**
 * هدف جني الربح — السعر ونسبة الإغلاق عنده.
 */
@Serializable
data class TakeProfit(
    val level: Int,
    val price: Double,
    val percentToClose: Double
)

/**
 * السيناريو المعاكس (الخطة ب).
 */
@Serializable
data class CounterScenario(
    val triggerCondition: String,
    val suggestedDirection: Direction?,
    val suggestedEntry: Double?,
    val reasoning: String
)

/**
 * بطاقة صفقة مقترحة تحتوي على خطة الدخول والإدارة كاملة.
 * takeProfits يجب أن تحتوي 3 عناصر (TP1, TP2, TP3).
 */
@Serializable
data class TradeCard(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val direction: Direction,
    val mode: TradeMode,
    val signalScore: Int,
    val signalStrength: SignalStrength,
    val entryZoneLow: Double,
    val entryZoneHigh: Double,
    val stopLossPrice: Double,
    val takeProfits: List<TakeProfit>,
    val riskRewardRatio: Double,
    val leverageSuggestion: Int,
    val positionSizeUsdt: Double,
    val indicators: IndicatorSnapshot,
    val arabicReasoning: String,
    val counterScenario: CounterScenario,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * صفقة مفتوحة قيد المتابعة.
 */
@Serializable
data class OpenTrade(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val direction: Direction,
    val entryPrice: Double,
    val currentPrice: Double,
    val quantity: Double,
    val stopLoss: Double,
    val takeProfits: List<TakeProfit>,
    val status: TradeStatus = TradeStatus.OPEN,
    val openedAt: Long = System.currentTimeMillis(),
    val closedAt: Long? = null,
    val realizedPnl: Double = 0.0,
    val healthIndex: Int = 50,
    val lastCoachAction: CoachAction = CoachAction.HOLD
)

/**
 * سجل صفقة منتهية.
 */
@Serializable
data class TradeHistoryEntry(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val direction: Direction,
    val entryPrice: Double,
    val exitPrice: Double,
    val pnlUsdt: Double,
    val pnlPercent: Double,
    val status: TradeStatus,
    val mode: TradeMode,
    val openedAt: Long,
    val closedAt: Long
)

/**
 * إعدادات إدارة المخاطر ورأس المال.
 */
@Serializable
data class RiskConfig(
    val capitalUsdt: Double = 10.0,
    val riskPerTradePercent: Double = 1.5,
    val maxLeverage: Int = 10,
    val maxConcurrentTrades: Int = 1,
    val circuitBreakerLosses: Int = 2,
    val cooldownMinutes: Int = 30
)

/**
 * حالة شاشة الماسح الضوئي.
 */
@Serializable
data class ScannerState(
    val pairs: List<ScannedPair> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val lastFetchTime: Long = 0L
)

/**
 * حالة قاطع الدائرة (Circuit Breaker).
 */
@Serializable
data class CircuitBreakerState(
    val isActive: Boolean = false,
    val consecutiveLosses: Int = 0,
    val cooldownUntil: Long? = null,
    val reason: String = ""
)
