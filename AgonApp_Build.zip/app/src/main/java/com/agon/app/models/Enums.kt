// File: Enums.kt
package com.agon.app.models

/**
 * اتجاه الصفقة — شراء (LONG) أو بيع (SHORT).
 */
enum class Direction {
    LONG,
    SHORT
}

/**
 * نمط التداول — SCALPING للصفقات السريعة (دقائق)، INTRADAY لليومية (ساعات).
 */
enum class TradeMode {
    SCALPING,
    INTRADAY
}

/**
 * حالة الصفقة — PENDING في الانتظار، OPEN مفتوحة، CLOSED_* مغلقة.
 */
enum class TradeStatus {
    PENDING,
    OPEN,
    CLOSED_TP,
    CLOSED_SL,
    CLOSED_MANUAL,
    CLOSED_TRAILING
}

/**
 * قوة الإشارة — WEAK أقل من 60، MODERATE بين 60-79، STRONG 80 فأعلى.
 */
enum class SignalStrength {
    WEAK,
    MODERATE,
    STRONG
}

/**
 * نوع أمر Binance.
 */
enum class OrderType {
    STOP_LIMIT,
    STOP_MARKET,
    LIMIT,
    MARKET
}

/**
 * مستوى المخاطرة.
 */
enum class RiskLevel {
    CONSERVATIVE,
    BALANCED,
    AGGRESSIVE
}

/**
 * توصية المدرب أثناء الصفقة.
 */
enum class CoachAction {
    HOLD,
    TAKE_PARTIAL_PROFIT,
    MOVE_SL_TO_BREAKEVEN,
    EXIT_EARLY,
    CANCEL_IF_TRIGGERED
}
