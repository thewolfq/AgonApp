// File: PreferencesManager.kt
package com.agon.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.agon.app.models.CircuitBreakerState
import com.agon.app.models.OpenTrade
import com.agon.app.models.RiskConfig
import com.agon.app.models.TradeHistoryEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "agon_prefs")

/**
 * إدارة كل التفضيلات والحالة الدائمة عبر DataStore.
 */
class PreferencesManager(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    companion object {
        private val KEY_CAPITAL = doublePreferencesKey("capital_usdt")
        private val KEY_RISK_PERCENT = doublePreferencesKey("risk_percent")
        private val KEY_CONSECUTIVE_LOSSES = intPreferencesKey("consecutive_losses")
        private val KEY_LAST_TRADE_DATE = stringPreferencesKey("last_trade_date")
        private val KEY_CIRCUIT_ACTIVE = booleanPreferencesKey("circuit_active")
        private val KEY_COOLDOWN_UNTIL = longPreferencesKey("cooldown_until")
        private val KEY_OPEN_TRADES = stringPreferencesKey("open_trades_json")
        private val KEY_HISTORY = stringPreferencesKey("history_json")
    }

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    val riskConfigFlow: Flow<RiskConfig> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            val capital = prefs[KEY_CAPITAL] ?: 10.0
            RiskConfig(
                capitalUsdt = capital,
                riskPerTradePercent = prefs[KEY_RISK_PERCENT] ?: 1.5,
                maxLeverage = 10,
                maxConcurrentTrades = if (capital < 50.0) 1 else 2,
                circuitBreakerLosses = 2,
                cooldownMinutes = 30
            )
        }

    suspend fun setCapital(capital: Double) {
        context.dataStore.edit { it[KEY_CAPITAL] = capital.coerceIn(5.0, 10000.0) }
    }

    suspend fun setRiskPercent(percent: Double) {
        context.dataStore.edit { it[KEY_RISK_PERCENT] = percent.coerceIn(0.5, 3.0) }
    }

    val circuitBreakerFlow: Flow<CircuitBreakerState> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            CircuitBreakerState(
                isActive = prefs[KEY_CIRCUIT_ACTIVE] ?: false,
                consecutiveLosses = prefs[KEY_CONSECUTIVE_LOSSES] ?: 0,
                cooldownUntil = prefs[KEY_COOLDOWN_UNTIL]?.takeIf { it > 0L },
                reason = ""
            )
        }

    suspend fun incrementLosses() {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_CONSECUTIVE_LOSSES] ?: 0
            val next = current + 1
            prefs[KEY_CONSECUTIVE_LOSSES] = next
            prefs[KEY_LAST_TRADE_DATE] = today()
            prefs[KEY_COOLDOWN_UNTIL] = System.currentTimeMillis() + 30L * 60L * 1000L
            if (next >= 2) prefs[KEY_CIRCUIT_ACTIVE] = true
        }
    }

    suspend fun resetDailyLossesIfNewDay() {
        context.dataStore.edit { prefs ->
            val stored = prefs[KEY_LAST_TRADE_DATE] ?: ""
            if (stored != today()) {
                prefs[KEY_CONSECUTIVE_LOSSES] = 0
                prefs[KEY_CIRCUIT_ACTIVE] = false
                prefs[KEY_COOLDOWN_UNTIL] = 0L
            }
        }
    }

    suspend fun resetCircuitBreaker() {
        context.dataStore.edit { prefs ->
            prefs[KEY_CIRCUIT_ACTIVE] = false
            prefs[KEY_CONSECUTIVE_LOSSES] = 0
            prefs[KEY_COOLDOWN_UNTIL] = 0L
        }
    }

    val openTradesFlow: Flow<List<OpenTrade>> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            val jsonStr = prefs[KEY_OPEN_TRADES] ?: "[]"
            runCatching { json.decodeFromString<List<OpenTrade>>(jsonStr) }.getOrElse { emptyList() }
        }

    suspend fun saveOpenTrades(trades: List<OpenTrade>) {
        context.dataStore.edit { prefs ->
            prefs[KEY_OPEN_TRADES] = json.encodeToString(trades)
        }
    }

    val historyFlow: Flow<List<TradeHistoryEntry>> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            val jsonStr = prefs[KEY_HISTORY] ?: "[]"
            runCatching { json.decodeFromString<List<TradeHistoryEntry>>(jsonStr) }.getOrElse { emptyList() }
        }

    suspend fun saveHistory(history: List<TradeHistoryEntry>) {
        context.dataStore.edit { prefs ->
            prefs[KEY_HISTORY] = json.encodeToString(history)
        }
    }

    suspend fun clearHistory() {
        context.dataStore.edit { prefs -> prefs[KEY_HISTORY] = "[]" }
    }
}
