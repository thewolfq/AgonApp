// File: ScannerScreen.kt
package com.agon.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.agon.app.models.ScannedPair
import com.agon.app.models.ScannerState
import com.agon.app.ui.components.PairRow
import com.agon.app.ui.theme.CoralRed

/**
 * شاشة الماسح — قائمة الأزواج المباشرة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    state: ScannerState,
    query: String,
    onQueryChange: (String) -> Unit,
    onRefresh: () -> Unit,
    onPairClick: (ScannedPair) -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("الملعب — الماسح") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "تحديث")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                label = { Text("بحث عن زوج") },
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                singleLine = true
            )
            if (state.isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            state.errorMessage?.let { msg ->
                Text("⚠️ $msg", color = CoralRed, modifier = Modifier.padding(12.dp))
            }
            val filtered = if (query.isBlank()) state.pairs
                else state.pairs.filter { it.symbol.contains(query.uppercase()) }
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filtered) { pair ->
                    PairRow(pair = pair, onClick = { onPairClick(pair) })
                }
            }
        }
    }
}
