// File: SignalsScreen.kt
package com.agon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.agon.app.models.TradeCard
import com.agon.app.ui.components.TradeCardView
import com.agon.app.ui.theme.CoralRed
import com.agon.app.ui.theme.TextSecondary
import com.agon.app.ui.viewmodel.SignalsViewModel

/**
 * شاشة الإشارات.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignalsScreen(
    state: SignalsViewModel.UiState,
    onCopy: () -> Unit,
    onOpenTrade: (TradeCard) -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("الإشارات") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())) {
            if (state.circuitBreaker.isActive) {
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(CoralRed.copy(alpha = 0.2f), RoundedCornerShape(0.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        "🛑 قاطع التشغيل مفعّل: ${state.circuitBreaker.reason.ifBlank { "خسارتان متتاليتان. توقف حتى الغد." }}",
                        color = CoralRed
                    )
                }
            }
            when {
                state.isLoading -> Box(
                    modifier = Modifier.fillMaxSize().padding(40.dp),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator() }

                state.errorMessage != null && state.currentSignal == null -> Box(
                    modifier = Modifier.fillMaxSize().padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(state.errorMessage, color = TextSecondary, textAlign = TextAlign.Center)
                }

                state.currentSignal != null -> {
                    TradeCardView(
                        card = state.currentSignal,
                        guardianInstructions = state.guardianInstructions,
                        onCopy = onCopy
                    )
                }

                else -> Box(
                    modifier = Modifier.fillMaxSize().padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "لا توجد إشارة حالياً.\nاضغط على زوج من تبويب \"الملعب\" لتحليله.",
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}
