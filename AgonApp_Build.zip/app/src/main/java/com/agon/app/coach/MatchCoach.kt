// File: MatchCoach.kt
package com.agon.app.coach

import com.agon.app.models.CoachAction
import com.agon.app.models.Direction
import com.agon.app.models.IndicatorSnapshot
import com.agon.app.models.OpenTrade
import com.agon.app.models.ScannedPair
import kotlin.math.abs
import kotlin.math.min

/**
 * المدرب — يراقب الصفقات الحية ويصدر توصيات تكتيكية.
 */
class MatchCoach {

    data class CoachEvaluation(
        val healthIndex: Int,
        val action: CoachAction,
        val arabicMessage: String,
        val warningMessage: String? = null
    )

    private val watchlist = mutableListOf<ScannedPair>()

    fun updateWatchlist(pairs: List<ScannedPair>) {
        watchlist.clear()
        watchlist.addAll(pairs.sortedByDescending { it.quoteVolume }.take(5))
    }

    fun removeFromWatchlist(symbol: String) {
        watchlist.removeAll { it.symbol == symbol }
    }

    fun getWatchlist(): List<ScannedPair> = watchlist.toList()

    fun canOpenNewTrade(openCount: Int, maxConcurrent: Int): Boolean = openCount < maxConcurrent

    fun evaluateTrade(
        trade: OpenTrade,
        currentPrice: Double,
        currentIndicators: IndicatorSnapshot
    ): CoachEvaluation {
        val entry = trade.entryPrice
        val sl = trade.stopLoss
        val tp1 = trade.takeProfits.firstOrNull { it.level == 1 }?.price ?: return holdEval()
        val stopDistance = abs(entry - sl)
        if (stopDistance <= 0.0) return holdEval()

        val priceMove = if (trade.direction == Direction.LONG) currentPrice - entry else entry - currentPrice
        val pnlPct = (priceMove / entry) * 100.0
        val slPct = (stopDistance / entry) * 100.0

        val pnlComp = if (slPct <= 0.0) 50.0
            else ((pnlPct / slPct) * 50.0 + 50.0).coerceIn(0.0, 100.0)

        val rsi = currentIndicators.rsi14
        val momComp = if (trade.direction == Direction.LONG)
            ((rsi - 30.0) / 40.0 * 100.0).coerceIn(0.0, 100.0)
        else
            (100.0 - ((rsi - 30.0) / 40.0 * 100.0)).coerceIn(0.0, 100.0)

        val trendAligned = if (trade.direction == Direction.LONG)
            currentIndicators.ema20 > currentIndicators.ema50
        else
            currentIndicators.ema20 < currentIndicators.ema50
        val trendComp = if (trendAligned) 100.0 else 30.0

        val minutes = ((System.currentTimeMillis() - trade.openedAt) / 60000L).toDouble()
        val timeComp = 100.0 - min(minutes / 240.0 * 100.0, 80.0)

        val health = (0.45 * pnlComp + 0.25 * momComp + 0.20 * trendComp + 0.10 * timeComp)
            .toInt().coerceIn(0, 100)

        val hitTP1 = if (trade.direction == Direction.LONG) currentPrice >= tp1 else currentPrice <= tp1
        val slAtBE = abs(sl - entry) < entry * 0.001

        val (action, message, warning) = when {
            hitTP1 && !slAtBE -> Triple(
                CoachAction.MOVE_SL_TO_BREAKEVEN,
                "TP1 تحقق. انقل وقف الخسارة إلى سعر الدخول ($entry) لتأمين النتيجة.",
                null
            )
            hitTP1 && slAtBE -> Triple(
                CoachAction.TAKE_PARTIAL_PROFIT,
                "الربح مستمر. فكر في جني جزء إضافي.",
                null
            )
            health < 25 -> Triple(
                CoachAction.EXIT_EARLY,
                "ضعف واضح (صحة $health). اخرج الآن قبل الوقف.",
                "تحذير: الصفقة تضعف بسرعة"
            )
            health < 40 -> Triple(
                CoachAction.HOLD,
                "الصفقة تضعف (صحة $health). راقب عن قرب.",
                "الصفقة تحت ضغط"
            )
            else -> Triple(
                CoachAction.HOLD,
                "الصفقة جيدة (صحة $health). استمر.",
                null
            )
        }
        return CoachEvaluation(health, action, message, warning)
    }

    private fun holdEval() = CoachEvaluation(50, CoachAction.HOLD, "بيانات غير كافية.", null)
}
