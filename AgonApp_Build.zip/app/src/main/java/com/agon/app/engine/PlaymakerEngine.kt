// File: PlaymakerEngine.kt
package com.agon.app.engine

import com.agon.app.models.CounterScenario
import com.agon.app.models.Direction
import com.agon.app.models.IndicatorSnapshot
import com.agon.app.models.SignalStrength
import com.agon.app.models.TakeProfit
import com.agon.app.models.TradeCard
import com.agon.app.models.TradeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * محرك التحليل — يجلب الشموع ويولّد بطاقات صفقات كاملة.
 */
class PlaymakerEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cache = mutableMapOf<String, Pair<Long, List<List<Double>>>>()

    private suspend fun fetchKlines(
        symbol: String,
        interval: String,
        limit: Int = 100
    ): Result<List<List<Double>>> = withContext(Dispatchers.IO) {
        val key = "$symbol:$interval"
        cache[key]?.let { (ts, data) ->
            if (System.currentTimeMillis() - ts < 30_000L) return@withContext Result.success(data)
        }
        try {
            val url = "https://fapi.binance.com/fapi/v1/klines?symbol=$symbol&interval=$interval&limit=$limit"
            client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                if (resp.code in listOf(451, 403)) return@withContext Result.failure(Exception("Binance محجوب من منطقتك"))
                if (resp.code in listOf(429, 418)) return@withContext Result.failure(Exception("تم تجاوز حد الطلبات"))
                if (resp.code !in 200..299) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val body = resp.body?.string() ?: return@withContext Result.failure(Exception("لا بيانات"))
                val arr = JSONArray(body)
                val klines = mutableListOf<List<Double>>()
                for (i in 0 until arr.length()) {
                    val k = arr.getJSONArray(i)
                    klines.add(
                        listOf(
                            k.getString(1).toDoubleOrNull() ?: 0.0,
                            k.getString(2).toDoubleOrNull() ?: 0.0,
                            k.getString(3).toDoubleOrNull() ?: 0.0,
                            k.getString(4).toDoubleOrNull() ?: 0.0,
                            k.getString(5).toDoubleOrNull() ?: 0.0
                        )
                    )
                }
                cache[key] = System.currentTimeMillis() to klines
                Result.success(klines)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun analyze(symbol: String, currentPrice: Double): Result<TradeCard?> =
        withContext(Dispatchers.IO) {
            val k15 = fetchKlines(symbol, "15m").getOrElse { return@withContext Result.failure(it) }
            val k5 = fetchKlines(symbol, "5m").getOrElse { return@withContext Result.failure(it) }
            if (k15.size < 50 || k5.size < 20) return@withContext Result.failure(Exception("بيانات غير كافية"))

            val closes15 = k15.map { it[3] }
            val highs15 = k15.map { it[1] }
            val lows15 = k15.map { it[2] }
            val volumes15 = k15.map { it[4] }
            val closes5 = k5.map { it[3] }

            val ema20 = Indicators.ema(closes15, 20)
            val ema50 = Indicators.ema(closes15, 50)
            val rsi = Indicators.rsi(closes15, 14)
            val atr = Indicators.atr(highs15, lows15, closes15, 14)
            val rvol = Indicators.rvol(volumes15, 20)
            val lastClose = closes15.last()
            val ema20_5m = Indicators.ema(closes5, 20)

            val isLong = ema20 > ema50 && lastClose > ema20 && rsi in 40.0..70.0
            val isShort = ema20 < ema50 && lastClose < ema20 && rsi in 30.0..60.0
            if (!isLong && !isShort) return@withContext Result.success(null)

            val direction = if (isLong) Direction.LONG else Direction.SHORT

            var score = 0
            if (isLong && ema20 > ema50) score += 25
            if (isShort && ema20 < ema50) score += 25
            if (isLong && lastClose > ema20) score += 15
            if (isShort && lastClose < ema20) score += 15
            if (if (isLong) rsi in 40.0..65.0 else rsi in 35.0..60.0) score += 20
            if (rvol > 1.2) score += 15
            val atrPct = if (lastClose > 0) atr / lastClose else 0.0
            if (atrPct in 0.003..0.02) score += 10
            val aligns5m = if (isLong) closes5.last() > ema20_5m else closes5.last() < ema20_5m
            if (aligns5m) score += 15
            if (score < 60) return@withContext Result.success(null)

            val entry = currentPrice
            val slDist = atr * 1.5
            if (slDist <= 0.0) return@withContext Result.success(null)

            val (stopLoss, tp1, tp2, tp3) = if (direction == Direction.LONG) {
                listOf(entry - slDist, entry + slDist, entry + slDist * 2, entry + slDist * 3)
            } else {
                listOf(entry + slDist, entry - slDist, entry - slDist * 2, entry - slDist * 3)
            }

            val rr = abs(tp2 - entry) / abs(entry - stopLoss)
            if (rr < 1.5) return@withContext Result.success(null)

            val mode = if (atrPct > 0.01) TradeMode.SCALPING else TradeMode.INTRADAY
            val strength = when {
                score >= 80 -> SignalStrength.STRONG
                score >= 60 -> SignalStrength.MODERATE
                else -> SignalStrength.WEAK
            }
            val zoneLow = minOf(entry, ema20) - atr * 0.2
            val zoneHigh = maxOf(entry, ema20) + atr * 0.2
            val tps = listOf(
                TakeProfit(1, tp1, 0.4),
                TakeProfit(2, tp2, 0.3),
                TakeProfit(3, tp3, 0.3)
            )
            val reasoning = if (direction == Direction.LONG) {
                "إشارة شراء على $symbol: السعر $entry فوق EMA20/50، RSI=$rsi، RVOL=${"%.2f".format(rvol)}x. الهدف الأول $tp1."
            } else {
                "إشارة بيع على $symbol: السعر $entry تحت EMA20/50، RSI=$rsi، RVOL=${"%.2f".format(rvol)}x. الهدف الأول $tp1."
            }
            val counter = if (direction == Direction.LONG) {
                CounterScenario(
                    triggerCondition = "كسر السعر EMA20 لأسفل مع RVOL > 1.5",
                    suggestedDirection = Direction.SHORT,
                    suggestedEntry = ema20,
                    reasoning = "قد ينعكس الاتجاه هبوطياً. راقب EMA50 كهدف."
                )
            } else {
                CounterScenario(
                    triggerCondition = "اختراق السعر EMA20 لأعلى مع RVOL > 1.5",
                    suggestedDirection = Direction.LONG,
                    suggestedEntry = ema20,
                    reasoning = "قد ينعكس الاتجاه صعودياً. راقب EMA50 كهدف."
                )
            }

            val indicators = IndicatorSnapshot(ema20, ema50, rsi, atr, rvol, lastClose)
            val card = TradeCard(
                symbol = symbol,
                direction = direction,
                mode = mode,
                signalScore = score,
                signalStrength = strength,
                entryZoneLow = zoneLow,
                entryZoneHigh = zoneHigh,
                stopLossPrice = stopLoss,
                takeProfits = tps,
                riskRewardRatio = rr,
                leverageSuggestion = 1,
                positionSizeUsdt = 0.0,
                indicators = indicators,
                arabicReasoning = reasoning,
                counterScenario = counter
            )
            Result.success(card)
        }
}
