// File: ScannerRepository.kt
package com.agon.app.scanner

import com.agon.app.models.ScannedPair
import com.agon.app.models.ScannerState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * مستودع الماسح — يغلّف MarketScanner بـ StateFlow وتحديث تلقائي.
 */
class ScannerRepository(
    private val marketScanner: MarketScanner,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(ScannerState())
    val state: StateFlow<ScannerState> = _state.asStateFlow()

    private var refreshJob: Job? = null

    suspend fun refresh() {
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)
        marketScanner.scan().fold(
            onSuccess = { pairs ->
                _state.value = ScannerState(
                    pairs = pairs,
                    isLoading = false,
                    errorMessage = null,
                    lastFetchTime = System.currentTimeMillis()
                )
            },
            onFailure = { e ->
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = e.message ?: "خطأ غير معروف"
                )
            }
        )
    }

    fun startAutoRefresh(intervalSeconds: Long = 20L) {
        refreshJob?.cancel()
        refreshJob = scope.launch {
            while (isActive) {
                refresh()
                delay(intervalSeconds * 1000L)
            }
        }
    }

    fun stopAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = null
    }

    fun filterBySymbol(query: String): List<ScannedPair> {
        if (query.isBlank()) return _state.value.pairs
        return _state.value.pairs.filter { it.symbol.contains(query.uppercase()) }
    }
}
