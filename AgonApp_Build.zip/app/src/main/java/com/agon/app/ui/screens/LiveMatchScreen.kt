// File: LiveMatchScreen.kt
package com.agon.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.models.Direction
import com.agon.app.models.TradeStatus
import com.agon.app.ui.components.HealthBar
import com.agon.app.ui.theme.CardBackground
import com.agon.app.ui.theme.CoralRed
import com.agon.app.ui.theme.EmeraldGreen
import com.agon.app.ui.theme.TextSecondary
import com.agon.app.ui.viewmodel.LiveMatchViewModel

/**
 * شاشة المباراة الحية — الصفقات المفتوحة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveMatchScreen(
    state: LiveMatchViewModel.UiState,
    onCloseTrade: (String, Double, TradeStatus) -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("المباراة الحية") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (state.openTrades.isEmpty()) {
                Text(
                    "لا توجد صفقات مفتوحة.\nافتح صفقة من تبويب الإشارات.",
                    color = TextSecondary,
                    modifier = Modifier.padding(40.dp)
                )
            } else {
                LazyColumn {
                    items(state.openTrades) { trade ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBackground)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        trade.symbol,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                    Text(
                                        if (trade.direction == Direction.LONG) "شراء" else "بيع",
                                        color = if (trade.direction == Direction.LONG) EmeraldGreen else CoralRed
                                    )
                                }
                                Text(
                                    "دخول: ${trade.entryPrice} • وقف: ${trade.stopLoss}",
                                    color = TextSecondary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                HealthBar(healthIndex = trade.healthIndex)
                                Button(
                                    onClick = {
                                        onCloseTrade(trade.id, trade.currentPrice, TradeStatus.CLOSED_MANUAL)
                                    },
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                                ) {
                                    Text("إغلاق الصفقة يدوياً")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
