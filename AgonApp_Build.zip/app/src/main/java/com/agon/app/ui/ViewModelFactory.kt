// File: ViewModelFactory.kt
package com.agon.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.agon.app.AgonApp
import com.agon.app.ui.viewmodel.LiveMatchViewModel
import com.agon.app.ui.viewmodel.ScannerViewModel
import com.agon.app.ui.viewmodel.SettingsViewModel
import com.agon.app.ui.viewmodel.SignalsViewModel

/**
 * Factory يدوي لربط ViewModels بـ AgonApp singletons.
 */
class AgonViewModelFactory(private val app: AgonApp) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ScannerViewModel::class.java) ->
                ScannerViewModel(app.scannerRepository) as T
            modelClass.isAssignableFrom(SignalsViewModel::class.java) ->
                SignalsViewModel(app.playmakerEngine, app.goalkeeperRisk, app.preferencesManager) as T
            modelClass.isAssignableFrom(LiveMatchViewModel::class.java) ->
                LiveMatchViewModel(app.matchCoach, app.preferencesManager) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(app.preferencesManager, app.tradeHistoryRepository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
        }
    }
}
