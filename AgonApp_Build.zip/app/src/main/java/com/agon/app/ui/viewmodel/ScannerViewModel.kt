// File: ScannerViewModel.kt
package com.agon.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.models.ScannerState
import com.agon.app.scanner.ScannerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel لشاشة الماسح.
 */
class ScannerViewModel(private val repository: ScannerRepository) : ViewModel() {

    val state: StateFlow<ScannerState> = repository.state

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    init {
        repository.startAutoRefresh(20)
    }

    fun onQueryChange(q: String) {
        _query.value = q
    }

    fun refreshNow() {
        viewModelScope.launch { repository.refresh() }
    }

    override fun onCleared() {
        super.onCleared()
        repository.stopAutoRefresh()
    }
}
