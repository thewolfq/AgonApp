// File: HealthBar.kt
package com.agon.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.agon.app.ui.theme.CoralRed
import com.agon.app.ui.theme.EmeraldGreen
import com.agon.app.ui.theme.WarningOrange

/**
 * شريط صحة الصفقة (0-100).
 */
@Composable
fun HealthBar(healthIndex: Int, modifier: Modifier = Modifier) {
    val (color, label) = when {
        healthIndex >= 60 -> EmeraldGreen to "جيدة"
        healthIndex >= 30 -> WarningOrange to "متوسطة"
        else -> CoralRed to "ضعيفة"
    }
    Column(modifier = modifier.padding(vertical = 4.dp)) {
        Text("صحة الصفقة: $healthIndex/100 ($label)", style = MaterialTheme.typography.bodySmall, color = color)
        LinearProgressIndicator(
            progress = { healthIndex / 100f },
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            color = color,
            trackColor = Color(0xFF2A3555)
        )
    }
}
