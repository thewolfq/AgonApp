package com.ghaith.trading.data

import java.math.BigDecimal

enum class MarketKind { SPOT, FUTURES }

data class Ticker(
    val symbol: String,
    val last: BigDecimal,
    val changePct: BigDecimal,
    val quoteVolume: BigDecimal,
)
