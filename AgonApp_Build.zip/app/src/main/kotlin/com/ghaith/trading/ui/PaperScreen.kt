package com.ghaith.trading.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghaith.trading.AppState
import com.ghaith.trading.domain.portfolio.CloseReason
import com.ghaith.trading.domain.portfolio.ClosedTrade
import com.ghaith.trading.domain.portfolio.PaperEngine
import com.ghaith.trading.domain.portfolio.PaperPosition
import com.ghaith.trading.domain.risk.Side
import com.ghaith.trading.ui.theme.GaithDown
import java.math.BigDecimal
import java.math.RoundingMode

private fun sideLabel(side: Side): String = if (side == Side.LONG) "شراء" else "بيع"

private fun reasonLabel(r: CloseReason): String =
    when (r) {
        CloseReason.MANUAL -> "إغلاق يدوي"
        CloseReason.STOP -> "وقف الخسارة"
        CloseReason.TAKE_PROFIT -> "جني الأرباح"
        CloseReason.LIQUIDATION -> "تصفية"
    }

@Composable
fun PaperScreen(state: AppState) {
    val account = state.account
    val prices = state.prices
    var message by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    var unrealized = BigDecimal.ZERO
    for (p in account.positions) {
        val price = prices[p.symbol]
        if (price != null) unrealized = unrealized.add(PaperEngine.unrealized(p, price))
    }
    val equity = account.balance.add(unrealized)
    val available = PaperEngine.available(account)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(12.dp),
    ) {
        item(key = "summary") {
            SectionCard(title = "حسابي التجريبي") {
                KeyValueRow("الرصيد", account.balance.fixed(2) + " USDT")
                KeyValueRow("المتاح", available.fixed(2) + " USDT")
                KeyValueRow("الربح/الخسارة المفتوحة", unrealized.signed(2) + " USDT", pnlColor(unrealized))
                KeyValueRow("إجمالي القيمة", equity.fixed(2) + " USDT")
                val pct = equity.subtract(PaperEngine.START_BALANCE)
                    .multiply(BigDecimal(100))
                    .divide(PaperEngine.START_BALANCE, 2, RoundingMode.HALF_UP)
                KeyValueRow("العائد منذ البداية", pct.signed(2) + "%", pnlColor(pct))
                OutlinedButton(onClick = { confirmReset = true }) { Text("إعادة ضبط الحساب") }
            }
        }
        val msg = message
        if (msg != null) {
            item(key = "message") { Text(text = "⚠ $msg", color = GaithDown) }
        }
        item(key = "open-title") {
            Text("المراكز المفتوحة (${account.positions.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        if (account.positions.isEmpty()) {
            item(key = "open-empty") {
                Text(
                    "لا توجد صفقات. اختر عملة من السوق ثم افتح صفقة من الحاسبة.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(account.positions, key = { "p" + it.id }) { p ->
            PositionCard(p, prices[p.symbol]) { message = state.closePosition(p.id) }
        }
        item(key = "history-title") {
            Text("السجل (${account.history.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        items(account.history, key = { "h" + it.id }) { t -> HistoryRow(t) }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("إعادة ضبط الحساب؟") },
            text = { Text("سيعود الرصيد إلى 10,000 USDT وتُحذف كل الصفقات والسجل.") },
            confirmButton = {
                TextButton(onClick = {
                    state.resetAccount()
                    message = null
                    confirmReset = false
                }) { Text("نعم، أعد الضبط") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun PositionCard(p: PaperPosition, price: BigDecimal?, onClose: () -> Unit) {
    SectionCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(p.symbol, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                text = sideLabel(p.side) + " ×" + p.leverage,
                color = pnlColor(if (p.side == Side.LONG) BigDecimal.ONE else BigDecimal.ONE.negate()),
                fontWeight = FontWeight.Medium,
            )
        }
        KeyValueRow("الدخول", p.entry.plain())
        KeyValueRow("السعر الحالي", price?.plain() ?: "—")
        KeyValueRow("الكمية", p.qty.floorTo(6))
        if (price != null) {
            val pnl = PaperEngine.unrealized(p, price)
            val roe = pnl.multiply(BigDecimal(100)).divide(p.margin, 2, RoundingMode.HALF_UP)
            KeyValueRow("الربح/الخسارة", pnl.signed(2) + " USDT (" + roe.signed(2) + "%)", pnlColor(pnl))
        }
        val stop = p.stop
        if (stop != null) KeyValueRow("الوقف", stop.plain())
        val tp = p.takeProfit
        if (tp != null) KeyValueRow("الهدف", tp.plain())
        KeyValueRow("التصفية", p.liquidation.fixed(4))
        OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("إغلاق الصفقة") }
    }
}

@Composable
private fun HistoryRow(t: ClosedTrade) {
    SectionCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(t.symbol + " · " + sideLabel(t.side), fontWeight = FontWeight.Bold)
            Text(ltr(t.pnl.signed(2) + " USDT"), color = pnlColor(t.pnl), fontWeight = FontWeight.Medium)
        }
        Text(
            text = reasonLabel(t.reason) + " · " + ltr(formatTime(t.closedAtMs, "MM-dd HH:mm")),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
        )
    }
}
