package com.ghaith.trading.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghaith.trading.AppState
import com.ghaith.trading.domain.risk.CalcResult
import com.ghaith.trading.domain.risk.PositionCalculator
import com.ghaith.trading.domain.risk.PositionInput
import com.ghaith.trading.domain.risk.Side
import com.ghaith.trading.ui.theme.GaithDown
import com.ghaith.trading.ui.theme.GaithUp
import java.util.Locale

@Composable
private fun NumField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier,
    )
}

@Composable
fun CalculatorScreen(state: AppState) {
    var feedback by remember { mutableStateOf<String?>(null) }

    val symbol = state.calcSymbol.trim().uppercase(Locale.US)
    val livePrice = state.prices[symbol]
    val entry = parseDecimal(state.calcEntry)
    val stop = parseDecimal(state.calcStop)
    val tpText = state.calcTp.trim()
    val tp = if (tpText.isEmpty()) null else parseDecimal(tpText)
    val leverage = state.calcLeverage.trim().toIntOrNull()
    val risk = parseDecimal(state.calcRisk)

    val input: PositionInput? =
        if (entry == null || stop == null || leverage == null || risk == null || (tpText.isNotEmpty() && tp == null)) {
            null
        } else {
            PositionInput(state.calcSide, entry, stop, tp, leverage, risk)
        }
    val result: CalcResult? = if (input == null) null else PositionCalculator.calculate(input)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        OutlinedTextField(
            value = state.calcSymbol,
            onValueChange = { state.calcSymbol = it },
            label = { Text("رمز العملة (مثل BTCUSDT)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = if (livePrice != null) "السعر الحالي: " + ltr(livePrice.plain()) else "السعر الحالي: غير متاح",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleChip("شراء (Long)", state.calcSide == Side.LONG) { state.calcSide = Side.LONG }
            ToggleChip("بيع (Short)", state.calcSide == Side.SHORT) { state.calcSide = Side.SHORT }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NumField("سعر الدخول", state.calcEntry, { state.calcEntry = it }, Modifier.weight(1f))
            OutlinedButton(
                onClick = { if (livePrice != null) state.calcEntry = livePrice.plain() },
                enabled = livePrice != null,
            ) { Text("السعر الحالي") }
        }
        NumField("وقف الخسارة", state.calcStop, { state.calcStop = it }, Modifier.fillMaxWidth())
        NumField("الهدف (اختياري)", state.calcTp, { state.calcTp = it }, Modifier.fillMaxWidth())
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumField("الرافعة (1–125)", state.calcLeverage, { state.calcLeverage = it }, Modifier.weight(1f))
            NumField("المخاطرة (USDT)", state.calcRisk, { state.calcRisk = it }, Modifier.weight(1f))
        }

        when (result) {
            null -> Text(
                text = "أدخل سعر الدخول والوقف والرافعة ومبلغ المخاطرة لتظهر النتيجة.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            is CalcResult.Invalid -> Text(text = "⚠ " + result.reason, color = GaithDown)
            is CalcResult.Ok -> {
                val o = result.value
                SectionCard(title = "نتيجة الحساب") {
                    KeyValueRow("الكمية", o.qty.floorTo(6))
                    KeyValueRow("قيمة المركز", o.notional.fixed(2) + " USDT")
                    KeyValueRow("الهامش المطلوب", o.margin.fixed(2) + " USDT")
                    KeyValueRow("عمولة الدخول", o.entryFee.fixed(4) + " USDT")
                    KeyValueRow("سعر التصفية (تقريبي)", o.liquidation.plain().let { trimmed(it) })
                    KeyValueRow("الخسارة عند الوقف", "-" + o.lossAtStop.fixed(2) + " USDT", GaithDown)
                    val profit = o.profitAtTp
                    if (profit != null) {
                        KeyValueRow("الربح عند الهدف", "+" + profit.fixed(2) + " USDT", GaithUp)
                    }
                    val rr = o.rewardRisk
                    if (rr != null) {
                        KeyValueRow("العائد / المخاطرة", "1 : " + rr.fixed(2))
                    }
                }
                Button(
                    onClick = { feedback = if (input == null) null else state.openPaper(input, o) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("فتح صفقة تجريبية") }
            }
        }
        val msg = feedback
        if (msg != null) {
            Text(text = "⚠ $msg", color = GaithDown)
        }
        Text(
            text = "تقديرات تعليمية: العمولة 0.05% لكل جهة، وهامش الصيانة 0.5%، والتصفية تقريبية. الصفقات تجريبية فقط.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
        )
    }
}

private fun trimmed(plainValue: String): String {
    val dot = plainValue.indexOf('.')
    return if (dot < 0 || plainValue.length - dot <= 7) plainValue else plainValue.substring(0, dot + 7)
}
