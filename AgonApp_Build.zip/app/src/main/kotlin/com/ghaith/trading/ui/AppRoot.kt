package com.ghaith.trading.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghaith.trading.AppState
import com.ghaith.trading.MainActivity
import com.ghaith.trading.R
import com.ghaith.trading.ui.theme.GaithDown
import com.ghaith.trading.ui.theme.GaithUp

private data class TabItem(val icon: String, val label: String)

private val TABS = listOf(
    TabItem("📈", "السوق"),
    TabItem("🧮", "الحاسبة"),
    TabItem("💼", "صفقاتي"),
)

@Composable
fun AppRoot(state: AppState) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = { TitleBar(state) },
        bottomBar = {
            NavigationBar {
                TABS.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = state.tab == index,
                        onClick = { state.tab = index },
                        icon = { Text(item.icon, fontSize = 20.sp) },
                        label = { Text(item.label) },
                    )
                }
            }
        },
    ) { insets ->
        Box(modifier = Modifier.fillMaxSize().padding(insets)) {
            when (state.tab) {
                0 -> MarketScreen(state)
                1 -> CalculatorScreen(state)
                else -> PaperScreen(state)
            }
        }
    }
}

@Composable
private fun TitleBar(state: AppState) {
    var showAbout by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .semantics { testTag = MainActivity.TAG_APP_TITLE },
                )
                IconButton(onClick = { showAbout = true }) {
                    Text("ⓘ", color = MaterialTheme.colorScheme.primary, fontSize = 22.sp)
                }
            }
            val err = state.error
            if (err != null) {
                Text(text = "⚠ $err", color = GaithDown, fontSize = 12.sp)
            } else if (state.updatedAtMs == 0L) {
                Text(
                    text = "جارٍ تحميل الأسعار…",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                )
            } else {
                Text(
                    text = "● مباشر · " + ltr(formatTime(state.updatedAtMs, "HH:mm:ss")),
                    color = GaithUp,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                )
            }
        }
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("حول التطبيق") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("غيث التداول - GAITH TRADING")
                    Text("المطوّر: عبد الوارث الذيب")
                    Text("الإصدار 0.3.0")
                    Text("© 2026")
                    Text("أداة تعليمية وتحليلية للتداول الورقي فقط؛ لا ترسل أوامر تداول حقيقية.")
                }
            },
            confirmButton = {
                TextButton(onClick = { showAbout = false }) { Text("إغلاق") }
            },
        )
    }
}
