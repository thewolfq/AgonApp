package com.ghaith.trading.ui

import androidx.compose.ui.graphics.Color
import com.ghaith.trading.ui.theme.GaithDown
import com.ghaith.trading.ui.theme.GaithUp
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val LRM = "\u200E"

/** يثبّت اتجاه الأرقام يسار→يمين داخل نص عربي حتى لا ينقلب موضع الإشارة. */
fun ltr(s: String): String = LRM + s

fun BigDecimal.plain(): String = stripTrailingZeros().toPlainString()

fun BigDecimal.fixed(scale: Int): String = setScale(scale, RoundingMode.HALF_UP).toPlainString()

fun BigDecimal.floorTo(scale: Int): String = setScale(scale, RoundingMode.DOWN).toPlainString()

fun BigDecimal.signed(scale: Int): String {
    val text = fixed(scale)
    return if (signum() > 0) "+$text" else text
}

fun pnlColor(v: BigDecimal): Color =
    when {
        v.signum() > 0 -> GaithUp
        v.signum() < 0 -> GaithDown
        else -> Color.Unspecified
    }

private val BILLION = BigDecimal("1000000000")
private val MILLION = BigDecimal("1000000")
private val THOUSAND = BigDecimal("1000")

fun compactVolume(v: BigDecimal): String =
    when {
        v >= BILLION -> v.divide(BILLION, 2, RoundingMode.HALF_UP).toPlainString() + "B"
        v >= MILLION -> v.divide(MILLION, 2, RoundingMode.HALF_UP).toPlainString() + "M"
        v >= THOUSAND -> v.divide(THOUSAND, 1, RoundingMode.HALF_UP).toPlainString() + "K"
        else -> v.setScale(0, RoundingMode.HALF_UP).toPlainString()
    }

/** يقرأ رقماً عشرياً ويقبل الأرقام العربية الهندية والفاصلة العربية. */
fun parseDecimal(raw: String): BigDecimal? {
    val sb = StringBuilder(raw.length)
    for (ch in raw.trim()) {
        when (ch) {
            in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
            in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
            '\u066B', ',' -> sb.append('.')
            else -> sb.append(ch)
        }
    }
    return sb.toString().toBigDecimalOrNull()
}

fun formatTime(ms: Long, pattern: String): String =
    SimpleDateFormat(pattern, Locale.US).format(Date(ms))
