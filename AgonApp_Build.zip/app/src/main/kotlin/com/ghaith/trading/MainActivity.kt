package com.ghaith.trading

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.ghaith.trading.data.PaperStore
import com.ghaith.trading.ui.AppRoot
import com.ghaith.trading.ui.theme.GaithTheme

/*
 * MainActivity — النشاط الوحيد. يحمل حالة التطبيق (AppState) ويشغّل التحديث الدوري
 * لأسعار بينانس فقط أثناء ظهور التطبيق (onStart/onStop).
 */
class MainActivity : ComponentActivity() {
    private lateinit var state: AppState

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        state = AppState(PaperStore(applicationContext))
        setContent {
            GaithTheme {
                AppRoot(state)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        state.start()
    }

    override fun onStop() {
        state.stop()
        super.onStop()
    }

    companion object {
        const val TAG_APP_TITLE = "app_title"
    }
}
