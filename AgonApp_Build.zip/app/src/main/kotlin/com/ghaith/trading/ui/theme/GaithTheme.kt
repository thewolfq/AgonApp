package com.ghaith.trading.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import com.ghaith.trading.domain.evaluation.DataState

/*
 * GaithTheme — §6.3 من 01_architecture: الهوية البصرية، الألوان الدلالية لحالات DataState،
 * وخط أحادي المسافة للأرقام لمنع اهتزازها. الاتجاه RTL حصري (§1.1).
 * ألوان نتائج TradeEvaluation تُضاف مع النوع نفسه في M2.
 */

private val GaithColors = darkColorScheme(
    primary = Color(0xFF4FC3F7),
    onPrimary = Color(0xFF00222E),
    background = Color(0xFF0E1A24),
    onBackground = Color(0xFFE3EEF5),
    surface = Color(0xFF14232F),
    onSurface = Color(0xFFE3EEF5),
    surfaceVariant = Color(0xFF1C3140),
    onSurfaceVariant = Color(0xFF9FB6C6),
    outline = Color(0xFF3C5668),
    error = Color(0xFFEF5350),
)

/** لون الارتفاع/الربح. */
val GaithUp = Color(0xFF26A69A)

/** لون الانخفاض/الخسارة. */
val GaithDown = Color(0xFFEF5350)

/** نمط الأرقام: أحادي المسافة كي لا تهتز الأعمدة عند التحديث. */
val GaithNumericStyle = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Medium,
    fontSize = 15.sp,
)

private val GaithTypography = Typography(
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 22.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp),
)

/** اللون الدلالي لكل حالة بيانات (تستعمله DataStateBadge في M3). */
fun dataStateColor(state: DataState): Color =
    when (state) {
        DataState.LIVE -> Color(0xFF2E7D32)
        is DataState.CACHED -> Color(0xFFF9A825)
        DataState.STALE -> Color(0xFFC62828)
        DataState.ESTIMATED -> Color(0xFF6A1B9A)
        DataState.PAPER -> Color(0xFF1565C0)
        DataState.RECONSTRUCTED -> Color(0xFF5D4037)
    }

@Composable
fun GaithTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = GaithColors,
            typography = GaithTypography,
            content = content,
        )
    }
}
