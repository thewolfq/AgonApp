package com.ghaith.trading.data

import android.content.Context
import com.ghaith.trading.domain.portfolio.Account
import com.ghaith.trading.domain.portfolio.ClosedTrade
import com.ghaith.trading.domain.portfolio.CloseReason
import com.ghaith.trading.domain.portfolio.PaperEngine
import com.ghaith.trading.domain.portfolio.PaperPosition
import com.ghaith.trading.domain.risk.Side
import org.json.JSONArray
import org.json.JSONObject

/** حفظ حساب التداول التجريبي محلياً (SharedPreferences، نص JSON). */
class PaperStore(context: Context) {
    private val prefs = context.getSharedPreferences("paper_account", Context.MODE_PRIVATE)

    var warning: String? = null
        private set
    var canWrite: Boolean = true
        private set
    private var recoveredFromBackup = false

    fun load(): Account {
        val raw = prefs.getString(KEY, null)
        if (raw != null) {
            try {
                return fromJson(JSONObject(raw))
            } catch (_: Exception) {
                // ننتقل إلى النسخة الاحتياطية أدناه، دون الكتابة فوق الحفظ التالف.
            }
        }

        val backup = prefs.getString(BACKUP_KEY, null)
        if (backup != null) {
            val recovered = try {
                fromJson(JSONObject(backup))
            } catch (_: Exception) {
                null
            }
            if (recovered != null) {
                recoveredFromBackup = true
                warning = "تعذر الوصول إلى الحفظ الأساسي؛ تم استرداد نسخة الحساب الاحتياطية."
                return recovered
            }
            canWrite = false
            warning = "بيانات الحساب الأساسية والاحتياطية غير صالحة. لم تُحذف البيانات ولم يُسمح بالكتابة فوقها؛ أعد الضبط يدويًا فقط إن قررت بدء حساب جديد."
            return PaperEngine.newAccount()
        }

        // إذا كان المفتاح الأساسي موجودًا لكنه تالف، فلا نعتبره تثبيتًا جديدًا.
        // امنع أي حفظ تلقائي فوقه حتى يقرر المستخدم إعادة الضبط صراحةً.
        if (raw != null) {
            canWrite = false
            warning = "تعذرت قراءة بيانات الحساب ولم توجد نسخة احتياطية سليمة. لم تُحذف البيانات؛ أعد الضبط يدويًا فقط إن قررت بدء حساب جديد."
        }
        // لا يوجد حفظ أساسي أو احتياطي أصلًا: تثبيت جديد طبيعي.
        return PaperEngine.newAccount()
    }

    fun loadLastPrices(symbols: Set<String>): Map<String, java.math.BigDecimal> {
        if (symbols.isEmpty()) return emptyMap()
        val raw = prefs.getString(PRICES_KEY, null) ?: return emptyMap()
        return try {
            val json = JSONObject(raw)
            buildMap {
                for (symbol in symbols) {
                    if (json.has(symbol)) {
                        val price = json.getString(symbol).toBigDecimal()
                        if (price.signum() > 0) put(symbol, price)
                    }
                }
            }
        } catch (_: Exception) {
            warning = warning ?: "تعذر قراءة آخر الأسعار المحفوظة؛ سيتم انتظار تحديث حي قبل أي إغلاق تلقائي."
            emptyMap()
        }
    }

    fun save(account: Account) {
        check(canWrite) { warning ?: "حفظ الحساب متوقف لحماية البيانات الحالية" }
        val current = prefs.getString(KEY, null)
        val editor = prefs.edit()
        if (!recoveredFromBackup && current != null) {
            val currentIsValid = try {
                fromJson(JSONObject(current))
                true
            } catch (_: Exception) {
                false
            }
            if (currentIsValid) editor.putString(BACKUP_KEY, current)
        }
        editor.putString(KEY, toJson(account).toString())
        check(editor.commit()) { "تعذر تثبيت حفظ الحساب على الجهاز" }
        recoveredFromBackup = false
        if (warning?.startsWith("تعذر الوصول إلى الحفظ الأساسي") == true ||
            warning?.startsWith("تعذرت قراءة آخر حفظ") == true
        ) {
            warning = null
        }
    }

    fun saveLastPrices(prices: Map<String, java.math.BigDecimal>, symbols: Set<String>) {
        var previousWasCorrupt = false
        val previous = try {
            prefs.getString(PRICES_KEY, null)?.let(::JSONObject) ?: JSONObject()
        } catch (_: Exception) {
            previousWasCorrupt = true
            warning = warning ?: "تعذر قراءة آخر الأسعار السابقة؛ ستُحفظ الأسعار المتاحة حاليًا فقط."
            JSONObject()
        }
        val json = JSONObject()
        for (symbol in symbols) {
            val cached = try {
                if (previous.has(symbol)) previous.getString(symbol).toBigDecimal() else null
            } catch (_: Exception) {
                null
            }
            // لا تمسح سعرًا محفوظًا لمركز مفتوح لمجرد أن استجابة السوق الحالية لم تتضمن رمزه.
            val price = prices[symbol]?.takeIf { it.signum() > 0 } ?: cached?.takeIf { it.signum() > 0 }
            if (price != null) json.put(symbol, price.toPlainString())
        }
        if (!prefs.edit().putString(PRICES_KEY, json.toString()).commit()) {
            warning = "تعذر حفظ آخر الأسعار؛ قد لا يمكن إغلاق بعض المراكز عند فقد الاتصال."
        } else if (!previousWasCorrupt && (
                warning?.startsWith("تعذر حفظ آخر الأسعار") == true ||
                    warning?.startsWith("تعذر قراءة آخر الأسعار") == true
                )
        ) {
            warning = null
        }
    }

    fun reset(account: Account) {
        val saved = prefs.edit()
            .remove(BACKUP_KEY)
            .remove(PRICES_KEY)
            .putString(KEY, toJson(account).toString())
            .commit()
        check(saved) { "تعذر إعادة ضبط الحساب وحفظه" }
        canWrite = true
        warning = null
        recoveredFromBackup = false
    }

    private fun toJson(a: Account): JSONObject {
        val positions = JSONArray()
        for (p in a.positions) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("symbol", p.symbol)
            o.put("side", p.side.name)
            o.put("entry", p.entry.toPlainString())
            o.put("qty", p.qty.toPlainString())
            o.put("lev", p.leverage)
            o.put("margin", p.margin.toPlainString())
            o.put("entryFee", p.entryFee.toPlainString())
            o.put("feeRate", p.feeRate.toPlainString())
            o.put("liq", p.liquidation.toPlainString())
            p.stop?.let { o.put("stop", it.toPlainString()) }
            p.takeProfit?.let { o.put("tp", it.toPlainString()) }
            o.put("openedAt", p.openedAtMs)
            positions.put(o)
        }
        val history = JSONArray()
        for (t in a.history) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("symbol", t.symbol)
            o.put("side", t.side.name)
            o.put("entry", t.entry.toPlainString())
            o.put("exit", t.exit.toPlainString())
            o.put("qty", t.qty.toPlainString())
            o.put("pnl", t.pnl.toPlainString())
            o.put("reason", t.reason.name)
            o.put("openedAt", t.openedAtMs)
            o.put("closedAt", t.closedAtMs)
            history.put(o)
        }
        val root = JSONObject()
        root.put("balance", a.balance.toPlainString())
        root.put("nextId", a.nextId)
        root.put("positions", positions)
        root.put("history", history)
        return root
    }

    private fun fromJson(root: JSONObject): Account {
        val positions = ArrayList<PaperPosition>()
        val pa = root.getJSONArray("positions")
        for (i in 0 until pa.length()) {
            val o = pa.getJSONObject(i)
            positions.add(
                PaperPosition(
                    id = o.getLong("id"),
                    symbol = o.getString("symbol"),
                    side = Side.valueOf(o.getString("side")),
                    entry = o.getString("entry").toBigDecimal(),
                    qty = o.getString("qty").toBigDecimal(),
                    leverage = o.getInt("lev"),
                    margin = o.getString("margin").toBigDecimal(),
                    entryFee = o.getString("entryFee").toBigDecimal(),
                    feeRate = if (o.has("feeRate")) o.getString("feeRate").toBigDecimal() else PaperEngine.TAKER_FEE,
                    liquidation = o.getString("liq").toBigDecimal(),
                    stop = if (o.has("stop")) o.getString("stop").toBigDecimal() else null,
                    takeProfit = if (o.has("tp")) o.getString("tp").toBigDecimal() else null,
                    openedAtMs = o.getLong("openedAt"),
                ),
            )
        }
        val history = ArrayList<ClosedTrade>()
        val ha = root.getJSONArray("history")
        for (i in 0 until ha.length()) {
            val o = ha.getJSONObject(i)
            history.add(
                ClosedTrade(
                    id = o.getLong("id"),
                    symbol = o.getString("symbol"),
                    side = Side.valueOf(o.getString("side")),
                    entry = o.getString("entry").toBigDecimal(),
                    exit = o.getString("exit").toBigDecimal(),
                    qty = o.getString("qty").toBigDecimal(),
                    pnl = o.getString("pnl").toBigDecimal(),
                    reason = CloseReason.valueOf(o.getString("reason")),
                    openedAtMs = o.getLong("openedAt"),
                    closedAtMs = o.getLong("closedAt"),
                ),
            )
        }
        return Account(
            balance = root.getString("balance").toBigDecimal(),
            positions = positions,
            history = history,
            nextId = root.getLong("nextId"),
        )
    }

    private companion object {
        const val KEY = "account"
        const val BACKUP_KEY = "account_backup"
        const val PRICES_KEY = "last_prices"
    }
}
