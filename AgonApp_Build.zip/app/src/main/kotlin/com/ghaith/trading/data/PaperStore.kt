package com.ghaith.trading.data

import android.content.Context
import com.ghaith.trading.domain.portfolio.Account
import com.ghaith.trading.domain.portfolio.ClosedTrade
import com.ghaith.trading.domain.portfolio.CloseReason
import com.ghaith.trading.domain.portfolio.PaperEngine
import com.ghaith.trading.domain.portfolio.PaperPosition
import com.ghaith.trading.domain.risk.Side
import org.json.JSONArray
import org.json.JSONObject

/** حفظ حساب التداول التجريبي محلياً (SharedPreferences، نص JSON). */
class PaperStore(context: Context) {
    private val prefs = context.getSharedPreferences("paper_account", Context.MODE_PRIVATE)

    fun load(): Account {
        val raw = prefs.getString(KEY, null) ?: return PaperEngine.newAccount()
        return try {
            fromJson(JSONObject(raw))
        } catch (e: Exception) {
            PaperEngine.newAccount()
        }
    }

    fun save(account: Account) {
        prefs.edit().putString(KEY, toJson(account).toString()).apply()
    }

    private fun toJson(a: Account): JSONObject {
        val positions = JSONArray()
        for (p in a.positions) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("symbol", p.symbol)
            o.put("side", p.side.name)
            o.put("entry", p.entry.toPlainString())
            o.put("qty", p.qty.toPlainString())
            o.put("lev", p.leverage)
            o.put("margin", p.margin.toPlainString())
            o.put("entryFee", p.entryFee.toPlainString())
            o.put("liq", p.liquidation.toPlainString())
            p.stop?.let { o.put("stop", it.toPlainString()) }
            p.takeProfit?.let { o.put("tp", it.toPlainString()) }
            o.put("openedAt", p.openedAtMs)
            positions.put(o)
        }
        val history = JSONArray()
        for (t in a.history) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("symbol", t.symbol)
            o.put("side", t.side.name)
            o.put("entry", t.entry.toPlainString())
            o.put("exit", t.exit.toPlainString())
            o.put("qty", t.qty.toPlainString())
            o.put("pnl", t.pnl.toPlainString())
            o.put("reason", t.reason.name)
            o.put("openedAt", t.openedAtMs)
            o.put("closedAt", t.closedAtMs)
            history.put(o)
        }
        val root = JSONObject()
        root.put("balance", a.balance.toPlainString())
        root.put("nextId", a.nextId)
        root.put("positions", positions)
        root.put("history", history)
        return root
    }

    private fun fromJson(root: JSONObject): Account {
        val positions = ArrayList<PaperPosition>()
        val pa = root.getJSONArray("positions")
        for (i in 0 until pa.length()) {
            val o = pa.getJSONObject(i)
            positions.add(
                PaperPosition(
                    id = o.getLong("id"),
                    symbol = o.getString("symbol"),
                    side = Side.valueOf(o.getString("side")),
                    entry = o.getString("entry").toBigDecimal(),
                    qty = o.getString("qty").toBigDecimal(),
                    leverage = o.getInt("lev"),
                    margin = o.getString("margin").toBigDecimal(),
                    entryFee = o.getString("entryFee").toBigDecimal(),
                    liquidation = o.getString("liq").toBigDecimal(),
                    stop = if (o.has("stop")) o.getString("stop").toBigDecimal() else null,
                    takeProfit = if (o.has("tp")) o.getString("tp").toBigDecimal() else null,
                    openedAtMs = o.getLong("openedAt"),
                ),
            )
        }
        val history = ArrayList<ClosedTrade>()
        val ha = root.getJSONArray("history")
        for (i in 0 until ha.length()) {
            val o = ha.getJSONObject(i)
            history.add(
                ClosedTrade(
                    id = o.getLong("id"),
                    symbol = o.getString("symbol"),
                    side = Side.valueOf(o.getString("side")),
                    entry = o.getString("entry").toBigDecimal(),
                    exit = o.getString("exit").toBigDecimal(),
                    qty = o.getString("qty").toBigDecimal(),
                    pnl = o.getString("pnl").toBigDecimal(),
                    reason = CloseReason.valueOf(o.getString("reason")),
                    openedAtMs = o.getLong("openedAt"),
                    closedAtMs = o.getLong("closedAt"),
                ),
            )
        }
        return Account(
            balance = root.getString("balance").toBigDecimal(),
            positions = positions,
            history = history,
            nextId = root.getLong("nextId"),
        )
    }

    private companion object {
        const val KEY = "account"
    }
}
