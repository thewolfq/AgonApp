package com.ghaith.trading.data

import org.json.JSONArray
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL

/** عميل بينانس العام (قراءة فقط، بلا مفاتيح). */
object BinanceApi {
    class HttpError(val code: Int) : Exception("HTTP $code")

    private const val SPOT_24H = "https://api.binance.com/api/v3/ticker/24hr"
    private const val SPOT_24H_MIRROR = "https://data-api.binance.vision/api/v3/ticker/24hr"
    private const val FUT_24H = "https://fapi.binance.com/fapi/v1/ticker/24hr"
    private const val FUT_PRICE = "https://fapi.binance.com/fapi/v1/ticker/price"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 15000
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            if (code != 200) throw HttpError(code)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun getFirst(urls: List<String>): String {
        var last: Exception? = null
        for (u in urls) {
            try {
                return get(u)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("no urls")
    }

    fun fetchTickers(kind: MarketKind): List<Ticker> {
        val urls = when (kind) {
            MarketKind.SPOT -> listOf(SPOT_24H, SPOT_24H_MIRROR)
            MarketKind.FUTURES -> listOf(FUT_24H)
        }
        val arr = JSONArray(getFirst(urls))
        val out = ArrayList<Ticker>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val symbol = o.optString("symbol")
            if (!symbol.endsWith("USDT")) continue
            val last = o.optString("lastPrice").toBigDecimalOrNull() ?: continue
            if (last.signum() <= 0) continue
            val change = o.optString("priceChangePercent").toBigDecimalOrNull() ?: BigDecimal.ZERO
            val volume = o.optString("quoteVolume").toBigDecimalOrNull() ?: BigDecimal.ZERO
            out.add(Ticker(symbol, last, change, volume))
        }
        return out
    }

    /** أسعار كل عقود USDT-M الآجلة (خفيف) — تُستعمل لتحديث الصفقات التجريبية. */
    fun fetchFuturesPrices(): Map<String, BigDecimal> {
        val arr = JSONArray(get(FUT_PRICE))
        val out = HashMap<String, BigDecimal>(arr.length() * 2)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val symbol = o.optString("symbol")
            if (!symbol.endsWith("USDT")) continue
            val price = o.optString("price").toBigDecimalOrNull() ?: continue
            if (price.signum() > 0) out[symbol] = price
        }
        return out
    }
}
