package com.ghaith.trading

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ghaith.trading.data.BinanceApi
import com.ghaith.trading.data.MarketKind
import com.ghaith.trading.data.PaperStore
import com.ghaith.trading.data.Ticker
import com.ghaith.trading.domain.portfolio.Account
import com.ghaith.trading.domain.portfolio.CloseReason
import com.ghaith.trading.domain.portfolio.OpenResult
import com.ghaith.trading.domain.portfolio.PaperEngine
import com.ghaith.trading.domain.risk.PositionInput
import com.ghaith.trading.domain.risk.PositionOutput
import com.ghaith.trading.domain.risk.Side
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** حالة التطبيق الوحيدة: السوق والحاسبة والحساب التجريبي + التحديث الدوري كل 10 ثوانٍ. */
class AppState(private val store: PaperStore) {
    var tab by mutableIntStateOf(0)
    var kind by mutableStateOf(MarketKind.FUTURES)
    var tickers by mutableStateOf<List<Ticker>>(emptyList())
    var prices by mutableStateOf<Map<String, BigDecimal>>(emptyMap())
    var error by mutableStateOf<String?>(null)
    var updatedAtMs by mutableLongStateOf(0L)
    var account by mutableStateOf(store.load())

    var calcSymbol by mutableStateOf("BTCUSDT")
    var calcSide by mutableStateOf(Side.LONG)
    var calcEntry by mutableStateOf("")
    var calcStop by mutableStateOf("")
    var calcTp by mutableStateOf("")
    var calcLeverage by mutableStateOf("10")
    var calcRisk by mutableStateOf("50")

    private val lock = Any()
    private var executor: ScheduledExecutorService? = null

    fun start() {
        if (executor != null) return
        val ex = Executors.newSingleThreadScheduledExecutor()
        executor = ex
        ex.scheduleWithFixedDelay({ refreshSafely() }, 0L, 10L, TimeUnit.SECONDS)
    }

    fun stop() {
        executor?.shutdownNow()
        executor = null
    }

    fun changeKind(newKind: MarketKind) {
        if (newKind == kind) return
        kind = newKind
        tickers = emptyList()
        refreshNow()
    }

    fun refreshNow() {
        val ex = executor ?: return
        try {
            ex.execute { refreshSafely() }
        } catch (e: Exception) {
            // المنفّذ أُوقف أثناء الإغلاق؛ لا شيء لفعله.
        }
    }

    private fun refreshSafely() {
        try {
            refresh()
        } catch (e: Exception) {
            error = describe(e)
        }
    }

    private fun refresh() {
        val k = kind
        var err: String? = null
        try {
            val list = BinanceApi.fetchTickers(k)
            if (kind == k) {
                tickers = list
                updatedAtMs = System.currentTimeMillis()
                if (k == MarketKind.FUTURES) prices = list.associate { it.symbol to it.last }
            }
        } catch (e: Exception) {
            err = describe(e)
        }
        if (k != MarketKind.FUTURES) {
            try {
                prices = BinanceApi.fetchFuturesPrices()
            } catch (e: Exception) {
                if (err == null) err = describe(e)
            }
        }
        error = err
        if (account.positions.isNotEmpty() && prices.isNotEmpty()) {
            mutateAccount { PaperEngine.applyPrices(it, prices, System.currentTimeMillis()) }
        }
    }

    private fun describe(e: Exception): String =
        when {
            e is UnknownHostException -> "لا يوجد اتصال بالإنترنت"
            e is BinanceApi.HttpError && (e.code == 451 || e.code == 403) ->
                "بينانس يحجب الاتصال من منطقتك (${e.code})؛ جرّب VPN"
            e is BinanceApi.HttpError -> "خطأ من بينانس (${e.code})"
            else -> "تعذّر الاتصال ببينانس"
        }

    private fun mutateAccount(block: (Account) -> Account) {
        synchronized(lock) {
            val before = account
            val after = block(before)
            if (after !== before) {
                account = after
                store.save(after)
            }
        }
    }

    /** اختيار عملة من السوق: تعبئة الحاسبة بسعرها الحالي والانتقال إليها. */
    fun pickSymbol(t: Ticker) {
        calcSymbol = t.symbol
        calcEntry = (prices[t.symbol] ?: t.last).stripTrailingZeros().toPlainString()
        calcStop = ""
        calcTp = ""
        tab = 1
    }

    /** يعيد رسالة خطأ، أو null عند النجاح (ثم ينتقل لتبويب الصفقات). */
    fun openPaper(input: PositionInput, output: PositionOutput): String? {
        val symbol = calcSymbol.trim().uppercase(Locale.US)
        if (symbol.isEmpty()) return "اكتب رمز العملة"
        val market = prices[symbol]
            ?: return "الرمز غير موجود في عقود بينانس الآجلة، أو الأسعار لم تُحمَّل بعد"
        val deviation = input.entry.subtract(market).abs().divide(market, 6, RoundingMode.HALF_UP)
        if (deviation > MAX_ENTRY_DEVIATION) {
            return "سعر الدخول بعيد عن السعر الحالي؛ اضغط «السعر الحالي»"
        }
        var failure: String? = null
        mutateAccount { acc ->
            when (val r = PaperEngine.open(acc, symbol, input, output, System.currentTimeMillis())) {
                is OpenResult.Opened -> r.account
                is OpenResult.Rejected -> {
                    failure = r.reason
                    acc
                }
            }
        }
        if (failure == null) tab = 2
        return failure
    }

    fun closePosition(id: Long): String? {
        val position = account.positions.firstOrNull { it.id == id } ?: return null
        val price = prices[position.symbol] ?: return "لا يوجد سعر حي لهذا الرمز الآن"
        mutateAccount { PaperEngine.close(it, id, price, CloseReason.MANUAL, System.currentTimeMillis()) }
        return null
    }

    fun resetAccount() {
        mutateAccount { PaperEngine.newAccount() }
    }

    private companion object {
        val MAX_ENTRY_DEVIATION: BigDecimal = BigDecimal("0.01")
    }
}
