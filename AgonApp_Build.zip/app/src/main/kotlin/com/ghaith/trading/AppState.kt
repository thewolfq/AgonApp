package com.ghaith.trading

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ghaith.trading.data.BinanceApi
import com.ghaith.trading.data.MarketKind
import com.ghaith.trading.data.PaperStore
import com.ghaith.trading.data.Ticker
import com.ghaith.trading.domain.portfolio.Account
import com.ghaith.trading.domain.portfolio.CloseReason
import com.ghaith.trading.domain.portfolio.OpenResult
import com.ghaith.trading.domain.portfolio.PaperEngine
import com.ghaith.trading.domain.risk.PositionInput
import com.ghaith.trading.domain.risk.PositionOutput
import com.ghaith.trading.domain.risk.Side
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** حالة التطبيق: السوق والحاسبة والحساب التجريبي وتحديث الأسعار كل 10 ثوانٍ. */
class AppState(private val store: PaperStore) {
    var tab by mutableIntStateOf(0)
    var kind by mutableStateOf(MarketKind.FUTURES)
    var tickers by mutableStateOf<List<Ticker>>(emptyList())
    var error by mutableStateOf<String?>(null)
    var updatedAtMs by mutableLongStateOf(0L)
    var futuresPricesUpdatedAtMs by mutableLongStateOf(0L)

    var account by mutableStateOf(store.load())
    var prices by mutableStateOf(store.loadLastPrices(account.positions.map { it.symbol }.toSet()))
    var storageWarning by mutableStateOf(store.warning)

    var calcSymbol by mutableStateOf("BTCUSDT")
    var calcSide by mutableStateOf(Side.LONG)
    var calcEntry by mutableStateOf("")
    var calcStop by mutableStateOf("")
    var calcTp by mutableStateOf("")
    var calcLeverage by mutableStateOf("10")
    var calcRisk by mutableStateOf("50")

    private val lock = Any()
    @Volatile private var lifecycleGeneration = 0L
    private var executor: ScheduledExecutorService? = null

    @Synchronized
    fun start() {
        if (executor != null) return
        val generation = ++lifecycleGeneration
        val ex = Executors.newSingleThreadScheduledExecutor()
        executor = ex
        ex.scheduleWithFixedDelay({ refreshSafely(generation) }, 0L, 10L, TimeUnit.SECONDS)
    }

    /**
     * لا تُترك الصفقات التجريبية مفتوحة بلا مراقبة في الخلفية.
     * عند مغادرة الشاشة يُغلق كل مركز له آخر سعر محفوظ، ويُسجل سبب الإغلاق.
     */
    @Synchronized
    fun stop() {
        // أبطِل أي طلب شبكة قديم قبل الإغلاق؛ لا نسمح لاستجابته المتأخرة بإحياء حالة قديمة.
        lifecycleGeneration++
        val previous = executor
        executor = null
        previous?.shutdownNow()
        closeAtLastPrices(CloseReason.APP_CLOSED)
        futuresPricesUpdatedAtMs = 0L
    }

    fun changeKind(newKind: MarketKind) {
        if (newKind == kind) return
        kind = newKind
        tickers = emptyList()
        refreshNow()
    }

    @Synchronized
    fun refreshNow() {
        val ex = executor ?: return
        val generation = lifecycleGeneration
        try {
            ex.execute { refreshSafely(generation) }
        } catch (_: Exception) {
            // المنفّذ أُوقف أثناء إغلاق الشاشة؛ لا توجد مهمة جديدة لإرسالها.
        }
    }

    private fun isCurrent(generation: Long): Boolean = generation == lifecycleGeneration

    private fun refreshSafely(generation: Long) {
        if (!isCurrent(generation)) return
        try {
            refresh(generation)
        } catch (e: Exception) {
            synchronized(lock) {
                if (!isCurrent(generation)) return
                futuresPricesUpdatedAtMs = 0L
                error = describe(e)
                if (account.positions.isNotEmpty()) closeAtLastPrices(CloseReason.CONNECTION_LOST)
            }
        }
    }

    private fun refresh(generation: Long) {
        val requestedKind = kind
        var marketError: String? = null
        var fetchedTickers: List<Ticker>? = null

        try {
            fetchedTickers = BinanceApi.fetchTickers(requestedKind)
            synchronized(lock) {
                if (!isCurrent(generation)) return
                if (kind == requestedKind) {
                    tickers = fetchedTickers
                    updatedAtMs = System.currentTimeMillis()
                }
            }
        } catch (e: Exception) {
            marketError = describe(e)
        }

        // الأسعار المستخدمة لإدارة الصفقات دائماً من عقود USDT-M، حتى عند تصفح سوق السبوت.
        var livePrices: Map<String, BigDecimal>? =
            if (requestedKind == MarketKind.FUTURES) {
                fetchedTickers?.associate { it.symbol to it.last }?.takeIf { it.isNotEmpty() }
            } else {
                null
            }

        if (livePrices.isNullOrEmpty()) {
            try {
                livePrices = BinanceApi.fetchFuturesPrices()
            } catch (e: Exception) {
                if (marketError == null) marketError = describe(e)
            }
        }

        if (livePrices.isNullOrEmpty()) {
            synchronized(lock) {
                if (!isCurrent(generation)) return
                futuresPricesUpdatedAtMs = 0L
                error = marketError ?: "تعذّر تحديث أسعار العقود الآجلة"
                if (account.positions.isNotEmpty()) closeAtLastPrices(CloseReason.CONNECTION_LOST)
            }
            return
        }

        val freshPrices = livePrices
        synchronized(lock) {
            // تحديث الأسعار والحساب وحفظهما كوحدة واحدة بالنسبة إلى onStop.
            if (!isCurrent(generation)) return
            prices = freshPrices
            futuresPricesUpdatedAtMs = System.currentTimeMillis()
            val openSymbols = account.positions.map { it.symbol }.toSet()
            if (openSymbols.isNotEmpty()) {
                store.saveLastPrices(freshPrices, openSymbols)
                storageWarning = store.warning
                mutateAccount { PaperEngine.applyPrices(it, freshPrices, System.currentTimeMillis()) }
            } else if (store.canWrite) {
                store.saveLastPrices(emptyMap(), emptySet())
                storageWarning = store.warning
            }
            error = marketError
        }
    }

    /** السعر صالح كمدخل تداول فقط إذا وصل تحديث عقود آجل حديث خلال آخر 30 ثانية. */
    fun hasFreshFuturesPrices(): Boolean {
        val age = System.currentTimeMillis() - futuresPricesUpdatedAtMs
        return futuresPricesUpdatedAtMs > 0L && age in 0..MAX_PRICE_AGE_MS
    }

    fun liveFuturesPrice(symbol: String): BigDecimal? =
        if (hasFreshFuturesPrices()) prices[symbol] else null

    private fun describe(e: Exception): String =
        when {
            e is UnknownHostException -> "لا يوجد اتصال بالإنترنت"
            e is BinanceApi.HttpError && (e.code == 451 || e.code == 403) ->
                "بينانس يحجب الاتصال من منطقتك (${e.code})؛ جرّب VPN"
            e is BinanceApi.HttpError -> "خطأ من بينانس (${e.code})"
            else -> "تعذّر الاتصال ببينانس"
        }

    private fun mutateAccount(block: (Account) -> Account): Boolean = synchronized(lock) {
        if (!store.canWrite) {
            storageWarning = store.warning ?: "حفظ الحساب متوقف لحماية البيانات الحالية"
            return@synchronized false
        }
        val before = account
        val after = block(before)
        if (after === before) return@synchronized true
        try {
            store.save(after)
            store.saveLastPrices(prices, after.positions.map { it.symbol }.toSet())
            account = after
            storageWarning = store.warning
            true
        } catch (e: Exception) {
            storageWarning = "تعذّر حفظ التغيير: ${e.message ?: "خطأ تخزين غير معروف"}"
            false
        }
    }

    private fun closeAtLastPrices(reason: CloseReason) = synchronized(lock) {
        if (account.positions.isEmpty()) return@synchronized
        val openSymbols = account.positions.map { it.symbol }.toSet()
        val savedPrices = store.loadLastPrices(openSymbols) + prices.filterKeys { it in openSymbols }
        storageWarning = store.warning
        mutateAccount {
            PaperEngine.closeAllAtPrices(it, savedPrices, reason, System.currentTimeMillis())
        }
        if (account.positions.isNotEmpty()) {
            storageWarning = "بقيت ${account.positions.size} صفقة مفتوحة لعدم توفر آخر سعر محفوظ لها؛ لا يمكن إغلاقها بأمان دون سعر موثوق."
        }
    }

    /** اختيار عملة من السوق: تعبئة الحاسبة بسعرها الحالي والانتقال إليها. */
    fun pickSymbol(t: Ticker) {
        calcSymbol = t.symbol
        calcEntry = (prices[t.symbol] ?: t.last).stripTrailingZeros().toPlainString()
        calcStop = ""
        calcTp = ""
        tab = 1
    }

    /** يعيد رسالة خطأ، أو null عند النجاح (ثم ينتقل لتبويب الصفقات). */
    fun openPaper(input: PositionInput, output: PositionOutput): String? {
        if (!store.canWrite) return storageWarning ?: "حفظ الحساب متوقف لحماية البيانات الحالية"
        val symbol = calcSymbol.trim().uppercase(Locale.US)
        if (symbol.isEmpty()) return "اكتب رمز العملة"
        val market = liveFuturesPrice(symbol)
            ?: return "انتظر تحديث سعر حي من عقود بينانس الآجلة قبل فتح الصفقة"
        val deviation = input.entry.subtract(market).abs().divide(market, 6, RoundingMode.HALF_UP)
        if (deviation > MAX_ENTRY_DEVIATION) {
            return "سعر الدخول بعيد عن السعر الحالي؛ اضغط «السعر الحالي»"
        }
        var failure: String? = null
        var wasOpened = false
        val saved = mutateAccount { acc ->
            when (val result = PaperEngine.open(acc, symbol, input, output, System.currentTimeMillis())) {
                is OpenResult.Opened -> {
                    wasOpened = true
                    result.account
                }
                is OpenResult.Rejected -> {
                    failure = result.reason
                    acc
                }
            }
        }
        if (failure != null) return failure
        if (!saved) return storageWarning ?: "تعذّر حفظ الصفقة التجريبية"
        if (wasOpened) tab = 2
        return null
    }

    fun closePosition(id: Long): String? {
        if (!store.canWrite) return storageWarning ?: "حفظ الحساب متوقف لحماية البيانات الحالية"
        val position = account.positions.firstOrNull { it.id == id } ?: return null
        val price = liveFuturesPrice(position.symbol)
            ?: return "لا يمكن الإغلاق اليدوي بسعر قديم؛ انتظر تحديث سعر العقود الآجلة"
        val saved = mutateAccount {
            PaperEngine.close(it, id, price, CloseReason.MANUAL, System.currentTimeMillis())
        }
        return if (saved) null else storageWarning ?: "تعذّر حفظ إغلاق الصفقة"
    }

    fun resetAccount() {
        val fresh = PaperEngine.newAccount()
        try {
            store.reset(fresh)
            account = fresh
            storageWarning = null
        } catch (e: Exception) {
            storageWarning = "تعذرت إعادة ضبط الحساب: ${e.message ?: "خطأ تخزين غير معروف"}"
        }
    }

    private companion object {
        val MAX_ENTRY_DEVIATION: BigDecimal = BigDecimal("0.01")
        const val MAX_PRICE_AGE_MS = 30_000L
    }
}
