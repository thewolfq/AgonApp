package com.ghaith.trading.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghaith.trading.AppState
import com.ghaith.trading.data.MarketKind
import com.ghaith.trading.data.Ticker
import java.math.BigDecimal
import java.util.Locale

private enum class SortMode { VOLUME, GAINERS, LOSERS }

private val MIN_MOVER_VOLUME = BigDecimal("1000000")

private fun visibleTickers(all: List<Ticker>, query: String, sort: SortMode): List<Ticker> {
    val q = query.trim().uppercase(Locale.US)
    val base = if (q.isEmpty()) all else all.filter { it.symbol.contains(q) }
    val sorted = when (sort) {
        SortMode.VOLUME -> base.sortedByDescending { it.quoteVolume }
        SortMode.GAINERS -> base.filter { q.isNotEmpty() || it.quoteVolume >= MIN_MOVER_VOLUME }
            .sortedByDescending { it.changePct }
        SortMode.LOSERS -> base.filter { q.isNotEmpty() || it.quoteVolume >= MIN_MOVER_VOLUME }
            .sortedBy { it.changePct }
    }
    return sorted.take(if (q.isEmpty()) 100 else 200)
}

@Composable
fun MarketScreen(state: AppState) {
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(SortMode.VOLUME) }
    val rows = remember(state.tickers, query, sort) { visibleTickers(state.tickers, query, sort) }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToggleChip("عقود آجلة", state.kind == MarketKind.FUTURES) { state.changeKind(MarketKind.FUTURES) }
                ToggleChip("سبوت", state.kind == MarketKind.SPOT) { state.changeKind(MarketKind.SPOT) }
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("ابحث عن عملة (مثل BTC)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToggleChip("الأعلى حجماً", sort == SortMode.VOLUME) { sort = SortMode.VOLUME }
                ToggleChip("الرابحون", sort == SortMode.GAINERS) { sort = SortMode.GAINERS }
                ToggleChip("الخاسرون", sort == SortMode.LOSERS) { sort = SortMode.LOSERS }
            }
        }
        if (rows.isEmpty()) {
            Text(
                text = if (state.tickers.isEmpty()) "لا توجد بيانات بعد…" else "لا نتائج مطابقة",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp),
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(12.dp),
            ) {
                items(rows, key = { it.symbol }) { t ->
                    TickerRow(t) { state.pickSymbol(t) }
                }
            }
        }
    }
}

@Composable
private fun TickerRow(t: Ticker, onClick: () -> Unit) {
    SectionCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(text = t.symbol, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    text = "حجم " + ltr(compactVolume(t.quoteVolume)),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = ltr(t.last.plain()), fontWeight = FontWeight.Medium, fontSize = 16.sp)
                Text(
                    text = ltr(t.changePct.signed(2) + "%"),
                    color = pnlColor(t.changePct),
                    fontSize = 13.sp,
                )
            }
        }
    }
}
