package com.ghaith.trading

import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.ghaith.trading.ui.theme.GaithTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Instrumented (M0): تشغيل يدوي عبر workflow_dispatch أو على الجهاز. الحالة NOT_RUN حتى يُرفق ناتج فعلي. */
@RunWith(AndroidJUnit4::class)
class MainActivityInstrumentedTest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    @Test
    fun launchesWithIdentityAndTitle() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.ghaith.trading", context.packageName)
        rule.onNodeWithTag(MainActivity.TAG_APP_TITLE).assertIsDisplayed()
    }
}

@RunWith(AndroidJUnit4::class)
class GaithThemeRtlInstrumentedTest {
    @get:Rule
    val rule = createComposeRule()

    @Test
    fun themeForcesRtl() {
        var direction: LayoutDirection? = null
        rule.setContent {
            GaithTheme { direction = LocalLayoutDirection.current }
        }
        rule.waitForIdle()
        assertEquals(LayoutDirection.Rtl, direction)
    }
}
