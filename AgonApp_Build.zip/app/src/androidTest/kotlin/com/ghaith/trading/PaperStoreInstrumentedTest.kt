package com.ghaith.trading

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.ghaith.trading.data.PaperStore
import com.ghaith.trading.domain.portfolio.CloseReason
import com.ghaith.trading.domain.portfolio.OpenResult
import com.ghaith.trading.domain.portfolio.PaperEngine
import com.ghaith.trading.domain.risk.CalcResult
import com.ghaith.trading.domain.risk.PositionCalculator
import com.ghaith.trading.domain.risk.PositionInput
import com.ghaith.trading.domain.risk.Side
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PaperStoreInstrumentedTest {
    private val context: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun accountAndLastPricesSurviveReload() {
        val prefs = context.getSharedPreferences("paper_account", Context.MODE_PRIVATE)
        try {
            prefs.edit().clear().commit()
            val input = input().copy(feeRate = BigDecimal("0.001"))
            val output = (PositionCalculator.calculate(input) as CalcResult.Ok).value
            val opened = PaperEngine.open(PaperEngine.newAccount(), "BTCUSDT", input, output, 1L)
            assertTrue(opened is OpenResult.Opened)
            val account = (opened as OpenResult.Opened).account

            val store = PaperStore(context)
            store.save(account)
            store.saveLastPrices(mapOf("BTCUSDT" to BigDecimal("105.25")), setOf("BTCUSDT"))

            val reloadedStore = PaperStore(context)
            val reloaded = reloadedStore.load()
            val position = reloaded.positions.single()
            assertEquals(0, BigDecimal("0.001").compareTo(position.feeRate))
            assertEquals(0, BigDecimal("105.25").compareTo(reloadedStore.loadLastPrices(setOf("BTCUSDT")).getValue("BTCUSDT")))
        } finally {
            prefs.edit().clear().commit()
        }
    }

    @Test
    fun partialPriceRefreshDoesNotEraseCachedPriceForOpenPosition() {
        val prefs = context.getSharedPreferences("paper_account", Context.MODE_PRIVATE)
        try {
            prefs.edit().clear().commit()
            val store = PaperStore(context)
            store.saveLastPrices(
                mapOf("BTCUSDT" to BigDecimal("105"), "ETHUSDT" to BigDecimal("50")),
                setOf("BTCUSDT", "ETHUSDT"),
            )
            store.saveLastPrices(
                mapOf("BTCUSDT" to BigDecimal("106")),
                setOf("BTCUSDT", "ETHUSDT"),
            )
            val cached = store.loadLastPrices(setOf("BTCUSDT", "ETHUSDT"))
            assertEquals(0, BigDecimal("106").compareTo(cached.getValue("BTCUSDT")))
            assertEquals(0, BigDecimal("50").compareTo(cached.getValue("ETHUSDT")))
        } finally {
            prefs.edit().clear().commit()
        }
    }

    @Test
    fun corruptPrimaryRecoversPreviousValidAccountBackup() {
        val prefs = context.getSharedPreferences("paper_account", Context.MODE_PRIVATE)
        try {
            prefs.edit().clear().commit()
            val initial = PaperEngine.newAccount()
            val input = input()
            val output = (PositionCalculator.calculate(input) as CalcResult.Ok).value
            val opened = PaperEngine.open(initial, "BTCUSDT", input, output, 1L) as OpenResult.Opened
            val closed = PaperEngine.close(
                opened.account,
                opened.account.positions.single().id,
                BigDecimal("110"),
                CloseReason.MANUAL,
                2L,
            )

            val store = PaperStore(context)
            store.save(initial)
            store.save(opened.account)
            store.save(closed) // تحفظ هذه العملية المركز المفتوح السابق كنسخة احتياطية.
            prefs.edit().putString("account", "{ damaged json ").commit()

            val recoveredStore = PaperStore(context)
            val recovered = recoveredStore.load()
            assertNotNull(recoveredStore.warning)
            assertTrue(recoveredStore.canWrite)
            assertEquals(1, recovered.positions.size)
            assertEquals("BTCUSDT", recovered.positions.single().symbol)
            assertEquals(0, opened.account.balance.compareTo(recovered.balance))
        } finally {
            prefs.edit().clear().commit()
        }
    }

    @Test
    fun corruptPrimaryWithoutBackupBlocksWritesUntilExplicitReset() {
        val prefs = context.getSharedPreferences("paper_account", Context.MODE_PRIVATE)
        try {
            prefs.edit().clear().putString("account", "{ damaged json ").commit()
            val store = PaperStore(context)
            store.load()
            assertTrue(!store.canWrite)
            assertNotNull(store.warning)

            var rejected = false
            try {
                store.save(PaperEngine.newAccount())
            } catch (_: IllegalStateException) {
                rejected = true
            }
            assertTrue(rejected)

            store.reset(PaperEngine.newAccount())
            assertTrue(store.canWrite)
            assertEquals(null, store.warning)
        } finally {
            prefs.edit().clear().commit()
        }
    }

    @Test
    fun missingPrimaryRecoversExistingBackupInsteadOfStartingFresh() {
        val prefs = context.getSharedPreferences("paper_account", Context.MODE_PRIVATE)
        try {
            prefs.edit().clear().commit()
            val initial = PaperEngine.newAccount()
            val store = PaperStore(context)
            store.save(initial)
            val input = input()
            val output = (PositionCalculator.calculate(input) as CalcResult.Ok).value
            val opened = PaperEngine.open(initial, "BTCUSDT", input, output, 1L) as OpenResult.Opened
            store.save(opened.account) // يحتفظ بالرصيد الابتدائي كنسخة سابقة.
            store.save(opened.account) // يدوّر الحفظ المفتوح إلى النسخة الاحتياطية.
            prefs.edit().remove("account").commit()

            val recoveredStore = PaperStore(context)
            val recovered = recoveredStore.load()
            assertTrue(recoveredStore.canWrite)
            assertNotNull(recoveredStore.warning)
            assertEquals(1, recovered.positions.size)
            assertEquals(0, opened.account.balance.compareTo(recovered.balance))

            recoveredStore.save(recovered)
            assertEquals(null, recoveredStore.warning)
        } finally {
            prefs.edit().clear().commit()
        }
    }

    private fun input() = PositionInput(
        side = Side.LONG,
        entry = BigDecimal("100"),
        stop = BigDecimal("90"),
        takeProfit = BigDecimal("120"),
        leverage = 5,
        riskAmount = BigDecimal("100"),
    )
}
