# AgonApp ProGuard Rules

# Keep data models (used by kotlinx.serialization)
-keep class com.agon.app.models.** { *; }
-keepclassmembers class com.agon.app.models.** { *; }

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.agon.app.**$$serializer { *; }
-keepclassmembers class com.agon.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.agon.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**

# Coroutines
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# Compose
-keep class androidx.compose.** { *; }
