# بيان البناء — BUILD_MANIFEST

> هذا هو «بيان البناء» المذكور في ملحق 03_implementation. يسجّل: مراجعة التوافق، خريطة الملفات،
> حالة كل بوابة، وكل بند `NOT_RUN` مع سببه. لا يُوضع ✅ على أي بند لم يُشغَّل فعلياً.

## 1. مراجعة التوافق (M0) — §12 من 03_implementation

| الأداة | الإصدار المثبّت | المبرر |
|---|---|---|
| Gradle | 8.14.3 (`distributionSha256Sum=bd71102213493060956ec229d946beee57158dbd89d0e62b91bca0fa2c5f3531`) | الحد الأدنى لـ AGP 8.13 هو Gradle 8.13. تحققتُ من SHA-256 الرسمي قبل التنزيل. |
| AGP | 8.13.2 | ملاحظات الإصدار الرسمية: «أقصى API تدعمه AGP 8.13 هو 36.1»، JDK 17، Build Tools 35.0.0 ⇒ يدعم `compileSdk 36`. |
| Kotlin | 2.2.21 (+ إضافة Compose compiler بالإصدار نفسه) | متوافق مع AGP 8.13.x. |
| JDK | 17 (Temurin) | الحد الأدنى لـ AGP 8.13. |
| Compose BOM | 2025.10.01 | يتوافق مع `compileSdk 36` (الإصدارات الأحدث قد تتطلب SDK أعلى). |
| core-ktx 1.17.0، activity-compose 1.11.0، lifecycle 2.9.4 | — | تتطلب `compileSdk 36` ويتحقق ذلك. |
| ArchUnit 1.4.1، JUnit 4.13.2 | — | اختبارات JVM. |

**قرار يحتاج تأكيدك:** تتوفر حالياً (نوفمبر 2026) إصدارات أحدث (AGP 9.5.x وGradle 9.x وKotlin 2.4.x).
اخترت سلسلة 8.13 المستقرة لأنها تكفي لـ `compileSdk 36` وتتطلب تغييرات أقل في DSL. لم أختبر AGP 9.x.

التحقق من التبعيات: `gradle/verification-metadata.xml` يحوي 516 مكوّناً بـ SHA-256، وقد وُلّد بتشغيل
`test lintDebug assembleDebug assembleDebugAndroidTest assembleRelease` على Linux x86_64.

## 2. خريطة ملفات النواة (§0 و§6) إلى المسارات الفعلية

الأسماء حرفية كما في §0. أضفت فقط تخطيط Gradle القياسي (`src/main/kotlin`) وحزمة الجذر `com.ghaith.trading`:

| الاسم في المواصفة | المسار الفعلي | الحالة |
|---|---|---|
| `build-logic/ConventionPlugins.kt` | `build-logic/src/main/kotlin/ConventionPlugins.kt` | M0 ✔ مبني |
| `core-domain/finance/Money.kt` | `core-domain/src/main/kotlin/com/ghaith/trading/domain/finance/Money.kt` | M0 ✔ مبني |
| `core-domain/evaluation/TradeEvaluation.kt` | `core-domain/src/main/kotlin/com/ghaith/trading/domain/evaluation/TradeEvaluation.kt` | M0 جزئي: `DataState`، `NetError`، `Observed` فقط. النتيجة والـFacade في M2 |
| `core-domain/test/ArchitectureRulesTest.kt` | `core-domain/src/test/kotlin/com/ghaith/trading/domain/arch/ArchitectureRulesTest.kt` | M0 ✔ |
| `app/MainActivity.kt` | `app/src/main/kotlin/com/ghaith/trading/MainActivity.kt` | M0 ✔ |
| `app/ui/theme/GaithTheme.kt` | `app/src/main/kotlin/com/ghaith/trading/ui/theme/GaithTheme.kt` | M0 ✔ |
| `Fees/Slippage/Liquidation/Solver/Risk.kt`، `Portfolio.kt` | — | M2 |
| `BinanceData.kt`، `EventStore.kt` | — | M1 |
| `Strategy.kt`، `Backtest.kt` | — | M4 |
| `GaithApplication.kt`، `AppNavigation.kt`، `AppViewModel.kt`، `DataStateBadge.kt`، الشاشات | — | M3/M5 |
| `KeystoreSecurity.kt` | — | M5 |
| `app/platform/*` (ملحق 03) | — | M5 |

**ملفات إضافية مع مبررها (§6: «لا ملف خارج القائمة دون مسوغ»):**

| الملف | المسوغ |
|---|---|
| `core-domain/src/test/.../finance/MoneyTest.kt` | اختبارات وحدة Money (بوابة M0 بند 3). |
| `core-domain/src/test/kotlin/android/archprobe/AndroidApiProbe.kt` | مجسّ اختبار يثبت أن R1 تلتقط `android.*` (Kotlin يفرض حزمة واحدة لكل ملف). |
| `core-domain/src/test/.../archprobe/ArchProbes.kt` | مجسّات مخالفة متعمدة لـ R1/R3/R4. |
| `core-domain/src/test/.../archprobe/finance/FloatingPointProbes.kt` | مجسّات مخالفة لـ R2 داخل حزمة `finance`. |
| `app/src/androidTest/.../MainActivityInstrumentedTest.kt` | اختبار أجهزة (§5.2، §11): الإقلاع والهوية وفرض RTL. |
| `app/src/main/res/xml/data_extraction_rules.xml` | يفرض `allowBackup=false` (§10) على Android 12+ لنقل جهاز-إلى-جهاز أيضاً. |
| `tools/env.sh` | متغيرات بيئة صندوق التطوير فقط؛ لا يستعمله CI. |
| `tools/check_16kb.py` | فحص §9.5 لمحاذاة مقاطع LOAD في كل `.so` (يستعمله CI). |
| `logs/M0/*.txt` | مخرجات الأوامر الخام لمرحلة M0. |

## 3. تعارضات المصادر وكيف حُلّت

| # | التعارض | القرار |
|---|---|---|
| 1 | 01 §2.1 تذكر Room، و03 §7.1 تنص: «SQLite الإطاري فقط… هذا القسم يحل محل الإشارة إلى Room» | اتبعت 03 (نص صريح بالاستبدال). |
| 2 | 01 §6: «لا ملف خارج القائمة»، وملحق 03 يضيف `app/platform/{MonitoringService,ReconcileScheduler,DiagnosticsCollector}.kt` | الملحق يجيزها صراحة، فستُعتمد في M5. |
| 3 | 01 §6.1 يضع `DataState/NetError` داخل `TradeEvaluation.kt`، و`PriceTriple` في `Money.kt` يحتاج `DataState` لكل سعر | `Money.kt` يستورد `DataState/Observed` من `evaluation`، داخل الوحدة نفسها. |

## 4. بوابة M0 — الحالة الفعلية

| البند | الحالة | الدليل / السبب |
|---|---|---|
| 1أ. نجاح `assembleDebug` | PASS (محلياً) | `logs/M0/final.txt` (بلا build cache، بعد `clean`) |
| 1ب. تثبيت الـAPK فعلياً على الجهاز | **NOT_RUN** | لا يوجد جهاز ولا محاكٍ في صندوق البناء (ذاكرة 2GB، بلا KVM). يلزم تشغيلك: `adb install -r app-debug.apk` |
| 2. اختبارات ArchUnit الأربعة 100% | PASS (محلياً) | 9 اختبارات: 4 قواعد + 4 اختبارات ذاتية + اختبار عدم الفراغ. مع اختبار طفرة سلبي في `logs/M0/mutation.txt` |
| 3. اختبارات Money.kt | PASS (محلياً) | 22 اختباراً |
| 4. CI أخضر في GitHub Actions | **NOT_RUN** | لا وصول لمستودعك الخاص من هنا. ملفات الـworkflow جاهزة وتحتاج push |
| (إضافي) `lintDebug` | PASS: 0 أخطاء، 2 تحذيران | `UnusedAttribute` (`enableOnBackInvokedCallback` يعمل من API 33)، و`DataExtractionRules` (`fullBackupContent` غير لازم لأن `allowBackup=false`) |
| (إضافي) `assembleDebugAndroidTest` | PASS (تجميع فقط) | الاختبارات نفسها لم تُشغَّل: **NOT_RUN** |
| (إضافي) `assembleRelease` مع R8 | PASS (تجميع فقط) | لم يُثبَّت ولم يُشغَّل: بوابة M6 |
| (إضافي) `zipalign -c -P 16` + فحص `.so` | PASS | `logs/M0/apk-checks.txt`. الـAPK يحوي مكتبة أصلية واحدة جلبها Compose: `libandroidx.graphics.path.so` (4 معماريات)، وكل مقاطع LOAD فيها `p_align=0x4000`. الفحص في `tools/check_16kb.py` واختُبر سلبياً بنسخة معدّلة إلى 4KB ففشل كما يجب |

**النتيجة: بوابة M0 غير مكتملة.** بقي البندان 1ب و4، وكلاهما يحتاج تنفيذاً من جهتك.
لن أنتقل إلى M1 قبل إرفاق ناتجيهما.

## 5. تصحيح M0.1 (توافق الرفع والبناء على GitHub)

لم يُعدَّل أي كود تطبيق ولا إصدار أداة. التعديلات على التغليف وبيئة CI فقط، ولم تُجرَّب في GitHub من صندوق التطوير (**NOT_RUN**):

| التعديل | السبب |
|---|---|
| الملفات في جذر الأرشيف دون مجلد غلاف | وجود `.github/` داخل مجلد فرعي يجعل GitHub لا يرى الـworkflows |
| خطوة `chmod +x gradlew` وإزالة CRLF في الـworkflows الثلاثة | الرفع عبر المتصفح/ضغط الهاتف يُسقط صلاحية التنفيذ فيفشل `./gradlew` بـ Permission denied |
| ci.yml: يعمل على أي فرع + `workflow_dispatch` | كان محصوراً بفرع `main` فلا يبدأ في مستودع فرعه الافتراضي `master` |
| `.gitattributes` | يثبّت LF لـ`gradlew` ويمنع تلف `gradle-wrapper.jar` |
| `org.gradle.jvmargs`: الذاكرة من 1536m إلى 3g | هوامش أوسع لـR8/Kotlin على مشغّل CI |

### M0.2 — فشل التحقق من التبعيات في CI (من reports.zip)

فشل `configuration 'classpath'` بثلاثة بنود «Checksums are missing»: `guava-parent-33.3.1-jre.pom` و`junit-bom-5.10.2.module` و`kotlinx-coroutines-bom-1.8.0.pom`.
الإصدارات تختلف عمّا في البيان المولَّد محلياً، فهي تأتي على الأرجح من إضافة `gradle/actions/setup-gradle` نفسها وليس من التطبيق.
المعالجة: إضافتها في `<trusted-artifacts>` بدل بصمات SHA-256 (لم أستطع جلب البصمات الرسمية بلا إنترنت). **NOT_RUN في CI.**
الأنسب لاحقاً: تثبيت البصمات الفعلية بتشغيل `./gradlew --write-verification-metadata sha256 help` على جهاز متصل ومراجعة الفرق.

## 6. الإصدار 0.2.0 (تطبيق وظيفي)

شاشات: السوق/الحاسبة/صفقاتي. حسابات جديدة في `core-domain` (`risk/PositionCalculator`، `portfolio/PaperEngine`) بـ BigDecimal فقط مع اختبارات وحدة.
بلا تبعيات جديدة (لا تغيير على verification-metadata): الشبكة عبر HttpURLConnection وorg.json المدمج.
تغيير بناء: `allWarningsAsErrors=false` لوحدات Android فقط (النواة JVM باقية صارمة). **NOT_RUN: لم يُبنَ هنا؛ التحقق عبر GitHub Actions.**

## 7. مراجعة ملفّي `AgonApp_Build.zip` و`reports (2).zip` — 27 نوفمبر 2026

### 7.1 نتيجة التقرير قبل الإصلاح

- تقرير اختبارات `core-domain`: **47 اختبارًا، اختبار فاشل واحد** (`PaperEngineTest.unrealizedPnlMatchesDirection` عند السطر 38، `expected 0 but was 1`).
- سبب الفشل: الاختبار افترض ربحًا إجماليًا ثابتًا قدره 50 USDT لكمية 10، لكن `PositionCalculator` يحسب الكمية بعد إدخال عمولتي الدخول والخروج في مخاطرة المركز؛ لذلك الكمية أقل من 10 والربح الإجمالي أقل من 50. كان التوقع في الاختبار غير متوافق مع مدخلاته، وليس خللًا في اتجاه معادلة الربح.
- ملف Lint الموجود في الأرشيف يخص `core-store` فقط ويذكر عدم وجود مشكلات. لم يتضمن الأرشيف تقرير Lint لتطبيق `app`، لذلك لا يُستنتج منه أن فحص جميع الوحدات أخضر.

### 7.2 الإصلاحات في نسخة المصدر الحالية

- تحديث اختبار الربح غير المحقق ليتحقق من الكمية الفعلية الناتجة عن الحاسبة بدل افتراض كمية ثابتة.
- حفظ معدل العمولة مع كل مركز واستخدامه عند الإغلاق، مع دعم بيانات الحساب القديمة التي لا تحتوي على الحقل.
- إضافة صافي الربح غير المحقق بعد عمولتي الدخول والخروج المقدّرة، وفصل مساهمة المركز في قيمة الحساب لمنع خصم عمولة الدخول مرتين.
- التحقق من أن نسب العمولة وهامش الصيانة غير سالبة وأقل من 100%.
- إضافة أسباب إغلاق واضحة عند مغادرة التطبيق وفقد تغذية الأسعار. تُحفظ آخر أسعار رموز المراكز، ولا يمحو رد السوق الجزئي سعر مركز مفتوح لم يتضمنه الرد. عند الإغلاق تُسترجع الأسعار المحفوظة، مع إعطاء أولوية لوقف الخسارة/الهدف/التصفية إذا كان السعر المحفوظ قد تجاوز أحدها. لا يُغلق مركز لا يتوفر له سعر موثوق، ويظهر تحذير.
- إضافة نسخة احتياطية متدرجة للحساب. عند فساد الحفظ الأساسي أو غيابه يجري استرداد النسخة الاحتياطية إن كانت سليمة؛ وعند فساد النسختين يُمنع الحفظ فوق البيانات ولا يُسمح بالبدء من الصفر إلا عبر إعادة ضبط يدوية صريحة.
- حماية تحديث الأسعار والحساب برقم دورة حياة وقفل متزامن، لمنع استجابة شبكة متأخرة من تعديل المراكز بعد إغلاق التطبيق.
- تصحيح نسبة العائد/المخاطرة لتستخدم صافي ربح الهدف ÷ صافي خسارة الوقف بعد الرسوم، ورفض هدف لا يغطي عمولتي الدخول والخروج.
- إضافة شاشة «حول التطبيق»: المطوّر عبد الوارث الذيب وحقوق © 2026.
- تصحيح تعليمات README: إزالة الإشارة إلى `build-apk.yml` غير الموجود، وتوضيح أن `core-data` و`core-store` هياكل تمهيدية وأن الحفظ الحالي SharedPreferences وليس SQLite.
- توضيح متطلبات التوقيع كي لا يُفهم أن APK غير موقّع أو APK debug من مشغّل GitHub يصلح تلقائيًا كتحديث لنسخة موجودة.

### 7.3 التحقق بعد التعديل

- **PASS (تحقق مستقل محدود):** ترجمة ملفات `core-domain` المصدرية باستخدام `kotlinc`.
- **PASS (تحقق مستقل محدود):** تشغيل 47 اختبارًا مركزًا في `MoneyTest` و`PositionCalculatorTest` و`PaperEngineTest` عبر مشغّل اختبار محلي خفيف؛ جميعها نجحت. هذا ليس تشغيل Gradle/JUnit الرسمي ولا يشمل اختبارات ArchUnit التسعة.
- **PASS (فحص صياغة محدود):** ترجمة `AppState.kt` و`PaperStore.kt` في بيئة Kotlin باستخدام واجهات بديلة (stubs) للتبعيات Android/Compose. لا يثبت ذلك نجاح Android Gradle Plugin أو Compose runtime.
- **NOT_RUN:** `./gradlew testDebugUnitTest :core-domain:test :core-data:test` بعد الإصلاح. تعذر تنزيل Gradle 8.14.3 لأن البيئة لا تصل إلى `services.gradle.org`.
- **NOT_RUN:** `lintDebug` و`assembleDebug` و`assembleRelease` بعد الإصلاح؛ لا يوجد Android SDK مثبت في بيئة الفحص الحالية.
- **NOT_RUN:** اختبار التثبيت الفعلي ومحاكي API 36 وGitHub Actions. لم يُنتج APK جديد من هذه المراجعة.
- رقم مصدر الإصدار بعد الإصلاح: `versionName 0.3.0` و`versionCode 3` مع بقاء `applicationId`=`com.ghaith.trading`.

**لا تُعد هذه المراجعة شهادة بناء نهائية.** يجب أن ينجح CI بعد رفع المصدر إلى GitHub، ثم يجب تنفيذ اختبار الأجهزة على Android. لا يمكن ضمان تحديث تثبيت سابق ما لم تتوفر keystore الأصلية نفسها؛ ملف المفتاح غير موجود في الأرشيف المرفق.
