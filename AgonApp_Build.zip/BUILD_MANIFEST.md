# بيان البناء — BUILD_MANIFEST

> هذا هو «بيان البناء» المذكور في ملحق 03_implementation. يسجّل: مراجعة التوافق، خريطة الملفات،
> حالة كل بوابة، وكل بند `NOT_RUN` مع سببه. لا يُوضع ✅ على أي بند لم يُشغَّل فعلياً.

## 1. مراجعة التوافق (M0) — §12 من 03_implementation

| الأداة | الإصدار المثبّت | المبرر |
|---|---|---|
| Gradle | 8.14.3 (`distributionSha256Sum=bd71102213493060956ec229d946beee57158dbd89d0e62b91bca0fa2c5f3531`) | الحد الأدنى لـ AGP 8.13 هو Gradle 8.13. تحققتُ من SHA-256 الرسمي قبل التنزيل. |
| AGP | 8.13.2 | ملاحظات الإصدار الرسمية: «أقصى API تدعمه AGP 8.13 هو 36.1»، JDK 17، Build Tools 35.0.0 ⇒ يدعم `compileSdk 36`. |
| Kotlin | 2.2.21 (+ إضافة Compose compiler بالإصدار نفسه) | متوافق مع AGP 8.13.x. |
| JDK | 17 (Temurin) | الحد الأدنى لـ AGP 8.13. |
| Compose BOM | 2025.10.01 | يتوافق مع `compileSdk 36` (الإصدارات الأحدث قد تتطلب SDK أعلى). |
| core-ktx 1.17.0، activity-compose 1.11.0، lifecycle 2.9.4 | — | تتطلب `compileSdk 36` ويتحقق ذلك. |
| ArchUnit 1.4.1، JUnit 4.13.2 | — | اختبارات JVM. |

**قرار يحتاج تأكيدك:** تتوفر حالياً (نوفمبر 2026) إصدارات أحدث (AGP 9.5.x وGradle 9.x وKotlin 2.4.x).
اخترت سلسلة 8.13 المستقرة لأنها تكفي لـ `compileSdk 36` وتتطلب تغييرات أقل في DSL. لم أختبر AGP 9.x.

التحقق من التبعيات: `gradle/verification-metadata.xml` يحوي 516 مكوّناً بـ SHA-256، وقد وُلّد بتشغيل
`test lintDebug assembleDebug assembleDebugAndroidTest assembleRelease` على Linux x86_64.

## 2. خريطة ملفات النواة (§0 و§6) إلى المسارات الفعلية

الأسماء حرفية كما في §0. أضفت فقط تخطيط Gradle القياسي (`src/main/kotlin`) وحزمة الجذر `com.ghaith.trading`:

| الاسم في المواصفة | المسار الفعلي | الحالة |
|---|---|---|
| `build-logic/ConventionPlugins.kt` | `build-logic/src/main/kotlin/ConventionPlugins.kt` | M0 ✔ مبني |
| `core-domain/finance/Money.kt` | `core-domain/src/main/kotlin/com/ghaith/trading/domain/finance/Money.kt` | M0 ✔ مبني |
| `core-domain/evaluation/TradeEvaluation.kt` | `core-domain/src/main/kotlin/com/ghaith/trading/domain/evaluation/TradeEvaluation.kt` | M0 جزئي: `DataState`، `NetError`، `Observed` فقط. النتيجة والـFacade في M2 |
| `core-domain/test/ArchitectureRulesTest.kt` | `core-domain/src/test/kotlin/com/ghaith/trading/domain/arch/ArchitectureRulesTest.kt` | M0 ✔ |
| `app/MainActivity.kt` | `app/src/main/kotlin/com/ghaith/trading/MainActivity.kt` | M0 ✔ |
| `app/ui/theme/GaithTheme.kt` | `app/src/main/kotlin/com/ghaith/trading/ui/theme/GaithTheme.kt` | M0 ✔ |
| `Fees/Slippage/Liquidation/Solver/Risk.kt`، `Portfolio.kt` | — | M2 |
| `BinanceData.kt`، `EventStore.kt` | — | M1 |
| `Strategy.kt`، `Backtest.kt` | — | M4 |
| `GaithApplication.kt`، `AppNavigation.kt`، `AppViewModel.kt`، `DataStateBadge.kt`، الشاشات | — | M3/M5 |
| `KeystoreSecurity.kt` | — | M5 |
| `app/platform/*` (ملحق 03) | — | M5 |

**ملفات إضافية مع مبررها (§6: «لا ملف خارج القائمة دون مسوغ»):**

| الملف | المسوغ |
|---|---|
| `core-domain/src/test/.../finance/MoneyTest.kt` | اختبارات وحدة Money (بوابة M0 بند 3). |
| `core-domain/src/test/kotlin/android/archprobe/AndroidApiProbe.kt` | مجسّ اختبار يثبت أن R1 تلتقط `android.*` (Kotlin يفرض حزمة واحدة لكل ملف). |
| `core-domain/src/test/.../archprobe/ArchProbes.kt` | مجسّات مخالفة متعمدة لـ R1/R3/R4. |
| `core-domain/src/test/.../archprobe/finance/FloatingPointProbes.kt` | مجسّات مخالفة لـ R2 داخل حزمة `finance`. |
| `app/src/androidTest/.../MainActivityInstrumentedTest.kt` | اختبار أجهزة (§5.2، §11): الإقلاع والهوية وفرض RTL. |
| `app/src/main/res/xml/data_extraction_rules.xml` | يفرض `allowBackup=false` (§10) على Android 12+ لنقل جهاز-إلى-جهاز أيضاً. |
| `tools/env.sh` | متغيرات بيئة صندوق التطوير فقط؛ لا يستعمله CI. |
| `tools/check_16kb.py` | فحص §9.5 لمحاذاة مقاطع LOAD في كل `.so` (يستعمله CI). |
| `logs/M0/*.txt` | مخرجات الأوامر الخام لمرحلة M0. |

## 3. تعارضات المصادر وكيف حُلّت

| # | التعارض | القرار |
|---|---|---|
| 1 | 01 §2.1 تذكر Room، و03 §7.1 تنص: «SQLite الإطاري فقط… هذا القسم يحل محل الإشارة إلى Room» | اتبعت 03 (نص صريح بالاستبدال). |
| 2 | 01 §6: «لا ملف خارج القائمة»، وملحق 03 يضيف `app/platform/{MonitoringService,ReconcileScheduler,DiagnosticsCollector}.kt` | الملحق يجيزها صراحة، فستُعتمد في M5. |
| 3 | 01 §6.1 يضع `DataState/NetError` داخل `TradeEvaluation.kt`، و`PriceTriple` في `Money.kt` يحتاج `DataState` لكل سعر | `Money.kt` يستورد `DataState/Observed` من `evaluation`، داخل الوحدة نفسها. |

## 4. بوابة M0 — الحالة الفعلية

| البند | الحالة | الدليل / السبب |
|---|---|---|
| 1أ. نجاح `assembleDebug` | PASS (محلياً) | `logs/M0/final.txt` (بلا build cache، بعد `clean`) |
| 1ب. تثبيت الـAPK فعلياً على الجهاز | **NOT_RUN** | لا يوجد جهاز ولا محاكٍ في صندوق البناء (ذاكرة 2GB، بلا KVM). يلزم تشغيلك: `adb install -r app-debug.apk` |
| 2. اختبارات ArchUnit الأربعة 100% | PASS (محلياً) | 9 اختبارات: 4 قواعد + 4 اختبارات ذاتية + اختبار عدم الفراغ. مع اختبار طفرة سلبي في `logs/M0/mutation.txt` |
| 3. اختبارات Money.kt | PASS (محلياً) | 22 اختباراً |
| 4. CI أخضر في GitHub Actions | **NOT_RUN** | لا وصول لمستودعك الخاص من هنا. ملفات الـworkflow جاهزة وتحتاج push |
| (إضافي) `lintDebug` | PASS: 0 أخطاء، 2 تحذيران | `UnusedAttribute` (`enableOnBackInvokedCallback` يعمل من API 33)، و`DataExtractionRules` (`fullBackupContent` غير لازم لأن `allowBackup=false`) |
| (إضافي) `assembleDebugAndroidTest` | PASS (تجميع فقط) | الاختبارات نفسها لم تُشغَّل: **NOT_RUN** |
| (إضافي) `assembleRelease` مع R8 | PASS (تجميع فقط) | لم يُثبَّت ولم يُشغَّل: بوابة M6 |
| (إضافي) `zipalign -c -P 16` + فحص `.so` | PASS | `logs/M0/apk-checks.txt`. الـAPK يحوي مكتبة أصلية واحدة جلبها Compose: `libandroidx.graphics.path.so` (4 معماريات)، وكل مقاطع LOAD فيها `p_align=0x4000`. الفحص في `tools/check_16kb.py` واختُبر سلبياً بنسخة معدّلة إلى 4KB ففشل كما يجب |

**النتيجة: بوابة M0 غير مكتملة.** بقي البندان 1ب و4، وكلاهما يحتاج تنفيذاً من جهتك.
لن أنتقل إلى M1 قبل إرفاق ناتجيهما.

## 5. تصحيح M0.1 (توافق الرفع والبناء على GitHub)

لم يُعدَّل أي كود تطبيق ولا إصدار أداة. التعديلات على التغليف وبيئة CI فقط، ولم تُجرَّب في GitHub من صندوق التطوير (**NOT_RUN**):

| التعديل | السبب |
|---|---|
| الملفات في جذر الأرشيف دون مجلد غلاف | وجود `.github/` داخل مجلد فرعي يجعل GitHub لا يرى الـworkflows |
| خطوة `chmod +x gradlew` وإزالة CRLF في الـworkflows الثلاثة | الرفع عبر المتصفح/ضغط الهاتف يُسقط صلاحية التنفيذ فيفشل `./gradlew` بـ Permission denied |
| ci.yml: يعمل على أي فرع + `workflow_dispatch` | كان محصوراً بفرع `main` فلا يبدأ في مستودع فرعه الافتراضي `master` |
| `.gitattributes` | يثبّت LF لـ`gradlew` ويمنع تلف `gradle-wrapper.jar` |
| `org.gradle.jvmargs`: الذاكرة من 1536m إلى 3g | هوامش أوسع لـR8/Kotlin على مشغّل CI |

### M0.2 — فشل التحقق من التبعيات في CI (من reports.zip)

فشل `configuration 'classpath'` بثلاثة بنود «Checksums are missing»: `guava-parent-33.3.1-jre.pom` و`junit-bom-5.10.2.module` و`kotlinx-coroutines-bom-1.8.0.pom`.
الإصدارات تختلف عمّا في البيان المولَّد محلياً، فهي تأتي على الأرجح من إضافة `gradle/actions/setup-gradle` نفسها وليس من التطبيق.
المعالجة: إضافتها في `<trusted-artifacts>` بدل بصمات SHA-256 (لم أستطع جلب البصمات الرسمية بلا إنترنت). **NOT_RUN في CI.**
الأنسب لاحقاً: تثبيت البصمات الفعلية بتشغيل `./gradlew --write-verification-metadata sha256 help` على جهاز متصل ومراجعة الفرق.
