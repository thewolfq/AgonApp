plugins {
    id("gaith.android.library")
}

// M0: هيكل الوحدة فقط. EventStore.kt (SQLite الإطاري) يُبنى في M1.
android {
    namespace = "com.ghaith.trading.store"
}

dependencies {
    implementation(project(":core-domain"))
    testImplementation(libs.junit)
}
