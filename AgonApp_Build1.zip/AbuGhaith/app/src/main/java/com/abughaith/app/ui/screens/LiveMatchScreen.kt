package com.abughaith.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.abughaith.app.AbuGhaithApp
import com.abughaith.app.models.CoachAction
import com.abughaith.app.models.Direction
import com.abughaith.app.models.OpenTrade
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.TradeCard
import com.abughaith.app.ui.components.HealthBar
import com.abughaith.app.ui.components.InfoRow
import com.abughaith.app.ui.components.Pill
import com.abughaith.app.ui.components.StatusStrip
import com.abughaith.app.ui.theme.CardBackground
import com.abughaith.app.ui.theme.CoralRed
import com.abughaith.app.ui.theme.DarkNavy
import com.abughaith.app.ui.theme.EmeraldGreen
import com.abughaith.app.ui.theme.TextSecondary
import com.abughaith.app.ui.theme.WarningOrange
import com.abughaith.app.util.Fmt
import kotlinx.coroutines.launch

/** تبويب المباراة الحية: الصفقات المفتوحة، مؤشر الصحة، توصيات المدرب، ودكة البدلاء. */
@Composable
fun LiveMatchScreen(app: AbuGhaithApp) {
    val trades by app.prefs.openTradesFlow.collectAsState(initial = emptyList())
    val hubState by app.hub.state.collectAsState()
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf<OpenTrade?>(null) }
    var exitText by remember { mutableStateOf("") }

    val openSymbols = trades.map { it.symbol }.toSet()
    val bench = app.coach.watchlist(hubState.signals, openSymbols)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("المباراة الحية", style = MaterialTheme.typography.headlineMedium, color = EmeraldGreen)
        }
        if (trades.isEmpty()) {
            item {
                Text(
                    "لا توجد صفقات مفتوحة. عند فتح صفقة من تبويب الإشارات (زر «فتحت الصفقة») سيتابعها المدرب هنا.",
                    color = TextSecondary
                )
            }
        }
        items(trades, key = { it.id }) { t ->
            OpenTradeCard(
                t = t,
                onBreakeven = {
                    scope.launch {
                        app.prefs.updateOpenTrades { list ->
                            list.map { if (it.id == t.id) it.copy(stopLoss = it.entryPrice) else it }
                        }
                    }
                },
                onClose = {
                    exitText = Fmt.price(t.currentPrice)
                    closing = t
                }
            )
        }
        item {
            Text("دكة البدلاء (أفضل 5)", style = MaterialTheme.typography.titleMedium, color = EmeraldGreen)
        }
        if (bench.isEmpty()) {
            item { Text("لا توجد بدائل جاهزة حالياً.", color = TextSecondary) }
        }
        items(bench, key = { it.id }) { c -> BenchRow(c) }
    }

    val ct = closing
    if (ct != null) {
        AlertDialog(
            onDismissRequest = { closing = null },
            title = { Text("إغلاق " + ct.symbol) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("أدخل سعر الخروج الفعلي الذي نُفّذت عنده الصفقة:")
                    OutlinedTextField(
                        value = exitText,
                        onValueChange = { exitText = it },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = exitText.trim().toDoubleOrNull()
                    if (p != null && p > 0.0) {
                        scope.launch {
                            val h = app.prefs.closeTrade(ct.id, p)
                            if (h != null) app.risk.recordTradeResult(h.pnlUsdt)
                        }
                        closing = null
                    }
                }) { Text("تأكيد الإغلاق") }
            },
            dismissButton = {
                TextButton(onClick = { closing = null }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun OpenTradeCard(t: OpenTrade, onBreakeven: () -> Unit, onClose: () -> Unit) {
    val long = t.direction == Direction.LONG
    val s = if (long) 1.0 else -1.0
    val pnl = (t.currentPrice - t.entryPrice) * t.quantity * s
    val base = if (t.marginUsdt > 0.0) t.marginUsdt else t.quantity * t.entryPrice
    val pnlPct = if (base > 0.0) pnl / base * 100.0 else 0.0
    val pnlColor = if (pnl >= 0.0) EmeraldGreen else CoralRed
    val atBreakeven = Math.abs(t.stopLoss - t.entryPrice) <= t.entryPrice * 0.001

    val coachColor = when (t.lastCoachAction) {
        CoachAction.STOP_HIT, CoachAction.EXIT_EARLY -> CoralRed
        CoachAction.HOLD -> TextSecondary
        else -> EmeraldGreen
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(t.symbol, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Pill(if (long) "شراء ▲" else "بيع ▼", if (long) EmeraldGreen else CoralRed)
                Pill(t.leverage.toString() + "x", WarningOrange)
            }
            InfoRow("سعر الدخول", Fmt.price(t.entryPrice))
            InfoRow("السعر الحالي", Fmt.price(t.currentPrice))
            InfoRow(
                "الربح/الخسارة (تقديري)",
                Fmt.num(pnl, 2) + "\$  (" + Fmt.pct(pnlPct, signed = true) + ")",
                pnlColor
            )
            InfoRow("وقف الخسارة", Fmt.price(t.stopLoss) + if (atBreakeven) "  (عند الدخول)" else "", CoralRed)
            t.takeProfits.forEach { tp ->
                val hit = if (long) t.currentPrice >= tp.price else t.currentPrice <= tp.price
                InfoRow(
                    "الهدف " + tp.level,
                    Fmt.price(tp.price) + if (hit) "  ✓" else "",
                    if (hit) EmeraldGreen else TextSecondary
                )
            }
            HealthBar(t.healthIndex)
            if (t.lastCoachMessage.isNotEmpty()) {
                StatusStrip("🧠 " + t.lastCoachMessage, coachColor)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!atBreakeven) {
                    OutlinedButton(onClick = onBreakeven) { Text("نقل الوقف للدخول") }
                }
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = CoralRed, contentColor = DarkNavy)
                ) { Text("إغلاق الصفقة") }
            }
        }
    }
}

@Composable
private fun BenchRow(c: TradeCard) {
    val long = c.direction == Direction.LONG
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBackground, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(c.symbol, fontWeight = FontWeight.Bold)
            Pill(if (long) "شراء" else "بيع", if (long) EmeraldGreen else CoralRed)
            Pill(
                if (c.status == SignalStatus.READY) "مفعّلة" else "انتظار",
                if (c.status == SignalStatus.READY) EmeraldGreen else WarningOrange
            )
            Text(
                c.signalScore.toString() + "/100",
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.End,
                color = TextSecondary
            )
        }
    }
}
