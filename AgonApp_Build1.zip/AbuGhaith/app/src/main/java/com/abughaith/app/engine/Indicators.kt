package com.abughaith.app.engine

import com.abughaith.app.models.Candle
import kotlin.math.abs
import kotlin.math.max

/**
 * مؤشرات فنية بحتة. كل الدوال تعيد 0.0 (أو 1.0 للحجم النسبي) عند نقص البيانات.
 * ملاحظة: يجب تمرير الشموع المكتملة فقط (بدون الشمعة الجارية).
 */
object Indicators {

    fun ema(prices: List<Double>, period: Int): Double {
        if (period <= 0 || prices.size < period) return 0.0
        val multiplier = 2.0 / (period + 1)
        var ema = prices.take(period).sum() / period
        for (i in period until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
        }
        return ema
    }

    /** RSI بطريقة Wilder. */
    fun rsi(prices: List<Double>, period: Int = 14): Double {
        if (prices.size < period + 1) return 0.0
        var avgGain = 0.0
        var avgLoss = 0.0
        for (i in 1..period) {
            val change = prices[i] - prices[i - 1]
            if (change > 0) avgGain += change else avgLoss -= change
        }
        avgGain /= period
        avgLoss /= period
        for (i in period + 1 until prices.size) {
            val change = prices[i] - prices[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) -change else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    /** ATR بطريقة Wilder. */
    fun atr(highs: List<Double>, lows: List<Double>, closes: List<Double>, period: Int = 14): Double {
        if (highs.size < period + 1 || highs.size != lows.size || highs.size != closes.size) return 0.0
        val trs = ArrayList<Double>()
        for (i in 1 until highs.size) {
            val hl = highs[i] - lows[i]
            val hc = abs(highs[i] - closes[i - 1])
            val lc = abs(lows[i] - closes[i - 1])
            trs.add(max(hl, max(hc, lc)))
        }
        if (trs.size < period) return 0.0
        var atr = trs.take(period).sum() / period
        for (i in period until trs.size) {
            atr = (atr * (period - 1) + trs[i]) / period
        }
        return atr
    }

    /** الحجم النسبي: حجم آخر شمعة مكتملة ÷ متوسط الشموع الـ20 التي قبلها. */
    fun rvol(volumes: List<Double>, period: Int = 20): Double {
        if (volumes.size < period + 1) return 1.0
        val avg = volumes.dropLast(1).takeLast(period).sum() / period
        if (avg == 0.0) return 1.0
        return volumes.last() / avg
    }
}

/** مستويات الدعم والمقاومة (قمم وقيعان محورية، نمط Fractal). */
object Levels {

    fun pivotHighs(c: List<Candle>, lookback: Int = 60, k: Int = 2): List<Double> {
        val res = ArrayList<Double>()
        val start = maxOf(k, c.size - lookback)
        for (i in start until c.size - k) {
            var ok = true
            for (j in 1..k) {
                if (c[i].high <= c[i - j].high || c[i].high <= c[i + j].high) {
                    ok = false
                    break
                }
            }
            if (ok) res.add(c[i].high)
        }
        return res
    }

    fun pivotLows(c: List<Candle>, lookback: Int = 60, k: Int = 2): List<Double> {
        val res = ArrayList<Double>()
        val start = maxOf(k, c.size - lookback)
        for (i in start until c.size - k) {
            var ok = true
            for (j in 1..k) {
                if (c[i].low >= c[i - j].low || c[i].low >= c[i + j].low) {
                    ok = false
                    break
                }
            }
            if (ok) res.add(c[i].low)
        }
        return res
    }
}
