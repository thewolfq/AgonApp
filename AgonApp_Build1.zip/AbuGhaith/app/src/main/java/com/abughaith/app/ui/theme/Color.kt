package com.abughaith.app.ui.theme

import androidx.compose.ui.graphics.Color

val DarkNavy = Color(0xFF0A1428)
val DarkNavyLight = Color(0xFF15203A)
val EmeraldGreen = Color(0xFF00C896)
val CoralRed = Color(0xFFFF6B6B)
val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFFB0B8C4)
val CardBackground = Color(0xFF1A2540)
val WarningOrange = Color(0xFFFFB74D)
val SuccessGreen = Color(0xFF4CAF50)
