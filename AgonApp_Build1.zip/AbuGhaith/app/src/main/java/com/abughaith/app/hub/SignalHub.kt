package com.abughaith.app.hub

import android.content.Context
import com.abughaith.app.coach.MatchCoach
import com.abughaith.app.data.PreferencesManager
import com.abughaith.app.engine.PlaymakerEngine
import com.abughaith.app.models.AnalysisOutcome
import com.abughaith.app.models.CoachAction
import com.abughaith.app.models.Direction
import com.abughaith.app.models.HubState
import com.abughaith.app.models.ManualResult
import com.abughaith.app.models.OpenTrade
import com.abughaith.app.models.RiskConfig
import com.abughaith.app.models.ScannedPair
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.TradeCard
import com.abughaith.app.models.TradeMode
import com.abughaith.app.notify.Notifier
import com.abughaith.app.risk.GoalkeeperRisk
import com.abughaith.app.scanner.ScannerRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit

/**
 * قلب التطبيق: يمسح السوق تلقائياً، يحلل الأزواج، يدير دورة حياة الإشارات
 * (قيد الانتظار ← مفعّلة)، ويطلق إشعاراً منبثقاً فقط عند تحقق شرط الدخول.
 * كما يتابع الصفقات المفتوحة عبر المدرب.
 */
class SignalHub(
    private val context: Context,
    private val scope: CoroutineScope,
    private val scanner: ScannerRepository,
    private val engine: PlaymakerEngine,
    private val risk: GoalkeeperRisk,
    private val coach: MatchCoach,
    private val prefs: PreferencesManager
) {
    companion object {
        private const val CYCLE_MS = 60_000L
        private const val FULL_SCAN_MS = 180_000L
        private const val NOTIFY_COOLDOWN_MS = 20L * 60_000L
        private const val DISMISS_MS = 60L * 60_000L
    }

    private class TradeUpdate(val price: Double, val eval: MatchCoach.CoachEvaluation)

    private val _state = MutableStateFlow(HubState())
    val state: StateFlow<HubState> = _state.asStateFlow()

    private val signals = LinkedHashMap<String, TradeCard>()
    private val lastNotified = HashMap<String, Long>()
    private val dismissedUntil = HashMap<String, Long>()
    private val notifiedCoach = HashSet<String>()
    private val mutex = Mutex()
    private val semaphore = Semaphore(6)

    private var loopJob: Job? = null
    private val lock = Any()

    @Volatile
    private var foreground = false

    @Volatile
    private var background = false

    @Volatile
    private var lastFull = 0L

    fun setForeground(value: Boolean) {
        foreground = value
        evaluateRunning()
    }

    fun setBackground(value: Boolean) {
        background = value
        evaluateRunning()
    }

    private fun evaluateRunning() {
        synchronized(lock) {
            val shouldRun = foreground || background
            if (shouldRun) {
                if (loopJob?.isActive != true) {
                    loopJob = scope.launch { runLoop() }
                }
            } else {
                loopJob?.cancel()
                loopJob = null
            }
        }
    }

    /** إخفاء إشارة (أو بعد فتح صفقة منها). */
    fun dismiss(symbol: String) {
        scope.launch {
            mutex.withLock {
                signals.remove(symbol)
                dismissedUntil[symbol] = System.currentTimeMillis() + DISMISS_MS
                publishLocked(null, _state.value.scannedCount)
            }
        }
    }

    /** مسح فوري يدوياً لجميع الأزواج. */
    fun requestFullScan() {
        lastFull = 0L
    }

    /** تحليل يدوي لزوج واحد (للسوق). لا يضيفه إلى قائمة الإشارات. */
    suspend fun analyzeNow(symbol: String): ManualResult {
        val r = engine.analyze(symbol)
        val outcome = r.getOrNull()
        if (outcome == null) {
            return ManualResult(null, r.exceptionOrNull()?.message ?: "تعذّر التحليل")
        }
        val cfg = prefs.riskConfigFlow.first()
        return if (outcome is AnalysisOutcome.Found) {
            ManualResult(AnalysisOutcome.Found(risk.plan(outcome.card, cfg)), null)
        } else {
            ManualResult(outcome, null)
        }
    }

    // ───────────────────────── الحلقة الرئيسية ─────────────────────────

    private suspend fun runLoop() {
        while (currentCoroutineContext().isActive) {
            try {
                cycle()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isScanning = false, error = e.message ?: "خطأ غير متوقع") }
            }
            delay(CYCLE_MS)
        }
    }

    private suspend fun cycle() {
        _state.update { it.copy(isScanning = true) }
        scanner.refresh()
        val sc = scanner.state.value
        if (sc.errorMessage != null || sc.pairs.isEmpty()) {
            _state.update { it.copy(isScanning = false, error = sc.errorMessage ?: "لا توجد بيانات سوق") }
            return
        }

        val now = System.currentTimeMillis()
        val full = now - lastFull >= FULL_SCAN_MS
        val pairs = sc.pairs
        val prices = HashMap<String, Double>()
        for (p in pairs) prices[p.symbol] = p.lastPrice

        val cfg = prefs.riskConfigFlow.first()
        val openTrades = prefs.openTradesFlow.first()
        val openSymbols = openTrades.map { it.symbol }.toSet()
        val block = risk.gate(openTrades.size)

        val tracked = mutex.withLock { signals.keys.toList() }
        val universe = LinkedHashSet<String>()
        if (full) universe.addAll(pickUniverse(pairs))
        universe.addAll(tracked)
        universe.removeAll(openSymbols)

        val results = coroutineScope {
            universe.map { sym ->
                async {
                    semaphore.withPermit { Pair(sym, engine.analyze(sym)) }
                }
            }.awaitAll()
        }
        if (full) lastFull = System.currentTimeMillis()

        mutex.withLock {
            processResults(results, cfg, block, prices, openSymbols)
            publishLocked(block, universe.size)
        }

        monitorOpenTrades(openTrades, prices)
    }

    private fun pickUniverse(pairs: List<ScannedPair>): List<String> {
        val out = LinkedHashSet<String>()
        pairs.take(15).forEach { out.add(it.symbol) }
        pairs.sortedByDescending { it.priceChangePercent }.take(8).forEach { out.add(it.symbol) }
        pairs.sortedBy { it.priceChangePercent }.take(8).forEach { out.add(it.symbol) }
        pairs.sortedByDescending { it.rangePercent }.take(6).forEach { out.add(it.symbol) }
        return out.take(32)
    }

    // يُستدعى داخل القفل
    private fun processResults(
        results: List<Pair<String, Result<AnalysisOutcome>>>,
        cfg: RiskConfig,
        block: String?,
        prices: Map<String, Double>,
        openSymbols: Set<String>
    ) {
        val now = System.currentTimeMillis()
        for ((sym, res) in results) {
            val outcome = res.getOrNull() ?: continue
            val existing = signals[sym]
            val suppressed = (dismissedUntil[sym] ?: 0L) > now
            when (outcome) {
                is AnalysisOutcome.NoSetup -> {
                    if (existing != null && existing.status == SignalStatus.PENDING) signals.remove(sym)
                }
                is AnalysisOutcome.Found -> {
                    val card = risk.plan(outcome.card, cfg)
                    if (suppressed || card.signalScore < cfg.minScore) {
                        if (existing != null && existing.status == SignalStatus.PENDING) signals.remove(sym)
                    } else if (card.status == SignalStatus.PENDING) {
                        if (existing == null) {
                            signals[sym] = card
                        } else if (existing.status == SignalStatus.PENDING) {
                            signals[sym] = card.copy(id = existing.id, createdAt = existing.createdAt)
                        }
                    } else {
                        // READY
                        if (existing != null && existing.status == SignalStatus.READY) {
                            // نُبقي البطاقة الأصلية ثابتة (لا نعيد حساب الوقف والأهداف)
                        } else if (block == null) {
                            val ready = if (existing != null) card.copy(id = existing.id) else card
                            signals[sym] = ready
                            val last = lastNotified[sym] ?: 0L
                            if (ready.riskError == null && now - last >= NOTIFY_COOLDOWN_MS) {
                                Notifier.signalReady(context, ready)
                                lastNotified[sym] = now
                            }
                        }
                    }
                }
            }
        }

        // انتهاء الصلاحية وإبطال الإشارات
        val iterator = signals.entries.iterator()
        while (iterator.hasNext()) {
            val card = iterator.next().value
            var drop = card.symbol in openSymbols
            val age = now - card.createdAt
            if (age > maxAgeMs(card)) drop = true
            val price = prices[card.symbol]
            if (price != null && card.status == SignalStatus.READY) {
                val long = card.direction == Direction.LONG
                if (long && price <= card.stopLossPrice) drop = true
                if (!long && price >= card.stopLossPrice) drop = true
                val tp3 = card.takeProfits.lastOrNull()?.price
                if (tp3 != null) {
                    if (long && price >= tp3) drop = true
                    if (!long && price <= tp3) drop = true
                }
            }
            if (drop) iterator.remove()
        }
    }

    private fun maxAgeMs(card: TradeCard): Long {
        val minutes = when {
            card.status == SignalStatus.READY && card.mode == TradeMode.SCALPING -> 60L
            card.status == SignalStatus.READY -> 240L
            card.mode == TradeMode.SCALPING -> 120L
            else -> 360L
        }
        return minutes * 60_000L
    }

    // يُستدعى داخل القفل
    private fun publishLocked(block: String?, scanned: Int) {
        val list = signals.values.sortedWith(
            compareByDescending<TradeCard> { it.status == SignalStatus.READY }
                .thenByDescending { it.signalScore }
        )
        _state.update {
            it.copy(
                signals = list,
                isScanning = false,
                lastScan = System.currentTimeMillis(),
                scannedCount = scanned,
                error = null,
                riskBlock = block
            )
        }
    }

    // ───────────────────────── متابعة الصفقات المفتوحة ─────────────────────────

    private suspend fun monitorOpenTrades(open: List<OpenTrade>, prices: Map<String, Double>) {
        if (open.isEmpty()) return
        val updates = HashMap<String, TradeUpdate>()
        for (t in open) {
            val price = prices[t.symbol] ?: continue
            val ind = engine.indicatorSnapshot(t.symbol)
            val ev = coach.evaluateTrade(t, price, ind)
            updates[t.id] = TradeUpdate(price, ev)
            val key = t.id + ":" + ev.action.name
            if (ev.action != CoachAction.HOLD && notifiedCoach.add(key)) {
                Notifier.coach(context, t, ev)
            }
        }
        if (updates.isEmpty()) return
        prefs.updateOpenTrades { list ->
            list.map { cur ->
                val u = updates[cur.id]
                if (u == null) {
                    cur
                } else {
                    cur.copy(
                        currentPrice = u.price,
                        healthIndex = u.eval.healthIndex,
                        lastCoachAction = u.eval.action,
                        lastCoachMessage = u.eval.arabicMessage
                    )
                }
            }
        }
    }
}
