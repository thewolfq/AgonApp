package com.abughaith.app.coach

import com.abughaith.app.models.CoachAction
import com.abughaith.app.models.Direction
import com.abughaith.app.models.IndicatorSnapshot
import com.abughaith.app.models.OpenTrade
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.TradeCard
import com.abughaith.app.util.Fmt
import kotlin.math.abs
import kotlin.math.min

/**
 * المدرب — يراقب الصفقات المفتوحة، يحسب مؤشر الصحة (0-100) ويصدر التوصيات التكتيكية.
 */
class MatchCoach {

    data class CoachEvaluation(
        val healthIndex: Int,
        val action: CoachAction,
        val arabicMessage: String,
        val warningMessage: String? = null
    )

    /** دكة البدلاء: أفضل 5 إشارات غير مفتوحة (المفعّلة أولاً ثم الأعلى درجة). */
    fun watchlist(signals: List<TradeCard>, openSymbols: Set<String>): List<TradeCard> =
        signals
            .filter { it.symbol !in openSymbols }
            .sortedWith(
                compareByDescending<TradeCard> { it.status == SignalStatus.READY }
                    .thenByDescending { it.signalScore }
            )
            .take(5)

    fun evaluateTrade(trade: OpenTrade, price: Double, ind: IndicatorSnapshot?): CoachEvaluation {
        val long = trade.direction == Direction.LONG
        val entry = trade.entryPrice
        val initialStop = if (trade.initialStopLoss > 0.0) trade.initialStopLoss else trade.stopLoss
        val risk = abs(entry - initialStop)
        if (entry <= 0.0 || risk <= 0.0) {
            return CoachEvaluation(50, CoachAction.HOLD, "بيانات الصفقة غير كافية للتقييم.")
        }

        val move = if (long) price - entry else entry - price
        val r = move / risk

        // ── مؤشر الصحة ──
        val pnlComp = ((r + 1.0) / 3.0 * 100.0).coerceIn(0.0, 100.0)
        val momComp = if (ind == null) {
            50.0
        } else if (long) {
            ((ind.rsi14 - 30.0) / 40.0 * 100.0).coerceIn(0.0, 100.0)
        } else {
            (100.0 - (ind.rsi14 - 30.0) / 40.0 * 100.0).coerceIn(0.0, 100.0)
        }
        val trendComp = if (ind == null) {
            60.0
        } else {
            val aligned = if (long) ind.ema20 > ind.ema50 else ind.ema20 < ind.ema50
            if (aligned) 100.0 else 30.0
        }
        val minutes = (System.currentTimeMillis() - trade.openedAt) / 60000.0
        val timeComp = 100.0 - min(minutes / 240.0 * 100.0, 60.0)
        val health = (0.45 * pnlComp + 0.25 * momComp + 0.20 * trendComp + 0.10 * timeComp)
            .toInt().coerceIn(0, 100)

        // ── حالات الأسعار ──
        val stopHit = if (long) price <= trade.stopLoss else price >= trade.stopLoss
        fun hit(level: Int): Boolean {
            val tp = trade.takeProfits.firstOrNull { it.level == level }?.price ?: return false
            return if (long) price >= tp else price <= tp
        }
        val slAtBreakeven = abs(trade.stopLoss - entry) <= entry * 0.001

        if (stopHit) {
            val msg = if (slAtBreakeven) {
                "وصل السعر إلى وقف التعادل. أغلق الصفقة وسجّلها."
            } else {
                "وصل السعر إلى وقف الخسارة. أغلق الصفقة وسجّلها."
            }
            return CoachEvaluation(health, CoachAction.STOP_HIT, msg, "تحذير: تم ضرب الوقف")
        }
        if (hit(3)) {
            return CoachEvaluation(health, CoachAction.CLOSE_ALL, "TP3 تحقق. أغلق ما تبقى من الصفقة.")
        }
        if (hit(2)) {
            return CoachEvaluation(
                health,
                CoachAction.TAKE_PARTIAL_PROFIT,
                "TP2 تحقق. اجنِ الجزء الثاني (30%) وشدّد الوقف."
            )
        }
        if (hit(1) && !slAtBreakeven) {
            return CoachEvaluation(
                health,
                CoachAction.MOVE_SL_TO_BREAKEVEN,
                "TP1 تحقق. اجنِ 40% وانقل وقف الخسارة إلى سعر الدخول (" + Fmt.price(entry) + ") لتأمين النتيجة."
            )
        }
        if (hit(1)) {
            return CoachEvaluation(health, CoachAction.HOLD, "الصفقة مؤمّنة (الوقف عند الدخول). استمر نحو TP2.")
        }
        if (health < 25 && move < 0.0) {
            return CoachEvaluation(
                health,
                CoachAction.EXIT_EARLY,
                "ضعف واضح (صحة $health) والصفقة خاسرة. فكّر في الخروج قبل ضرب الوقف.",
                "تحذير: الصفقة تضعف بسرعة"
            )
        }
        if (health < 35 && move > 0.0) {
            return CoachEvaluation(
                health,
                CoachAction.TAKE_PARTIAL_PROFIT,
                "الزخم يضعف مع ربح قائم (صحة $health). فكّر في جني جزء وتشديد الوقف."
            )
        }
        if (health < 40) {
            return CoachEvaluation(
                health,
                CoachAction.HOLD,
                "الصفقة تحت ضغط (صحة $health). راقب عن قرب.",
                "الصفقة تحت ضغط"
            )
        }
        return CoachEvaluation(health, CoachAction.HOLD, "الصفقة بحالة جيدة (صحة $health). استمر.")
    }
}
