package com.abughaith.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.abughaith.app.AbuGhaithApp
import com.abughaith.app.service.MonitorService
import com.abughaith.app.ui.screens.LiveMatchScreen
import com.abughaith.app.ui.screens.MarketScreen
import com.abughaith.app.ui.screens.SettingsScreen
import com.abughaith.app.ui.screens.SignalsScreen
import com.abughaith.app.ui.theme.AbuGhaithTheme
import com.abughaith.app.ui.theme.DarkNavy
import com.abughaith.app.ui.theme.DarkNavyLight
import com.abughaith.app.ui.theme.EmeraldGreen
import com.abughaith.app.ui.theme.TextSecondary
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as AbuGhaithApp

        lifecycleScope.launch {
            if (app.prefs.monitorEnabledFlow.first()) {
                MonitorService.start(this@MainActivity)
            }
        }

        setContent {
            AbuGhaithTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    RequestNotificationPermission()
                    AppRoot(app)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        (application as AbuGhaithApp).hub.setForeground(true)
    }

    override fun onStop() {
        (application as AbuGhaithApp).hub.setForeground(false)
        super.onStop()
    }
}

private class TabItem(val label: String, val icon: ImageVector)

@Composable
private fun AppRoot(app: AbuGhaithApp) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf(
        TabItem("الإشارات", Icons.Filled.Bolt),
        TabItem("السوق", Icons.Filled.Public),
        TabItem("المباراة", Icons.Filled.PlayArrow),
        TabItem("الإدارة", Icons.Filled.Settings)
    )

    Scaffold(
        containerColor = DarkNavy,
        bottomBar = {
            NavigationBar(containerColor = DarkNavyLight) {
                tabs.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldGreen,
                            selectedTextColor = EmeraldGreen,
                            indicatorColor = DarkNavy,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> SignalsScreen(app = app, onTradeOpened = { tab = 2 })
                1 -> MarketScreen(app = app)
                2 -> LiveMatchScreen(app = app)
                else -> SettingsScreen(app = app)
            }
        }
    }
}

@Composable
private fun RequestNotificationPermission() {
    if (Build.VERSION.SDK_INT < 33) return
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}
