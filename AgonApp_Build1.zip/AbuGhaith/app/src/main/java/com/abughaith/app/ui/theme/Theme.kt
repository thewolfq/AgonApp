package com.abughaith.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AbuGhaithDarkColors = darkColorScheme(
    primary = EmeraldGreen,
    onPrimary = DarkNavy,
    secondary = WarningOrange,
    onSecondary = DarkNavy,
    background = DarkNavy,
    onBackground = TextPrimary,
    surface = CardBackground,
    onSurface = TextPrimary,
    error = CoralRed,
    onError = Color.White
)

/** ثيم التطبيق — وضع داكن بألوان كحلي/زمردي/مرجاني. */
@Composable
fun AbuGhaithTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AbuGhaithDarkColors,
        typography = AbuGhaithTypography,
        content = content
    )
}
