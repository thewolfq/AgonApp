package com.abughaith.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abughaith.app.AbuGhaithApp
import com.abughaith.app.models.AnalysisOutcome
import com.abughaith.app.models.ManualResult
import com.abughaith.app.models.ScannedPair
import com.abughaith.app.ui.components.SignalCardView
import com.abughaith.app.ui.components.TrendChips
import com.abughaith.app.ui.theme.CoralRed
import com.abughaith.app.ui.theme.DarkNavy
import com.abughaith.app.ui.theme.EmeraldGreen
import com.abughaith.app.ui.theme.TextSecondary
import com.abughaith.app.util.Fmt

/** تبويب السوق: قوائم الأكثر صعوداً/هبوطاً/سيولة/تذبذباً. الضغط على زوج يحلله فوراً. */
@Composable
fun MarketScreen(app: AbuGhaithApp) {
    val state by app.scanner.state.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var target by remember { mutableStateOf<String?>(null) }
    var manual by remember { mutableStateOf<ManualResult?>(null) }

    DisposableEffect(Unit) {
        app.scanner.startAutoRefresh(20L)
        onDispose { app.scanner.stopAutoRefresh() }
    }

    LaunchedEffect(target) {
        val sym = target
        if (sym != null) {
            manual = null
            manual = app.hub.analyzeNow(sym)
        }
    }

    val titles = listOf("الأكثر صعوداً", "الأكثر هبوطاً", "الأعلى سيولة", "الأكثر تذبذباً")

    val list = remember(state.pairs, tab, query) {
        val q = query.trim()
        val filtered = if (q.isEmpty()) state.pairs else state.pairs.filter { it.symbol.contains(q, ignoreCase = true) }
        val sorted = when (tab) {
            0 -> filtered.sortedByDescending { it.priceChangePercent }
            1 -> filtered.sortedBy { it.priceChangePercent }
            2 -> filtered.sortedByDescending { it.quoteVolume }
            else -> filtered.sortedByDescending { it.rangePercent }
        }
        sorted.take(60)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            Text("السوق", style = MaterialTheme.typography.headlineMedium, color = EmeraldGreen)
            val sub = if (state.lastFetchTime > 0L) {
                "عقود USDT-M بحجم ≥ 2M • تحديث " + Fmt.time(state.lastFetchTime) + " • اضغط زوجاً لتحليله"
            } else if (state.errorMessage != null) {
                state.errorMessage ?: ""
            } else {
                "جارٍ تحميل السوق…"
            }
            Text(
                sub,
                color = if (state.lastFetchTime == 0L && state.errorMessage != null) CoralRed else TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }

        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 8.dp,
            containerColor = DarkNavy,
            contentColor = EmeraldGreen
        ) {
            titles.forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("ابحث عن زوج، مثل BTC") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )

        if (list.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (state.pairs.isEmpty()) "لا توجد بيانات بعد" else "لا نتائج مطابقة",
                    color = TextSecondary
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(list, key = { it.symbol }) { pair ->
                    PairRow(pair = pair, onClick = { target = pair.symbol })
                }
            }
        }
    }

    val sym = target
    if (sym != null) {
        AlertDialog(
            onDismissRequest = {
                target = null
                manual = null
            },
            confirmButton = {
                TextButton(onClick = {
                    target = null
                    manual = null
                }) { Text("إغلاق") }
            },
            title = { Text(sym) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    val m = manual
                    if (m == null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("جارٍ التحليل على 5 أطر زمنية…")
                        }
                    } else {
                        val err = m.error
                        val outcome = m.outcome
                        if (err != null) {
                            Text(err, color = CoralRed)
                        } else if (outcome is AnalysisOutcome.Found) {
                            SignalCardView(card = outcome.card)
                        } else if (outcome is AnalysisOutcome.NoSetup) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("لا توجد إشارة الآن", fontWeight = FontWeight.Bold)
                                if (outcome.tfTrends.isNotEmpty()) TrendChips(outcome.tfTrends)
                                Text(outcome.reason, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        )
    }
}

@Composable
private fun PairRow(pair: ScannedPair, onClick: () -> Unit) {
    val up = pair.priceChangePercent >= 0.0
    val color = if (up) EmeraldGreen else CoralRed
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(pair.baseAsset, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(
                "حجم " + Fmt.volume(pair.quoteVolume) + " • مدى " + Fmt.pct(pair.rangePercent),
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(Fmt.price(pair.lastPrice), fontWeight = FontWeight.SemiBold)
            Text(
                Fmt.pct(pair.priceChangePercent, signed = true),
                color = color,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
