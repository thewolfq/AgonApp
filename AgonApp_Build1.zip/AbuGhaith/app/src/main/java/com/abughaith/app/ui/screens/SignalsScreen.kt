package com.abughaith.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.abughaith.app.AbuGhaithApp
import com.abughaith.app.models.HubState
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.toOpenTrade
import com.abughaith.app.ui.components.StatusStrip
import com.abughaith.app.ui.components.SignalCardView
import com.abughaith.app.ui.theme.CoralRed
import com.abughaith.app.ui.theme.DarkNavy
import com.abughaith.app.ui.theme.EmeraldGreen
import com.abughaith.app.ui.theme.TextSecondary
import com.abughaith.app.ui.theme.WarningOrange
import com.abughaith.app.util.Fmt
import kotlinx.coroutines.launch

/** تبويب الإشارات: تُجلب تلقائياً (مفعّلة + قيد الانتظار) دون اختيار زوج. */
@Composable
fun SignalsScreen(app: AbuGhaithApp, onTradeOpened: () -> Unit) {
    val state by app.hub.state.collectAsState()
    var tab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    val ready = state.signals.filter { it.status == SignalStatus.READY }
    val pending = state.signals.filter { it.status == SignalStatus.PENDING }
    val shown = if (tab == 0) ready else pending

    Column(modifier = Modifier.fillMaxSize()) {
        StatusHeader(state)
        TabRow(
            selectedTabIndex = tab,
            containerColor = DarkNavy,
            contentColor = EmeraldGreen
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("مفعّلة (" + ready.size + ")") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("قيد الانتظار (" + pending.size + ")") })
        }

        if (shown.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (tab == 0) {
                        "لا توجد إشارة مفعّلة الآن.\nالتطبيق يمسح السوق تلقائياً ويحلل 5 أطر زمنية، وسيُنبّهك فور تحقق شرط دخول."
                    } else {
                        "لا توجد إشارات قيد الانتظار حالياً."
                    },
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(shown, key = { it.id }) { card ->
                    SignalCardView(
                        card = card,
                        onOpenTrade = {
                            scope.launch {
                                app.prefs.addOpenTrade(card.toOpenTrade())
                                app.hub.dismiss(card.symbol)
                                onTradeOpened()
                            }
                        },
                        onDismiss = { app.hub.dismiss(card.symbol) }
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusHeader(state: HubState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("أبو غيث", style = MaterialTheme.typography.headlineMedium, color = EmeraldGreen)
        val status = when {
            state.isScanning && state.lastScan == 0L -> "جارٍ المسح الأول للسوق…"
            state.isScanning -> "جارٍ المسح…"
            state.lastScan > 0L -> "آخر مسح " + Fmt.time(state.lastScan) + " • " + state.scannedCount + " زوج قيد التحليل"
            else -> "بانتظار بدء المسح"
        }
        Text(status, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        val err = state.error
        if (err != null) {
            Text(err, color = CoralRed, style = MaterialTheme.typography.bodySmall)
        }
        val block = state.riskBlock
        if (block != null) {
            StatusStrip("🛡️ " + block, WarningOrange)
        }
    }
}
