package com.abughaith.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abughaith.app.AbuGhaithApp
import com.abughaith.app.models.CircuitBreakerState
import com.abughaith.app.models.Direction
import com.abughaith.app.models.RiskConfig
import com.abughaith.app.models.TradeHistoryEntry
import com.abughaith.app.notify.Notifier
import com.abughaith.app.service.MonitorService
import com.abughaith.app.ui.components.InfoRow
import com.abughaith.app.ui.components.SectionCard
import com.abughaith.app.ui.theme.CoralRed
import com.abughaith.app.ui.theme.DarkNavy
import com.abughaith.app.ui.theme.EmeraldGreen
import com.abughaith.app.ui.theme.TextSecondary
import com.abughaith.app.ui.theme.WarningOrange
import com.abughaith.app.util.Fmt
import kotlinx.coroutines.launch

private const val ABOUT_TEXT =
    "«أبو غيث» مستشار تداول ميداني للعقود الآجلة (Binance Futures USDT-M). " +
        "يمسح السوق تلقائياً، ويحلل أربعة أطر زمنية رئيسية (يومي، 4 ساعات، 15 دقيقة، 5 دقائق) " +
        "إضافة إلى الساعة، ليحدد هل الفرصة تصلح لتداول سريع أم يومي. " +
        "يصدر إشارات واضحة بمنطقة دخول ووقف خسارة وثلاثة أهداف وخطة بديلة، " +
        "أو إشارات مسبقة بشروط دخول تُنبّهك بإشعار منبثق فور تحققها. " +
        "يحميك حارس المخاطر بسقف خسارة ورافعة محسوبة وقاطع تشغيل يومي، ويتابع المدرب صفقاتك المفتوحة. " +
        "التنفيذ يدوي بالكامل، والتطبيق لا يملك أي صلاحية على حسابك. " +
        "هذه الأداة ليست نصيحة مالية، والتداول بالعقود الآجلة عالي المخاطر وقد تخسر رأس مالك."

private const val AUTHOR_TEXT = "تطوير: عبدالوارث الذيب"

/** تبويب الإدارة: رأس المال، المخاطر، المراقبة، قاطع التشغيل، السجل، الربط الآلي، نبذة. */
@Composable
fun SettingsScreen(app: AbuGhaithApp) {
    val prefs = app.prefs
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val cfg by prefs.riskConfigFlow.collectAsState(initial = RiskConfig())
    val circuit by prefs.circuitBreakerFlow.collectAsState(initial = CircuitBreakerState())
    val history by prefs.historyFlow.collectAsState(initial = emptyList<TradeHistoryEntry>())
    val monitor by prefs.monitorEnabledFlow.collectAsState(initial = false)

    var capital by remember(cfg.capitalUsdt) { mutableStateOf(cfg.capitalUsdt.toFloat()) }
    var maxLoss by remember(cfg.maxLossPercent) { mutableStateOf(cfg.maxLossPercent.toFloat()) }
    var minScore by remember(cfg.minScore) { mutableStateOf(cfg.minScore.toFloat()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("الإدارة", style = MaterialTheme.typography.headlineMedium, color = EmeraldGreen)

        SectionCard("رأس المال والمخاطر") {
            Text("رأس المال: \$" + capital.toInt(), fontWeight = FontWeight.Bold)
            Slider(
                value = capital,
                onValueChange = { capital = it },
                valueRange = 1f..100f,
                steps = 98,
                onValueChangeFinished = { scope.launch { prefs.setCapital(capital.toDouble()) } },
                colors = SliderDefaults.colors(thumbColor = EmeraldGreen, activeTrackColor = EmeraldGreen)
            )
            Text(
                "أقصى عدد صفقات متزامنة: " + cfg.maxConcurrentTrades +
                    " • هامش كل صفقة: \$" + Fmt.usd(cfg.capitalUsdt / cfg.maxConcurrentTrades),
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )

            Text("أقصى خسارة للصفقة: " + maxLoss.toInt() + "% من مبلغ الدخول", fontWeight = FontWeight.Bold)
            Slider(
                value = maxLoss,
                onValueChange = { maxLoss = it },
                valueRange = 3f..10f,
                steps = 6,
                onValueChangeFinished = { scope.launch { prefs.setMaxLossPercent(maxLoss.toDouble()) } },
                colors = SliderDefaults.colors(thumbColor = EmeraldGreen, activeTrackColor = EmeraldGreen)
            )
            Text(
                "الرافعة تُحسب تلقائياً من مسافة الوقف وبحد أقصى 10x.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )

            Text("أدنى درجة للإشارة: " + minScore.toInt() + "/100", fontWeight = FontWeight.Bold)
            Slider(
                value = minScore,
                onValueChange = { minScore = it },
                valueRange = 60f..90f,
                steps = 5,
                onValueChangeFinished = { scope.launch { prefs.setMinScore(minScore.toInt()) } },
                colors = SliderDefaults.colors(thumbColor = EmeraldGreen, activeTrackColor = EmeraldGreen)
            )
        }

        SectionCard("المراقبة والإشعارات") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("المراقبة في الخلفية", fontWeight = FontWeight.Bold)
                Switch(
                    checked = monitor,
                    onCheckedChange = { on ->
                        scope.launch { prefs.setMonitorEnabled(on) }
                        if (on) MonitorService.start(ctx) else MonitorService.stop(ctx)
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = DarkNavy, checkedTrackColor = EmeraldGreen)
                )
            }
            Text(
                "عند التفعيل يبقى التطبيق يمسح السوق والشاشة مغلقة ويُرسل إشعاراً منبثقاً عند تفعيل الإشارات. " +
                    "يستهلك بطارية أكثر. لأفضل نتيجة استثنِ التطبيق من توفير البطارية.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { Notifier.test(ctx) }) { Text("اختبار الإشعار") }
                OutlinedButton(onClick = {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (_: ActivityNotFoundException) {
                    }
                }) { Text("إعدادات البطارية") }
            }
        }

        SectionCard("قاطع التشغيل اليومي") {
            val now = System.currentTimeMillis()
            val cd = circuit.cooldownUntil
            val statusText = when {
                circuit.isActive -> "🔴 مفعّل — لا إشارات جديدة حتى الغد"
                cd != null && now < cd -> "🟠 فترة هدوء — " + ((cd - now) / 60000L + 1L) + " دقيقة متبقية"
                else -> "🟢 يعمل بشكل طبيعي"
            }
            InfoRow("الحالة", statusText)
            InfoRow("خسائر متتالية اليوم", circuit.consecutiveLosses.toString() + " / 2")
            Text(
                "خسارتان متتاليتان توقفان الإشارات الجديدة، وبعد أي خسارة هدوء 30 دقيقة.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = { scope.launch { prefs.resetCircuitBreaker() } }) { Text("إعادة ضبط القاطع") }
        }

        SectionCard("سجل الصفقات") {
            val wins = history.count { it.pnlUsdt > 0.0 }
            val total = history.sumOf { it.pnlUsdt }
            if (history.isEmpty()) {
                Text("لا توجد صفقات مسجلة بعد.", color = TextSecondary)
            } else {
                InfoRow("عدد الصفقات", history.size.toString())
                InfoRow("نسبة الربح", Fmt.pct(wins * 100.0 / history.size))
                InfoRow(
                    "صافي الربح (بعد رسوم تقديرية)",
                    Fmt.num(total, 2) + "\$",
                    if (total >= 0.0) EmeraldGreen else CoralRed
                )
                history.takeLast(15).reversed().forEach { h ->
                    InfoRow(
                        h.symbol + " " + (if (h.direction == Direction.LONG) "▲" else "▼") + " " + Fmt.dateTime(h.closedAt),
                        Fmt.num(h.pnlUsdt, 2) + "\$ (" + Fmt.pct(h.pnlPercent, signed = true) + ")",
                        if (h.pnlUsdt >= 0.0) EmeraldGreen else CoralRed
                    )
                }
                TextButton(onClick = { scope.launch { prefs.clearHistory() } }) {
                    Text("مسح السجل", color = CoralRed)
                }
            }
        }

        SectionCard("الربط الآلي (API)") {
            Text(
                "🔒 مقفل — وضع التدريب اليدوي. التنفيذ على Binance يتم يدوياً من قِبلك. " +
                    "مستقبلاً سيُتاح الربط بمفاتيح API مع حظر صلاحية السحب تماماً.",
                color = WarningOrange,
                style = MaterialTheme.typography.bodyMedium
            )
            Button(
                onClick = {},
                enabled = false,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = DarkNavy)
            ) { Text("تفعيل الربط الآلي") }
        }

        SectionCard("عن التطبيق") {
            Text(ABOUT_TEXT, style = MaterialTheme.typography.bodyMedium)
            Text(AUTHOR_TEXT, color = EmeraldGreen, fontWeight = FontWeight.Bold)
        }
    }
}
