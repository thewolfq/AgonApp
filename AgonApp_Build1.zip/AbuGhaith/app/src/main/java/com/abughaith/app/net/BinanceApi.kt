package com.abughaith.app.net

import com.abughaith.app.models.Candle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class ApiException(message: String) : Exception(message)

/**
 * عميل Binance Futures العام (بدون مفاتيح). يحتوي على:
 *  - تخزين مؤقت للشموع حسب الإطار الزمني لتقليل الطلبات.
 *  - إيقاف مؤقت تلقائي عند تجاوز حد الطلبات (429/418).
 */
class BinanceApi {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var blockedUntil = 0L

    private val klineCache = ConcurrentHashMap<String, Pair<Long, List<Candle>>>()

    companion object {
        const val BASE = "https://fapi.binance.com"
    }

    suspend fun getJson(url: String): Result<String> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (now < blockedUntil) {
            val secs = (blockedUntil - now) / 1000L + 1L
            return@withContext Result.failure<String>(ApiException("تم تجاوز حد الطلبات، إعادة المحاولة بعد $secs ثانية"))
        }
        try {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { resp ->
                val code = resp.code
                if (code == 429 || code == 418) {
                    val retry = resp.header("Retry-After")?.toLongOrNull() ?: 60L
                    blockedUntil = System.currentTimeMillis() + retry * 1000L
                    return@withContext Result.failure<String>(ApiException("تم تجاوز حد الطلبات في Binance، سيُعاد المحاولة تلقائياً"))
                }
                if (code == 451 || code == 403) {
                    return@withContext Result.failure<String>(ApiException("الوصول إلى Binance محجوب من منطقتك. جرّب VPN"))
                }
                if (!resp.isSuccessful) {
                    return@withContext Result.failure<String>(ApiException("خطأ في الشبكة: $code"))
                }
                val body = resp.body?.string()
                    ?: return@withContext Result.failure<String>(ApiException("لا توجد بيانات"))
                Result.success(body)
            }
        } catch (e: IOException) {
            Result.failure<String>(ApiException("تعذّر الاتصال بالشبكة"))
        } catch (e: Exception) {
            Result.failure<String>(e)
        }
    }

    private fun ttlFor(interval: String): Long = when (interval) {
        "1d" -> 15L * 60_000L
        "4h" -> 10L * 60_000L
        "1h" -> 4L * 60_000L
        "15m" -> 50_000L
        else -> 25_000L
    }

    /** يعيد الشموع بما فيها الشمعة الأخيرة الجارية (غير المكتملة). */
    suspend fun klines(symbol: String, interval: String, limit: Int = 100): Result<List<Candle>> {
        val key = "$symbol|$interval"
        val now = System.currentTimeMillis()
        val cached = klineCache[key]
        if (cached != null && now - cached.first < ttlFor(interval)) {
            return Result.success<List<Candle>>(cached.second)
        }
        val url = "$BASE/fapi/v1/klines?symbol=$symbol&interval=$interval&limit=$limit"
        val body = getJson(url).getOrElse { return Result.failure<List<Candle>>(it) }
        return try {
            val list = parseKlines(body)
            klineCache[key] = Pair(now, list)
            Result.success<List<Candle>>(list)
        } catch (e: Exception) {
            Result.failure<List<Candle>>(ApiException("بيانات الشموع غير صالحة لـ $symbol"))
        }
    }

    private fun parseKlines(body: String): List<Candle> {
        val arr = JSONArray(body)
        val out = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val k = arr.getJSONArray(i)
            out.add(
                Candle(
                    openTime = k.getLong(0),
                    open = k.getString(1).toDouble(),
                    high = k.getString(2).toDouble(),
                    low = k.getString(3).toDouble(),
                    close = k.getString(4).toDouble(),
                    volume = k.getString(5).toDouble(),
                    closeTime = k.getLong(6)
                )
            )
        }
        return out
    }
}
