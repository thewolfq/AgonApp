package com.abughaith.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object Fmt {
    fun price(p: Double): String {
        if (p.isNaN() || p.isInfinite()) return "-"
        val a = abs(p)
        val decimals = when {
            a >= 1000.0 -> 2
            a >= 100.0 -> 3
            a >= 1.0 -> 4
            a >= 0.1 -> 5
            a >= 0.01 -> 6
            a >= 0.001 -> 7
            else -> 8
        }
        return String.format(Locale.US, "%." + decimals + "f", p)
    }

    fun usd(v: Double): String = String.format(Locale.US, "%.2f", v)

    fun num(v: Double, decimals: Int = 2): String =
        String.format(Locale.US, "%." + decimals + "f", v)

    fun pct(v: Double, signed: Boolean = false): String {
        val s = String.format(Locale.US, "%.2f", v)
        return if (signed && v > 0.0) "+$s%" else "$s%"
    }

    fun volume(v: Double): String = when {
        v >= 1.0e9 -> String.format(Locale.US, "%.2fB", v / 1.0e9)
        v >= 1.0e6 -> String.format(Locale.US, "%.1fM", v / 1.0e6)
        v >= 1.0e3 -> String.format(Locale.US, "%.0fK", v / 1.0e3)
        else -> String.format(Locale.US, "%.0f", v)
    }

    fun ago(ms: Long): String {
        val m = ms / 60000L
        return when {
            m < 1L -> "الآن"
            m < 60L -> "منذ $m د"
            else -> "منذ ${m / 60L} س"
        }
    }

    fun time(ts: Long): String =
        SimpleDateFormat("HH:mm", Locale.US).format(Date(ts))

    fun dateTime(ts: Long): String =
        SimpleDateFormat("MM/dd HH:mm", Locale.US).format(Date(ts))
}
