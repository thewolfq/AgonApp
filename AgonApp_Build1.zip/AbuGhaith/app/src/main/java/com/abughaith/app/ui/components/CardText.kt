package com.abughaith.app.ui.components

import com.abughaith.app.models.Direction
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.TradeCard
import com.abughaith.app.models.TradeMode
import com.abughaith.app.util.Fmt

/** نص جاهز للنسخ إلى الحافظة لتنفيذ الصفقة يدوياً على Binance. */
fun buildCopyText(card: TradeCard): String {
    val long = card.direction == Direction.LONG
    val sb = StringBuilder()
    sb.appendLine(
        card.symbol + " — " + (if (long) "شراء LONG" else "بيع SHORT") +
            " (" + (if (card.mode == TradeMode.SCALPING) "سريع" else "يومي") + ")"
    )
    if (card.status == SignalStatus.PENDING) {
        sb.appendLine("الحالة: بانتظار الشرط — " + card.triggerText)
    } else {
        sb.appendLine("الحالة: مفعّلة — " + card.triggerText)
    }
    sb.appendLine("منطقة الدخول: " + Fmt.price(card.entryZoneLow) + " – " + Fmt.price(card.entryZoneHigh))
    sb.appendLine("وقف الخسارة: " + Fmt.price(card.stopLossPrice))
    card.takeProfits.forEach { sb.appendLine("TP" + it.level + ": " + Fmt.price(it.price)) }
    val plan = card.plan
    if (plan != null) {
        sb.appendLine()
        sb.append(plan.guardianText)
    }
    return sb.toString().trim()
}
