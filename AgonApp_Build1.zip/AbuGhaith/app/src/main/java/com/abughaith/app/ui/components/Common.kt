package com.abughaith.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abughaith.app.models.TfTrend
import com.abughaith.app.models.Trend
import com.abughaith.app.ui.theme.CardBackground
import com.abughaith.app.ui.theme.CoralRed
import com.abughaith.app.ui.theme.EmeraldGreen
import com.abughaith.app.ui.theme.TextPrimary
import com.abughaith.app.ui.theme.TextSecondary
import com.abughaith.app.ui.theme.WarningOrange

@Composable
fun Pill(text: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.18f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(text = text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TrendChips(trends: List<TfTrend>) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        trends.forEach { t ->
            val color = when (t.trend) {
                Trend.UP -> EmeraldGreen
                Trend.DOWN -> CoralRed
                Trend.NEUTRAL -> TextSecondary
            }
            val arrow = when (t.trend) {
                Trend.UP -> "▲"
                Trend.DOWN -> "▼"
                Trend.NEUTRAL -> "◆"
            }
            Pill(t.label + " " + arrow, color)
        }
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = TextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = valueColor, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun StatusStrip(text: String, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(text, color = color, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = EmeraldGreen)
            content()
        }
    }
}

@Composable
fun HealthBar(health: Int) {
    val color = when {
        health >= 65 -> EmeraldGreen
        health >= 40 -> WarningOrange
        else -> CoralRed
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("مؤشر صحة الصفقة", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            Text("$health / 100", color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        }
        LinearProgressIndicator(
            progress = { health.coerceIn(0, 100) / 100f },
            modifier = Modifier.fillMaxWidth(),
            color = color,
            trackColor = TextSecondary.copy(alpha = 0.25f)
        )
    }
}
