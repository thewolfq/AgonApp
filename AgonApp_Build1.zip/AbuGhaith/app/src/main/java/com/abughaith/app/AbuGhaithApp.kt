package com.abughaith.app

import android.app.Application
import com.abughaith.app.coach.MatchCoach
import com.abughaith.app.data.PreferencesManager
import com.abughaith.app.engine.PlaymakerEngine
import com.abughaith.app.hub.SignalHub
import com.abughaith.app.net.BinanceApi
import com.abughaith.app.notify.Notifier
import com.abughaith.app.risk.GoalkeeperRisk
import com.abughaith.app.scanner.MarketScanner
import com.abughaith.app.scanner.ScannerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** حاوية الاعتماديات المشتركة (Singleton) — تُشارك بين الواجهة والخدمة. */
class AbuGhaithApp : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var prefs: PreferencesManager
        private set
    lateinit var scanner: ScannerRepository
        private set
    lateinit var coach: MatchCoach
        private set
    lateinit var risk: GoalkeeperRisk
        private set
    lateinit var hub: SignalHub
        private set

    override fun onCreate() {
        super.onCreate()
        val api = BinanceApi()
        prefs = PreferencesManager(this)
        scanner = ScannerRepository(MarketScanner(api), appScope)
        coach = MatchCoach()
        risk = GoalkeeperRisk(prefs)
        hub = SignalHub(this, appScope, scanner, PlaymakerEngine(api), risk, coach, prefs)
        Notifier.createChannels(this)
    }
}
