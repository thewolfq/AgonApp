package com.abughaith.app.engine

import com.abughaith.app.models.AnalysisOutcome
import com.abughaith.app.models.Candle
import com.abughaith.app.models.CounterScenario
import com.abughaith.app.models.Direction
import com.abughaith.app.models.IndicatorSnapshot
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.SignalStrength
import com.abughaith.app.models.TakeProfit
import com.abughaith.app.models.TfTrend
import com.abughaith.app.models.TradeCard
import com.abughaith.app.models.TradeMode
import com.abughaith.app.models.Trend
import com.abughaith.app.net.ApiException
import com.abughaith.app.net.BinanceApi
import com.abughaith.app.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * محرك التحليل متعدد الأطر الزمنية.
 *
 *  - 1D  : الاتجاه العام + شمعة اليوم (الجارية) + قمة/قاع أمس.
 *  - 4H  : الاتجاه الرئيسي ومستويات الدعم والمقاومة الكبرى.
 *  - 1H  : إطار الإعداد للتداول اليومي.
 *  - 15m : إطار الإعداد للتداول السريع / إطار التأكيد لليومي.
 *  - 5m  : إطار التأكيد للتداول السريع.
 *
 * تُحسب كل المؤشرات على الشموع المكتملة فقط. الإشارة إما READY (شرط الدخول تحقق الآن)
 * أو PENDING (الإعداد جاهز وبانتظار اختراق مستوى محدد).
 */
class PlaymakerEngine(private val api: BinanceApi) {

    companion object {
        private const val MIN_SCORE = 60
        private const val MIN_SL_PCT = 0.006
        private const val MAX_SL_PCT = 0.06
    }

    private class Snap(
        val close: Double,
        val ema20: Double,
        val ema50: Double,
        val ema20Prev: Double,
        val rsi: Double,
        val atr: Double,
        val rvol: Double,
        val trend: Trend
    )

    private class Frames(
        val d1: List<Candle>,
        val h4: List<Candle>,
        val h1: List<Candle>,
        val m15: List<Candle>,
        val m5: List<Candle>
    )

    private class Ctx(
        val symbol: String,
        val price: Double,
        val s1d: Snap?,
        val s4h: Snap,
        val s1h: Snap,
        val s15: Snap,
        val s5: Snap,
        val h4: List<Candle>,
        val h1: List<Candle>,
        val m15: List<Candle>,
        val m5: List<Candle>,
        val today: Candle,
        val yesterday: Candle?,
        val trends: List<TfTrend>
    )

    private class Eval(val card: TradeCard?, val reason: String)

    // ───────────────────────── واجهة عامة ─────────────────────────

    suspend fun analyze(symbol: String): Result<AnalysisOutcome> = withContext(Dispatchers.Default) {
        val frames = fetchFrames(symbol).getOrElse {
            return@withContext Result.failure<AnalysisOutcome>(it)
        }
        try {
            Result.success<AnalysisOutcome>(evaluateAll(symbol, frames))
        } catch (e: Exception) {
            Result.failure<AnalysisOutcome>(e)
        }
    }

    /** لقطة مؤشرات 15 دقيقة لاستخدام المدرب في متابعة الصفقات المفتوحة. */
    suspend fun indicatorSnapshot(symbol: String): IndicatorSnapshot? {
        val k = api.klines(symbol, "15m").getOrNull() ?: return null
        val s = snap(k.dropLast(1), 55) ?: return null
        return IndicatorSnapshot(s.ema20, s.ema50, s.rsi, s.atr, s.rvol, s.close)
    }

    // ───────────────────────── جلب البيانات ─────────────────────────

    private suspend fun fetchFrames(symbol: String): Result<Frames> = coroutineScope {
        val d1 = async { api.klines(symbol, "1d") }
        val h4 = async { api.klines(symbol, "4h") }
        val h1 = async { api.klines(symbol, "1h") }
        val m15 = async { api.klines(symbol, "15m") }
        val m5 = async { api.klines(symbol, "5m") }
        val all = listOf(d1.await(), h4.await(), h1.await(), m15.await(), m5.await())
        val failed = all.firstOrNull { it.isFailure }
        if (failed != null) {
            return@coroutineScope Result.failure<Frames>(
                failed.exceptionOrNull() ?: ApiException("فشل جلب الشموع")
            )
        }
        Result.success(
            Frames(
                all[0].getOrThrow(),
                all[1].getOrThrow(),
                all[2].getOrThrow(),
                all[3].getOrThrow(),
                all[4].getOrThrow()
            )
        )
    }

    // ───────────────────────── المؤشرات ─────────────────────────

    private fun snap(closed: List<Candle>, minSize: Int): Snap? {
        if (closed.size < minSize) return null
        val closes = closed.map { it.close }
        val highs = closed.map { it.high }
        val lows = closed.map { it.low }
        val vols = closed.map { it.volume }
        val e20 = Indicators.ema(closes, 20)
        val e50 = Indicators.ema(closes, 50)
        val last = closes.last()
        val trend = when {
            e20 <= 0.0 || e50 <= 0.0 -> Trend.NEUTRAL
            e20 > e50 && last > e50 -> Trend.UP
            e20 < e50 && last < e50 -> Trend.DOWN
            else -> Trend.NEUTRAL
        }
        return Snap(
            close = last,
            ema20 = e20,
            ema50 = e50,
            ema20Prev = Indicators.ema(closes.dropLast(3), 20),
            rsi = Indicators.rsi(closes, 14),
            atr = Indicators.atr(highs, lows, closes, 14),
            rvol = Indicators.rvol(vols, 20),
            trend = trend
        )
    }

    private fun aligned(long: Boolean, t: Trend): Boolean =
        (long && t == Trend.UP) || (!long && t == Trend.DOWN)

    private fun opposite(long: Boolean, t: Trend): Boolean =
        (long && t == Trend.DOWN) || (!long && t == Trend.UP)

    private fun trendWord(t: Trend): String = when (t) {
        Trend.UP -> "صاعد"
        Trend.DOWN -> "هابط"
        Trend.NEUTRAL -> "محايد"
    }

    // ───────────────────────── التقييم ─────────────────────────

    private fun evaluateAll(symbol: String, f: Frames): AnalysisOutcome {
        if (f.m5.size < 3 || f.d1.size < 2) {
            return AnalysisOutcome.NoSetup("بيانات الشموع غير كافية", emptyList())
        }
        val price = f.m5.last().close
        val d1c = f.d1.dropLast(1)
        val h4c = f.h4.dropLast(1)
        val h1c = f.h1.dropLast(1)
        val m15c = f.m15.dropLast(1)
        val m5c = f.m5.dropLast(1)

        val s1d = snap(d1c, 25)
        val s4h = snap(h4c, 55)
        val s1h = snap(h1c, 55)
        val s15 = snap(m15c, 55)
        val s5 = snap(m5c, 55)
        if (s4h == null || s1h == null || s15 == null || s5 == null) {
            return AnalysisOutcome.NoSetup("بيانات الشموع غير كافية (زوج حديث الإدراج؟)", emptyList())
        }

        val trends = listOf(
            TfTrend("1D", s1d?.trend ?: Trend.NEUTRAL),
            TfTrend("4H", s4h.trend),
            TfTrend("1H", s1h.trend),
            TfTrend("15M", s15.trend),
            TfTrend("5M", s5.trend)
        )

        val ctx = Ctx(
            symbol = symbol,
            price = price,
            s1d = s1d,
            s4h = s4h,
            s1h = s1h,
            s15 = s15,
            s5 = s5,
            h4 = h4c,
            h1 = h1c,
            m15 = m15c,
            m5 = m5c,
            today = f.d1.last(),
            yesterday = f.d1[f.d1.size - 2],
            trends = trends
        )

        val results = listOf(evaluate(TradeMode.INTRADAY, ctx), evaluate(TradeMode.SCALPING, ctx))
        val found = results.mapNotNull { it.card }
        val best = found.maxByOrNull {
            it.signalScore * 2 + (if (it.mode == TradeMode.INTRADAY) 1 else 0)
        }
        return if (best != null) {
            AnalysisOutcome.Found(best)
        } else {
            AnalysisOutcome.NoSetup(results.joinToString(" • ") { it.reason }, trends)
        }
    }

    private fun evaluate(mode: TradeMode, c: Ctx): Eval {
        val intraday = mode == TradeMode.INTRADAY
        val modeName = if (intraday) "يومي" else "سريع"
        val setup = if (intraday) c.s1h else c.s15
        val entrySnap = if (intraday) c.s15 else c.s5
        val setupCandles = if (intraday) c.h1 else c.m15
        val entryCandles = if (intraday) c.m15 else c.m5
        val setupLabel = if (intraday) "الساعة" else "15 دقيقة"
        val entryLabel = if (intraday) "15 دقيقة" else "5 دقائق"

        fun no(r: String): Eval = Eval(null, "$modeName: $r")

        // ── الاتجاه على إطار الإعداد ──
        val long = when (setup.trend) {
            Trend.UP -> true
            Trend.DOWN -> false
            Trend.NEUTRAL -> return no("اتجاه $setupLabel محايد")
        }

        // ── بوابة الاتجاه الأعلى ──
        val t1d = c.s1d?.trend ?: Trend.NEUTRAL
        val t4h = c.s4h.trend
        if (intraday) {
            if (!aligned(long, t4h)) return no("4 ساعات لا يدعم الاتجاه")
            if (opposite(long, t1d)) return no("الاتجاه اليومي معاكس")
        } else {
            if (opposite(long, t4h)) return no("4 ساعات معاكس")
            if (!aligned(long, t4h) && opposite(long, t1d)) return no("اليومي معاكس و4 ساعات غير داعم")
            if (opposite(long, c.s1h.trend)) return no("اتجاه الساعة معاكس")
        }

        // ── RSI والامتداد والتقلب ──
        val rsiDir = if (long) setup.rsi else 100.0 - setup.rsi
        if (rsiDir >= 75.0) return no("RSI متشبع (" + Fmt.num(setup.rsi, 0) + ")")
        val atrS = setup.atr
        val atrE = entrySnap.atr
        if (atrS <= 0.0 || atrE <= 0.0) return no("ATR غير متاح")
        val ext = abs(c.price - setup.ema20) / atrS
        if (ext > 2.2) return no("السعر مبتعد عن المتوسط (مطاردة)")

        // ── شرط الدخول (اختراق مؤكد بإغلاق شمعة) ──
        if (entryCandles.size < 12) return no("شموع غير كافية")
        val lastE = entryCandles.last()
        val prior = entryCandles.dropLast(1).takeLast(10)
        val level = if (long) prior.maxOf { it.high } else prior.minOf { it.low }
        val broke = if (long) lastE.close > level else lastE.close < level
        val priceHolds = if (long) c.price > level else c.price < level
        val volOk = entrySnap.rvol >= 1.0
        val ready = broke && priceHolds && volOk && ext <= 1.8
        if (!ready && !broke) {
            val gap = if (long) level - c.price else c.price - level
            if (gap > 2.5 * atrE) return no("السعر بعيد عن مستوى الاختراق")
        }
        if (!ready && broke && ext > 1.8) return no("اختراق لكن السعر بعيد عن المتوسط")

        val buffer = 0.1 * atrE
        val entry = if (ready) {
            c.price
        } else if (long) {
            maxOf(c.price, level + buffer)
        } else {
            minOf(c.price, level - buffer)
        }

        // ── وقف الخسارة (هيكلي مع بديل بالـ ATR) ──
        val pivots = if (long) Levels.pivotLows(setupCandles, 40) else Levels.pivotHighs(setupCandles, 40)
        val nearest = if (long) {
            pivots.filter { it < entry }.maxOrNull()
        } else {
            pivots.filter { it > entry }.minOrNull()
        }
        var slDist = 1.5 * atrS
        if (nearest != null) {
            val d = abs(entry - nearest) + 0.15 * atrS
            if (d >= 1.0 * atrS && d <= 2.2 * atrS) slDist = d
        }
        val s = if (long) 1.0 else -1.0
        val sl = entry - s * slDist
        val slPct = slDist / entry
        if (slPct < MIN_SL_PCT) {
            return no("التقلب منخفض: الوقف " + Fmt.pct(slPct * 100.0) + " لا يغطي الرسوم")
        }
        if (slPct > MAX_SL_PCT) return no("الوقف بعيد جداً (" + Fmt.pct(slPct * 100.0) + ")")

        // ── الأهداف من هيكل السعر ──
        val levels = ArrayList<Double>()
        if (long) {
            levels.addAll(Levels.pivotHighs(setupCandles, 60))
            levels.addAll(Levels.pivotHighs(c.h4, 60))
            c.yesterday?.let { levels.add(it.high) }
            levels.add(c.today.high)
        } else {
            levels.addAll(Levels.pivotLows(setupCandles, 60))
            levels.addAll(Levels.pivotLows(c.h4, 60))
            c.yesterday?.let { levels.add(it.low) }
            levels.add(c.today.low)
        }
        val ahead = levels
            .filter { s * (it - entry) > 0.1 * slDist }
            .sortedBy { s * (it - entry) }
        val first = ahead.firstOrNull()
        if (first != null && s * (first - entry) < 1.0 * slDist) {
            return no("عائق قريب عند " + Fmt.price(first) + " يمنع الهدف الأول")
        }

        val tp1 = entry + s * 1.0 * slDist
        val c2 = ahead.firstOrNull {
            val d = s * (it - entry)
            d >= 1.6 * slDist && d <= 3.0 * slDist
        }
        val tp2 = if (c2 != null) c2 - s * 0.1 * atrS else entry + s * 2.0 * slDist
        val d2 = s * (tp2 - entry)
        val c3 = ahead.firstOrNull {
            val d = s * (it - entry)
            d >= d2 + 0.8 * slDist && d <= 5.0 * slDist
        }
        var tp3 = if (c3 != null) c3 - s * 0.1 * atrS else entry + s * 3.0 * slDist
        if (s * (tp3 - entry) < d2 + 0.8 * slDist) tp3 = entry + s * (d2 + 0.8 * slDist)
        val rr2 = d2 / slDist
        val rr3 = s * (tp3 - entry) / slDist
        val rrWeighted = 0.4 * 1.0 + 0.3 * rr2 + 0.3 * rr3

        // ── الدرجة من 100 (تأكيدات فقط، بدون احتساب شروط البوابة) ──
        var score = 0
        score += when {
            c.s1d == null -> 5
            aligned(long, t1d) -> 15
            t1d == Trend.NEUTRAL -> 7
            else -> 0
        }
        score += when {
            aligned(long, t4h) -> 20
            t4h == Trend.NEUTRAL -> 8
            else -> 0
        }
        score += 10
        val slopeOk = if (long) setup.ema20 > setup.ema20Prev else setup.ema20 < setup.ema20Prev
        if (slopeOk) score += 5
        score += when {
            aligned(long, entrySnap.trend) -> 6
            entrySnap.trend == Trend.NEUTRAL -> 3
            else -> 0
        }
        val candleOk = if (long) lastE.close > lastE.open else lastE.close < lastE.open
        if (candleOk) score += 4
        score += when {
            rsiDir >= 50.0 && rsiDir <= 65.0 -> 10
            rsiDir >= 40.0 && rsiDir <= 70.0 -> 6
            else -> 2
        }
        score += when {
            entrySnap.rvol >= 1.5 -> 10
            entrySnap.rvol >= 1.2 -> 7
            entrySnap.rvol >= 1.0 -> 5
            entrySnap.rvol >= 0.8 -> 2
            else -> 0
        }
        val range = c.today.high - c.today.low
        val pos = if (range > 0.0) (c.price - c.today.low) / range else 0.5
        val todayDir = if (long) c.price > c.today.open else c.price < c.today.open
        val todayPos = if (long) pos >= 0.55 else pos <= 0.45
        if (todayDir) score += 5
        if (todayPos) score += 5
        val atrPct = atrS / c.price
        score += if (atrPct >= 0.004 && atrPct <= 0.03) 5 else 2
        score += if (ext <= 1.0) 5 else if (ext <= 1.8) 2 else 0

        if (score < MIN_SCORE) return no("الدرجة $score/100 أقل من $MIN_SCORE")

        // ── بناء البطاقة ──
        val status = if (ready) SignalStatus.READY else SignalStatus.PENDING
        val strength = when {
            score >= 80 -> SignalStrength.STRONG
            score >= 60 -> SignalStrength.MODERATE
            else -> SignalStrength.WEAK
        }
        val side = if (long) "فوق" else "تحت"
        val triggerText = if (ready) {
            "تحقق الاختراق: إغلاق شمعة $entryLabel $side " + Fmt.price(level) +
                " بحجم " + Fmt.num(entrySnap.rvol, 1) + "× من المتوسط"
        } else if (!broke) {
            "بانتظار إغلاق شمعة $entryLabel $side " + Fmt.price(level) + " بحجم لا يقل عن المتوسط"
        } else {
            "اخترق السعر " + Fmt.price(level) + " بحجم ضعيف: بانتظار إغلاق شمعة بحجم لا يقل عن المتوسط"
        }

        val w = 0.25 * atrS
        val zoneLow = if (long) entry - w else entry - 0.5 * w
        val zoneHigh = if (long) entry + 0.5 * w else entry + w

        val dayWord = if (c.price > c.today.open) "خضراء" else "حمراء"
        val reasoning = buildString {
            append(if (intraday) "نمط يومي (ساعات). " else "نمط سريع (دقائق إلى ساعة). ")
            append("الاتجاه على $setupLabel ${trendWord(setup.trend)}، ")
            append("و4 ساعات ${trendWord(t4h)}، واليومي ${trendWord(t1d)}.\n")
            append("شمعة اليوم $dayWord والسعر عند ${(pos * 100.0).toInt()}% من مدى اليوم.\n")
            append("RSI($setupLabel)=${Fmt.num(setup.rsi, 0)} • الحجم النسبي على $entryLabel=")
            append(Fmt.num(entrySnap.rvol, 1))
            append("× • التقلب ATR=${Fmt.pct(atrPct * 100.0)}.\n")
            append("الأهداف: TP1=1R، TP2=${Fmt.num(rr2, 1)}R، TP3=${Fmt.num(rr3, 1)}R ")
            append("(مرتبطة بأقرب دعم/مقاومة).")
        }

        val counter = if (long) {
            CounterScenario(
                triggerText = "إغلاق شمعة $entryLabel تحت " + Fmt.price(sl) + " (فشل السيناريو الصاعد)",
                direction = Direction.SHORT,
                entry = sl,
                stop = sl + slDist,
                target = sl - 1.5 * slDist,
                reasoning = "إذا كُسر الوقف بإغلاق مؤكد فقد ينقلب الاتجاه هبوطاً. فكّر في بيع " +
                    "بشرط تأكيد الإغلاق فقط، ولا تدخل قبل ذلك."
            )
        } else {
            CounterScenario(
                triggerText = "إغلاق شمعة $entryLabel فوق " + Fmt.price(sl) + " (فشل السيناريو الهابط)",
                direction = Direction.LONG,
                entry = sl,
                stop = sl - slDist,
                target = sl + 1.5 * slDist,
                reasoning = "إذا كُسر الوقف بإغلاق مؤكد فقد ينقلب الاتجاه صعوداً. فكّر في شراء " +
                    "بشرط تأكيد الإغلاق فقط، ولا تدخل قبل ذلك."
            )
        }

        val card = TradeCard(
            symbol = c.symbol,
            direction = if (long) Direction.LONG else Direction.SHORT,
            mode = mode,
            status = status,
            signalScore = score,
            signalStrength = strength,
            entryPrice = entry,
            entryZoneLow = zoneLow,
            entryZoneHigh = zoneHigh,
            stopLossPrice = sl,
            takeProfits = listOf(
                TakeProfit(1, tp1, 0.4),
                TakeProfit(2, tp2, 0.3),
                TakeProfit(3, tp3, 0.3)
            ),
            riskRewardRatio = rrWeighted,
            triggerPrice = level,
            triggerText = triggerText,
            tfTrends = c.trends,
            indicators = IndicatorSnapshot(
                setup.ema20, setup.ema50, setup.rsi, setup.atr, entrySnap.rvol, setup.close
            ),
            arabicReasoning = reasoning,
            counterScenario = counter
        )
        return Eval(card, "")
    }
}
