package com.abughaith.app.models

enum class Direction { LONG, SHORT }

/** SCALPING = تداول سريع (دقائق إلى ساعة) ، INTRADAY = تداول يومي (ساعات). */
enum class TradeMode { SCALPING, INTRADAY }

enum class TradeStatus { PENDING, OPEN, CLOSED_TP, CLOSED_SL, CLOSED_MANUAL }

enum class SignalStrength { WEAK, MODERATE, STRONG }

/** PENDING = إشارة مسبقة بانتظار شرط الدخول ، READY = شرط الدخول تحقق. */
enum class SignalStatus { PENDING, READY }

enum class Trend { UP, DOWN, NEUTRAL }

enum class CoachAction {
    HOLD,
    TAKE_PARTIAL_PROFIT,
    MOVE_SL_TO_BREAKEVEN,
    EXIT_EARLY,
    STOP_HIT,
    CLOSE_ALL
}
