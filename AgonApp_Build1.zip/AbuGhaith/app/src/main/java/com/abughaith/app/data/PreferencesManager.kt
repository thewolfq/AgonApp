package com.abughaith.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.abughaith.app.models.CircuitBreakerState
import com.abughaith.app.models.OpenTrade
import com.abughaith.app.models.RiskConfig
import com.abughaith.app.models.TradeHistoryEntry
import com.abughaith.app.models.TradeStatus
import com.abughaith.app.models.Direction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "abu_ghaith_prefs")

/**
 * كل الإعدادات والحالة الدائمة (رأس المال، الصفقات، السجل، قاطع التشغيل).
 */
class PreferencesManager(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    companion object {
        private val KEY_CAPITAL = doublePreferencesKey("capital_usdt")
        private val KEY_MAX_LOSS = doublePreferencesKey("max_loss_percent")
        private val KEY_MIN_SCORE = intPreferencesKey("min_score")
        private val KEY_MONITOR = booleanPreferencesKey("monitor_enabled")
        private val KEY_CONSECUTIVE_LOSSES = intPreferencesKey("consecutive_losses")
        private val KEY_LAST_LOSS_DATE = stringPreferencesKey("last_loss_date")
        private val KEY_CIRCUIT_ACTIVE = booleanPreferencesKey("circuit_active")
        private val KEY_COOLDOWN_UNTIL = longPreferencesKey("cooldown_until")
        private val KEY_OPEN_TRADES = stringPreferencesKey("open_trades_json")
        private val KEY_HISTORY = stringPreferencesKey("history_json")

        /** رسوم تقديرية: 0.05% دخول + 0.05% خروج من القيمة الاسمية. */
        private const val FEE_RATE = 0.001

        fun concurrentFor(capital: Double): Int = when {
            capital < 30.0 -> 1
            capital < 100.0 -> 2
            else -> 3
        }
    }

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private val data: Flow<Preferences> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }

    // ───────────── الإعدادات ─────────────

    val riskConfigFlow: Flow<RiskConfig> = data.map { p ->
        val capital = (p[KEY_CAPITAL] ?: 10.0).coerceIn(1.0, 100.0)
        RiskConfig(
            capitalUsdt = capital,
            maxLossPercent = (p[KEY_MAX_LOSS] ?: 10.0).coerceIn(3.0, 10.0),
            maxLeverage = 10,
            maxConcurrentTrades = concurrentFor(capital),
            circuitBreakerLosses = 2,
            cooldownMinutes = 30,
            minScore = (p[KEY_MIN_SCORE] ?: 60).coerceIn(60, 90)
        )
    }

    suspend fun setCapital(capital: Double) {
        context.dataStore.edit { it[KEY_CAPITAL] = Math.round(capital).toDouble().coerceIn(1.0, 100.0) }
    }

    suspend fun setMaxLossPercent(percent: Double) {
        context.dataStore.edit { it[KEY_MAX_LOSS] = Math.round(percent).toDouble().coerceIn(3.0, 10.0) }
    }

    suspend fun setMinScore(score: Int) {
        context.dataStore.edit { it[KEY_MIN_SCORE] = score.coerceIn(60, 90) }
    }

    val monitorEnabledFlow: Flow<Boolean> = data.map { it[KEY_MONITOR] ?: false }

    suspend fun setMonitorEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_MONITOR] = enabled }
    }

    // ───────────── قاطع التشغيل ─────────────

    val circuitBreakerFlow: Flow<CircuitBreakerState> = data.map { p ->
        CircuitBreakerState(
            isActive = p[KEY_CIRCUIT_ACTIVE] ?: false,
            consecutiveLosses = p[KEY_CONSECUTIVE_LOSSES] ?: 0,
            cooldownUntil = p[KEY_COOLDOWN_UNTIL]?.takeIf { it > 0L }
        )
    }

    /** يُسجَّل نتيجة صفقة: الخسارة تزيد العداد وتفعّل فترة هدوء 30 دقيقة، والربح يصفّر العداد. */
    suspend fun recordTradeResult(pnlUsdt: Double) {
        context.dataStore.edit { p ->
            if (pnlUsdt < 0.0) {
                val next = (p[KEY_CONSECUTIVE_LOSSES] ?: 0) + 1
                p[KEY_CONSECUTIVE_LOSSES] = next
                p[KEY_LAST_LOSS_DATE] = today()
                p[KEY_COOLDOWN_UNTIL] = System.currentTimeMillis() + 30L * 60L * 1000L
                if (next >= 2) p[KEY_CIRCUIT_ACTIVE] = true
            } else if (pnlUsdt > 0.0) {
                p[KEY_CONSECUTIVE_LOSSES] = 0
            }
        }
    }

    suspend fun resetDailyLossesIfNewDay() {
        context.dataStore.edit { p ->
            val stored = p[KEY_LAST_LOSS_DATE] ?: ""
            if (stored.isNotEmpty() && stored != today()) {
                p[KEY_CONSECUTIVE_LOSSES] = 0
                p[KEY_CIRCUIT_ACTIVE] = false
                p[KEY_COOLDOWN_UNTIL] = 0L
                p[KEY_LAST_LOSS_DATE] = ""
            }
        }
    }

    suspend fun resetCircuitBreaker() {
        context.dataStore.edit { p ->
            p[KEY_CIRCUIT_ACTIVE] = false
            p[KEY_CONSECUTIVE_LOSSES] = 0
            p[KEY_COOLDOWN_UNTIL] = 0L
        }
    }

    // ───────────── الصفقات المفتوحة ─────────────

    private fun decodeTrades(raw: String?): List<OpenTrade> =
        runCatching { json.decodeFromString<List<OpenTrade>>(raw ?: "[]") }.getOrElse { emptyList() }

    private fun decodeHistory(raw: String?): List<TradeHistoryEntry> =
        runCatching { json.decodeFromString<List<TradeHistoryEntry>>(raw ?: "[]") }.getOrElse { emptyList() }

    val openTradesFlow: Flow<List<OpenTrade>> = data.map { decodeTrades(it[KEY_OPEN_TRADES]) }

    val historyFlow: Flow<List<TradeHistoryEntry>> = data.map { decodeHistory(it[KEY_HISTORY]) }

    /** تعديل ذرّي لقائمة الصفقات المفتوحة (آمن مع التحديثات المتزامنة). */
    suspend fun updateOpenTrades(transform: (List<OpenTrade>) -> List<OpenTrade>) {
        context.dataStore.edit { p ->
            val current = decodeTrades(p[KEY_OPEN_TRADES])
            p[KEY_OPEN_TRADES] = json.encodeToString(transform(current))
        }
    }

    suspend fun addOpenTrade(trade: OpenTrade) {
        updateOpenTrades { it + trade }
    }

    /** يغلق الصفقة ويسجلها في السجل (صافي بعد رسوم تقديرية). يعيد السجل أو null. */
    suspend fun closeTrade(tradeId: String, exitPrice: Double): TradeHistoryEntry? {
        var result: TradeHistoryEntry? = null
        context.dataStore.edit { p ->
            val current = decodeTrades(p[KEY_OPEN_TRADES])
            val t = current.firstOrNull { it.id == tradeId }
            if (t != null) {
                val gross = if (t.direction == Direction.LONG) {
                    (exitPrice - t.entryPrice) * t.quantity
                } else {
                    (t.entryPrice - exitPrice) * t.quantity
                }
                val fees = t.quantity * t.entryPrice * FEE_RATE
                val net = gross - fees
                val base = if (t.marginUsdt > 0.0) t.marginUsdt else t.quantity * t.entryPrice
                val pct = if (base > 0.0) net / base * 100.0 else 0.0
                val status = when {
                    net > 0.0 -> TradeStatus.CLOSED_TP
                    net < 0.0 -> TradeStatus.CLOSED_SL
                    else -> TradeStatus.CLOSED_MANUAL
                }
                val entry = TradeHistoryEntry(
                    symbol = t.symbol,
                    direction = t.direction,
                    entryPrice = t.entryPrice,
                    exitPrice = exitPrice,
                    pnlUsdt = net,
                    pnlPercent = pct,
                    status = status,
                    mode = t.mode,
                    openedAt = t.openedAt,
                    closedAt = System.currentTimeMillis()
                )
                p[KEY_OPEN_TRADES] = json.encodeToString(current.filterNot { it.id == tradeId })
                val history = decodeHistory(p[KEY_HISTORY])
                p[KEY_HISTORY] = json.encodeToString((history + entry).takeLast(200))
                result = entry
            }
        }
        return result
    }

    suspend fun clearHistory() {
        context.dataStore.edit { it[KEY_HISTORY] = "[]" }
    }
}
