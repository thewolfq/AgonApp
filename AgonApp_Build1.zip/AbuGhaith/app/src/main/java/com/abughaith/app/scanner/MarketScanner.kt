package com.abughaith.app.scanner

import com.abughaith.app.models.ScannedPair
import com.abughaith.app.net.ApiException
import com.abughaith.app.net.BinanceApi
import org.json.JSONArray

/**
 * ماسح السوق — يجلب كل عقود USDT-M Futures ويُبقي فقط ما يتجاوز حجمه اليومي 2M USDT.
 */
class MarketScanner(private val api: BinanceApi) {

    companion object {
        private const val MIN_QUOTE_VOLUME = 2_000_000.0
        private const val URL = BinanceApi.BASE + "/fapi/v1/ticker/24hr"
        private val EXCLUDED_PREFIXES = listOf("USDC", "BUSD", "TUSD", "FDUSD", "USDP", "EUR", "DAI")
    }

    suspend fun scan(): Result<List<ScannedPair>> {
        val body = api.getJson(URL).getOrElse { return Result.failure<List<ScannedPair>>(it) }
        return try {
            Result.success<List<ScannedPair>>(parse(body))
        } catch (e: Exception) {
            Result.failure<List<ScannedPair>>(ApiException("تعذّر قراءة بيانات السوق"))
        }
    }

    private fun parse(body: String): List<ScannedPair> {
        val arr = JSONArray(body)
        val now = System.currentTimeMillis()
        val result = ArrayList<ScannedPair>()
        for (i in 0 until arr.length()) {
            try {
                val obj = arr.getJSONObject(i)
                val symbol = obj.optString("symbol", "")
                if (!symbol.endsWith("USDT") || symbol.contains("_")) continue
                if (EXCLUDED_PREFIXES.any { symbol.startsWith(it) }) continue
                val volume = obj.optString("quoteVolume", "0").toDoubleOrNull() ?: 0.0
                if (volume < MIN_QUOTE_VOLUME) continue
                val price = obj.optString("lastPrice", "0").toDoubleOrNull() ?: 0.0
                if (price <= 0.0) continue
                result.add(
                    ScannedPair(
                        symbol = symbol,
                        lastPrice = price,
                        priceChangePercent = obj.optString("priceChangePercent", "0").toDoubleOrNull() ?: 0.0,
                        quoteVolume = volume,
                        highPrice = obj.optString("highPrice", "0").toDoubleOrNull() ?: 0.0,
                        lowPrice = obj.optString("lowPrice", "0").toDoubleOrNull() ?: 0.0,
                        lastUpdated = now
                    )
                )
            } catch (_: Exception) {
                // تجاهل العنصر التالف
            }
        }
        result.sortByDescending { it.quoteVolume }
        return result
    }
}
