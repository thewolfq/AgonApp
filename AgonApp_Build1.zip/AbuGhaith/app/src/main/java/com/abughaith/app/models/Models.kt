package com.abughaith.app.models

import kotlinx.serialization.Serializable
import java.util.UUID

data class Candle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val closeTime: Long
)

data class ScannedPair(
    val symbol: String,
    val lastPrice: Double,
    val priceChangePercent: Double,
    val quoteVolume: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val lastUpdated: Long
) {
    val rangePercent: Double
        get() = if (lowPrice > 0.0) (highPrice - lowPrice) / lowPrice * 100.0 else 0.0

    val baseAsset: String
        get() = symbol.removeSuffix("USDT")
}

data class TfTrend(val label: String, val trend: Trend)

data class IndicatorSnapshot(
    val ema20: Double,
    val ema50: Double,
    val rsi14: Double,
    val atr14: Double,
    val rvol: Double,
    val closePrice: Double
)

@Serializable
data class TakeProfit(
    val level: Int,
    val price: Double,
    val percentToClose: Double
)

/** الجناحان: السيناريو المعاكس إذا فشلت الصفقة الأساسية. */
data class CounterScenario(
    val triggerText: String,
    val direction: Direction,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val reasoning: String
)

/** خطة الحارس: الرافعة والهامش وحجم الصفقة. */
data class RiskPlan(
    val marginUsdt: Double,
    val leverage: Int,
    val notionalUsdt: Double,
    val quantity: Double,
    val maxLossUsdt: Double,
    val lossAtStopPercent: Double,
    val guardianText: String
)

data class TradeCard(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val direction: Direction,
    val mode: TradeMode,
    val status: SignalStatus,
    val signalScore: Int,
    val signalStrength: SignalStrength,
    val entryPrice: Double,
    val entryZoneLow: Double,
    val entryZoneHigh: Double,
    val stopLossPrice: Double,
    val takeProfits: List<TakeProfit>,
    val riskRewardRatio: Double,
    val triggerPrice: Double,
    val triggerText: String,
    val tfTrends: List<TfTrend>,
    val indicators: IndicatorSnapshot,
    val arabicReasoning: String,
    val counterScenario: CounterScenario,
    val createdAt: Long = System.currentTimeMillis(),
    val plan: RiskPlan? = null,
    val riskError: String? = null
)

sealed class AnalysisOutcome {
    data class Found(val card: TradeCard) : AnalysisOutcome()
    data class NoSetup(val reason: String, val tfTrends: List<TfTrend>) : AnalysisOutcome()
}

/** نتيجة تحليل يدوي لزوج (للواجهة). */
data class ManualResult(val outcome: AnalysisOutcome?, val error: String?)

@Serializable
data class OpenTrade(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val direction: Direction,
    val mode: TradeMode = TradeMode.INTRADAY,
    val entryPrice: Double,
    val currentPrice: Double,
    val quantity: Double,
    val leverage: Int = 1,
    val marginUsdt: Double = 0.0,
    val stopLoss: Double,
    val initialStopLoss: Double = 0.0,
    val takeProfits: List<TakeProfit>,
    val status: TradeStatus = TradeStatus.OPEN,
    val openedAt: Long = System.currentTimeMillis(),
    val healthIndex: Int = 50,
    val lastCoachAction: CoachAction = CoachAction.HOLD,
    val lastCoachMessage: String = ""
)

@Serializable
data class TradeHistoryEntry(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val direction: Direction,
    val entryPrice: Double,
    val exitPrice: Double,
    val pnlUsdt: Double,
    val pnlPercent: Double,
    val status: TradeStatus,
    val mode: TradeMode,
    val openedAt: Long,
    val closedAt: Long
)

data class RiskConfig(
    val capitalUsdt: Double = 10.0,
    val maxLossPercent: Double = 10.0,
    val maxLeverage: Int = 10,
    val maxConcurrentTrades: Int = 1,
    val circuitBreakerLosses: Int = 2,
    val cooldownMinutes: Int = 30,
    val minScore: Int = 60
)

data class CircuitBreakerState(
    val isActive: Boolean = false,
    val consecutiveLosses: Int = 0,
    val cooldownUntil: Long? = null
)

data class ScannerState(
    val pairs: List<ScannedPair> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val lastFetchTime: Long = 0L
)

data class HubState(
    val signals: List<TradeCard> = emptyList(),
    val isScanning: Boolean = false,
    val lastScan: Long = 0L,
    val scannedCount: Int = 0,
    val error: String? = null,
    val riskBlock: String? = null
)

fun TradeCard.toOpenTrade(): OpenTrade {
    val p = plan
    return OpenTrade(
        symbol = symbol,
        direction = direction,
        mode = mode,
        entryPrice = entryPrice,
        currentPrice = entryPrice,
        quantity = p?.quantity ?: 0.0,
        leverage = p?.leverage ?: 1,
        marginUsdt = p?.marginUsdt ?: 0.0,
        stopLoss = stopLossPrice,
        initialStopLoss = stopLossPrice,
        takeProfits = takeProfits
    )
}
