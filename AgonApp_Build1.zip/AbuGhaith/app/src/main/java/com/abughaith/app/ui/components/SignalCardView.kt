package com.abughaith.app.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abughaith.app.models.Direction
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.TradeCard
import com.abughaith.app.models.TradeMode
import com.abughaith.app.ui.theme.CardBackground
import com.abughaith.app.ui.theme.CoralRed
import com.abughaith.app.ui.theme.DarkNavy
import com.abughaith.app.ui.theme.DarkNavyLight
import com.abughaith.app.ui.theme.EmeraldGreen
import com.abughaith.app.ui.theme.SuccessGreen
import com.abughaith.app.ui.theme.TextSecondary
import com.abughaith.app.ui.theme.WarningOrange
import com.abughaith.app.util.Fmt
import kotlin.math.abs

/** بطاقة الإشارة: مفعّلة أو قيد الانتظار، مع الأهداف والوقف والخطة البديلة وتعليمات الحارس. */
@Composable
fun SignalCardView(
    card: TradeCard,
    onOpenTrade: (() -> Unit)? = null,
    onDismiss: (() -> Unit)? = null
) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var expanded by remember(card.id) { mutableStateOf(false) }

    val long = card.direction == Direction.LONG
    val dirColor = if (long) EmeraldGreen else CoralRed
    val ready = card.status == SignalStatus.READY
    val scoreColor = when {
        card.signalScore >= 80 -> EmeraldGreen
        card.signalScore >= 70 -> SuccessGreen
        else -> WarningOrange
    }
    val slPct = if (card.entryPrice > 0.0) abs(card.entryPrice - card.stopLossPrice) / card.entryPrice * 100.0 else 0.0
    val plan = card.plan

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(card.symbol, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Pill(if (long) "شراء ▲" else "بيع ▼", dirColor)
                Pill(if (card.mode == TradeMode.SCALPING) "سريع" else "يومي", WarningOrange)
                Spacer(Modifier.weight(1f))
                Text(
                    card.signalScore.toString() + "/100",
                    color = scoreColor,
                    fontWeight = FontWeight.Bold
                )
            }

            if (ready) {
                StatusStrip(
                    "✅ مفعّلة — " + Fmt.ago(System.currentTimeMillis() - card.createdAt) + "\n" + card.triggerText,
                    EmeraldGreen
                )
            } else {
                StatusStrip("⏳ " + card.triggerText + "\nسيصلك إشعار فور تفعيل الشرط.", WarningOrange)
            }

            InfoRow("منطقة الدخول", Fmt.price(card.entryZoneLow) + " – " + Fmt.price(card.entryZoneHigh))
            InfoRow("وقف الخسارة", Fmt.price(card.stopLossPrice) + "  (" + Fmt.pct(slPct) + ")", CoralRed)
            card.takeProfits.forEach { tp ->
                InfoRow(
                    "الهدف " + tp.level,
                    Fmt.price(tp.price) + "  (" + (tp.percentToClose * 100.0).toInt() + "%)",
                    EmeraldGreen
                )
            }
            InfoRow("العائد/المخاطرة (مرجّح)", "1 : " + Fmt.num(card.riskRewardRatio, 1))

            TrendChips(card.tfTrends)

            if (plan != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkNavyLight, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        "الرافعة " + plan.leverage + "x • الهامش " + Fmt.usd(plan.marginUsdt) +
                            "\$ • القيمة " + Fmt.usd(plan.notionalUsdt) +
                            "\$ • أقصى خسارة " + Fmt.usd(plan.maxLossUsdt) + "\$",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
            val err = card.riskError
            if (err != null) {
                StatusStrip("⚠️ غير قابلة للتنفيذ برأس مالك الحالي: " + err, WarningOrange)
            }

            TextButton(onClick = { expanded = !expanded }) {
                Text(if (expanded) "إخفاء التفاصيل ▲" else "التفاصيل والخطة البديلة ▼", color = EmeraldGreen)
            }

            if (expanded) {
                Text("تبرير المدرب", style = MaterialTheme.typography.titleMedium, color = EmeraldGreen)
                Text(card.arabicReasoning, style = MaterialTheme.typography.bodyMedium)

                val cs = card.counterScenario
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkNavy, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الصفقة المعاكسة / الخطة ب", color = WarningOrange, fontWeight = FontWeight.Bold)
                        Text("الشرط: " + cs.triggerText, style = MaterialTheme.typography.bodySmall)
                        Text(
                            (if (cs.direction == Direction.LONG) "شراء" else "بيع") +
                                " عند " + Fmt.price(cs.entry) +
                                " • وقف " + Fmt.price(cs.stop) +
                                " • هدف " + Fmt.price(cs.target),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(cs.reasoning, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }

                if (plan != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkNavy, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(plan.guardianText, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        clipboard.setText(AnnotatedString(buildCopyText(card)))
                        Toast.makeText(context, "تم نسخ المعطيات", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = DarkNavy)
                ) {
                    Text("نسخ للتنفيذ اليدوي")
                }
                if (onOpenTrade != null && ready && plan != null) {
                    OutlinedButton(onClick = onOpenTrade) { Text("فتحت الصفقة") }
                }
                if (onDismiss != null) {
                    TextButton(onClick = onDismiss) { Text("إخفاء", color = TextSecondary) }
                }
            }
        }
    }
}
