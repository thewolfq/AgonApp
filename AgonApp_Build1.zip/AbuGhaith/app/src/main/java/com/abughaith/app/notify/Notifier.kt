package com.abughaith.app.notify

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.abughaith.app.R
import com.abughaith.app.coach.MatchCoach
import com.abughaith.app.models.CoachAction
import com.abughaith.app.models.Direction
import com.abughaith.app.models.OpenTrade
import com.abughaith.app.models.TradeCard
import com.abughaith.app.ui.MainActivity
import com.abughaith.app.util.Fmt

/** كل إشعارات التطبيق: الإشارات المفعّلة، تنبيهات المدرب، وإشعار خدمة المراقبة. */
object Notifier {

    const val CH_SIGNALS = "abu_ghaith_signals"
    const val CH_COACH = "abu_ghaith_coach"
    const val CH_MONITOR = "abu_ghaith_monitor"
    const val ID_MONITOR = 1001

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val signals = NotificationChannel(CH_SIGNALS, "الإشارات المفعّلة", NotificationManager.IMPORTANCE_HIGH)
        signals.description = "تنبيه فوري عند تحقق شرط دخول إشارة"
        signals.enableVibration(true)
        val coach = NotificationChannel(CH_COACH, "تنبيهات المدرب", NotificationManager.IMPORTANCE_HIGH)
        coach.description = "توصيات المدرب للصفقات المفتوحة"
        coach.enableVibration(true)
        val monitor = NotificationChannel(CH_MONITOR, "المراقبة في الخلفية", NotificationManager.IMPORTANCE_LOW)
        monitor.description = "يظهر أثناء مراقبة السوق في الخلفية"
        nm.createNotificationChannel(signals)
        nm.createNotificationChannel(coach)
        nm.createNotificationChannel(monitor)
    }

    private fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun openAppIntent(ctx: Context): PendingIntent {
        val intent = Intent(ctx, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        return PendingIntent.getActivity(
            ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun post(ctx: Context, id: Int, n: Notification) {
        if (!canNotify(ctx)) return
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            nm.notify(id, n)
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    fun signalReady(ctx: Context, card: TradeCard) {
        createChannels(ctx)
        val long = card.direction == Direction.LONG
        val title = (if (long) "🟢 شراء مفعّلة — " else "🔴 بيع مفعّلة — ") + card.symbol
        val sb = StringBuilder()
        sb.append("دخول ").append(Fmt.price(card.entryPrice))
        sb.append(" • وقف ").append(Fmt.price(card.stopLossPrice)).append("\n")
        card.takeProfits.forEach { sb.append("TP").append(card.takeProfits.indexOf(it) + 1).append(": ").append(Fmt.price(it.price)).append("  ") }
        sb.append("\n")
        val p = card.plan
        if (p != null) {
            sb.append("الرافعة ").append(p.leverage).append("x • الهامش ").append(Fmt.usd(p.marginUsdt)).append("$")
            sb.append(" • الدرجة ").append(card.signalScore).append("/100")
        }
        val text = sb.toString().trim()
        val n = NotificationCompat.Builder(ctx, CH_SIGNALS)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(text.lineSequence().firstOrNull() ?: text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        post(ctx, card.symbol.hashCode(), n)
    }

    fun coach(ctx: Context, trade: OpenTrade, ev: MatchCoach.CoachEvaluation) {
        createChannels(ctx)
        val title = when (ev.action) {
            CoachAction.STOP_HIT -> "🛑 وصل الوقف — "
            CoachAction.CLOSE_ALL -> "🏁 الهدف الأخير — "
            CoachAction.TAKE_PARTIAL_PROFIT -> "💰 جني أرباح — "
            CoachAction.MOVE_SL_TO_BREAKEVEN -> "🛡️ أمّن الصفقة — "
            CoachAction.EXIT_EARLY -> "⚠️ خروج مبكر — "
            CoachAction.HOLD -> "ℹ️ المدرب — "
        } + trade.symbol
        val n = NotificationCompat.Builder(ctx, CH_COACH)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(ev.arabicMessage)
            .setStyle(NotificationCompat.BigTextStyle().bigText(ev.arabicMessage))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        post(ctx, (trade.id + ev.action.name).hashCode(), n)
    }

    fun monitorNotification(ctx: Context): Notification {
        createChannels(ctx)
        return NotificationCompat.Builder(ctx, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle("أبو غيث يراقب السوق")
            .setContentText("سيصلك تنبيه عند تفعيل أي إشارة")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent(ctx))
            .build()
    }

    fun test(ctx: Context) {
        createChannels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_SIGNALS)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle("✅ اختبار الإشعارات")
            .setContentText("إذا ظهر هذا التنبيه فالإشعارات تعمل بشكل صحيح")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        post(ctx, 9999, n)
    }
}
