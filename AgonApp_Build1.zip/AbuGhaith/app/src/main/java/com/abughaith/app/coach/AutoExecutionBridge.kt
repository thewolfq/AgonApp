package com.abughaith.app.coach

/**
 * واجهة التنفيذ الآلي — معطّلة حالياً (مرحلة التدريب اليدوي).
 * مستقبلاً: ربط عبر Binance API Key & Secret مع حظر صلاحية السحب.
 */
interface AutoExecutionBridge {
    val isEnabled: Boolean
    val bridgeName: String
    suspend fun placeOrder(symbol: String, side: String, type: String, quantity: Double, price: Double?): Result<String>
    suspend fun cancelOrder(symbol: String, orderId: String): Result<Unit>
    suspend fun getBalance(): Result<Double>
}

object DisabledAutoExecutionBridge : AutoExecutionBridge {
    override val isEnabled: Boolean = false
    override val bridgeName: String = "معطّل (وضع التدريب اليدوي)"

    override suspend fun placeOrder(
        symbol: String,
        side: String,
        type: String,
        quantity: Double,
        price: Double?
    ): Result<String> =
        Result.failure(UnsupportedOperationException("الربط الآلي غير مفعّل"))

    override suspend fun cancelOrder(symbol: String, orderId: String): Result<Unit> =
        Result.failure(UnsupportedOperationException("الربط الآلي غير مفعّل"))

    override suspend fun getBalance(): Result<Double> =
        Result.failure(UnsupportedOperationException("الربط الآلي غير مفعّل"))
}
