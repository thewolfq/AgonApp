package com.abughaith.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.abughaith.app.AbuGhaithApp
import com.abughaith.app.notify.Notifier

/**
 * خدمة مقدمة تُبقي المراقبة تعمل والشاشة مغلقة، لتصلك إشعارات الإشارات في أي وقت.
 */
class MonitorService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = Notifier.monitorNotification(this)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(Notifier.ID_MONITOR, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(Notifier.ID_MONITOR, notification)
        }
        acquireWakeLock()
        (application as AbuGhaithApp).hub.setBackground(true)
        return START_STICKY
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AbuGhaith::Monitor")
            wl.setReferenceCounted(false)
            wl.acquire(12L * 60L * 60L * 1000L)
            wakeLock = wl
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
        (application as AbuGhaithApp).hub.setBackground(false)
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, MonitorService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
