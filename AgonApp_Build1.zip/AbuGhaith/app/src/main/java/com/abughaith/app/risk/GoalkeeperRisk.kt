package com.abughaith.app.risk

import com.abughaith.app.data.PreferencesManager
import com.abughaith.app.models.Direction
import com.abughaith.app.models.RiskConfig
import com.abughaith.app.models.RiskPlan
import com.abughaith.app.models.SignalStatus
import com.abughaith.app.models.TradeCard
import com.abughaith.app.util.Fmt
import kotlinx.coroutines.flow.first
import kotlin.math.abs
import kotlin.math.floor

/**
 * الحارس — يطبّق قواعد المخاطر:
 *  1) أقصى خسارة عند الوقف = maxLossPercent (10% افتراضياً) من مبلغ الدخول (الهامش).
 *  2) الرافعة تُشتق من مسافة الوقف: الرافعة = أقصى خسارة ÷ مسافة الوقف، بحد أقصى 10x.
 *  3) قاطع التشغيل: خسارتان متتاليتان في اليوم يوقفان الإشارات الجديدة، وهدوء 30 دقيقة بعد أي خسارة.
 */
class GoalkeeperRisk(private val prefs: PreferencesManager) {

    companion object {
        const val MIN_NOTIONAL = 5.0
    }

    /** يعيد سبب المنع (نص عربي) أو null إذا كان مسموحاً بإصدار إشارات جديدة. */
    suspend fun gate(openTradesCount: Int): String? {
        prefs.resetDailyLossesIfNewDay()
        val circuit = prefs.circuitBreakerFlow.first()
        if (circuit.isActive) {
            return "قاطع التشغيل مفعّل: خسارتان متتاليتان اليوم. لا إشارات دخول جديدة حتى الغد."
        }
        val cooldown = circuit.cooldownUntil
        val now = System.currentTimeMillis()
        if (cooldown != null && now < cooldown) {
            val minutes = ((cooldown - now) / 60000L).toInt() + 1
            return "فترة هدوء بعد صفقة خاسرة: انتظر $minutes دقيقة."
        }
        val cfg = prefs.riskConfigFlow.first()
        if (openTradesCount >= cfg.maxConcurrentTrades) {
            return "بلغت الحد الأقصى للصفقات المتزامنة (${cfg.maxConcurrentTrades})."
        }
        return null
    }

    suspend fun recordTradeResult(pnlUsdt: Double) {
        prefs.recordTradeResult(pnlUsdt)
    }

    /** يحسب الهامش والرافعة والكمية ويعيد البطاقة مع الخطة (أو مع riskError إذا تعذّر التنفيذ). */
    fun plan(card: TradeCard, cfg: RiskConfig): TradeCard {
        val entry = card.entryPrice
        if (entry <= 0.0) return card.copy(riskError = "سعر الدخول غير صالح")
        val slPct = abs(entry - card.stopLossPrice) / entry
        if (slPct <= 0.0) return card.copy(riskError = "وقف الخسارة غير صالح")

        val maxLoss = cfg.maxLossPercent / 100.0
        val leverage = floor(maxLoss / slPct).toInt().coerceIn(1, cfg.maxLeverage)
        val lossFraction = leverage * slPct
        if (lossFraction > maxLoss + 1e-9) {
            return card.copy(
                riskError = "الوقف بعيد (" + Fmt.pct(slPct * 100.0) + "): حتى برافعة 1x تتجاوز الخسارة " +
                    Fmt.num(cfg.maxLossPercent, 0) + "% من مبلغ الدخول."
            )
        }

        val margin = cfg.capitalUsdt / cfg.maxConcurrentTrades
        val notional = margin * leverage
        if (notional < MIN_NOTIONAL) {
            return card.copy(
                riskError = "القيمة الاسمية المتاحة " + Fmt.usd(notional) +
                    "$ أقل من الحد الأدنى (5$). ارفع رأس المال أو انتظر إشارة بوقف أضيق."
            )
        }

        val quantity = notional / entry
        val maxLossUsdt = notional * slPct
        val long = card.direction == Direction.LONG
        val s = if (long) 1.0 else -1.0

        val sb = StringBuilder()
        sb.appendLine("تعليمات الحارس (نفّذها على Binance Futures):")
        sb.appendLine("• نوع الهامش: Isolated (معزول)، والرافعة: ${leverage}x")
        sb.appendLine(
            "• الهامش: " + Fmt.usd(margin) + "$ • القيمة الاسمية: " + Fmt.usd(notional) +
                "$ • الكمية ≈ " + Fmt.num(quantity, 4)
        )
        if (card.status == SignalStatus.READY) {
            sb.appendLine("• الدخول: داخل المنطقة " + Fmt.price(card.entryZoneLow) + " – " + Fmt.price(card.entryZoneHigh))
        } else {
            sb.appendLine("• لا تدخل الآن. الدخول فقط بعد تحقق الشرط: " + card.triggerText)
        }
        sb.appendLine(
            "• وقف الخسارة Stop-Limit: تفعيل " + Fmt.price(card.stopLossPrice) +
                " • تنفيذ " + Fmt.price(card.stopLossPrice * (1.0 - s * 0.001))
        )
        sb.appendLine(
            "• وقف نهائي Stop-Market (شبكة أمان): " + Fmt.price(card.stopLossPrice * (1.0 - s * 0.003))
        )
        sb.appendLine("• فعّل خيار Reduce-Only للأوامر الواقية.")
        card.takeProfits.forEach { tp ->
            sb.appendLine("• TP${tp.level}: " + Fmt.price(tp.price) + " (إغلاق " + (tp.percentToClose * 100.0).toInt() + "%)")
        }
        sb.appendLine("• بعد تحقق TP1: انقل الوقف إلى سعر الدخول.")
        sb.appendLine(
            "• أقصى خسارة عند الوقف ≈ " + Fmt.usd(maxLossUsdt) + "$ (" +
                Fmt.num(lossFraction * 100.0, 1) + "% من الهامش) قبل الرسوم."
        )
        sb.append("• تنبيه: تحقق من الحد الأدنى للصفقة للزوج في Binance (قد يكون أعلى من 5$ لبعض الأزواج).")

        return card.copy(
            plan = RiskPlan(
                marginUsdt = margin,
                leverage = leverage,
                notionalUsdt = notional,
                quantity = quantity,
                maxLossUsdt = maxLossUsdt,
                lossAtStopPercent = lossFraction * 100.0,
                guardianText = sb.toString()
            ),
            riskError = null
        )
    }
}
