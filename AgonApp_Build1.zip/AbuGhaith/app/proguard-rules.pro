# Abu Ghaith ProGuard Rules
-keep class com.abughaith.app.models.** { *; }
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.abughaith.app.**$$serializer { *; }
-keepclassmembers class com.abughaith.app.** { *** Companion; }
-keepclasseswithmembers class com.abughaith.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
